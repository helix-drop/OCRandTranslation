## LEÇON DU 14 MARS 1979

[待翻译]

### Il faudrait

### NOTES

> 9. Jean-Luc Migué était alors professeur à l'École nationale d'administration publique du Québec.
> 10. « Méthodologie économique et Économie non marchande », communication au congrès des Économistes de langue française (Québec, mai 1976), reproduite en partie dans la Revue d'économie politique, juillet-août 1977 (cf. H. Lepage, Demain le capitalisme, op. cit., p. 224).
> 11. J.-L. Migué, ibid., cité par H. Lepage, op.cit., p. 346 : « L'une des grandes contributions récentes de l'analyse économique a été d'appliquer intégralement au secteur domestique le cadre analytique traditionnellement réservé à la firme et au consommateur. En faisant du ménage une unité de production au même titre que la firme classique, on découvre que ses fondements analytiques sont en fait identiques à ceux de la firme. Comme dans la firme, les deux parties en ménage évident grâce à un contrat qui les lie pour de longues périodes les coûts de transaction et le risque d'être privées à tout moment des inputs du conjoint et, partant, de l'output commun du ménage. Qu'est-ce en effet que le ménage sinon l'engagement contractuel des deux parties à fournir des inputs spécifiques et à partager dans des proportions données les bénéfices de l'output du ménage ? Ainsi donc, plutôt que de s'engager dans un processus coûteux
> 25. Cette phrase ne se trouve pas dans l'article de G. Becker. M. Foucault s'appuie sur la synthèse des travaux de G. Becker et G.J. Stigler présentée par F. Jenny, « La théorie économique du crime… », in op. cit., p. 298 : « Rejetant, ici comme dans les autres domaines de la théorie économique, tout jugement moral, l'économiste distingue les activités criminelles des activités légitimes sur la seule base du type de risque encouru. Les activités criminelles sont celles qui font courir à l'individu qui s'y livre un type de risque particulier : celui d'être appréhendé et condamné à une peine (amende, emprisonnement, exécution). »
> 66. août 1958, p. 281-302), que Th. Schultz qualifie de « pioneering paper » (Investment in Human Capital, op. cit., p. 46 n.
