## Situation du cours

[待翻译]
