## LEÇON DU 10 JANVIER 1979

[待翻译]

### NOTES

> 7. Cf. ibid., leçon du l $ ^{er} $ février 1978, p. 112 et 118 n.
