## LEÇON DU 31 JANVIER 1979

[待翻译]

### NOTES

> 4. Cf. Sécurité, Territoire, Population, leçon du 1er février 1978, p. 105.
> 14. Programme de reconstruction européenne (European Recovery Program) proposé en 1947 par le secrétaire d'État américain G. Marshall, adopté en 1948 par 16 pays d'Europe de l'Ouest. 15. Le Conseil national de la Résistance (CNR) avait été constitué au printemps 1943 pour unifier les divers mouvements de Résistance, politiquement divisés. Il fut présidé par Jean Moulin, puis par Georges Bidault. « Tous, lors de leur réunion plémière du 15 mars 1944, tombèrent d'accord pour rester unis après la Libération. La Charte de la Résistance, qui résulta de ces délibérations, discutée et approuvée par les divers groupements qui composaient le CNR, contenait un programme social et économique hardi. Entre autres réformes, elle réclamait “un plan complet de sécurité sociale, visant à assurer à tous les citoyens des moyens d'existence, dans les cas où ils sont incapables de se les procurer par le travail avec gestion appartenant aux représentants des intéressés et de l'État” » (H.G. Galant, Histoire politique de la sécurité sociale française, 1945-1952, Paris, Librairie A. Colin, « Cahiers de la Fondation nationale des sciences politiques », 1955, p. 24). Cf. infra, leçon du 7 mars 1979, p. 216-217, note 25 sur le plan français de sécurité sociale en 1945.
