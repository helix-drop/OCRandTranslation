## LEÇON DU 14 FÉVRIER 1979

[待翻译]

### NOTES

> 2. 2, 3° section, § 3 (« Les analogies de l'expérience »), trad. A. Trémesaygues & B. Pacaud, 6° éd. Paris, PUF, 1968, p. 176.
