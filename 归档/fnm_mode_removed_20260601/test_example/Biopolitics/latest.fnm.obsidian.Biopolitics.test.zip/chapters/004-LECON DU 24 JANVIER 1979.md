## LECON DU 24 JANVIER 1979

[待翻译]

### NOTES

> 1. Cf. Sécurité, Territoire, Population, op. cit., leçon du 22 mars 1978, p. 295 sq.
> 30. Cf. infra, leçons des 31 janvier, 7 février, 14 février et 21 février 1979.
