## Introduction

[待翻译]

### NOTES

> 78. Mary Pickering, Auguste Comte: An Intellectual Biography, vol. 1 (Cambridge: Cambridge University Press, 1993), pp. 303–5, 349, 420, 600–604.
> 113. Luchet, "Un mot," p. 43.
> 114. Vacherot to Cousin, 4 April 1836, Cousin MSS, vol. 251, #5041.
> 114. Broussais, Communication sur Raucourt, pp. 3, 5–6, 12, 14–16, my italics.
> 115. For Raucourt's comments, see L'Educateur 1 (January–February 1836): 2; and 2 (May–June 1837): 65 and 69 n. 13.
> 116. See Jacques Rancière, Le Maître ignorant: Cinq leçons sur l'émancipation intellectuelle (Paris: Fayard, 1987); and Jean-François Garcia, Jacotot (Paris: Presses universitaires de France, 1997).
> 117. “Philosophie panécastique: éducation des abonnés,” Journal de l’émancipation intellectuelle 2 (1830): 441–48, esp. 448.
> 118. Ibid., p. 441. Jacotot seems not to know that Cousin, a bachelor, had raised no children.
> 119. “Variétés,” Journal de l’émancipation intellectuelle 2 (1830), p. 477.
> 120. See H. V. Jacotot, “3e lettre au dr. Broussais,” Journal de l’émancipation intellectuelle 3 (1835): 17–32, esp. 20–21, 31. The first two letters are absent from the Bibliothèque Nationale’s incomplete collection of this journal.
> 121. A. Guépin, Résumé de la méthode de Jacotot, par M. [Emile] Souvestre, 2d ed. (Nantes: Mellinet-Malassis, n.d.), p. 10.
> 131. Comte, Cours de philosophie positive, ed. Michel Serres et al., Lesson 45, esp. p. 858.
> 139. Spurzheim to Combe, 10 June 1819, NLS, Combe MSS 7204, fols. 106–7.
> 140. Spurzheim to Combe, August 1818, NLS, Combe MSS 7203, fols. 111–12. On the claim to fame of the individual Spurzheim identifies only as “the shoemaker Spence,” see Arthur W. J. G. Ord-Hume, Perpetual Motion: The History of an Obsession (London: Allen and Unwin, 1977), pp. 85–86; Spence’s invention was written up in the Annales de chimie in 1818.
> 141. Spurzheim to Combe, 7 November 1818, NLS, Combe MSS 7203, fols. 115–16.
> 142. Spurzheim to Combe, 12 August 1820, NLS, Combe MSS 7205, fols. 160–61.
> 143. Franck's election took place in 1844. On his academic career and his involvement in Jewish community affairs, see A la mémoire d'Adolphe Franck: Discours et articles (Paris: Impr. J. Montorier, 1893), and Perrine Simon-Nahum, La cité investie: La science du judaïsme français et la République (Paris: Cerf, 1991), pp. 73–78.
> 143. Spurzheim to Combe, February 1824, NLS, Combe MSS 7214, fols. 50–52.
> 144. See Pauline Franck, Une vie de femme: Lettres intimes (Tours: Impr. Paul Bousrez, 1898). The collection was edited by Pauline's daughter, Marguerite, who decided not to include her father's letters because he was already well known through his public writings; see Preface, pp. 7–8. My thanks to Aron Rodrigue for alerting me to this source.
> 144. Spurzheim to Combe, London, March 1825, Combe MSS 7216, fols. 74–75.
> 145. On this point, see Danièle Poublan, “Les lettres font-elles les sentiments? S’écrire avant le mariage au milieu du XIXe siècle,” in Séduction et sociétés: Approches historiques, ed. Cécile Dauphin and Arlette Farge, (Paris: Seuil, 2001), pp. 141–82.
> 145. Spurzheim to Combe, 21 August 1822, NLS, Combe MSS 7209, fols. 107–8.
> 146. P. Franck to A. Franck, 23 April 1833, in Vie de femme, p. 41.
> 146. David seems to have adopted a dualist version of phrenology. As he wrote in 1839 about listening to the music of Cherubini at a funeral mass and then catching sight of the heads of the singers: “One is pained to see such sublime sounds come out of such a ridiculous machine. That’s what proves that mind (âme) is independent of matter. . . .” Les Carnets de David d’Angers, 2 vols. (Paris: Plon, 1958), 2: 40.
> 147. P. Franck to A. Franck, letter of 15 April 1836, in ibid., p. 223.
> 147. Ibid., 1: 172.
> 148. P. Franck to A. Franck, 30 May 1836, in ibid., 249–50.
> 148. Ibid., 2: 93.
> 149. See ibid., p. 32 n. 1. Franck prepared for the philosophy aggregation at Toulouse under Gatien-Arnoult's supervision, receiving the highest grade on that examination in 1832 and thus coming to Cousin's attention. For another reference to Gatien-Arnoult as Franck's teacher, see P. Franck to A. Franck, 5 June 1834, in ibid., p. 103.
> 149. Ibid., 1: 225.
> 150. P. Franck to A. Franck, 30 May 1836, in ibid., pp. 249–50.
> 150. Thoré to his mother, 27 December 1835, in Thoré-Bürger peint par lui-même, p. 25.
> 151. P. Franck to A. Franck, 12 June 1833, in ibid., p. 53.
> 151. Dumont to Marion Cox, 23 April 1833, NLS, Combe MSS 7230.
> 152. P. Franck to A. Franck, 14 January 1834, in ibid., pp. 83–85.
> 152. Hippolyte Tampucci, “Remerciement aux souscripteurs aux oeuvres de Magu,” in Magu, Poésies nouvelles (Paris: Delloye, 1842), p. v. The worker-poet Magu was well-known for his connections with the Paris Phrenological Society; see, e.g., A. Carro, “Biographie littéraire de Magu,” in ibid., pp. vii–viii. ## Epilogue The epigraph is from Jean-Paul Sartre, “An Interview,” New York Review of Books, 26 May 1970, p 23.
> 153. P. Franck to A. Franck, 4 June 1834, in ibid., p. 98.
> 154. P. Franck to A. Franck, 5 June 1834, in ibid., p. 105.
> 155. P. Franck to A. Franck, 18 December 1834, in ibid., p. 123.
> 156. P. Franck to A. Franck, 28 December 1835, in ibid., pp. 195–96.
> 157. P. Franck to A. Franck, 21 March 1837, in ibid., esp. pp. 322–23.
> 158. Cousin, Introduction à l'histoire de la philosophie (Paris: Pichon et Didier, 1828), Lesson 1, pp. 11–12.
> 159. Damiron, Cours de philosophie, 1: xxvii.
> 160. Jacques et al. Manuel, pp. 6–7, 11–12.
> 161. See Jan Goldstein, “Eclectic Subjectivity and the Impossibility of Female Beauty,” in Picturing Science, Producing Art, ed. Caroline A. Jones and Peter Galison (London: Routledge, 1998), pp. 360–78.
> 162. Guizot, Histoire de la civilisation en Europe depuis la chute de l’empire romain jusqu’à la révolution française, new ed. (Paris: Didier, 1846), Lesson 1, pp. 3, 5.
> 163. Ibid., Lesson 4, pp. 91–92.
> 164. Ibid., Lesson 7, p. 188.
> 165. See, e.g., ibid., Lesson 4, p. 99.
> 166. Ibid., Lesson 2, p. 57. On the linkage of barbarism and civilization in Guizot, see Jacques Billard, De l'école à la république: Guizot et Victor Cousin (Paris: Presses universitaires de France, 1998), pp. 36–60, esp. p. 51.
> 167. Guizot, Histoire de la civilisation en Europe, pp. 99–101, 119, 195–96, my italics.
> 168. Guizot synoptically sketches this long development in ibid., pp. 206–7.
> 169. Jürgen Habermas, The Structural Transformation of the Public Sphere: An Inquiry into a Category of Bourgeois Society, trans. Thomas Burger (Cambridge, MA: MIT Press, 1989), pp. 46–48 for bourgeois “psychological emancipation” and p. 88. Note that Guizot includes in this definition the Doctrinaire proviso about capacité that tempers universalism with practical restrictions on political participation.
