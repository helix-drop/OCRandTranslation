## Is There a Self in This Mental Apparatus?

[待翻译]

### The Lockean Self and Its Critics

### Condillac and the Minimalist Self

### New Terminology: From Ame to Moi

### The Deaccentuated Self of Later Sensationalism

### Contrapuntal Rumblings

### A Columbus of the Self

### An A Priori Self for the Bourgeois Male: Victor Cousin's Project

### Vernacular Knowledge: The Status of Sensationalism circa 1830

### Improbable Guru: Cousin's Early Career

### A Moi Given Whole and A Priori

### Cousinian Introspection as a Technology of the Self

### A Discourse of Human Difference: The Solved and the Unsolved

### The Ambiguous Gift of Bourgeois Selfhood

### Cousinian Hegemony

### Institutionalizing Psychology: The Teamwork of Cousin and Guizot

### The Cousinian Textbook: Supplementing the Master

### The Regiment

### Internalizing the Cousinian Self (1): Men

### Internalizing the Cousinian Self (2): Women

### Extending the Cousinian Self: Guizot's Theory of History

### The Religious Inner Life, or Mediated Introspection

### Catholic Objections to the Cousinian Self

### Mid-Nineteenth-Century Seminary Psychology

### Renan Adumbrates a Secular Interiority

### Rendezvous with Cousin
