## The Post- Revolutionary Self

[待翻译]
