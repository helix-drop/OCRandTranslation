## The Revolutionary Schooling of Imagination

[待翻译]

### Renovated Sign Systems, or the Epistemology of Imagination

### The Well-Made Language of Science

### Revolutionaries Confront the Imagination

### The Progenitor: Rousseau on the Training of Imagination

### Revolutionary Political Culture: The Refurbished Environment of Everyday Life

### The Central Schools and the Teaching of Condillac

### Combating Imagination with Condillac's Philosophy

### Responsibility toward Possessors of a Wayward Imagination

### Sensationalism Reconsidered

### NOTES

> 8. The text of Les mannequins, conte ou histoire, comme l'on voudra can be found in Louis-François Métra, Correspondance secrète politique et littéraire, 18 vols. (London: J. Adamson, 1787–90), 3: 87–110.
