## The Perils of Imagination at the End of the Old Regime

[待翻译]

### Targeted Mental Operations

### The Philosophical Discourse of Imagination

### Imagination in Socioeconomic Discourse (1): The Trade Corporation

### The Worker's Imagination Further Scrutinized

### Imagination in Socioeconomic Discourse (2): Credit

### Self-Contained Persons: The Odd Trio
