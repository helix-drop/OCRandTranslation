## A Palpable Self for the Socially Marginal: The Phrenological Alternative

[待翻译]

### Rudiments of the Scientific Theory

### The Checkered Fortunes of Phrenology in France

### The Imperative of Popularization

### The Laudable Superficiality of Phrenology

### Channels of Popularization: Cours libres and Almanachs populaires

### The Company It Kept

### Women as Consumers of Phrenology

### Can Phrenology Ground a Self?

### Phrenological Subjectivity

### Banishing Self-Talk
