## Epilogue

[待翻译]

### Vindicating the Workingman: The Affaire Jacques

### A Female Cousinian-Style Self?

### A Long-Lived Programme

### Rethinking the Discovery of the Unconscious

### NOTES

> 22. Henri Marion, “Le nouveau programme de philosophie,” Revue philosophique 10 (1880); 414–28, esp. 422–23, 423 for the quotation.
> 25. Henri Joly, Cours de philosophie, répondant au nouveau programme officiel des lycées et du baccalauréat, 6th ed. (Paris: Delalain, 1881), pp. 15, 30, 35–36.
> 143. Spurzheim to Combe, February 1824, NLS, Combe MSS 7214, fols. 50–52.
> 144. Spurzheim to Combe, London, March 1825, Combe MSS 7216, fols. 74–75.
> 145. Spurzheim to Combe, 21 August 1822, NLS, Combe MSS 7209, fols. 107–8.
> 146. David seems to have adopted a dualist version of phrenology. As he wrote in 1839 about listening to the music of Cherubini at a funeral mass and then catching sight of the heads of the singers: “One is pained to see such sublime sounds come out of such a ridiculous machine. That’s what proves that mind (âme) is independent of matter. . . .” Les Carnets de David d’Angers, 2 vols. (Paris: Plon, 1958), 2: 40.
> 147. Ibid., 1: 172.
> 148. Ibid., 2: 93.
> 149. Ibid., 1: 225.
> 150. Thoré to his mother, 27 December 1835, in Thoré-Bürger peint par lui-même, p. 25.
> 151. Dumont to Marion Cox, 23 April 1833, NLS, Combe MSS 7230.
> 152. Hippolyte Tampucci, “Remerciement aux souscripteurs aux oeuvres de Magu,” in Magu, Poésies nouvelles (Paris: Delloye, 1842), p. v. The worker-poet Magu was well-known for his connections with the Paris Phrenological Society; see, e.g., A. Carro, “Biographie littéraire de Magu,” in ibid., pp. vii–viii. ## Epilogue The epigraph is from Jean-Paul Sartre, “An Interview,” New York Review of Books, 26 May 1970, p 23.
