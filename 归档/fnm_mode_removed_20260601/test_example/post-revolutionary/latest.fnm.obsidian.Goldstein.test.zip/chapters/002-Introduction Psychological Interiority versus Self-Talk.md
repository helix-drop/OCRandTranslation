## Introduction: Psychological Interiority versus Self-Talk

[待翻译]

### Influences, Interlocutors
