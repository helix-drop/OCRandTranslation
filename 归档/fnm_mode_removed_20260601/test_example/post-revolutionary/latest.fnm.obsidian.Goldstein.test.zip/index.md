# 目录

- [The Post- Revolutionary Self](chapters/001-The Post- Revolutionary Self.md)
- [Introduction: Psychological Interiority versus Self-Talk](chapters/002-Introduction Psychological Interiority versus Self-Talk.md)
- [The Perils of Imagination at the End of the Old Regime](chapters/003-The Perils of Imagination at the End of the Old Regime.md)
- [The Revolutionary Schooling of Imagination](chapters/004-The Revolutionary Schooling of Imagination.md)
- [Is There a Self in This Mental Apparatus?](chapters/005-Is There a Self in This Mental Apparatus.md)
- [A Palpable Self for the Socially Marginal: The Phrenological Alternative](chapters/006-A Palpable Self for the Socially Marginal The Phrenological Alternative.md)
- [Epilogue](chapters/007-Epilogue.md)
- [Introduction](chapters/008-Introduction.md)
