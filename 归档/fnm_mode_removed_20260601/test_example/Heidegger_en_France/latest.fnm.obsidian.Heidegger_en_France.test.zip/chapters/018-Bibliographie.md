## Bibliographie

Bibliographie

Des précisions préalables s’imposent quant à la conception d’ensemble de cette bibliographie et à son organisation.

On a distingué trois grandes parties, afin d'éviter une dispersion dans le maquis des publications de (et sur) Heidegger. Celles-ci sont extrêmement abondantes, même si l'on s'en tient (comme il se doit ici) au domaine d'expression française. La priorité revient aux traductions, présentées par ordre chronologique. On trouvera, en second lieu, parmi les études sur Heidegger (livres et articles), celles qui nous ont paru les plus significatives, classées par ordre alphabétique. Sont retenues enfin, dans le même ordre, les publications qui, sans porter explicitement sur Heidegger, témoignent, à des titres variables, de son « influence » ou sont révélatrices des différentes phases de sa réception (et de ses contextes) dans l'ère francophone.

La première rubrique se veut exhaustive ; elle s'en tient cependant aux publications « autonomes » (ou identifiables comme telles) de traductions, en livres bien entendu, mais aussi en revues ; on a dû renoncer à se lancer dans une recherche, presque infinie, incluant des citations ou de fragments inédits dispersés dans l'immense corpus concernant directement ou indirectement Heidegger.

Les deux rubriques suivantes ne peuvent qu'être sélectives. S'il était matériellement possible de citer tous les livres consacrés à Heidegger en français depuis soixante-dix ans, il devenait presque absurde de faire un inventaire complet des articles, voire des entrefilets, parus dans l'ensemble de la presse (sans compter les médias, depuis quelques décennies). Que dire des innombrables allusions à l'œuvre du philosophe et parfois à son seul nom devenu «objet culturel» ? Un tel travail documentaire eût été[^5] considérable; il est sans doute à faire; on en trouve une ébauche (pour les années 1930 à 1983) aux pages 494-509 du Cahier de l'Herne Martin Heidegger, mais il ne correspond ni à l'esprit de notre projet ni à ses inévitables limites. En concevant une bibliographie importante, mais dont les dimensions restent raisonnables, nous avons voulu proposer un instru- ment de travail lisible et offrir des pistes de recherche où l'essentiel soit

Je tiens à remercier tout spécialement Guy Basset dont l'aide m'a été très précieuse dans la mise à jour de la bibliographie des traductions françaises de Heidegger.

1.

### NOTES

> 5. « Concepts fondamentaux de la philosophie antique », traduction Alain Bourot, Paris, Gallimard, 2003, 370 p.
