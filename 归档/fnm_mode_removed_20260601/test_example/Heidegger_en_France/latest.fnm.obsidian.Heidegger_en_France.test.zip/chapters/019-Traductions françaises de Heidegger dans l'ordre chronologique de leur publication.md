## Traductions françaises de Heidegger dans l'ordre chronologique de leur publication

TRADUCTIONS FRANÇAISES DE HEIDEGGER DANS L'ORDRE CHRONOLOGIQUE DE LEUR PUBLICATION

« Qu’est-ce que la métaphysique? », trad. par M. CORBIN-PETTTHENRY, précédé d’une introduction par A. KOYRE, Bifur, juin 1931, pp. 1-27 (reprod. Paris, Jean-Michel Place, 1976).

«De la nature de la cause», trad. A. BESSEY, Recherches philosophiques, publiées par A. KOYRE, H.-C. PUECH, A. SPAIER, Paris, Boivin, 1931-1932, pp. 83-124.

«Hölderlin et l'essence de la poésie», trad. Henry CORBIN, Mesures, n°3, 15 juillet 1937, p. 119-144.

«Lettre de Martin Heidegger», 4 décembre 1937, Bulletin de la Société française de philosophie, t. 37, p. 193.

Qu'est-ce que la métaphysique ?, suivi d'extraits sur l'être et le temps et d'une conférence sur Hölderlin, trad. avec un avant-propos et des notes par Henry CORBIN, Paris, Gallimard, «Les Essais VII.», 1938.

«Phénoménologie de la mort», trad. Henry CORBIN des § 52-53 de Sein und Zeit, Hermès, Bruxelles, 1938, 3° série, pp. 37-51.

«Fragments sur le temps», traduits et adaptés par Joseph ROSENTHAL [pseudonyme de ROVAN], L'Arbalète, Lyon, été-automne 1941, pp. 33-48.

«Hölderlin et l'essence de la poésie», reprod. de la fin de la trad. Corbin citée ci-dessus, in Friedrich Hölderlin. En commémoration du centenaire de sa mort, le 7 juin 1843, Paris, Sorlot, 1943, pp. 131-154.

« Commentaire à l'hymne Tel qu'en un jour de fête », trad. Joseph ROVAN, Fontaine, n° 54, juillet 1946, pp. 206-235.

«Le remontée au fondement de la métaphysique», première trad. (partielle) par Joseph ROVAN, Fontaine, n° 58, mars 1947, pp. 888-898.

«Lettre à Jean Beaufret» (Fragment), trad. Joseph ROVAN, Fontaine, n° 63, novembre 1947, pp. 786-804.

De l'essence de la vérité, trad. Alphonse de WAELHENS et Walter BIEMEL, Louvain-Paris, Nauwelaerts-Vrin, 1948.

Kant et le problème de la métaphysique, Introd. et trad. par Alphonse de WAELHENS et Walter BIEMEL, Paris, Gallimard, 1953.

«Lettre sur l'humanisme» (1), trad. Roger MUNIER, Cahiers du Sud, n° 319, 1953, pp. 385-406.

«Lettre sur l'humanisme» (2), trad. Roger MUNIER, Cahiers du Sud, n° 320, 1953, pp. 68-88.

« Que signifie penser ? », trad. Annelise BOTOND, Mercure de France, n° 1075, 1 $ ^{e} $ mars 1953, pp. 393-407.

«Le sentier», précédé d'une introd. par le traducteur Jacques GÉRARD, La Nouvelle Revue française, janvier 1954, pp. 41-46.

«Sur l'expérience de la pensée», trad. Jacques GÉRARD, Nouvelle Revue française, février 1954, pp. 236-239.

«Logos», trad. Jacques LACAN, La Psychanalyse, Paris, PUF, 1956, n° 1, pp. 59-79.

Lettre sur l'humanisme, texte allemand traduit et présenté par Roger

MINIER, Paris, Aubier, 1957.

«L’homme habite en poète…», trad. André PRÉAU, Cahiers du Sud, n° 344, 1957, pp. 50-66.

Qu'est-ce que la philosophie?, trad. Kostas AXELOS et Jean BEAUFRET, Paris, Gallimard, 1957.

« Georg Trakl. Situation de son Dict », trad. Jean BEAUFRET et Wolfgang BROKMEIER, La Nouvelle Revue française, janvier et février 1958, pp. 52-75 et 213-236.

«Le principe d’identité», trad. Gilbert KAHN, Arguments, n° 7, avril-mai 1958, pp. 2-8 (reprod. Éditions Privat, 1983).

Introduction à la métaphysique, trad. Gilbert KAHN, Paris, PUF, coll. « Épiméthée », 1958.

« Qui est le Zarathoustra de Nietzsche ? », trad. André PRÉAU, Les Lettres nouvelles, n° 65, novembre 1958, pp. 517-538.

« Hegel et les Grecs », trad. Jean BEAUFRET et Pierre-Paul SAGAVE, Cabiers du Sud, n° 349, 1958, pp. 355-368.

Essais et conférences, trad. par André PRÉAU et préfacé par Jean BEAUFRET, Paris, Gallimard, « les Essais LXC », 1958.

« Lettre de Mozart et glose », début de la 9° leçon de Der Satz vom Grund, trad. Jean BEAUFRET, Encyclopédie de la musique, Paris, Fasquelle, 1958, Tome I, pp. 91-92.

«Le retour au fondement de la métaphysique», trad. R. MUNIER, Revue des sciences philosophiques et théologiques, t. XLIII, n° 3, juillet 1959, pp. 401-433.

«Le mot de Nietzsche Dieu est mort», trad. Wolfgang BROKMEIER, Arguments, n° 15, 3° trimestre 1959, pp. 2-13 (reprod. Éditions Privat, 1983).

Qu'appelle-t-on penser?, trad. Aloys BECKER et Gérard GRANEL, Introduction par Gérard GRANEL, Paris, PUE, coll. « Épiméthée », 1959.

«Principes de la pensée», trad. François FÉDIER, Arguments, n° 20, 4° trimestre 1960, pp. 27-33 (reprod. Éditions Privat, 1983); nouvelle publication, Arguments/3, Les intellectuels et la pensée anticipatrice, 1978, UGE, 10/18, n° 1208, pp. 97-118.

«Hebel l'ami de la maison», trad. Annie Li CARRILLO, Cabiers du Sud, n° 355, 1960, pp. 383-396.

« Textes et proclamations », trad. Jean-Pierre FAYE, Médiations. Revue des expressions contemporaines, n° 3, automne 1961, pp. 139-150.

«Au-delà de la métaphysique», trad. Roger MUNIER, Arguments, n° 24, 1961, pp. 35-39 (reprod. Éditions Privat, 1983).

« Le principe de raison », trad. André PRÉAU, Les Lettres nouvelles, novembre 1961, pp. 17-37.

Le Principe de raison, trad. André PRÉAU, Préface de Jean BEAUFRET, Paris, Gallimard, 1962.

Chemins qui ne mènent nulle part, trad. par Wolfgang BROKMEIER et édité par François FÉDIER, Paris, Gallimard, 1962 (nouvelle édition Paris, Gallimard, collection « Idées », 1980, reprise en 1986 dans la collection « Tel », trad. revue et corrigée avec le concours de Jean BEAUFRET, François FÉDIER et François VEZIN).

Approche de Hôlderlin, trad. Henry CORBIN, Michel DEGUY, François FÉDIER et Jean LAUNAY, Paris, Gallimard, 1962 (nouvelle éd. augmentée de deux traductions de François FÉDIER, « Terre et ciel de Hôlderlin » et « Le poème », 1974).

«De l’essence et du concept de φύσις» (Aristote, Physique B 1), Ie partie, trad. Jean-Luc NANCY et François WARN, Aletheïa, n° 1-2, janvier 1964, pp. 1-13.

L'Être et le temps, I (jusqu'au § 44 inclus), traduit et annoté par Rudolf Boehm et Alphonse de Waelhens, Paris, Gallimard, 1964.

«Pour René Char en souvenir du grand ami Georges Braque (Devant une lithographie pour Lettera Amorosa)», trad. Jean BEAUFRET, Derrière le miroir, n° 144-146, Paris, Maeght, 1964, pp. 14-15.

«Texte prononcé le 24 février 1964 à Bühlerhöhe», Revue de poésie, octobre 1964, pp. 52-57.

« Appel aux étudiants allemands », La Brèche, n° 8, novembre 1965, pp. 46-48, nouvelle publication de la traduction de Jean-Pierre FAYE.

«De l’essence et du concept de φύσις» (Aristote, Physique B 1), Π° partie, trad. Jean-Luc NANCY et François WARIN, Aletheia, n° 3, mai 1964, pp. 149-159; n° 4, mai 1966, pp. 242-277.

Questions III (Le Chemin de campagne. L'expérience de la pensée. Hebel. Lettre sur l'humanisme, suivie d'une Lettre à Jean Beaufret du 23 novembre 1945. Sérédité), trad. André PRÉAU, Roger MUNIER et Julien HERVIER, Paris, Gallimard 1966.

«La fin de la philosophie et la tâche de la pensée», trad. Jean BEAUFRET et François FÉDIER, Kierkegaard vivant, Colloque organisé par l’Unesco à Paris du 21 au 23 avril 1964, Paris, Gallimard, coll. «Idées», 1966, pp. 167-204.

«Extrait de En chemin vers la langue», Les Cahiers du Cinéma, présentation et traduction de Patrick LÉVY, n° 186. ianvier 1967. pp. 44-46.

Questions II (Qu'est-ce que la philosophie ? Hegel et les Grecs. La thèse de Kant sur l'être. La doctrine de Platon sur la vérité. Ce qui est et comment se détermine la Physis), trad. Kostas AXELOS, Jean BEAUFRET, Dominique JANICAUD, Lucien BRAUN, Michel HAAR, André PRÉAU, François FÉDIER, Paris, Gallimard, 1968.

Lettre à François Bondy, texte allemand et traduction, Critique, n° 251, avril 1968, pp. 434-435.

« Temps et être », texte allemand et trad. François FÉDIER, L'Endurance de la pensée. Pour saluer Jean Beaufret, Paris, Plon, 1968, pp. 12-71.

Questions I (Qu'est-ce que la métaphysique ? Ce qui fait l'essentiel d'un fondement ou « raison ». De l'essence de la vérité. Contribution à la question de l'être. Identité et différence), trad. Henry CORBIN, Roger MUNIER, Alphonse de WAELHENS, Walter BIEMEL, Gérard GRANEL, André PRÉAU, Paris, Gallimard, 1968.

«Phénoménologie et théologie» suivi de « Quelques indications sur des points de vue principaux du colloque théologique consacré au problème d’une pensée et d’un langage non-objectivants dans la théologie d’aujourd’hui », texte allemand et trad. avec l’aide de M. Marcel MÉRY, Archives de philosophie, XXXII, n° 3, juillet-sept. 1969, pp. 355-395 et 396-415.

Séminaire du Thor (30 août-8 septembre 1968), tirage à cent exemplaires numérotés hors commerce à la diligence de Roger Munier, 1969.

Séminaire du Thor (2-11 septembre 1969), tirage à deux cents exemplaires numérotés hors commerce pour le compte et le plaisir de Roger Munier, 1969.

Die Kunst und der Raum / L'art et l'espace, texte allemand et trad. par Jean

BEAUFRET et François FÉDIER, Saint-Gall, Erker-Verlag, 1969.

« Qu’est-ce que la métaphysique ? », précédé d’une lettre de l’auteur, trad. Roger MUNIER, Le Nouveau Commerce, cahier 14, été-automne 1969, pp. 55-76.

Traité des catégories et de la signification chez Duns Scot, traduit et présenté par Florent GABORIAU, Paris, Gallimard, 1970.

«Pensivement» (Temps, Chemins, Signes, Site, Cézanne, Prélude, Reconnaissance), texte allemand, trad. Jean BEAUFRET et François FÉDIER, Cahier de l'Herne, René Char, Paris, 1971, pp. 169-187.

Qu'est-ce qu'une chose ?, trad. Jean REBOUL et Jacques TAMINIAUX, Paris, Gallimard, 1971.

Nietzsche, I et II, trad. Pierre Klosowski, Paris, Gallimard, 1971.

«Lettre à Richardson» et «Mon chemin de pensée et la phénoméno-logie», trad. Jean LAUXEROIS et Claude ROËLS, Les Études philosophiques, n° 1, janvier-mars 1972, pp. 3-22.

Ernst CASSIRER-Martin HEIDEGGER, Débat sur le kantisme et la philosophie et autres textes de 1929-1931, présentés par Pierre AUBENQUE, trad. par P. AUBENQUE, J.-M. FATAUD, P. QUILLET, Paris, Beauchesne, 1972.

Héraclite. Séminaire du semestre d'hiver 1966-67 (en collaboration avec

Eugen FINK), trad. Jean LAUNAY et Patrick LÉVY, Paris, Gallimard, 1973.

«L'habitation de l'homme», trad. François FÉDIER, La Traverse, n° 7, automne 1973.

«Sprache / Parole», trad. Roger MUNIER, Argile, n° 1, hiver 1973, pp. 4-5; nouvelle édition, tirage à 10 exemplaires rehaussés par Pierre MREJEN, Rouleau libre, Paris, 1993.

« Lettre de Martin Heidegger à Ernst Jünger, 7 novembre 1969 », in Ernst JÜNGER, Rivarol et autres essais, trad. Jeanne NAUJAC et Louis EZE, Paris, Grasset, 1974, pp. 161-164.

« Le défaut des noms sacrés », trad. Philippe LACQUE-LABARTHE et Roger MUNIER, Contre toute attente, 2/3, 1974, pp. 39-55.

Questions IV (Temps et Être. La fin de la philosophie et la tâche de la pensée. Le tournant. La phénoménologie et la pensée de l'être. Les séminaires du Thor. Le séminaire de Zähringen), trad. Jean BEAUFRET, François FÉDIER, Jean LAUXEROIS et Claude ROËLS, Paris, Gallimard, 1976.

Acheminement vers la parole, trad. par Jean BEAUFRET, Wolfgang BROKMEIER et François FÉDIER, Paris, Gallimard. 1976.

« Aujourd’hui Rimbaud », texte allemand et trad. Roger MUNIER, Archives de lettres modernes, n° 60, Paris, Minard, 1976, pp. 12-17.

Lettre-préface de Martin HEIDEGGER au livre de Henri MONGIS, Heidegger et la critique de la notion de valeur, La Haye, Martinus Nijhoff, 1976, pp. VI-XI.

« L'Être a besoin des hommes », extrait de l'entretien de HEIDEGGER avec Richard WISSER « Réponses et questions... », Le Magazine littéraire, (« Heidegger aujourd'hui »), n° 117, octobre 1976, pp. 22-23.

«Discours de rectorat de 1933 », trad. Gérard GRANEL, Annales de l'université de Toulouse-Le Mirail (Supplément), janvier 1977, pp. 44-52.

Réponses et questions sur l'histoire et la politique, trad. Jean LAUNAY, Paris, Mercure de France, 1977.

Schelling, trad. Jean-François COURTINE, Paris, Gallimard, 1977.

Traduction inédite (dactylogramme hors commerce) par Gérard GRANEL des § 45 et 54 à 63 de Sein und Zeit (Université de Toulouse, Unité de valeur PH 393, « Allemand philosophique », 1978-1979).

«Séminaire de Zurich» (6 novembre 1951), traduit et présenté par François FÉDIER, Po&sie, n° 13, 1980, pp. 52-62.

« Texte inédit, tiré d’un résumé des protocoles du semestre d’hiver 1950-1951 » (trad. Jean BEAUFRET) et « Dialogue avec Martin Heidegger, le 6 novembre 1951 » (trad. Jean GREISCH), in Heidegger et la question de Dieu, Paris, Grasset, 1980, pp. 333-336.

«Le chemin de pays», trad. Jean BEAUFRET et Dominique JANICAUD, Poésie d'ici, Nice, automne 1980, pp. 76-79.

Lettres à Henry Corbin (17 juillet 1935, 15 mars 1937), trad. Yvonne

GIBERT, Cahier de l'Herne Henry Corbin, Paris, 1981, pp. 319-320.

« Lettre à M. Gros », Sud, numéro consacré à L.G. GROS, n° 41-42, p. 116 (sans nom de traducteur).

«Remarque avant une lecture de poèmes (Bühlerhöhe, le 24 février 1951) » et «L'habitation de l'homme», trad. François FÉDIER, Exercices de la patience, n° 3/4, printemps 1982, pp. 145-147, 149-154.

L'Auto-affirmation de l'Université allemande (Die Selbstbehauptung der deutschen Universität), édition bilingue, trad. Gérard GRANEL, Mauvezin, TER, 1982.

Interprétation phénoméologique de la « Critique de la raison pure » de

Kant, trad. Emmanuel MARTINEAU, Paris, Gallimard, 1982.

Lettre à Jean Beaufret (22 février 1975), texte allemand et traduction in Éryck de RUBERCY-Dominique LE BUHAN, Douze questions posées à Jean Beaufret à propos de Martin Heidegger, Paris, Aubier, 1983, pp. 72-77.

Textes de Martin Heidegger (Le concept de temps, 1924/Seconde version de l'article «Phénémologie», 1927 / Lettre à Husserl, 22 octobre 1927 / Qu'est-ce que la métaphysique?, 1929 (traduction nouvelle) / Chemins d'explication, 1937 / Sur un vers de Môrikie, 1951/ Principes de la pensée, 1958 / Esquisses tirées de l'atelier, 1959 / La provenance de l'art et la destination de la pensée, 1967 / Entretien entre Richard Wisser et Martin Heidegger, 1969 / Sprache (Langue), 1972 / Lettre au rectorat académique de l'Université Albert-Ludwig, 1945 / Neuf lettres à Roger Munier, comprenant un texte sur Rimbaud, 1966 à 1976 / Deux lettres à Jean-Michel Palmier, 1969 et 1972 / Passage du soir sur Reichenau, 1917 / Vers de Hölderlin choisis par Martin Heidegger et lus par son fils sur sa tombe ouverte), Paris, Cahier de l'Herne Martin Heidegger, dirigé par Michel HAAR, 1983, pp. 27-126.

«Le rectorat 1933-1934. Faits et réflexions. - L'Université allemande envers et contre tout elle-même», trad. François FÉDIER, Le Débat, n° 27, novembre 1983, pp. 73-97.

«Le souvenir de Marcelle Mathieu», trad. François FÉDIER in René CHAR, Œuvres complètes, Paris, Gallimard, Bibliothèque de la Pléiade, 1983, pp. 1248-1249.

La «Phénoménologie de l'esprit» de Hegel, trad. Emmanuel MARTINEAU, Paris, Gallimard, 1984.

Les Problèmes fondamentaux de la phénoménologie, trad. Jean-François

COURTINE, Paris, Gallimard, 1985.

Le Chemin de campagne, trad. Jean BEAUFRET, François FÉDIER, Julien HERVIER et François VEZIN, La Clayette, Chandeigne, 1985.

Être et temps, trad. Emmanuel MARTINEAU, Paris, Authentica, 1985.

«Dicté» («La question portant fondamentalement sur l'être même»: voir infra], éd. bilingue par Philippe CLIDIÈRE, Éditions de l'Abîme en effet, automne 1985, pp. 1-38.

Concepts fondamentaux, trad. Pascal DAVID, Paris, Gallimard, 1985.

Être et temps, trad. François VEZIN d'après les travaux de Rudolf BOEHM et Alphonse de WAELHENS (I° partie), Jean LAUXEROIS et Claude ROËLS (II° partie), Paris, Gallimard, 1986.

«Remarques sur la Psychologie der Weltanschauungen de Karl Jaspers» (I), trad. P. COLLOMBY, Philosophie, n° 11, été 1986, pp. 3-24; (II), n° 12, automne 1986, pp. 3-21.

« La question portant fondamentalement sur l'être même », éd. par Philippe CLIDIÈRE, Heidegger-Studies, 1986, n° 2, pp. 7-10 (texte dicté à Jean Beaufret en septembre 1946, reprod. in Frédéric de TOWARNICKI, À la rencontre de Heidegger, Paris, Gallimard, 1993, pp. 255-258).

«Pourquoi restons-nous en province ? », trad. Françoise DASTUR et Nicole PARFAIT, Le Magazine littéraire, n° 235, novembre 1986, pp. 24-25.

« La chance » ; « En chemin » ; « Les veilleurs » ; « Être et pensée » ; extraits de Signes, trad. Michel HAAR, Le Magazine littéraire, n° 235, novembre 1986, pp. 41.

De l'origine de l'œuvre d'art, première version inédite (1935), texte allemand et trad. par Emmanuel MARTINEAU, Paris, Authentica, 1987 ; reprise in Conférence n° 4, printemps 1997, avant-propos pp. 397-409, trad. pp. 410-441.

De l'essence de la liberté humaine. Introduction à la philosophie, trad. Emmanuel MARTINEAU, Paris, Gallimard, 1987.

Max KOMMERELL et Martin HEIDEGGER, Correspondance, Introd. et trad. par Marc CRÉPON, Philosophie, n° 16, automne 1987, pp. 3-16.

« Réponses et questions sur l'histoire et la politique », trad. Jean LAUNAY, nouvelle publication Le Messager européen, n° 1, Paris, 1987, POL, pp. 15-71, commentaire de Jan PATOCKA.

« Extrait d’une lettre de Martin Heidegger à Médard Boss en date du 3 janvier 1955 », in Beda ALLEMAN, Hölderlin et Heidegger, trad. François FÉDIER, Paris, PUF, seconde édition revue et corrigée,

* Note finale à De l'essence de la vérité » (deuxième édition 1949), extraits, in Jean GRONDIN, Le Tournant dans la pensée de Martin Heidegger, Paris, PUE, 1987, p. 31.

« Textes politiques 1933-1934 », trad. Nicole PARFAIT, présentée par François FÉDIER, Le Débat, n° 48, janvier-février 1988, pp. 176-192.

Lettre à Carl Schmitt (22 août 1932), in Jürgen HABERMAS, Martin Heidegger. L'œuvre et l'engagement, trad. Rainer ROCHLITZ, Paris, Éditions du Cerf, 1988, p. 35.

«Abraham a Santa Clara» (à l'occasion de l'inauguration de sa statue à Kreenheinstetten, 15 août 1910), « Sur Abraham a Santa Clara » (2 mai 1964), trad. François VEZIN, Recueil, Champ vallon, n° 9, mai 1988, pp. 8-21.

Les Hymnes de Hölderlin : La Germanie et Le Rhin, trad. François FÉDIER et Julien HERVIER, Paris, Gallimard, 1988.

« Nuit », trad. Françoise DASTUR, in Rencontre de René Char et de Martin Heidegger, Europe, n° 705-706, janvier-février 1988, pp. 109-110.

« Heidegger : Parménide, pp. 58-61 et 67-68 » trad. Éliane ESCOUBAS in Heidegger, questions ouvertes, Collège international de philosophie, Paris, Osiris, 1988, pp. 186-188.

Daniel ROCHE, Heidegger et Héraclite : traduction du cours de Heidegger de 1943 intitulé « Le Commencement de la pensée occidentale », paru dans le tome 55 de l'édition complète allemande, Lille, ANRT, 1988, microfiche.

«Le manque de noms salutaires», trad. Dominique SAATDJIAN, Recueil, Champ vallon, n° 11, mars 1989, pp. 41-47.

Réponse à Max Kommerell (4 août 1942), trad. Dominique LE BUHAN et Éryck de RUBERCY, in Max KOMMERELL, Le Chemin poétique de Hölderlin, Paris, Aubier, 1989, pp. 117-118.

Langue de tradition et langue technique, édité par Hermann HEIDEGGER, trad. et postface par Michel HAAR, Bruxelles, Lebeer-Hossmann, 1990.

L'Affaire de la pensée, (Pour aborder la question de sa détermination), trad. et notes d'Alexandre SCHILD, Mauvezin, TER, 1990.

« Lettre à M. Lan »; « Recension de O. Zimmermann »; « Le besoin de Dieu » (extrait) ; « L’heure du mont des Oliviers »; « Sur de calmes sentiers »; « Nuit de juillet »; « Lettre à Joseph Stauer »; « Lettres à Engelbert Krebs »; « Consolation » pp. 57-58, 69, 74-78, 87-88, 95, 112-113, in Hugo OTT, Martin Heidegger. Éléments pour une biographie, trad. J.M. BELOEIL, Paris, Payot, 1990.

« Lettre à Victor Schwoerer, 2 octobre 1929 », trad. de Nicolas TERTULIAN, « Histoire de l'être et révolution politique », Les Temps modernes, n° 523, février 1990, note pp. 124-125.

«Beiträge zur Philosophie (Vom Ereignis)», trad. du § 267 par Jean GREISCH, Rue Descartes. Collège international de philosophie, n° 1, avril 1991, pp. 213-224.

Aristote, Métaphysique θ 1-3, trad. Bernard STEVENS et Paul VANDEVELDE, Paris, Gallimard, 1991.

«Lettre à R. Krämer-Badoni», trad. Mira KÖLLER et Dominique SÉGLARD, Po&sie, n° 59, 1992, pp. 32-35.

Interprétations phénoménologiques d'Aristote, précédé de Hans-Georg GADAMER, Un écrit « théologique » de jeunesse, Postface de H. U. LESSING, trad. Jean-François COURTINE, Mauvezin, TER, 1992.

Séjours/Aufenthalte, édition bilingue, trad., postface et notes par François

VEZIN, Paris, Le Rocher, 1992.

Les Concepts fondamentaux de la métaphysique. Monde-finitude-solitude, trad. Daniel PANIS, Paris, Gallimard, 1992.

«L’essence de l’art», entretiens des 18 et 19 mai 1958 avec Hisamatsu, trad. et préface de Jean-Marie SAUVAGE, Nioques, n° 6, 1993, pp. 7-20.

«Lettre de Heidegger à Husserl (22 oct. 1927)», trad. Jean-François COURTINE et « La phénoménologie », (deuxième version, article pour l'Encyclopaedia Britannica), trad. Jean-Luc FIDEL, in Edmund HUSSERL, Notes sur Heidegger, éd. par Didier FRANCK, Paris, Éditions de Minuit, 1993, pp. 115-118 et 93-101.

« Remarques sur la traduction » (extrait), cours du semestre d'été 1942, Hölderlin Hymne « Der Ister » (GÄ 53), trad. François FÉDIER, Heidegger Studies, Berlin, 1993, n° 9, repris in François FÉDIER, Regarder voir, Paris, Les Belles Lettres/Archimbaud, 1995, p. 96.

L'unique lettre de Heidegger à Sartre », trad. François FÉDIER, Le Magazine littéraire, n° 320, avril 1994, p. 47. Prépublication du premier paragraphe de cette lettre, sans nom de traducteur, dans Frédéric de TOWARNICKI, « Sartre-Heidegger : le rendez-vous manqué », Le Figaro, 28 mai 1990, p. 26 ; lettre reproduite, sans nom de traducteur, dans Frédéric de TOWARNICKI, À la rencontre de Heidegger, souvenirs d'un messager de la Forêt Noire, Gallimard, Paris, 1993, pp. 83-85.

Martin HEIDEGGER et Kojima TAKEHIKO, «Une correspondance (1963-1965)», trad. et notes par Jean-Marie SAUVAGE, Philosophie, n° 43, 1994, pp. 3-21.

« Lettre à Stäbel » et « Lettre à Die Zeit du 24 septembre 1953 », trad. Jean-Pierre FAYE, Le Piège, Balland, Paris, 1994, pp. 97-98 et 110-111.

« Un souvenir d'enfance de Martin Heidegger : le mystère du clocher » (GA 13, pp. 115-116) ; « Une philosophie sous influence » (GA 63, pp. 5-6) ; « La vie artificielle ou le rendez-vous réel avec la réalité réelle » (GA 58, pp. 103-104) ; « Lettre à un doctorant, lettre à Karl Löwith du 19 août 1921 » (nouvelle publication partielle in Emmanuel Falque, Saint Bonaventure et l'entrée de Dieu en théologie, Paris, Vrin, 2000, pp. 13-14) ; « Toute connaissance est assignée à l'intuition » (GA 25) ; « Préparer un sol pour la question du sens de l'être » (GA 19, pp. 447-448) ; « La crise des fondements » (GA 24, p. 75) ; « Lettre du 27 juin 1922 à Karl Jaspers » ; « L'idée formelle et l'effectuation concrète de la phénoménologie » (GA 19, p. 586) ; « Soi-même et l'autre » (GA 21, pp. 235-236) ; « Un affect : la tristesse » (GA 29/30, pp. 99-100) ; « Le phénomène du langage » (GA 21, p. 151) ; « Le temps public : un temps commun » (GA 24, p. 373) ; « L'espace pensé comme temps ou l'espace pensé à partir du temps : une alternative tranchée » (GA 21, pp. 256-257) ; « Sein und Zeit : un "livre" et une "nécessité" » (GA 49, pp. 26-27) ; « Lettre à Elisabeth Blochmann du 8 août 1928 » ; « Le Dasein n'a pas besoin de fenêtre » (GA 24, p. 427) ; « Le Dasein comme "ouvrier" de la différence ontologique » (GA 24, p. 454) ; « L'a priori comme source de toutes les possibilisations » (GA 24, pp. 462-463) ; « Toute connaissance est intuition » (GA 25, pp. 63-64), in Jean Greisch, Ontologie et temporalié, esquisse d'une interprétation intégrale de Sein und Zeit, Paris, PUE, 1994, pp. 5, 24, 32, 35-36, 51, 74, 84, 96, 103-04, 165, 183, 206, 395, 412-413, 424, 432-433, 459, 475, 488, 492.

Écrits politiques, 1933-1966, Présentation, trad. et notes par François

FÉDIER, Paris, Gallimard, 1995.

«En mémoire de l'ami qu'était Hans Jantzen», Cahiers philosophiques, trad. François VEZIN, n° 66, mars 1996, pp. 111-113.

Correspondance avec Karl Jaspers, trad. Claude-Nicolas GRIMBERT, Correspondance avec Elisabeth Blochmann, trad. Pascal DAVID, Paris, Gallimard, 1996.

« Promenade du soir à Reichenau », trad. Isabelle KALINOWSKI, in Rüdiger

SAFRANSKI, Martin Heidegger, Paris, Grasset, 1996.

«Sur la Madone Sixtine», trad. Matthieu MAVRIDIS; «Apports à la philosophie», § 238-242, trad. François FÉDIER, Po&sie, n° 81, oct. 1997, pp. 4-7 et 9-21.

Réponse au doyen de la Faculté des lettres d'Aix-en-Provence le 20 mars 1958, in François FÉDIER, Soixante-deux photographies de Martin Heidegger, Paris, Gallimard, 1999, p. 65 qui reprend « Pourquoi parlé-je ici à Aix-en-Provence ?. » in François FÉDIER, « …Voir sous le voile de l'interprétation… (Cézanne et Heidegger) » Kunst und Technik Gedächtnisschrift zum 100. Geburtstag vom Martin Heidegger, Frankfurt am Main, Klostermann, 1989 ; même traduction reprise in François FÉDIER, Regarder voir, Paris, Les Belles Lettres/Archimbaud,

« Lettre à René Char », janvier 1973, Frédéric de TOWARNICKI, Martin Heidegger, souvenirs et chroniques, Paris, Rivages, 1999, p. 134..

«Die Differenz und das Nichts»/ La «différence» et le «néent», trad.

François FÉDIER, L'Enseignement par excellence. Hommage à François

Vezin, Paris, L'Harmattan, 2000, pp. 10-13.

Hannah ARENDT-Martin HEIDEGGER, Lettres et autres documents 1925-1975, trad. Pascal DAVID, Paris, Gallimard, 2001.

De l'essence de la vérité. Approche de l'« allégorie de la caverne » et du « Théétète » de Platon, trad. Alain BOUTOT, Paris, Gallimard, 2001.

«Colloque sur la dialectique», trad. Pascal DAVID et Jürgen GEDINAT, Philosophie, n° 69, mars 2001, pp. 3-19.

« Annexe au colloque sur la dialectique », trad. Pascal DAVID et Jürgen GEDINAT, Philosophie, n° 70, juin 2001, pp. 13-24.

« Existenzialismus/Existentialisme », trad. Francesca FERRÉ, Philippe JULLIEN et Éric SORLOT, et « Hegel et le problème de la métaphysique », trad. François VEZIN, in La Fête de la pensée, hommage à François Fédier, Paris Lettrage Distribution, 2001, pp. 12-15.

« Lettre de Martin Heidegger à Paul Celan, 30 janvier 1968 » in Paul Celan-Gisèle CELAN- LESTRANGE, Correspondance, Paris, Le Seuil, 2001, p. 393.

« La lettre retrouvée de Heidegger à Paul Celan, 30 Janvier 1968 » et « Avant-Propos au poème Todtnauberg », trad. Hadrien FRANCE-LANORD, Le Magazine littéraire, janvier 2002, p. 102 et p. 103.

REMARQUES

ANDIA (Ysabel de), Présence et eschatologie dans la pensée de Martin Heidegger, Lille-Paris, université de Lille-III / Éditions universitaires, 1975.

AUBENQUE (Pierre), « Martin Heidegger (1889-1976), In memoriam », Les Études philosophiques, n° 3, 1976, pp. 259-272.

BARASH (Jeffrey Andrew), Heidegger et son siècle. Temps de l'être et temps de l'histoire, Paris, PUF, 1995.

BEAUFRET (Jean), « Martin Heidegger et le problème de la vérité », Fontaine, n° 63, novembre 1947, pp. 758-785.

— «Heidegger vu de France», Die Frage Martin Heideggers. Beiträge zu einem Kolloquium mit Heidegger an Anlass seines 80. Geburtstages, Heidelberg, Carl Winter, 1969, pp. 9-16.

— Introduction aux philosophies de l'existence, de Kierkegaard à Heidegger, Paris, Denoël/Gonthier, Bibliothèque Médiations, 1971. Minun, Dialogue avec Heidegger. II. Philosophie moderne, Paris, Éditions de Linuit, 1973.

- Dialogue avec Heidegger. III. Approche de Heidegger, Paris, Éditions le Minuit, 1974.

- «L’énormité de Heidegger», entretien avec Roger-Pol DROIT, Le Monde, n° 9238, 27 septembre 1974, p. 18.

— «En France», Erinnerung an Martin Heidegger, Pfullingen, Neske, 1977, pp. 9-13.

– Dialogue avec Heidegger. IV. Le Chemin de Heidegger, Paris, Éditions de Minuit, 1985.

– De l’existentialisme à Heidegger. Introduction aux philosophies de l’existence et autres textes, suivi d’une Bibliographie complète par Guy BASSET, Paris, Vrin, 1986.

BESPALOFF (Rachel), « Lettre sur Heidegger à M. Daniel Halévy », Revue philosophique, novembre-décembre 1933, p. 321 sq.; reprod. in Conférence, n° 6, printemps 1998, pp. 452-479.

BIEMEL (Walter), Le Concept de monde chez Heidegger, Louvain, Nauwelaerts / Paris, Vrin, 1950.

BIRAULT (Henri), « Existence et vérité d'après Heidegger », Revue de métaphysique et de morale, janvier-mars 1951, pp. 35-87.

— « La foi et la pensée d'après Martin Heidegger », Philosophies chrétiennes, Recherches et débats n° 10, Paris; Fayard, 1955, pp. 108-132.

– Heidegger et l'expérience de la pensée, Paris, Gallimard, 1978.

BLANCHARD (Jean-Pierre), Martin Heidegger, philosophe incorrect, Paris, Éditions Déterna, 1997. - Heidegger, Puiseaux, Éditions Par

BOLLACK (Jean) et WISMANN (Heinz), « Heidegger l’incontournable », Actes de la recherche en sciences sociales, n° 5/6, novembre 1975, pp. 157-161.

BONZON (Alfred), Racine et Heidegger, Paris, Nizet, 1995.

BOURDIEU (Pierre), « L'ontologie politique de Martin Heidegger », Actes de la recherche en sciences sociales, n° 5-6, novembre 1975, pp. 109-156.

- L'Ontologie politique de Martin Heidegger, nouvelle éd., Paris, Éditions de Minuit, 1988.

BOUTOT (Alain), Heidegger et Platon : le problème du nibilisme, Paris, PUF, 1987.

– Heidegger, Paris, PUF, coll. « Que sais-je ? », 1989.

BRAGUE (Rémi), « La phénoménologie comme voie d'accès au monde grec. Note sur la critique de la Vorhandenheit comme modèle ontologique dans la lecture heideggérienne d'Aristote», Phénoménologie et métaphysique, sous la dir. de J.-L. Marion et Guy Planty-Bonjour, Paris, PUF, 1984, pp. 247-273.

BRITO (Emilio), Heidegger et l'hymne du sacré, Bibliotheca Ephemeridum Theologicarum Lovaniensium CXLI, Louvain, Peeters, 1999.

CAPELLE (Philippe), Philosophie et théologie dans la pensée de Martin Heidegger, Paris, Éditions du Cerf, 1998.

CHAPELLE (Albert), L'Ontologie phénoménologique de Heidegger. Un commentaire de « Sein und Zeit », Paris, Éditions universitaires, 1962.

CHRÉTIEN (Jean-Louis), «De l'espace au lieu dans la pensée de Heidegger», Revue de l'enseignement philosophique, février-mars 1982, pp. 3-21.

COMETTI (Jean-Pierre) et JANICAUD (Dominique) éd., «Être et temps » de Martin Heidegger. Questions de méthode et voies de recherche (Contributions de J. Sallis, D. Janicaud, J. Taminiaux, J.-P. Cometti, J.-P. Larthomas, M. Meyer, M. de Launay, M. Froment-Meurice, P. Livet, A. Villani, J. Gino, A. Flécheux, M. Haar, J.-L. Nancy, J. Rive-laygue), Marseille, Sud, 1989.

CONCHE (Marcel), Heidegger résistant, Treffort, Éditions de Mégare, 1996.

– Heidegger inconsidéré, Treffort, Éditions de Mégare, 1996.

CORVEZ (Maurice), «La place de Dieu dans l'ontologie de Martin Heidegger», Revue Thomiste, t. LIII, n° 1, 1953, pp. 287-320.

- La Philosophie de Heidegger, Paris, PUF, 1961.

COTTEN (Jean-Pierre), Heidegger, Paris, Éditions du Seuil, 1974.

COTTEN (Jean-Pierre), Heidegger, e.e.

COURTINE (Jean-François), « Gilson et Heidegger », Étienne Gilson et nous : La philosophie et son bistoire, textes réunis par M. Couratier, Paris, Vrin, 1980, pp. 103-116.

- Heidegger et la phénoménologie, Paris, Vrin, 1990.

- éd., Heidegger 1919-1929. De l'herméneutique de la facticité à la métaphysique du Dasein, Paris, Vrin, 1996.

COUTURIER (Fernand), Monde et être chez Heidegger, Préface de Bernhard

Welte, Presses de l'université de Montréal, 1971.

DASTUR (Françoise), «Heidegger», Histoire de la philosophie, Paris, Gallimard, III, encyclopédie de la Pléiade, sous la dir. d'Y. BELAVAL, 1974, pp. 608-630.

– Heidegger et la question du temps, Paris, PUF, 1990.

– «Heidegger et la théologie», Revue philosophique de Louvain, maï�ut 1994, pp. 226-245.

DECLÈVE (Henri), Heidegger et Kant, La Haye, Martinus Nijhoff, «Phänomenologica» n° 40, 1970.

DERRIDA (Jacques), De l'esprit. Heidegger et la question, Paris, Galilée, 1987.

DUBOIS (Christian), Heidegger. Introduction à une lecture, Paris, Éditions du Seuil, coll. « Points », 2000.

DUFRENNE (Mikel), « Heidegger et Kant », Revue de métaphysique et de morale, janvier 1949, pp. 1-28.

- « La mentalité primitive et Heidegger », Les Études philosophiques, 1954, pp. 284-306.

FARIAS (Victor), Heidegger et le nazisme, trad. de l'espagnol et de l'allemand par Myriam Benarroch et Jean-Baptiste Grasset, Préface de Christian Jambet, Lagrasse, Verdier, 1987.

FAYÉ (Jean-Pierre), « Heidegger et la Révolution », Médiations. Revue des expressions contemporaines, n° 3, automne 1961, pp. 151-159.

- « À propos de Heidegger : La lecture et l'énoncé », Critique, n° 237, fév. 1967, pp. 288-295.

- « Heidegger : la chaîne de la “dureté », Études germaniques, t. 23, 1968, p. 283-286.

- Le Piège. La philosophie heideggerienne.

1994.

FÉDIER (François), « Trois attaques contre Heidegger », Critique, n° 234, novembre 1966, pp. 883-904.

- « À propos de Heidegger : une lecture dénoncée », Critique, n° 242, juillet 1967, pp. 672-686.

- « Le point », Critique, n° 251, avril 1968, pp. 433-437.

- « Heidegger : l'édition complète », Le Débat, n° 22, novembre 1982, pp. 31-40.

- Heidegger : anatomie d'un scandale, Paris, Robert Laffont, 1988.

— Soixante-deux photographies de Martin Heidegger, Paris, Gallimard, 1999.

FERRIÉ (Christian), Heidegger et le problème de l'interprétation, Paris, Kimé, 1999.

— Heidegger et le problème de Kant, Paris, Kimé, 2000.

FERRY (Luc) et RENAUT (Alain), Heidegger et les Modernes, Paris, Grasset, 1988.

FONDANE (Benjamin), « Martin Heidegger, sur les routes de Kierkegaard et de Dostoïevski », La Conscience malheureuse, Paris, Denoël et Steele, 1936, pp. 169-198.

FRANCK (Didier), Heidegger et le problème de l'espace, Paris, Éditions de

Minuit, 1986.

FROMENT-MEURICE (Marc), Solitudes. De Rimbaud à Heidegger, Paris, Galilée, 1989.

- C'est à dire. Poétique de Heidegger, Paris, Galilée, 1996.

FUMET (Stanislas), « Heidegger et les mystiques », La Table ronde, n° 182, 1963, pp. 82-88.

GOLDMANN (Lucien), Lukács et Heidegger, Paris, Denoël-Gonthier, 1973.

GRANEL (Gérard), «Remarques sur l'accès à la pensée de Martin Heidegger : Sein und Zeit », La Philosophie au XX* siècle, dir. François Châtelet, Paris, Hachette, 1973, pp. 173-215.

– «Après Heidegger», Écrits logiques et politiques, Paris, Galilée, 1990, pp. 95-125.

- «Ipse Dasein» et «Lacan et Heidegger», Études, Paris, Galilée, 1995, pp. 27-43 et 45-63.

GREISCH (Jean), La Parole heureuse. Martin Heidegger entre les choses et les mots, Paris, Beauchesne, 1987.

—« La parole d’origine, l’origine de la parole. Logique et sigétique dans les Beiträge zur Philosophie de Martin Heidegger», Rue Descartes.

Collège international de philosophie, n° 1, avril 1991, pp. 191-212.

- Ontologie et temporalité. Esquisse d'une interprétation intégrale de «Sein und Zeit», Paris, PUF, 1994.

- L'Arbre de vie et l'arbre du savoir. Les racines phénoménologiques de l'herméneutique heideggerienne (1919-1923), Paris, Éditions du Cert, 2000.

GRONDIN (Jean), «Heidegger et la théologie. A propos de quelques ouvrages récents», Archives de philosophie, n° 46, 1983, pp. 459-464.

- «L’école heideggérienne de Nice», Archives de philosophie, n° 50, 1987, pp. 271-280.

- Le Tournant dans la pensée de Martin Heidegger, Paris, PUF, 1987.

GUÉRY (François), Heidegger rediscuté. Nature, technique et philosophie, Paris, Descartes & Cie, 1995.

GUIBAL (Francis), et combien de dieux nouveaux. Approches contemporaines, I. Heidegger, Paris, Aubier, 1980.

GUILREAD (Ruben), Être et liberté. Une étude sur le dernier Heidegger, Paris-Louvain, Nauwelaerts, 1965.

GUITTON (Jean), « Visite à Heidegger », La Table ronde, n° 123, mars 1958, pp. 143-155.

- « Chemins de campagne. Méditation sur Heidegger », La Table ronde, n° 162, juin 1961, pp. 9-15.

- « Claude et Heidegger », Profils parallèles, Paris, Fayard, 1970, pp. 461-496.

GURVITCH (Georges), Les Tendances actuelles de la philosophie allemande (E. Husserl, M. Scheler, E. Lask, N. Hartmann, M. Heidegger), Paris, Vrin, 1930, Préface de Léon Brunschvice.

HAAR (Michel), Le Chant de la terre. Heidegger et les assises de l'histoire de l'être, Paris, L'Herne, 1987.

– Heidegger et l'essence de l'homme, Grenoble, Millon, 1990.

– La Fracture de l'histoire. Douze essais sur Heidegger, Grenoble, Millon, 1994.

HABERMAS (Jürgen), Martin Heidegger. L'œuvre et l'engagement, trad.

Reiner ROCHLITZ, Paris, Éditions du Cerf, 1988.

HEIDEGGER (n° spécial), Revue internationale de philosophie, n° 52, Bruxelles, 1960 (contributions de Henri Birault, Rudolf Boehm, Jean Paumen, Alphonse de Waelhens ; une bibliographie heideggérienne).

«Martin HEIDEGGER», par Jean Beaufret en collaboration avec Claude Roëls, Encyclopædia Universalis, supplément annuel, Universalia, Paris, 1976, pp. 496-497; reprod. in article «Heidegger», Encyclopædia Universalis, Paris, 1985.

HEIDEGGER, n° spécial des Études germaniques (contributions de Pierre Aubenque, Gerhart Baumann, Jean Beaufret, Michel Haar, Dominique Janicaud), n° 3, juillet-septembre 1977.

HEIDEGGER (n° spécial préparé par F. WYBRANDS), Exercices de la patience, n° 3/4 (contributions de R. Munier, É. Lévinas, H. Birault, H. Valavanidis-Wybrands, J.-P. Charcosset, J.-F. Courtine, J. Barash, M. Haar, D. Charles, G. Vattimo, L. Irigaray, P. Tal-Coat, F. Laruelle, A. David, G. Petitdemange, P. Lacoue-Labarthe et J.-L. Nancy, J. Rolland), Paris, Éditions Obsidiane, printemps 1982.

Martin HEIDEGGER, Cahier de l'Herne, sous la dir. de Michel HAAR (contributions de W. Biemel, H.-G. Gadamer, E. Jünger, R. Munier, C.-F. von Weizsäcker, H. Marcuse, J.-L. Marion, J. Sallis, D. Krell, J. Beaufret, D. Janicaud, O. Pöggeler, J.-L. Chrétien, J.-P. Charcosset, F. Wybrands, J. Taminiaux, H. Dreyfus, M. Froment-Meurice, J.-M. Palmier, R. Schürmann, J.-M. Vaysse, H. Birault, J. Derrida, G. Granel, D. Charles, G. Liiceanu, J. Greisch, R. Gonner), Paris, Éditions de l'Herne, 1983.

« Heidegger, la philosophie et le nazisme », Le Débat, n° 48, janvier-février 1988, avec la participation de Pierre Aubenque, Henri Crétella, Michel Deguy, François Fédier, Gérard Granel, Stéphane Mosès, Alain Renault.

HEIDEGGER, Table ronde organisée à l'E.N.S. par les Archives Husserl de Paris à l'occasion du centenaire de la naissance du philosophe, avec Catherine Chevalley, Jacques Colléony, Jean Grondin, Pierre Rodrigo, Les Études philosophiques, juillet-septembre 1990, pp. 289-372.

«HEIDEGGER, Questions ouvertes II », Le Cabier du Collège international de Philosophie, Paris, éditions Osiris, n° 8, 1989 (contributions de John Sallis, Werner Marx, Nicole Parfait, Karl Løewith, pp. 51-198).

HEIDEGGER, « Semaine de Chexbres (1988) », Genos, Lausanne, 1992 (contributions de Ingeborg Schüssler, Gérard Guest, François Vezin, Wolfgang Brokmeier, Alain David, Alexandre Schild, François Fédier).

«Heidegger et les Grecs», Revue de philosophie ancienne (n° 1 : contributions de M. Zarader, E. Martineau, D. Panis; n° 2 : contributions d'A. Lowit, B. Cassin, M. Villela-Petit, L. Couloubaritsis), Bruxelles, Ousia, 1986.

HERSCH (Jeanne), « Les enjeux du débat autour de Heidegger », Commentaire, été 1988, n° 42, pp. 474-480.

HUSSERL (Edmund), Notes sur Heidegger (suivies d’une étude de

D. SOUCHE-DAGUES sur la « Lecture husserlienne de Sein und Zeit »), Paris, Éditions de Minuit, 1993.

HYPPOLITE (Jean), « Ontologie et phénoménologie chez Martin Heidegger ». Les Études philosophiques, 1954, pp. 307-314.

IRIGARAY (Luce), L'Oubli de l'air chez Martin Heidegger, Paris, Éditions de Minuit, 1983.

JACERME Pierre, « Être et temps : Traduction et interprétation », Revue philosophique, n° 3, 1987, pp. 273-290.

- « À propos de la traduction de Être et temps », Cabiers philosophiques, n° 32, septembre 1987, C.N.D.P., pp. 33-90..

– Même texte, in Heidegger-Studies, vol.3/4, 1987/1988, pp. 155-199.

– « Heidegger en question », Revue philosophique, n° 1, 1989, pp. 93-100.

– « Martin Heidegger et Jean Beaufret : un dialogue », Revue philosophique, n° 4, 2002, pp. 387-402.

JANICAUD (Dominique) et MATTÉI (Jean-François), La Métaphysique à la limite. Cinq études sur Heidegger, Paris, PUF, 1983.

JANICAUD (Dominique), L'Ombre de cette pensée. Heidegger et la question politique, Grenoble, Jérôme Millon, 1990.

JEANNIÈRE (Abel), « L'itinéraire de Martin Heidegger », Études, janvier-mars 1954, pp. 64-74.

JONAS (Hans), « Heidegger et la théologie », trad. L. ÉVRARD, Esprit, juillet-août 1988, pp. 172-195.

KEARNEY (Richard) et O'LEARY (Joseph Stephen) éd., Heidegger et la question de Dieu, Paris, Grasset, 1980.

KELKEL (Arion L.), La Légende de l'être. Langage et poésie chez Heideggen Paris, Vrin, 1980.

KOYRE (Alexandre), «Was ist Metaphysik? par Martin Heidegger», La Nouvelle Revue française, 1931, t. XXXVI, n° CCXII, pp. 750-753.

- «L’évolution philosophique de Heidegger», Critique, n° 1, juin 1946, pp. 73-82; n° 2, juillet 1946, pp. 161-183.

LAFFOURIÈRE (Odette), Le Destin de la pensée et la «mort de Dieu» d'après Heidegger, La Haye, Martinus Nijhoff, 1968.

LARUELLE (François), Nietzsche contre Heidegger. Thèses pour une politique nietzschéenne, Paris, Payot, 1977.

LAUNAY (Jean), « Sartre lecteur de Heidegger, ou l'Être et le Non », Les Temps modernes, octobre-décembre 1990, I, pp. 412-435.

LAUTMANN (Jacques), Essai sur l'unité des mathématiques, 10/18, pp. 203-209.

LÉVINAS (Emmanuel), En découvrant l'existence avec Husserl et Heidegger, Paris, Vrin, 1949.

- «L’ontologie est-elle fondamentale ?», Revue de métaphysique et de morale, janvier-mars 1951, pp. 88-98.

- « Compte rendu sur De l'essence de la vérité », Revue philosophique t. 149, 1959, pp. 561-563.

LÉWITH (Karl), «Les implications politiques de la philosophie de l'existence chez Heidegger», Les Temps modernes, nov. 1946, pp. 343-360.

- «Réponse à M. de Waelhens», Les Temps modernes, août 1948, pp. 370-373.

LOSURDO (Domenico), Heidegger et l'idéologie de la guerre, trad. J.-M.

BUÉE, Paris, PUF, 1998.

LOTZ (Johannes B.), Martin Heidegger et Thomas d'Aquin, trad. P. SECRETAN, Paris, PUF, 1988.

LYOTARD (Jean-François), Heidegger et «lès Juifs », Paris, Galilée, 1988.

MAN (Paul de), «Les exégèses de Hölderlin par Martin Heidegger», Critique, septembre-octobre 1955, pp. 800-819.

MARCEL (Gabriel), « Autour de Heidegger », Cahiers Dieu vivant, n° 2, Paris, Éditions du Seuil, 1945, pp. 89-102.

– « Ma relation avec Heidegger », Présence de Gabriel Marcel, Cahier 1, « G. Marcel et la pensée allemande (Nietzsche, Heidegger, E. Bloch) », Paris, Aubier, 1980, pp. 25-38.

MARION (Jean-Luc), Réduction et donation. Recherches sur Husserl, Heidegger et la phénoménologie, Paris, PUF, 1989.

MASCOLO (Dionys), Haine de la philosophie. Heidegger pour modèle, Paris, Jean-Michel Place, 1993.

MATTÉI (Jean-François), L'Ordre du monde. Platon – Nietzsche – Heidegger, Paris, PUF, 1989.

– Hölderlin et Heidegger. Le C-adriparti, Paris, PUF, 2001.

MESCHONNIC (Henri), Le Langage Heidegger, Paris, PUF, 1990.

MINDER (Robert), « À propos de Heidegger: Langage et nazisme », Critique, n° 237, février 1967, pp. 284-287.

MOUGIN (Henri), « Comme Dieu en France: Heidegger parmi nous », Europe, avril 1946, pp. 132-138.

MUNIER (Roger), « Visite à Heidegger », Cahiers du Sud, n° 312, 1952, pp. 292-296.

– Stèle pour Heidegger, Paris, Arfuyen, 1992.

Nancy (Jean-Luc), «L'éthique originaire de Heidegger», La Pensée dérobée, Paris, Galilée, 2001, pp. 85-113.

Orr (Hugo), Martin Heidegger. Éléments pour une biographie, trad. J.-M. BELCEIL, Postface de J.-M. PALMIER, Paris, Payot, 1990.

PALMIER (Jean-Michel), Les Écrits politiques de Heidegger, Paris, Éditions de l'Herne, 1968.

PANIS (Daniel), Il y a le il y a. L'énigme de Heidegger, Bruxelles, Ousia, 1993.

PARFAIT (Nicole), Une certaine idée de l'Allemagne. L'identité allemande et ses penseurs, de Luther à Heidegger, Paris, Desjonquères, 1999.

PATRI (Aimé), « Heidegger et le nazisme », Le Contrat social, vol. VI, n° 1, janvier-février 1962, pp. 37-42.

PAYOT (Daniel), La Statue de Heidegger. Art, vérité, souveraineté, Belfort, Circé, 1998.

PÖGGELER (Otto), La Pensée de Martin Heidegger, trad. M. Simon, Paris, Aubier, 1967.

POULAIN (Jacques) et SCHIRMACHER (Wolfgang) éd., Penser après Heidegger, Paris, L'Harmattan, 1992.

PRÉAU (André), « L'âge technique d'après Heidegger et Léopold Ziegler », Cabiers du Sud, n° 317, 1953, pp. 93-102.

PRZYWARA (Erich), «Husserl et Heidegger», Les Études philosophiques, janvier-mars 1961, pp. 55-62.

QUILLIEN (Jean), «Philosophie et politique. Heidegger, le nazisme et la pensée française», Germanica, 1990, VIII, pp. 103-142.

RENAUT (Alain), « Heidegger: 1927-1929 », Les Études philosophiques, 1973, n° 3, pp. 355-370.

– «Vers la pensée du déclin», Les Études philosophiques, n° 2, 1975, pp. 197-206.

RUBERCY (Éryck de) et Le BUHAN (Dominique), Douze questions posées à Jean Beaufret à propos de Martin Heidegger, Paris, Aubier, 1983.

SAFRANSKI (Rüdiger), Heidegger et son temps, trad. I. KALINOWSKI, Paris, Grasset, 1996.

SAGAVE (Pierre-Paul), « Martin Heidegger à Aix », Cahiers du Sud, 1957, n° 344, p. 31 de l'encart.

SALANSKIS (Jean-Michel), Heidegger, Paris, Les Belles Lettres, 1997.

SCHÉRER (René) et KELKEL (Arion L.), Heidegger ou l'expérience de la pensée, Paris, Seghers, « Philosophes de tous les temps », 1973.

SCHÜRMANN (Reiner), Le Principe d'anarchie. Heidegger et la question de l'agir, Paris, Éditions du Seuil, 1982.

- Compte rendu critique sur les Beiträge zur Philosophie, Annuaire philosophique 1988-1989, Paris, Éditions du Seuil, 1989, pp. 107-130.

SIPRIOT (Pierre), « Pascal, Léon Bloy, Martin Heidegger », La Table ronde, janvier 1958, pp. 124-131.

SOUCHE-DAGUES (Denise), « Une exégèse heideggérienne : le temps chez Hegel d'après le § 82 de Sein und Zeit », Revue de métaphysique et de morale, t. 84, janvier-mars 1979, pp. 101-120.

-Du «Logos» chez Heidegger, Grenoble, Jérôme Millon. 1999.

STEINER (George), Martin Heidegger, trad. D. de Caprona, Paris, Albin Michel, 1981.

TAMINIAUX (Jacques), Lectures de l'ontologie fondamentale. Essais sur Heidegger, Grenoble, Jérôme Millon, 1989.

— La Fille de Thrace et le penseur professionnel. Arendt et Heidegger, Paris, Payot, 1992.

TAUXE (Henri-Charles), La Notion de finitude dans la philosophie de Martin Heidegger, Lausanne, L'Âge d'homme, 1971.

TEZUKA (Tomio), «Une heure avec Heidegger», Philosophie, n° 69, pp. 20-29.

THIELEMANS (H.), «Existence tragique. La métaphysique du nazisme», Nouvelle Revue Théologique, Louvain, 1936, t. 63, n° 6, pp. 561-579.

TOWARNICKI (Frédéric de), À la rencontre de Heidegger. Souvenirs d'un messager de la Forêt-Noire, Paris, Gallimard, 1993.

– Martin Heidegger. Souvenirs et Chroniques, Paris, Payot/Rivages, 1999.

TROITIGNON (Pierre), Heidegger, Paris, PUF, 1965.

VATTIMO (Gianni), Introduction à Heidegger, trad. J. ROLLAND, Paris, Éditions du Cerf, 1985.

VEYNE (Paul), « À propos d’Heidegger. Responsabilité ou hagiographie du philosophe ? », Raison présente, 1988, n° 87, pp. 27-38.

VIEILLARD-BARON (Louis), Le Temps: Platon, Hegel, Heidegger, Paris, Vrin, 1978.

VIETTA (Silvio), Heidegger critique du national-socialisme et de la technique, trad. Jan OLLIVIER, Puiseaux, Pardès, 1993.

VOLPI (Franco), « Wittgenstein et Heidegger », La Métaphysique, éd. J.-M.

Narbonne et L. Langlois, Paris-Québec, Vrin-PUL, 1999, pp. 61-89.

VUILLEMIN (Jules), L'Héritage kantien et la révolution copernicienne.

Fichte-Cohen-Heidegger, Paris, PUF, 1954.

WAHL (Jean), Vers le concret. Études d'histoire de la philosophie contemporaine, Paris, Vrin, 1932.

– «Heidegger et Kierkegaard. Recherche des éléments originaux de la philosophie de Heidegger», Recherches philosophiques, publiées par A. Koyré, H.-C. Puech et A. Spaier, Paris, Boivin, 1932, pp. 349-370.

– Vers la fin de l'ontologie. Étude sur l'introduction dans la métaphysique par Heidegger, Paris, SEDES, 1956.

– Introduction à la pensée de Heidegger, Paris, Le Livre de Poche-Librairie Générale Française, 1998.

WAELHENS (Alphonse de), La Philosophie de Martin Heidegger, Louvain, Institut supérieur de philosophie, 1942.

– « La philosophie de Heidegger et le nazisme », Les Temps modernes, juillet 1947, pp. 115-127.

– Chemins et impasses de l'ontologie heideggérienne, Paris, Desclée de Brouwer – Louvain, Nauwelaerts, 1953.

WEIL (Éric), «Le cas Heidegger», Les Temps modernes, juillet 1947, pp. 128-138; repris dans Lignes, n° 2, février 1988, pp. 139-151.

WELTE (Bernhard), «Remarques sur l'ontologie de Heidegger», Revue des sciences philosophiques et théologiques, t. XXXI, 1947, pp. 377-393.

- «La question de Dieu dans la pensée de Heidegger», Les Études philosophiques, n° 1, 1964, pp. 69-84.

WITTGENSTEIN (Ludwig), « Sur Heidegger, séance du lundi 30 décembre 1929 (chez Schlick) », Wittgenstein et le Cercle de Vienne, texte original et trad. G. GRANEL, Mauvezin, TER, 1991, pp. 38-39.

WOLIN (Richard), La Politique de l'être, trad. Catherine Goulard, Paris, Kimé, 1992.

ZARADER (Marlène), Heidegger et les paroles de l'origine, Paris, Vrin, 1986.

- La Dette impensée. Heidegger et l'héritage hébraïque, Paris, Éditions du Cerf, 1990.

ALTHUSSER (Louis), L'avenir dure longtemps, Paris, Stock/IMEC, 1992.

- Sur la philosophie, Paris, Gallimard, 1994.

ARENDT (Hannah), Vies politiques, trad. Éric ADDA, Paris, Gallimard, 1974.

ARON (Jean-Paul), Les Modernes, Paris, Gallimard, 1984.

ARON (Raymond), Mémoires, Paris, Julliard, 1983.

ASSOULINE (Pierre), Un demi-siècle d'édition française, Paris, Balland, 1984.

AUBENQUE (Pierre), Le Problème de l'être chez Aristote, Paris, PUF, 1962.

- «Plotin et le dépassement de l'ontologie grecque classique», Le Néoplatonisme, colloque de Royaumont, Paris, Éditions du CNRS, 1971, pp. 101-108.

AUFFRET (Dominique), Alexandre Kojève, Paris, Grasset, 1990.

AXELOS (Kostas), Marx penseur de la technique, Paris, Éditions de Minu 1961.

– Héraclite et la philosophie, Paris, Éditions de Minuit, 1962.

– Vers la pensée planétaire, Paris, Éditions de Minuit, 1964.

– Arguments d'une recherche, Paris, Éditions de Minuit, 1969.

– Métamorphoses, Paris, Éditions de Minuit, 1991.

BADIOU (Alain), L'Être et l'événement, Paris, Éditions du Seuil, 1988.

- Manifeste pour la philosophie, Paris, Éditions du Seuil, 1989.

BARASH (Jeffrey Andrew), Martin Heidegger and the Problem of historical Meaning, Dordrecht-Boston, Nijhoff, 1988.

BARBARAS (Renaud), De l'être du phénomène. Sur l'ontologie de Merleau-Ponty, Grenoble, Millon, 1991.

- Le Désir et la distance. Introduction à une phénoménologie de la perception, Paris, Vrin, 1999.

BARDOUT (Jean-Christophe), Malebranche et la métaphysique, Paris, PUF, 1999.

BATAILLE (Georges), L'Expérience intérieure, Paris, Gallimard, 1954.

BEAUFRET (Jean), « Vers une critique marxiste de l'existentialisme », Revue Socialiste, n° 2, juin 1946, pp. 149-154.

- Le Poème de Parménide, Paris, PUF, 1955 (nouvelle trad. sans l'introduction, La Clayette, Chandeigne, 1984).

- Entretiens avec Frédéric de Towarnicki, Paris, PUF, 1984.

- (hommage à), L'Endurance de la pensée. Pour saluer Jean Beaufret, Paris, Plon, 1968.

- Leçons de philosophie, édition établie par Philippus Bann, Paris, Éditions du Seuil, 1998, 2 vol.

- Leçons de philosophie, édition établie par Philippe Fouillaron, Paris, Éditions du Seuil, 1998, 2 vol.

BEAUVOIR (Simone de), La Force des choses, Paris, Gallimard, 1963.

BENOIST (Alain de), Vu de droite. Anthologie critique des idées contemporaines, Paris, Copernic, 1978.

BIDENT (Christophe), Maurice Blanchot partenaire invisible, Paris, Champ Vallon, 1998.

BLANCHOT (Maurice), Thomas l'obscur, Paris, Gallimard, 1950.

- L'Espace littéraire, Paris, Gallimard, 1955.

- «L'attente», Martin Heidegger zum siebzigsten Geburtstag, Pfullingen, Neske, 1959, pp. 217-224.

- L'Entretien infini, Paris, Gallimard, 1969.

- L'Amitié, Paris, Gallimard, 1971.

- L'Écriture du désastre. P.

BOEHM (Rudolf), La Métaphysique d'Aristote. Le fondamental et l'essentiel, trad. E. MARTINEAU, Paris, Gallimard, 1976.

BOLLACK (Jean) et WISMANN (Heinz), Héraclite ou la séparation, Paris, Éditions de Minuit, 1972.

BORCH-JACOBSEN (Mikkel), Lacan. Le maître absolu, Paris, Champs-Flammarion, 1995.

BOUCHINDHOMME (Christian) et ROCHLITZ (Reiner), « Temps et récit » de Paul Ricœur en débat, Paris, Éditions du Cerf, 1990.

BOULNOIS (Olivier), Être et représentation. Une généalogie de la métaphysique moderne à l'époque de Duns Scot, Paris, PUE, 1994.

BOURSEILLER (Christophe), Les Maoïstes. La folle histoire des gardes rouges français, Paris, Plon, 1996.

BOUTOT (Alain), L'Invention des formes, Paris, Odile Jacob, 1993.

BOUVERESSE (Jacques), Le Mythe de l'intériorité, Paris, Éditions de Minuit, 2° éd., 1987.

- «Les philosophes et la technique», Zouila, n° 4, Hiver 1998, pp. 9-23.

BRAGUE (Rémi), « Heideggers Einfluss auf das französische Geistesleben. Elemente eines Rückblickes auf die bisherige Rezeptionsgeschichte», Theologie und Philosophie, Heft 1, 1982, pp. 21-42.

– Aristotle et la question du monde, Paris, PUF, 1988.

BRAQUE (Georges), Le Jour et la Nuit, Paris, Gallimard, 1952.

– et PRÉVERT (Jacques), Varengeville, Paris, Maeght, 1958.

BRÉHIER (Émile), Histoire de la philosophie allemande, Paris, Vrin, 1953, 3° éd. mise à jour par Paul RICCEUR.

BURNIER (Michel-Antoine), Les Existentialistes et la politique, Paris, Gallimard, coll. « Idées », 1966.

CARRAUD (Vincent), Pascal et la philosophie, Paris, PUF, 1992.

CASSIN (Barbara), Présentation de PARMÉNIDE, Sur la nature ou sur l'étant, Paris, Éditions du Seuil, coll. « Points-Essais », 1998, pp. 9-68.

CAU (Jean), Croquis de mémoire, Paris, Julliard, 1985.

CHAMFORT, Maximes et pensées, Paris, J.-J. Pauvert, 1960.

CHAR (René), Œuvres complètes, Paris, Gallimard, Bibliothèque de la Pléiade, 1983.

— Cahier de l'Herne, René Char, Paris, Éditions de l'Herne, 1971.

CLÉMENT (Catherine), Martin et Hannah, Paris, Calmann-Lévy, 1998.

COHEN-SOLAL (Annie), Sartre, Paris, Gallimard, 1985.

COLETTE (Jacques), L'Existentialisme, Paris, PUF, 1994.

CONTAT (Michel) et RYBALKA (Michel), Les Écrits de Sartre. Chronologie, Bibliographie commentée, Paris, Gallimard, 1970.

COURTINE (Jean-François), Suarez et le système de la métaphysique, Paris, PUF, 1990.

CUVILLIER (Armand), Parti pris sur l'art, la philosophie et l'histoire, Paris, Armand Colin, 1956.

DASTUR (Françoise), Dire le temps. Esquisse d'une chronologie phénoménologique, La Versanne, Encre marine, 1994.

- Hölderlin. Le retournement natal. La Versanne. Encre marine. 1997.

DAVY (Marie-Madeleine), Un philosophe itinérant : Gabriel Marcel, Paris, Flammarion, 1959.

DEBRAY (Régis), Contretemps. Éloges des idéaux perdus, Paris, Gallimard, « Folio », 1992.

– Par amour de l'art. Une éducation intellectuelle, Paris, Gallimard, 1998.

– Introduction à la médiologie, Paris, PUF, 2000.

DELACAMPAGNE (Christian), De l'indifférence, Paris, Odile Jacob, 1998.

DELEUZE (Gilles), Différence et répétition, Paris, PUF, 1968. - et GUATTARI (Félix). L'Anti-Edite Paris Éditions de

- et GUATTARI (Félix), L'Anti-Edipe, Paris, Éditions de Minuit, 1972.

DERRIDA (Jacques), L'Écriture et la différence, Paris, Éditions du Seuil, 1967.

- Marges de la philosophie, Paris, Éditions de Minuit, 1972.

- La Dissémination, Paris, Éditions du Seuil, 1972.

– Positions, Paris, Éditions de Minuit, 1972.

- La Vérité en peinture, Paris, Flammarion, coll. « Champs », 1978.

— La Carte postale de Socrate à Freud et au-delà, Paris, Aubier-Flammarion, 1980.

— Psyché. Inventions de l'autre, Paris, Galilée, 1987.

- Le Problème de la genèse dans la philosophie de Husserl, Paris, PUF, 1990.

-Donner le temps. 1. La Fausse Monnaie, Paris, Galilée, 1991.

- Points de suspension, Entretiens choisis et présentés par Élisabeth

WEBER, Paris, Galilée, 1992.

- Politiques de l'amitié, Paris, Galilée, 1994.

-Apories. Mourir - s'attendre aux «limites de la vérité », Paris, Galilée, 1993.

DESANTT (Dominique), Les Staliniens. Une expérience politique, 1944/1956, Paris, Fayard, 1975.

DESANTI (Jean-Toussaint), Introduction à l'histoire de la philosophie, Paris, Éditions de la Nouvelle Critique, 1956.

DESCOMBES (Vincent), Le Même et l'Autre, Paris, Éditions de Minuit, 1979.

DEUTSCH (Michel), en collaboration avec Philippe LACOUE-LABARTHE. Sit venia verbo, Paris, Bourgois, 1988.

DIELS-KRANZ, Die Fragmente der Vorsokratiker, Berlin, Weidmann, 1960, 3 vol.

DOSSE (François), Histoire du structuralisme, Paris, Éditions La Découverte: I. Le champ du signe, 1945-1966, 1991; II. Le Chant du cygne, 1967 à nos jours, 1992.

DREYFUS (Hubert) et RABINOV (Paul), Michel Foucault. Un parcours philosophique, trad. F. Durand-Bogaert, Paris, Gallimard. 1984.

DUFRENNE (Mikel), Pour l'homme, Paris, Éditions du Seuil, 1968.

ENGEL (Pascal), La Dispute, Paris, Éditions de Minuit, 1997.

(Jean-Pierre), Théorie du récit, Paris, Hermann, 1972.

- Le Vrai Nietzsche. Guerre à la guerre, Paris, Hermann, 1998.

FÉDIER (François), Interprétations, Paris, PUF, 1985.

FÉDIER (François), 1995.

- Regarder voir, Paris, Les Belles Lettres, 1995.

FEICK (Hildegard), Index zu Heideggers «Sein und Zeit», Tübingen, Niemeyer, 1961.

FERRY (Luc) et RENAUT (Alain), La Pensée 68. Essai sur l'anti-humanisme contemporain, Paris, Gallimard, 1968.

FINKIELKRAUT (Alain), La Défaite de la pensée, Paris, Gallimard, 1987.

FOUCAULT (Michel), Folie et déraison. Histoire de la folie à l'âge classique, Paris, Plon, 1961.

Les Mots et les Choses. Une archéologie des sciences humaines, Paris, Gallimard, 1966.

FOULQUIÉ (Paul), L'Existentialisme, coll. « Que sais-je ? », n° 253, Paris, PUF, 1947.

GADAMER (Hans-Georg), Philosophische Lehrjahre, Francfort, Klostermann, 1995.

GANDILLAC (Maurice de), Le Siècle traversé, Paris, Albin Michel, 1998.

GARELLI (Jacques), Rythmes et mondes. Au revers de l'identité et de l'altérité, Grenoble, Millon, 1991.

GAXOTTE (Pierre), Histoire de l'Allemagne, Paris, Flammarion, 1963, 2 vol.

GEFFRÉ (Claude), Le Nouvel Âge de la théologie, Paris, Éditions du Cerf, 1987.

– Le Christianisme au risque de l'interprétation, Paris, Éditions du Cert, 1988.

– Profession-théologien, Paris, Albin Michel, 1999.

– éd., Procès de l'objectivité de Dieu, Paris, Éditions du Cert, 1969. GILSON (Etienne), L'Etre et l'essence, Paris, Vrin, 1

GLUCKSMANN (André), Les Maitres penseurs, Paris, Grasset, 1977.

GOLDSCHMIDT (Georges-Arthur), La Traversée des fleuves, Paris, Éditions du Seuil, 1999.

GRANEL (Gérard), Le Sens du temps et de la perception chez E. Husserl, Paris, Gallimard, 1968.

- L'Équivoque ontologique de la pensée kantienne, Paris, Gallimard, 1970.

- Traditionis traditio, Paris, Gallimard, 1972.

- De l'université, Mauvezin, TER, 1982.

- Écrits logiques et politiques, Paris, Gallée, 1990.

- Études, Paris, Gallée, 1995.

GRANGER (Gilles-Gaston), Pour la connaissance philosophique, Paris, Odile Jacob, 1988.

GREISCH (Jean) et KEARNEY (Richard) ed., Les Métamorphoses de la raison herméneutique, Paris, Éditions du Cert, 1991.

GUITTON (Jean), Le Clair et l'Obscur, Paris, Librairie Auguste Blaizot, 1962.

- Profils parallèles, Paris, Fayard, 1970.

HADOT (Pierre), « Heidegger et Plotin », Critique, n° 145, juin 1959, pp. 539-556.

HAN (Béatrice), L'Ontologie manquée de Michel Foucault, Grenoble, Millon, 1998.

HAVILAND (Éric), Kostas Axelos. Une vie pensée - une pensée vécue, Paris, L'Harmattan, 1995.

HEGEL, Phänomenologie des Geistes, ed. Hoffmeister, Hambourg, Meiner, 1952; Phénoménologie de l'esprit, trad. J.-P. Lefebvre, Paris, Aubier, 1991.

- «Differenz des Fichteschen und Schellingschen Systems der Philosophie», Werke in zwanzig Bänden, Francfort, Suhrkamp, 2 (Jenaer Schriften), 1970, pp. 7-138.

- Premières publications.

HEIDEGGER (Martin), Vier Seminare, trad. allemande des protocoles français par Curd Ochwadt, Francfort, Klostermann, 1977.

– et FINK (Eugen), Heraklit, Francfort, Klostermann, 1970.

– Contributions to Philosophy, trad. anglaise P. Emad et K. Maly, Bloomington, Indiana University Press, 1999.

– (hommage à) : Martin Heidegger zum siebzigsten Geburstag, Pfullingen, Neske, 1959.

HENRY (Michel), Généalogie de la psychanalyse, Paris, PUF, 1985.

- Phénoménologie matérielle, Paris, PUF, 1990.

– Incarnation. Une philosophie de la chair, Paris, Éditions du Seuil, 2000.

HERING (Jean), Phénoménologie et philosophie religieuse. Étude sur la théorie de la connaissance religieuse, Paris, Alcan, 1926.

HOTTOS (Gilbert), Le Signe et la Technique, Paris, Aubier, 1984.

HYPPOLITE (Jean), Figures de la pensée philosophique, Paris, PUF, 1971, 2 vol.

JANICAUD (Dominique), Le Tournant théologique de la phénoménologie française, Combas, Éditions de l'Éclat, 1990.

- À nouveau la philosophie, Paris, Albin Michel, 1991.

– Chronos. Pour l'intelligence du partage temporel, Paris, Grasset, 1997.

– La Phénoménologie éclatée, Combas, Éditions de l'Éclat, 1998.

JAUSS (Hans Robert), Pour une esthétique de la réception, trad.

C. Maillard, Préface de Jean Starobinski, Paris, Gallimard, 1978.

JOSEPH (Gilbert), Une si douce occupation... Simone de Beauvoir et Jean-Paul Sartre, 1940-1944, Paris, Albin Michel, 1991.

JURANVILLE (Alain), Lacan et la philosophie, Paris, PUF, 1984.

KANT, Œuvres philosophiques, I, trad. sous la dir. de F. Alquié, Paris, Gallimard, Bibliothèque de la Pléiade, 1980.

KISIEL (Theodore), The Genesis of Heidegger's «Being and Time», Berkeley-Los Angeles, University of California Press, 1983.

KLEMPERER (Victor), LTI. La Langue du IIIe Reich, trad. E. Guillot, Paris, Albin Michel, 1996.

KOJÈVE (Alexandre), Introduction à la lecture de Hegel, Paris, Gallimard, 1947.

LACAN (Jacques), Écrits, Paris, Éditions du Seuil, 1966.

Lacan avec les philosophes (collectif), Bibliothèque du Collège international de Philosophie, Paris, Albin Michel, 1991.

LACOSTE (Jean-Yves) dir., Dictionnaire critique de théologie, Paris, PUF, 1998.

LACOUE-LABARTHE (Philippe), « Typographie », Mimésis des articulations, Paris, Aubier-Flammarion, 1975, pp. 165-270.

– Le Sujet de la philosophie (Typographies I), Paris, Aubier-Flammarion, 1979.

— Rejouer le politique, Paris, Galilée, 1981.

- L'Imitation des modernes. (Typographies II), Paris, Galilée, 1986.

- La Poésie comme expérience, Paris, Bourgois, 1986.

— La Fiction du politique, Paris, Bourgois, 1988.

- et NANCY (Jean-Luc), Le Titre de la lettre. Une lecture de Lacan, Paris, Galilée, 1973.

- Le Mythe nazi, La Tour d'Aigues, Éditions de l'Aube, 1991.

LEBRUN (Gérard), Kant et la fin de la métaphysique, Paris, Armand Colin, 1970.

LECOURT (Dominique), Contre la peur, Paris, Hachette, 1990.

LEFEBVRE (Jean-Pierre), « Auch die Stege sind Holzwege », Hölderlin vu de France, ed. B. BÖSCHENSTEIN et J. LE RIDER, Tübingen, Günter Narr, 1987, pp. 53-76.

LE RIDER (Jacques), Nietzsche en France. De la fin du XIXe siècle au temps présent, Paris, PUF, 1999.

LESCOURRET (Anne-Marie), Emmanuel Lévinas, Paris, Flammarion, 1994.

LÉVINAS (Emmanuel), Théorie de l'intuition dans la phénoménologie de Husserl, Paris, Vrin, 1930.

Husserl, Paris, Vrin, 1930.

- De l'existence à l'existant, Paris, Éditions de la revue Fontaine, 1947.

- Totalité et infini, La Haye, Martinus Nijhoff, 1961; rééd. Paris, Kluwer-Le Livre de Poche, 1990.

- Difficile liberté, Paris, Albin Michel, 1963.

- Autrement qu'être ou au-delà de l'essence, La Haye, Martinus Nijhoff, 1974.

- Le Temps et l'Autre, Montpellier, Fata Morgana, 1979; Paris, PUF, 1983.

— Entre nous. Essai sur le penser-à-l'autre, Paris, Grasset, 1992.

LÉVI-STRAUSS (Claude), Les Structures élémentaires de la parenté, Paris, PUF, 1949.

- Anthropologie structurale, Paris, Plon, 1958.

LÉVY (Pierre), Qu'est-ce que le virtuel?, Paris, La Découverte, 1995.

LÉWITH (Karl), Ma vie en Allemagne avant et après 1933, trad.

M. LEBEDEL, Paris, Hachette, 1988.

LOREAU (Max), La Genèse du phénomène. Le phénomène, le logos, l'origine, Paris, Éditions de Minuit, 1989.

LUKACS (Georges), Existentialisme ou marxisme?, trad. E. KELEMEN, Paris, Nagel, 1948; 2° éd., 1961.

LYOTARD (Jean-François), La Phénoménologie, Paris, PUF, 1954.

- Dérive à partir de Marx et Freud, Paris, UGE, 1973.

– Économie libidinale, Éditions de Minuit, 1974.

MALABOU (Catherine) en collaboration avec Jacques DERRIDA, Jacques Derrida. La Contre-allée, Paris, La Quinzaine-Louis Vuitton, 1999.

MALDINEY (Henri), Regard, Parole, Espace, Lausanne, L'Âge d'homme, 1973.

- Aîtres de la langue et demeures de la pensée, Lausanne, L'Âge d'homme, 1975.

- L'Art, l'éclair de l'être. Traversées, Seyssel, Éditions Comp'Act, 1993.

– Penser l'homme et la folie. À la lumière de l'analyse existentielle et de l'analyse du destin, Grenoble, Millon, 1991.

MARCEL (Gabriel), La Dimension Florestan, Paris, Plon, 1958.

MARION (Jean-Luc), Sur l'ontologie grise de Descartes, Paris, Vrin, 1975.

– L'Idole et la Distance, Paris, Grasset, 1977.

– Dieu sans l'être, Paris, Fayard, 1982.

– Sur la théologie blanche de Descartes, Paris, PUF, 1981.

– Sur le prisme métaphysique de Descartes, Paris, PUF, 1986.

– Étiant donné. Essai d'une phénoménologie de la donation, Paris, PUF, 1997.

MARQUET (Jean-François), Singularité et événement, Grenoble, Millon, 1995.

MATTÉI (Jean-François) éd., La Naissance de la raison en Grèce, Paris, PUF, 1990.

MAULNIER (Thierry), Introduction à la poésie française, Paris, Gallimard, 1939.

MAY (Reinhard), Heidegger's hidden Sources, trad. anglaise G. Parkes, Londres-New York, Routledge, 1996.

MERLEAU-PONTY (Maurice), Phénoménologie de la perception, Paris, Gallimard, 1945.

- Humanisme et terreur. Essai sur le problème communiste, Paris, Gallimard, 1947.

MONGIN (Olivier), Paul Ricœur, Éditions du Seuil, 1994.

MOUGIN (Henri), La Sainte Famille existentialiste, Paris, Éditions sociales, 1947.

MOUNIER (Emmanuel), Introduction aux existentialismes, Paris, Denoël, 1947.

Nancy (Jean-Luc), Le Partage des voix, Paris, Galilée, 1982.

Nancy (Jean-Luc), Le Tage des vues, 1987.

- Des lieux divins, Mauvezin, TER, 1987.

- Une pensée finie, Paris, Galilée, 1990.

- Le Sens du monde, Paris, Galilée, 1993.

NESKE (Günther) ed., Martin Heidegger zum siebzigsten Geburtstag, Pfullingen, Neske, 1959.

OLIVETTI (Marco) dir., La recezione italiana di Heidegger, Padoue, Cedam, 1989.

OTTO (Walter F.), Dionysos. Le mythe et le culte, trad. P. Lévy, Paris, Mercure de France, 1969.

- Les Dieux de la Grèce, trad. C.-N. Grimbert et A. Morgant, Préface de Marcel DETIENNE, Paris, Payot, 1981.

— Essais sur le mythe, trad. P. David, Mauvezin, TER, 1987.

PALMIER (Jean-Michel), Présentation d'Herbert Marcuse, Paris, Plon, 1968.

- Ernst Jünger : rêveries sur un chasseur de cicindèles, Paris, Hachette, 1995.

PÉNARD (Jean), Rencontres avec René Char, Paris, José Corti, 1991.

PETZET (Heinrich), Auf einen Stern zugehen, Francfort, Societäts-Verlag, 1983.

PINSON (Jean-Claude), Habiter en poète. Essai sur la poésie contemporaine, Seyssel, Champ Vallon, 1995.

PINTO (Louis), Les Neveux de Zarathoustra. La réception de Nietzsche en France, Paris, Éditions du Seuil, 1995.

POIRIE (François), Emmanuel Lévinas, Lyon, La Manufacture, 1987.

POLITZER (Georges), Écrits I. La Philosophie et les Mythes, textes réunis par Jacques DEBOUZY, Paris, Éditions sociales, 1969.

POMEAU (René), Mémoires d'un siècle entre XIX et XXI, Paris, Fayard, 1999.

QUILLIEN (Jean) éd., La Réception de la philosophie allemande en France aux XIX et XX siècles, Presses universitaires de Lille, 1994.

RAND (Nicholas), Le Cryptage et la vie des œuvres, Paris, Aubier, 1989.

REDFERN (W. D.), Paul Nizan, Princeton, University Press, 1972.

RENAUT (Alain), «Système et histoire de l'être», Les Études philosophiques, n° 2, 1974, pp. 245-264.

- «La nature aime à se cacher», Revue de métaphysique et de morale, janvier-mars 1976, pp. 62-111.

– éd.. Histoire de la philosophie politique, Paris, Calmann-Lévy, 1999REVEL (Jean-François), Pourquoi des philosophes?, Paris, Julliard, 1957.

RICHARDSON (William J.), Heidegger. Through Phenomenology to Thought, La Haye, Martinus Nijhoff, 1963.

RICHIR (Marc), Méditations phénoménologiques. Phénoménologie et phénoménologie du langage, Grenoble, Millon, 1992.

– L'Expérience du penser. Phénoménologie, philosophie, mythologie, Grenoble, Millon, 1996.

RICCEUR (Paul), Entretiens Paul Ricceur-Gabriel Marcel, Paris, Aubier, 1968.

– Le Conflit des interprétations. Essais d'herméneutique, Paris, Éditions du Seuil, 1969.

- La Métaphore vive, Paris, Éditions du Seuil, 1975.

– Temps et récit, Paris, Éditions du Seuil, 1983-1985, 3 vol.

–Du texte à l'action. Essais d'herméneutique II, Éditions du Seuil, 1986.

—Soi-même comme un autre, Paris, Éditions du Seuil, 1990.

– Réflexion faite. Autobiographie intellectuelle, Paris, Éditions Esprit, 1995.

— La Critique et la conviction. Entretien avec François Azouvi et Marc de Launay, Paris, Calmann-Lévy, 1995.

ROCKMORE (Tom), Heidegger and French Philosophy, Londres-New York, Routledge, 1995.

ROMANO (Claude), L'Événement et le Monde, Paris, PUF, 1998.

- L'Événement et le Temps, Paris, PUF, 1999.

ROUDINESCO (Élisabeth), Histoire de la psychanalyse en France, Paris, Éditions du Seuil, 1986.

-Jacques Lacan, Paris, Fayard, 1993.

ROVAN (Joseph), Mémoires d'un Français qui se souvient d'avoir été Allemand, Paris, Éditions du Seuil, 1999.

SALANSKIS (Jean-Michel), Herméneutique formelle, Paris, Éditions du

C.N.R.S., 1991.

SARTRE (Jean-Paul), L'Être et le Néant. Essai d'ontologie phénoménologique, Paris, Gallimard, 1943. SARTRE (Jean-Paul), L'Etre et le Neant. Essa gique, Paris, Gallimard, 1943.

- L'existentialisme est un humanisme, Paris, Nagel, 1946.

- Situations I, Paris, Gallimard, 1947.

- Situations IV, Paris, Gallimard, 1964.

- Cabiers pour une morale, Paris, Gallimard, 1982.

- Les Carnets de la drôle de guerre, Paris, Gallimard, 1983.

- Vérité et existence. Paris, Gallimard, 1989.

SASSO (Robert), Georges Bataille : le système du non-savoir, Paris, Éditions de Minuit, 1978.

SCHNEEBERGER (Guido), Nachlese zu Heidegger, Berne (chez l'auteur), 1962.

SCHULZ (Walter), Die Vollendung des Deutschen Idealismus in der Spätphilosophie Schellings, Stuttgart, Kohlhammer, 1955.

SCHÜRMANN (Reiner), Des hégémonies brisées, Mauvezin, TER, 1996.

SÉRIS (Jean-Pierre), La Technique, Paris, PUF, 1994.

SERRES (Michel), Atlas, Paris, Julliard, 1994.

Sollers (Philippe), Studio, Paris, Gallimard, 1997.

Souche-Dagues (Denise), Nihilismes, Paris, PUF, 1996.

SOULEZ (Antonia) éd., Manifeste du Cercle de Vienne et autres écrits, Paris, PUF, 1985.

STIEGLER (Bernard), La Technique et le Temps. 1. La Faute d'Épiméthée, Paris, Galilée / Cité des sciences et de l'industrie, 1994; 2. La Désorientation, 1996.

TAMINIAUX (Jacques), Lè Théâtre des philosophes. La tragédie, l'être, l'action, Grenoble, Jérôme Millon, 1995.

THOM (René), « Halte au hasard, silence au bruit », Le Débat, n° 3, juillet-août 1980, pp. 11-132.

- «La science en crise ?», Le Débat, n° 18, janvier 1982, pp. 34-43.

— Paraboles et catastrophes, Paris, Flammarion, 1983.

VEYNE (Paul), « Char et Sade », La Nouvelle Revue française, mars 1984, pp. 1-19.

- René Char en ses poèmes, Paris, Gallimard, 1990.

- «René Char et l'expérience de l'extase», La Nouvelle Revue française, novembre-décembre 1995, pp. 3-25.

VEZIN (François) (hommage à), L'Enseignement par excellence, textes rassemblés par Pascal DAVID, Paris, L'Harmattan, 2000.

VOLPI (Franco), Heidegger e Aristotele, Padoue, Daphne, 1984.

WAHL (Jean), Petite bistoire de « l'existentialisme », Paris, Club Maintenant, 1947.

- Traité de métaphysique. Paris. Pavot. 1953.

WARIN (François), Nietzsche et Bataille. La parodie à l'infini, Paris, PUF, 1994.

WEIL (Éric), Logique de la philosophie, Paris, Vrin, 1951.

WITTGENSTEIN (Ludwig), Tractatus logico-philosophicus, Francfort, Suhrkamp, 1971.

ZARADER (Marlène), L'Être et le Neutre. À partir de Maurice Blanchot, Lagrasse, Verdier, 2001.
