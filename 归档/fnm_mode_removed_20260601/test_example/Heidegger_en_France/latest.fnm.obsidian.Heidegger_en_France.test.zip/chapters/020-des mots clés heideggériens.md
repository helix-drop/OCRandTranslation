## des mots clés heideggériens

Index historique des traductions françaises de mots clés heideggériens

En matière de traduction, aucun index n'est une panacée. Surtout s'il entend prescrire mécaniquement la «bonne» traduction, il risque de devenir un cruel et stérile lit de Procuste.

Dans le cas présent, notre but n'est nullement de présenter au lecteur une grille idéale qui représenterait le compendium de « nos solutions », après tant de tentatives plus ou moins heureuses. Ce serait une entreprise uniquement prescriptive, excessivement ambitieuse et — au demeurant — utopique (car détachée des contextues). Beaucoup plus modestement et à un niveau essentiellement documentaire, sans d'ailleurs viser l'exhaustivité, l'index qui suit devrait être doublement utile : au lecteur du présent ouvrage, pour mieux s'y retrouver dans la terminologie si particulière à Heidegger ; au spécialiste, pour obtenir une vue synoptique des différentes « couches » de traductions déjà proposées, surtout lorsqu'il s'agit des termes les plus essentiels.

Un tel bilan n'a jamais été effectué sous cette forme. Différents index ont certes déjà été proposés, mais aucun d'entre eux n'a eu - à notre connaissance - le caractère récapitulatif et «historique » que nous entendons donner à celui-ci.

Nous avons eu l'idée d'entreprendre une telle tâche, en constatant que le foisonnement des traductions s'est souvent opéré de manière « sauvage », dans l'ignorance (feinte ou réelle) de travaux antérieurs. L'occasion nous a été donnée de mettre un peu d'ordre et surtout plus de clarté au sein d'une véritable jungle herméneutique. Mais nous ne prétendons ni être complet ni nous ériger en arbitre ultime. Alors que, dans le cours du texte, il nous a paru normal et légitime de donner notre avis sur tel ou tel point de traduction, l'index que voici reste « neutre ». Conformément à la loi du genre, il se borne à enregistrer la date d'apparition d'une traduction et son auteur : pour chaque terme allemand, les traductions sont présentées dans l'ordre chronologique. Le rappel constant des dates peut paraître redondant ; nous avons cependant pensé qu'il faciliterait considérablement l'utilisation de l'index en faisant apparaître, au premier coup d'œil, la sédimentation chronologique des traductions. On s'étonnera peut-être de voir réapparaître parfois le mot allemand : il s'agit évidemment des cas où la non-traduction a été jugée préférable. Les noms et les dates renvoient à la bibliographie sélective quand ils ne sont pas répertoriés dans les abréviations et sigles. La mention « etc. » signale que la traduction citée est adoptée par la très grande majorité des traducteurs et interprètes.

On notera également que nous avons élargi notre enquête hors du pré carré des traductions proprement dites, l'inventivité en la matière s'étant parfois manifestée au détour d'une interprétation, en particulier chez Jean

Beaufret (on notera à son propos que la date de 1985, postérieure à son décès, renvoie à la date de publication du vol. IV de Dialogue avec

Heidegger qui regroupe des textes dont la composition s'étage, en fait, de

1976 à 1982).

ABRÉVIATIONS ET SIGLES

AB : Qu'est-ce que la philosophie?, trad. Kostas Axelos et Jean Beaufret, Paris, Gallimard, 1957.

BARASH : Jeffrey A. BARASH, Heidegger et son siècle, Paris, PUF, 1995.

BEAUFRET : Jean BEAUFRET, « A propos de l'existentialisme », Confluences, nouvelle série, 2-6, Lyon, 1945.

– Introduction aux philosophies de l'existence, Paris, Denoël/Gonthier, 1971.

– Dialogue avec Heidegger, III. Approche de Heidegger, Paris, Éditions de Minuit, 1974.

– Dialogue avec Heidegger, IV. Le Chemin de Heidegger, Paris, Éditions de Minuit, 1985.

B-F : «La fin de la philosophie et la tâche de la pensée», trad. Jean Beau-fret et François Fédier, Kierkegaard vivant, Paris, Gallimard, 1966, pp. 167-204.

B-J : trad. de « Hegel et les Grecs », trad. Jean Beaufret et Dominique Janicaud, Questions II, Paris, Gallimard, 1968, pp. 41-68.

BROKMEIER : Chemins qui ne mènent nulle part, trad. Wolfgang Brokmeier, Paris, Gallimard, 1962.

BW : L'Être et le Temps, I, trad. Rudolf Boehm et Alphonse de Waelhens, Paris, Gallimard, 1964.

BIRAULT : Henri BIRAULT, « Heidegger et la pensée de la finitude », Revue internationale de philosophie, n° 52, 1960, pp. 135-162.

BOUTOT : De l'essence de la vérité, trad. Alain Boutot, Paris, Gallimard, 2001.

CORBIN : « Qu’est-ce que la métaphysique ? », trad. par M. Corbin-Petit-thenry, Bifur, n° 8, juin 1931, pp. 1-27.

- Qu'est-ce que la métaphysique ?, trad. Henry Corbin, Paris, Galli-mard, 1938.

COURTINE : trad. de Schelling, Paris, Gallimard, 1977.

– trad. de Les Problèmes fondamentaux de la phénoménologie, Paris, Gallimard, 1985.

DASTUR : Françoise DASTUR, Heidegger et la question du temps, Paris, PUF, 1990 (voir en particulier les «Remarques sur la traduction de certains termes » aux pages 119-124).

DERRIDA : Jacques DERRIDA, De l'esprit, Paris, Galilée, 1987.

DJ : Dominique JANICAUD, La Puissance du rationnel, Paris, Gallimard, 1985.

– Note sur la trad. de Dasein, « Être et temps » de Martin Heidegger, Marseille, Sud, 1989, p. 46.

FÉDIER : François Fédier, trad. de « Temps et être », L’Endurance de la pensée. Pour saluer Jean Beaufret, Paris, Plon, 1968, pp. 12-71.

– trad. de Acheminement vers la parole, Paris, Gallimard, 1976.

– trad. de « Ce qu'est et comment se détermine la Physis », Questions II, Paris, Gallimard, 1968, pp. 165-276.

– «… Voir sous le voile de l'interprétation… Cézanne et Heidegger», Kunst und Technik, Gedächtnisschrift zum 100. Geburstag von Martin Heidegger, Francfort, Klostermann, 1989, pp. 331-347, reprod. in François FÉDIER, Regarder voir, Paris, Les Belles Lettres, 1995, pp. 19-42.

- « Traduire les Beiträge... », in Regarder voir, op. cit., pp. 83-117.

– trad. de «Die Differenz und das Nichts», in L’Enseignement par excellence. Hommage à François Vezin, Paris, L’Harmattan, 2000, pp. 10-13.

FH : Les Hymnes de Hölderlin : La Germanie et Le Rhin, trad. François

Fédier et Julien Hervier, Paris, Gallimard, 1988.

GRANEL: Gérard Granel, « Contribution à la question de l'être », Questions I, Paris, Gallimard, 1968, pp. 195-252.

– trad. inédite (dactylogramme) des § 45 et 54 à 63 de Sein und Zeit (université de Toulouse, Unité de valeur PH 393, « Allemand philosophique », 1978-1979).

GUEST : Gérard GUEST, « L'aîtrée de l'être », Cahiers philosophiques, 41, 1989 (CDP, 29 rue d'Ulm, 75005 PARIS).

GURVITCH: Georges GURVITCH, Les Tendances actuelles de la philosophie allemande, Paris, Vrin, 1930.

HAAR: «Esquisses tirées de l’atelier», trad. Michel HAAR, Cahier de l’Herne Heidegger, 1983, pp. 81-83.

– Michel HAAR, Le Chant de la terre, Paris, L'Heme, 1987.

– id., Heidegger et l'essence de l'homme, Grenoble, Millon, 1990.

KAHN : trad. Introduction à la métaphysique, Paris, PUF, 1958.

LAUNAY : Réponses et questions sur l'histoire et la politique, trad. Jean

Launay, Paris, Mercure de France, 1977.

LÉVINAS : Emmanuel LÉVINAS, « Martin Heidegger et l'ontologie », Revue philosophique, mai-juin 1932, pp. 395-431.

LOREAU : Max LOREAU, La Genèse du phénomène, Paris, Éditions de

Minuit. 1989.

L-R : trad. de Jean Lauxerois et Claude Roëls, Questions IV, Paris, Gallimard, 1976.

MARTINEAU : Être et temps, trad. Emmanuel Martineau, Paris, Authentica, 1985.

LOWIT : Alexandre Lowit, « Le “principe” de la lecture heideggérienne de Parménide », Revue de philosophie ancienne, Bruxelles, 1986, n° 2, pp. 163-210.

MUNIER : Lettre sur l'humanisme, trad. Roger Munier, Paris, Aubier, 1957.

PRÉAU : André Préau, trad. de Heidegger, Essais et conférences, Paris, Gallimard, 1958.

- «Sérédité», trad. André Préau, Questions III, Paris, Gallimard, 1966.

- «Identité et différence», trad. André Préau, Questions I, Paris, Gallimard, 1968.

- «La doctrine platonicienne de la vérité», trad. André Préau, Questions II, Paris, Gallimard, 1968.

ROVAN: Joseph Rovan (sous le pseudonyme de Rosenthal), trad. d'extraits de Sein und Zeit, Lyon, L'Arbalète, été-automne 1941, pp. 33-48.

- « La remontée au fondement de la métaphysique », Fontaine, n° 58, mars 1947, pp. 888-898.

SARTRE: Jean-Paul Sartre, L'Être et le Néant, Paris, Gallimard, 1943.

SCHILD: Alexandre Schild, trad. de Heidegger, L'Affaire de la pensée, Mauvezin, TER, 1990.

SCHÜRMANN: Reiner SCHÜRMANN, Le Principe d'anarchie, Paris, Éditions du Seuil, 1982.

- Les Hégémonies brisées, Mauvezin, TER, 1996.

VEZIN: Être et temps, trad. François Vezin, Paris, Gallimard, 1986.

W-BIEMEL: De l'essence de la vérité, trad. A. de Waelhens-W. Biemel, Louvain-Paris, Nauwelaerts-Vrin, 1948.

ANWESEN : adestance, présence (KAHN, 1958) ; présence (PRÉAU, 1958) ; approche, déploiement en présence (FÉDIER, 1968).

ANWESENHEIT : adestance (KAHN, 1958); Pré-sence (GRANEL, 1968); «présence» (BW, 1964); présence (B-J, 1968; MARTINEAU, 1985); avancée-de-l'être, παρουσία (FÉDIER, 1968); présentété (VEZIN, 1986).

AUSLEGUNG : explicitation, interprétation (BW, 1964 ; MARTINEAU, 1985)); lecture (GRANEL, 1978-79); explicitation (VEZIN, 1986).

BEFINDLICHKEIT: état émotif (GURVITCH, 1930); disposition affective (LÉVINAS, 1932); situation-affective (CORBIN, 1938); sentiment de la situation (BW, 1964); le « comment ça va », la façon dont on se trouve (GRANEL, 1978-79); affection (MARTINEAU, 1985); disposibilité (VEZIN, 1986); affectivité (HAAR, 1990).

BEWANDTNS : finalité (BW, 1964) ; « ce dont il retourne » (GRANEL, 1978-79) ; tournure (MARTINEAU, 1985) ; tournure, finalité, destination (COURTINE, 1985) ; conjointure (VEZIN, 1986).

BRAUCH : maintien (BROKMEIER, 1962) ; utilisation, maintien (HAAR, 1990).

DASEIN : existence (GURVITCH, 1930 ; CORBIN, 1931 ; ROVAN, 1941 ; MUNIER, 1957) ; réalité-humaine (CORBIN, 1938 ; SARTRE, 1943) ; Dasein, présence, me voilà ! (BEAUFRET, 1945) ; être-le-là (MUNIER, 1957) ; l'être-Là (KAHN, 1958) ; être-là (BW,1964) ; Dasein (W-BIEMEL, 1948 ; GRANEL, 1978-79 ; COURTINE, MARTINEAU, 1985 ; VEZIN, 1986) ; Existant, Ek-sistant (DJ, 1989).

DESTRUKTION : Dé-construction (GRANEL, 1968) ; destruction (BW, 1964 ; AB, 1957 ; MARTINEAU, 1985) ; désobstruction (VEZIN, 1986).

EIGENTLICHKEIT: authenticité (BW, 1964; GRANEL, 1978-79; MARIT-NEAU, 1985); propriété (VEZIN, 1986); « propriété », « authenticité » (DASTUR, 1990).

ENTBERGUNG : dévoilement (W-BIEMEL,1948) ; déclosion dans l'ouverture (FÉDIER, 1968) ; désabritement (B-J, 1968 ; FÉDIER, 1976) ; décryptation (LOWIT, 1986) ; découvrement (HAAR, 1990).

ENTBORGENHEIT : être dévoilé (W-BIEMEL, 1948) ; délatence (KAHN, 1958).

ENTSCHLOSSENHEIT: résolution résignée (GURVITCH, 1930); décision-résolue (CORBIN, 1938; SARTRE, 1943); acceptation résolue (WBIEMEL, 1948); résolution, décision déterminée, résolvance déterminée, ouverture déterminée (KAHN, 1958); résolution (GRANEL, 1978-79 : MARTINEAU, 1985 : VEZIN, 1986) ; être-résolu (HAAR, 1990).

ENTWURF : pro-jet (CORBIN, 1938 ; BW, 1964) ; projet (MUNIER, 1957 ; MARTINEAU, 1985) ; projection (VEZIN, 1986).

EREIGNIS : événement (KAHN, 1958 ; MARTINEAU, 1985); avènement (PRÉAU, 1958; L-R, 1976); Événement (GRANEL, 1968); Ereignis, appropriement (FÉDIER, 1968, 1995); événement d'appropriation (SCHÜRMANN, 1996); amêmement (FÉDIER, 2000).

ERSCHLOSSENHEIT : réalité-révélée, réalité révélée à elle-même (CORBIN, 1938) ; illumination (BEAUFRET, 1945) ; patience (KAHN, 1958) ; révélation, ouverture (BW, 1964) ; apérité, ouverture (GRANEL, 1978-79) ;

ouverture (MARTINEAU, 1985 ; HAAR, 1987, 1990) ; ouvertude (VEZIN, 1986).

EXISTENZ: existence, ex-sistance (CORBIN, 1938); existence (BW, 1964; MARTINEAU, 1985; VEZIN, 1986).

FAKTIZITÄT : facticité (SARTRE, 1943 ; BW, 1964 ; MARTINEAU, 1986) ;

factualité (GRANEL, 1978-79) ; factivité (VEZIN, 1986).

FUGE : ajointement, accord (BROKMEIER, 1962); jointure (COURTINE, 1977).

FÜGUNG : injonction (MUNIER, 1957) ; disposition (KAHN, 1958) ; ajointement, jointoiement (COURTINE, 1977).

FÜRSORGE: « sympathie intentionnelle » (GURVITCH, 1930); assistance (BW, 1964); sollicitude (MARTINEAU, 1985; DASTUR, 1990); souci mutuel (VEZIN, 1986).

GEGEND : les entours (BW, 1964) ; contrée (PRÉAU, 1966 ; FÉDIER, 1976 ; MARTINEAU, 1985) ; coin (VEZIN, 1986).

GEHEIMNIS : mystère (W-BIEMEL, 1948) ; secret (PrÉAU, 1966).

GELASSENHEIT : souple douceur (W-BIEMEL, 1948); sérénité, égalité d'âme (PRÉAU, 1966); désinvolture (BEAUFRET, 1971); délaissement (SCHÜRMANN, 1982); acquiescement, désinvolture (BEAUFRET, 1985); laisser être (HAAR, 1987).

WUbUTU J pqr|uryu 8\ÙfY^Qc< AICB9 K rqvqrtqwu 8Rg< AIFD K ]QbdY^UQe< AIHE9 K o~=tyt 8fUjY^< AIHF9>

GESCHEHEN : historical (CORBIN, 1938) ; avoir lieu, se produire, pro-venir (KAHN, 1958) ; provenir (MARTINEAU, 1985) ; aventure (VEZIN, 1986).

GESCHICHTE : pro-venance (KAHN, 1958) ; histoire (MUNIER, 1957 ; BW, 1964 ; MARTINEAU, 1985 ; VEZIN, 1986).

GESCHICHTLICH : historical (CORBIN, 1938; MARTINEAU, 1985; VEZIN, 1986); historique (BARASH, 1995).

GESCHICHTLICHKEIT : historicité (CORBIN, 1938 ; BW, 1964 ; BARASH, 1995) ; historialité (MARTINEAU, 1985 ; VEZIN, 1986).

GESCHICK: destinée (CORBIN, 1938); pro-de-stin (KAHN, 1958); destiné (MUNIER, 1957; BW, 1964); « destin » (MARTINEAU, 1985; VEZIN, 1986); envoi, destination (HAAR, 1987); dispensation (LOREAU, 1989).

GESTELL (ou GE-STELL) : Ge-stell (GRANEL, 1968); arraisonnement (PRÉAU, 1958); Gestell (L-R, 1976); Dis-positif (HAAR, 1983); Dispositif (DJ, 1985).

GEVIERT : Cadran (GRANEL, 1968) ; cadre (FÉDIER, 1976) ; Quadriparti (PRÉAU, 1958) ; Quadrité, Uniquadrité, croisée (BEAUFRET, 1985) ; Mise en quatre, Tétrade (LOREAU, 1989).

GEWESENHEIT : être-ayant-été (CORBIN, 1938) ; être-été (MARTINEAU, 1985 ; VEZIN, 1986).

GEWISSEN : conscience (GRANEL, 1978-79 ; MARTINEAU, 1985) ; conscience morale (VEZIN, 1986).

GEWORFENHEIT : délaissement (GURVITCH, 1930) ; déréliction (CORBIN, 1938) ; déchéance, délaissement (ROVAN, 1941) ; être-jeté (MARTINEAU, 1985 ; VEZIN, 1986 ; DASTUR, 1990).

HEILE : indemne (MUNIER, 1957) ; «sauf» (HAAR, 1987).

HEILIGE : Sacré, sacré (MUNIER, 1957 ; BEAUFRET, 1985 ; FH, 1988), HISTORIE : chronique (MUNIER, 1957) ; recherche historique (BW, 1954) ; enquête historique (MARTINEAU, 1985) ; études historiques, historiographie (VEZIN, 1986).

IN-DER-WELT-SEIN : être-dans-le-monde (BW, 1964) ; être-au-monde (MUNIER, 1957 ; MARTINEAU, 1985 ; VEZIN, 1986).

JEMEINIGKEIT : être-mien (B3W, 1964) ; mienneté (MARTINEAU, 1985) ; l'être-chaque-fois-à-moi (VEZIN, 1986).

KEHRE : tournant (L-R, 1976, etc.) ; tournement (FÉDIER, 1995).

LICHTUNG : éclairement (MUNIER, 1957); lumination (KAHN, 1958); lumière (BW, 1964); clairière (B-F, 1966; VEZIN, 1986); éclaircie (FÉDIER, 1976; SCHÜRMANN, 1982; MARTINEAU, 1985); allégeance, allégie (FÉDIER, 1989); Lichtung (SCHILD, 1990).

MAN : Monsieur-tout-le-monde (GURVTTCH, 1930) ; « on » (CORBIN, 1938 ; SARTRE, 1943 ; BW, 1964 ; MARTINEAU, 1985 ; VEZIN, 1986).

MITSEIN : être-avec-autrui (BW, 1964) ; être-avec (SARTRE, 1943 ; MARTI-NEAU, 1985 ; VEZIN, 1986).

NICHTS (das) : (le) Néant (CORBIN, 1938); (le) rien (BW, 1964; MARIT-NEAU, 1985; VEZIN, 1986); le Néant (GRANEL, 1968); le néent (FÉDIER, 2000).

OFFENBAR (das), OFFENBARE : manifeste (ROVAN, 1947 ; MARTINEAU, 1985) ; le manifeste, ce qui ce manifeste (BW, 1964).

OFFENBARKEIT : évidence (ROVAN, 1947) ; manifesteté (MARTINEAU, 1985).

OFFENHEIT : franchise (BEAUFRET, 1945); ouverture (BW, 1964; MARIT-NEAU, 1985; VEZIN, 1986).

bUTU J tyssours 8Rg< AIFD9 K pqr|ur 8]QbdY^UQe< AIHE9 K pqro|u 8WbQ^U\< AIGH=AIGI K fUjY^< AIHF9>

REICHEN : porrection (FÉDIER, 1968) ; offrande (LOREAU, 1989) ; donation à distance (DASTUR, 1990).

SAGE : dict, légende (KAHN, 1958) ; parole (PRÉAU, 1958) ; la Dite (FÉDIER, 1976).

SCHRITT ZURÜCK : décrochage (BIRAULT, 1960) ; pas en arrière (PRÉAU, 1968) ; pas qui rétrocède (L-R, 1976).

SCHULDIGSEIN : culpabilité (GRANEL, 1978-79) ; être-en-dette (MARIT-NEAU, 1985) ; être-en-faute (VEZIN, 1986).

SEIN : Être (CORBIN, 1938 ; MUNIER, 1957, etc.)

SEIENDE : existant (CORBIN, 1931, 1938); étant (W-BIEMEL, 1948; MUNIER, 1957, etc.).

SORGE : souci (ROVAN, 1941 ; BW, 1964 ; MAKTINEAU, 1985 ; VEZIN, 1986).

SPRACHE : langage, langue (BW, 1964); parole (FÉDIER, 1976; MARIT-NEAU, 1985); langue (VEZIN, 1986).

STIMMUNG : tonalité-affective (CORBIN, 1938) ; humeur, disposition (d'humeur) (BW, 1964) ; disposition (AB, 1957 ; VEZIN, 1986) ; corde (FÉDIER, 1976) ; tonalité (MARTINEAU, 1985) ; disposition affective (HAAR, 1987).

TEMPORALITÄT : «temporalité» (BW, 1964) ; être-temporal (COURTINE, 1985 ; MARTINEAU, 1985) ; temporalité (VEZIN, 1986).

TODE (SEIN ZUM) : être-pour-la-mort (CORBIN, 1938 ; SARTRE, 1943) ; être-à-la-mort (GRANEL, 1978-79) ; être pour la mort (MARTINEAU, 1985) ; être vers la mort (VEZIN, 1986).

UNVERBORGENHEIT: non-abscondité (ROVAN, 1947); décèlement (MUNIER, 1957); non-latence (KAHN, 1958); non-occultation (PRÉAU, 1958); dé-voilement, non-dissimulation (BW, 1964); non-retrait, ouvert sans retrait (B-F, 1966; FÉDIER, 1976; BOUTOT, 2001); non-voilement (PRÉAU, 1968); non-retrait, désabritement (B-J, 1968); hors-retrait (MARTINEAU, 1985); non-retrait (VEZIN, 1986); non-crypture (LOWIT, 1986); dé-cèlement (HAAR, 1987).

URSPRUNG : origine (BROKMEIER, 1962) ; pimesaut (LOREAU, 1989).

VERBORGENHEIT : obnubilation (W-BIEMEL, 1948) ; cèlement (MUNIER, 1957 ; HAAR, 1987) ; latence (KAHN, 1958) ; dissimulation, être-couvert (BW, 1964) ; retrait (BEAUFRET, MARTINEAU, 1985) ; être en retrait (VEZIN, 1986) ; crypture (LOWIT, 1986) ; opacité (BARASH, 1995).

VERFALLEN, VERFALLENHEIT : dégradation (GURVITCH, 1930); chute (LÉVINAS, 1932; ROVAN, 1941; BEAUFRET, 1945); déchéance (MUNIER, 1957; BW, 1964; GRANEL, 1978-79); déclin (BEAUFRET, 1974); échouement (LAUNAY, 1977); échéance, être-échu (MARTINEAU, 1985); déclin, déval (BEAUFRET, 1985); dévalement (VEZIN, 1986), VERSTEHEN: compréhension (GURVITCH, 1930; BW, 1964; GRANEL, 1978-79); comprendre (MARTINEAU, 1985); entendre (VEZIN, 1986).

VERWINDUNG : Appropriation (GRANEL, 1968); acceptation (PRÉAU, 1958); guérison (HAAR, 1987).

VORHANDENHEIT : réalité-des-choses subsistantes (CORBIN, 1938) ; subsistance (KAHN, 1958 ; BW, 1964 ; COURTINE, 1985) ; être-à-portée-de-la-main (FÉDIER, 1968) ; être-sous-la-main (MARTINEAU, 1985) ; être-là-devant (VEZIN, 1986) ; subsistance, pré-sence (DASTUR, 1990).

WELTLICHKEIT: mondanéité (BW, 1964); mondéité (VEZIN, 1986).

WESEN : essence (CORBIN, 1938 ; MUNIER, 1957 ; BW, 1964) ; estance (KAHN, 1958) ; essence, « essence », être (PRÉAU, 1958) ; esprit (BEAU-FRET, 1974) ; déploiement (FÉDIER, 1976) ; maintien (GRANEL, 1968) ; aître (GUEST, 1989).

ZEITLICHKEIT : temporalité (CORBIN, 1938 ; ROVAN, 1941 ; KAHN, 1958 ; GRANEL, 1978-79 ; COURTINE, MARTINEAU, 1985) ; temporellité (VEZIN, 1986).

ZEUG : outil (BW, 1964 ; MARTINEAU, 1985) ; util (VEZIN, 1986).

ZUHANDENHEIT : maniabilité (LÉVINAS, 1932 ; DASTUR, 1990) ; réalité-ustensile (CORBIN, 1938) ; disponibilité (BW, 1964 ; COURTNE, 1985) ; être-en-main (FÉDIER, 1968) ; être-à-portée-de-la-main (MARTINEAU, 1985) ; utilisabilité (VEZIN, 1986).

ZUSAGE : le dire fianciant ou fié, la fiance (FÉDIER, 1976); Zusage (DERRIDA, 1987).

ZUWENDUNG : atour (GRANEL, 1968).
