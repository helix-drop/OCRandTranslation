## Index

Index
acetylcholine 111–112
adrenalin/noradrenalin 111
affective neuroscience 6–7
Alcaro, A 134–135
alignment and entrainment in
schizophrenia 130–132
alpha power 94
anesthesia 74–75, 95
arousal level and global brain
activity 73–74

attachment: introduction to 33; LRTCs matching and connecting brain and world in 35; LRTCs of the brain nesting the self within the world in 36–37; nature and world exhibiting scale-free temporal structure in 34–35; as neuro-ecological/social, temporal, and scale free 38–39; temporal continuity of self and world in 37–38; topographic and dynamic view of 34–39; see also trauma autocorrelation window (ACW) 113–114; in schizophrenia 133 basis model of self-specificity (BMSS) 52–54 Bazan, A 94 Berberian, N 119 bipolar disorder (BD) 135

Borges, A 35

brain, the: cathexis and 70–77; central executive network (CEN) 109–111, 114–115; "common currency" of psyche and 3–4, 7–8; concept of the self and regions of 13; default-mode network (DMN) 13, 17, 45–46, 81, 109–111, 114–117, 119, 136–138; defense mechanisms and 58–59; disbalance between medial and lateral prefrontal cortex in 134–135; dissociation as cracks in consciousness and 61–62; dissociation as disrupted integration on intra-regional, inter-regional, and global levels of neural activity in 62–63; in early relational trauma 40–41; early vs. late stimulus-induced activity in 90; frequencies (see frequencies, brain); global signal (GS) in 71–73; hippocampus 109–111; imbalance of brain-based spatial nestedness of self and 26–27; insula and other regions in narcissism and 25–27; long-range temporal correlation (LRTC) and 19–21; medial prefrontal cortex (MPFC) of 16–17; mismatch
