## Bibliography

PRIMARY SOURCES

Archives and Manuscript Collections (with Abbreviations)

Haina Hospitalsarchiv (HHA), Receptions-Reskripte (RR)

Leiden: Rijksuniversiteit Library, Cod. Voss. Chym. 25: Paracelsus, De secretis secretorum theologiae

Marburg: Hessisches Staatsarchiv Marburg (StAM)

Marburg: University of Marburg, Paracelsusedition (MP) typescript of Leiden Cod. Voss. Chym. 25: De secretis secretorum theologiae; typescript of Paracelsus's unpublished religious writings

Nuremberg: Staatsarchiv Nürnberg, Ratsverlässe (StAN) Stuttgart: Württembergishes Hauptstaatsarchiv

Tübingen: Institut für Spätmittelalter und Reformation, Lutherindex

Würzburg: Stadtarchiv Literalien (StAW)

Printed Sources

Agricola, Sixtus, and Georg Witmer. Erschröckliche gantz warhaftige Geschicht welche sich mit Apolonia, Hannsen Geisslbrechts ... Haussfrawen, so ... von dem bösen Feind gar hart besessen. Ingolstadt, 1584.

Agrippa, Heinrich Cornelius, von Nettesheim. Opera omnia. "Lyon" [probably Germany, 1600?]; repr. Hildesheim, 1970.

Alberti, Michael. De melancholia vera et simulata. Halle, 1743.

Alciati, Andrea. Digestorum titulos aliquot, pagina quarta enumeratos Commentaria. Lyon, 1560.

Altenstaig, Johannes. Vocabularius Theologiae. Hagenau, 1517.

Amman, Jost. Frauentrachtenbuch von Jost Amman. Mit kolorierten Holzschnitten der Erstausgabe von 1586 und einem Nachwort. Edited by Manfred Lemmer. Frankfurt a/M, 1986.

Amman, Jost, and Hans Sachs. Eygentliche Beschreibung Aller Stände auff Erden, Hoher und Nidriger, Geistlicher und Weltlicher, Aller Künsten, Handwercken und Händeln, etc. vom grosten biß zum kleinesten, Auch von irem Ursprung, Erfindung und gebreuchen. Frankfurt a/M, 1568.

—. The Book of Trades (Ständebuch). Edited and with an introduction by Benjamin A. Rifkin. New York, 1973.

Angelus, Andreas. Wider Natur und Wunderbuch. Darin so wol in gemein von Wunderwercken dess Himmels, Luffts, Wassers und Erden, als insonderheit von allen wider-naturlichen wunderlichen Geschichten grossern theils Europae, fürnemlich der Chur-fürstlichen Brandenburgischen Marck, vom Jahr 490. biss auff 1597. ablauffendes Jahr beschehen gehandelt wird. Frankfurt a/M, 1597.

___. Annales Marchiae Brandenburgicae, das ist, Ordentliche Verzeichnus und Beschreibung der fürnemsten ... Jahrgeschichten und Historien, so sich vom 416. Jahr vor Christi geburt, bis auffs 1596. Jahr ... begeben ... haben. Frankfurt a/O, 1598.

Anglicus, Bartholomaeus. De proprietatibus rerum. Nuremberg: Anton Koberger, 1483.

Aretinus, Angelus. De maleficiis, cum additionibus. Lyon, 1555.

Aschner, Bernhard, ed. and tr. Paracelsus: Sämtliche Werke nach der 10-bändigen Huserschen Gesamtausgabe (1589–91), zum erstenmal in neuzeitliches Deutsch übersetzt. 3 vols. Jena, 1926–1930.

Baldus, Petrus. Commentaria in digestum vetus. Lyon, 1562.

Bartolus de Saxoferrato. Commentaria in primam digesti veteris partem. Edited by Petrus Paulus Parisii Cardinalis. Lyon, 1550.

___. Opera omnia. 11 vols. Venice, 1570–71.

Bericht eines Edelmannes in einem Stetlein Beltzig genannt mit Namen Anthonius Seele, welcher gar schwere und erschreckliche Anfechtungen hat. N.p., 1562.

Besold, Christoph. Ad tit. I, III, IV, V, et VI lib. I. pandectarum commentarii succincti. Tübingen, 1616.

___. Thesaurus practicus, continens explicationem terminorum atque clausularum, in aulis et dicasteriis Romano-Germanici Imperii usitatarum. Tübingen, 1629.

___. Thesaurus practicus . . . Additionibus Dn. Joh. Jacobi Speidelii . . . cum novis additionibus . . . Christophori Ludovici Dietherns. Nuremberg, 1659.

Binsfeld, Peter. Tractatus de confessionibus maleficorum et sagarum recognitus et auctus: An et quanta fides iis adhibenda sit. Trier, 1591.

___. Tractat von Bekanntnuss der Zauberer und Hexen: Ob und wie viel denselben zu glauben. Munich, 1591.

Bloss, Sebastian (praeside), and Matthaeus Müller (respondent). ΠΕΡΙ ΤΕΣ ΦΡΕΝΙΤΙΔΕ: De Phrenetide Assertiones Medicae. Tübingen, 1602.

Blumius, Nicolaus. Historische erzehlung: Was sich mit einem fürnehmen Studenten, der von dem leidigen Teuffel zwölff Wochen besessen gewesen, verlauffen. Leipzig, 1605.

Boaistuuau, P. Le theatre du monde ou il est faict ung ample discours des miseres humaines ... Weltlicher Schawplatz darinn Menschliche jammer, kummer und EllendaußgefURT. Würzburg, 1587.

___. Histoires prodigieuses, extraicts de plusieurs fameux auteurs ... nouvellement augmentées de plusieurs histoires. Antwerp, 1594.

Bobertag, Felix, ed. Narrenbuch. Berlin, 1884.

Bodin, Jean. De la démonomanie des sorciers. Paris, 1581.

—___. Les six livres de la république. Paris, 1583. Reprint, Aalen, Ger., 1977.

—. The Six Books of a Commonwealth. Translation by Richard Knolles of Les six livres, 1606. Edited by Kenneth D. McRae. Cambridge, Mass., 1962.

Bohlen von Bohlendorff, Freiherr Julius, ed. Hausbuch des Herrn Joachim von Wedel, Auf Krempzow Schloss und Blumberg Erbgesessen. Tübingen, 1882.

Brant, Sebastian. "The Ship of Fools" by Sebastian Brant. 1494. Translated by Edwin H. Zeydel. New York, 1944.

—. Das Narrenschiff. 1494. Edited by H. A. Junghans and Hans-Joachim Mähl. Stuttgart, 1985.

Brunfels, Otto. Spiegel der Artzny. Strasbourg, 1532.

Brunner, Balthasar (1533–1604). Consiliorum Medicorum liber unicus ex bibliotheca Jo. Jacobi Strasskirchneri. Frankfurt a/M, 1727.

Burgkmair, Hans. The Triumph of Maximilian I: 137 Woodcuts by Hans Burgkmair and Others. With a translation of descriptive text, introd., and notes by Stanley Appelbaum. New York, 1964.

Burton, Robert. The Anatomy of Melancholy. London, 1621.

Buttner, Wolfgang. Sechs hundert / sieben und zwantzig Historien / Von Claus Narrenn. Feine schimpfliche wort und Reden / die Erbare Ehrenleut Clausen abgemerckt / und nachgesagt haben / Zur Bürgerlichen und Christ-lichen Lere / wie andere Apologen / dienstlich und förderlich. Mit lustigen Reimen gedeutet und erkleret. Eisleben, 1572. Frankfurt a/M, 1602.

Cardano, Girolamo. De rerum varietate. Basel, 1557.

Carpzov, Benedict. Practicae novae imperialis Saxonicae rerum criminalium. 1635. 8th ed. 3 vols. Wittenberg, 1684.

Celichius, Andreas. Notwendige Erinnerung Von des Sathans letzten Zornsturm, Und was es auff sich habe und bedeute, das nu zu dieser zeit so viel Menschen an Leib und Seel vom Teuffel besessen werden. Wittenberg, 1594, 1595.

Celsi, Mino. In haereticis coercendis quatenus progredi liceat: Poems, Correspondence. Edited by Peter Bietenholz. Naples, 1982.

Chemnitz, Martin. Examination of the Council of Trent. Translated by Fred Kramer. 4 vols. St. Louis, 1971–86.

Cicero, Marcus Tullius. The Academic Questions, Treatise De Finibus, and Tusculan Disputations. Edited by C. D. Yonge. London, 1880.

Clarus, Julius. Opera omnia. Frankfurt a/M, 1576.

Clavisio, Angelus Carletus de. Summa angelica. Lyon, 1521.

Coler, Jacob. Eigentlicher Bericht, Von den seltzamen ... Wunderwercken ... so sich newlicher Zeit in der Marck Brandenburg zugetragen. Erfurt, 1595.

Covarruvias, Didacus. Opera omnia. Frankfurt a/M, 1583.

Cradelius, Philipp. Eine Lehr-, Trost-, und Vermahnungs-Predigt bey der Leich- und Be- gräbniss des weyland albern und unweisen Hans Mieszko. 3d ed. N.p., 1692.

Cramer, Daniel. Das Grosse Pomersche Kirchen Chronicon. Stettin [Szczecin, Poland], 1628.

Crell, Jacob Ernest Friedrich. "Observationes de probatione sanae mentis ... defend. Iac. Ernest. Frider. Crellius ... 5 Dec. 1737." In Christoph Ludwig Crell, Dis- sertationum atque programmatum Crellianorum fasciculi XII. Halle, 1775–84.

Crooke, Helkiah, Microcosmographia: a description of the body of man: together with the controversies thereto belonging. London, 1615.

Dacheux, L., ed. Les chroniques strasbourgeoises de Jacques Trausch et de Jean Wencker.

Les annales de Sébastien Brant. Fragments recueillis par l'abbé L. Dacheux. Strasbourg, 1892.

-. Fragments des anciennes chroniques d'Alsace. Vol. 4. Strasbourg, 1901.

[Dallmayer,] Martin [abbot of Inchenhofen]. Synopsis miraculorum et beneficiorum seu vincula charitatis, Lieb-Bänder und Ketten-Glider, welche berührt . . . S. Leonardus . . . zu Inchenhofen . . . uber dreytausend Wunderzaichen . . . geschehen. Munich, 1659.

Damhouder, Jost. Enchiridion rerum criminalium. Lyon, 1555.

Dannhauer, Johann Conrad. Scheid- und Absag-Brieff Einem ungenanten Priester auss

Cöllen, auff sein AntwortsSchreiben an einen seiner vertrawten guten Freunde, über das zu Strassburg (also titulirte) vom Teuffel besessene Adeliche Jungfräwlin gegeben. Strasbourg, 1654.

Delrio, Martin. Disquisitionum magicarum libri sex. Louvain, 1599-1600.

Denkwürdige Miracula unnd Wunderzaichen in Zwölff underschidliche Ordnungen aufgethailt ... zu Tundenhausen. Munich, 1646.

Du Laurens, André. Discours de la conservation de la veue: Des maladies melancholiques: des cartarrhes: et de la vieillesse. Tours, 1594. English trans., London, 1599. Italian trans., Naples, 1626.

Eigentliche unnd Warhaffte vertzaichnus, was sich in disem 1563 Jar . . . zu Augspurg, mit eines armen Burgers Tochter daselbst ziügetragen, wie sy vomm bösen Geist . . . besessen, und derselbig . . . von Herrn Simon Scheibenhart . . . ausgetriben. N.p., n.d. [1563].

Eine Grawsame erschreckliche und wunderbarliche Geschicht oder Newe Zeitung, welche warhaftig geschehen ist, in diesem MDLIX. Jar, zur Platten . . . Alda hat ein Schmid eine Tochter die ist vom bösen Feind dem Teufel eingenommen und besessen. Wittenberg, 1559.

Eisengrein, Martin. Unser liebe Fraw zu Alten Oetting. Ingolstadt, 1571.

Erasmus, Desiderius. Encomium moriae. 1509. In Opera omnia, 4th ser., vol. 3. Edited by Clarence Miller. Amsterdam and Oxford, 1979.

——. The Praise of Folly. 1509. Translated by Clarence Miller. New Haven, 1979.

Ebliche Wunderzaichen, die Gott der Almächtig auff dem heiligen Berg Andechs ... gewirckt und erzaigt hat. Munich, 1602.

Extract Unnd gründtlicher Bericht, etlichen Gnaden: und Wunderwercken, so . . . Gott, durch das . . . Fürbitt . . . Bennonis . . . gewirckt. Munich, 1643.

Ferrand, Jacques. De la maladie d'amour ou melancholie erotique. Paris, 1610. Expanded ed., Paris, 1623.

___. A Treatise on Lovesickness. Edited by Donald A. Beecher and Massimo Ciavolella. Syracuse, N.Y., 1990.

Fichard, Johann. Consiliorum. 2 vols. Frankfurt a/M, 1590.

Fincel, Job. Wunderzeichen: Der dritte Teil, so von der zeit an, da Gottes wort in Deudschland, Rein und lauter geprediget worden, geschehen und ergangen sind. Jena, 1562.

Forestus, Petrus. Observationum et curationum medicinalium de febribus ephemeris et continuis libri duo. Antwerp, 1584.

——. Observationum et curationum medicinalium libri tres, . . . nonus de variis capitis doloribus; decimus de universis ac cerebri & meningum eiusdem symptomatis ac morbis. Leiden, 1590.

—. Observationum et curationum medicinalium liber XXXII, de lue venerea. Leiden, 1606.

Franz, Eckhart G., ed. Kloster Haina: Regesten und Urkunden. Vol. 2: (1300–1560), Erste Hälfte: Regensten. Veröffentlichungen der Historischen Kommission für Hessen und Waldeck, 9, Klosterarchive, vol. 6. Marburg, 1970.

Franz, Günther. Urkundliche Quellen zur hessischen Reformationsgeschichte. Vol. 2: 1525–1547. Marburg, 1954.

Fries, Laurentius. Spiegel der Artzny. Strasbourg, 1519.

Frommann, Johann Andreas. Hypotyposis Juris Furiosorum singularis quam deo ter opt. max. miserabilium eiusmodi personarum defensore justissimo dirigente. Strasbourg, 1655.

Galen. On the Natural Faculties. Translated by Arthur John Brock. London, 1916.

Gemeiner, Carl Theodor. Regensburgische Chronik: Unveränderter Nachdruck der Originalausgabe. Mit einer Einleitung, einem Quellenverzeichnis und einem Register. Edited by Heinz Angermeier. 4 vols. Munich, 1987.

Gewiß und Approbirte Historia Von S. Bennonis etwo Bischoffen zu Meissen, Leben und Wunderzaichen. Munich, 1602.

Godelmann, Johann Georg. Disputatio de magis, veneficis, maleficis et lamiis. Praeside Ioanne Georgio Godelmanno. Frankfurt a/M, 1584.

——. Tractatus de magis, veneficis et lamiis. Frankfurt a/M, 1591.

___. Von Zäuberern Hexen und Unholden, Warhafftiger und Wolgegründeter Bericht.

Frankfurt a/M, 1592.

Goethe, Johann Wolfgang. Italienische Reise. Part 2. Edited by Christoph Michel and Hans Georg Dewitz. Frankfurt a/M, 1993. In Sämtliche Werke, pt. 1, vol. 15, 2: Briefe, Tagebücher und Gespräche, ed. Dieter Borchmeyer. Frankfurt a/M, 1985-.

Graminaeus, Dieterich. Inductio sive Directorium, Das ist: Anleitung oder underweisung wie ein Richter in Criminal und peinlichen sachen die Zauberer und Hexen belangendst sich zu verhalten. Cologne, 1594.

Gretser, Jacob. Heylsamer Oelbrunn der Hl. Junckfrawen S. Walburgen. Ingolstadt, 1621.

Gross, Henning. Magica. Das ist: Wunderbarliche Historien von Gespensten und mancherley Erscheinungen der Geister. 2 vols. Eisleben, Ger., 1600.

Gross, Johannes. Kurtze Basler Chronik. Basel, 1614.

Grosscurdt, Justus. Warhafter Bericht von einer Frauen aus Solingen welche vorm Jahr leider vom bösen Geist besessen. Statthagen, 1618.

Hagen, Friedrich Heinrich von der, ed. Narrenbuch. Halle, 1811.

Hamberger, Georg (praeside), and Balthasar Bruno (Braun) (respondent). Disputatio de Phrenetide. Tübingen, 1588.

Harsnet, Samuel. A Declaration of Egregious Popish Impostures. London, 1603.

Heerbrand, Jacob. Ein Predig Vom Straal. Tübingen, 1579.

Heigius, Petrus. Quaestiones iuris tam civilis quam Saxonici . . . ditae nunc primum cura Ludovici Person. 2 vols. Wittenberg, 1601.

Hirth, George. Die Wunder von Mariazell: Facsimile-Reproduction der 25 Holzschnitte eines unbekannten deutschen Meisters um 1520. Munich, 1883.

Hocker, Jodocus, with additions by Hermann Hammelmann. "Der Teuffel selbs." In Theatrum diabolorum, das ist: Warhaftige eigentliche und kurtze Beschreibung allerley gewlicher, schrecklicher und abschewlicher Laster, ed. Sigismund Feyerabend. Frankfurt a/M, 1569 (repr. 1575, 1587), fols. 1–146.

Hoffmann, Paul, and Peter Dohms. Die Mirakelbücher des Klosters Eberhardsklausen.

Publikationen der Gesellschaft für rheinische Geschichte, vol. 64, no. 179. Düsseldorf, 1988.

Horn, Caspar Heinrich. Consultationum responsorum ac sēntentiarum liber unus in XVI classes distributus. Dresden and Leipzig, 1711.

Hubmaier, Balthasar. Schriften. Edited by Gunnar Westin and Torsten Bergsten. Quellen und Forschungen zur Reformationsgeschichte, vol. 29. Gütersloh, Ger., 1962.

Hueber, Fortunat. "Zeitiger Granatapfel." Muenchen 1671: Mirakelbuch des bayrisch-böhmischen Wallfahrtsortes Neukirchen bei Heilig Blut. Edited by Guillaume van Gemert. Amsterdam, 1983.

Irsing, Jacob, S.J. Historia von der weitberühmbten unser lieben Frauen Capell zu AltenOeting in Nidern Bayern. Translated by Johann Scheitenberger. Munich, 1644.

Justinian. The Digest of Justinian. Edited and translated by Alan Watson et al. Philadelphia, 1985.

—. Justinian's Institutes. Translated by Peter Birks and Grant McLeod, with the Latin text of Paul Krueger. Ithaca, N.Y., 1987.

Karlstadt, Johann Schöner von. Ein nutzlichs büchlein viler bewerter Ertzney, lang zeyt versamlet und züsammen pracht. Nuremberg, 1528.

Khueller, Sebastian. Kurtze unnd warhaftige Historia, von einer Junckfrawen, wölche mit etlich unnd dreissig bösen Geistern leibhaftig besessen. Munich, 1574.

Kleinlawel, Michael. Straßburgische Chronik. Strasbourg, 1625.

Kornmann, Henricus. Templum naturae historicum, ... in quo de natura et miraculis quatuor elementorum ... disseritur. Darmstadt, 1611.

Kraftheim, Johannes Crato von. Consiliorum et epistolarum medicinalium libri septem. Edited by Lorenz Scholtz. Frankfurt a/M, 1671.

Krämer, Heinrich (Institoris). Malleus maleficarum. 1487. Edited by André Schnyder.

Göppingen, 1991.

Kurtzer Bericht Etlicher Miracul unnd Wunderwercken so ... 1605 ... bey S. Bennonis Hailthum in München. Munich, 1606.

Lang, Johann. Epistolarum medicinalium volumen tripartitum. Frankfurt a/M, 1589. Lemnius, Levinus. De miraculis occultis naturae librii iiii. Antwerp, 1574.

___. The Secret Miracles of Nature in four books. London, 1658.

Letzener, Johann. Historische, kurtze, einfaltige und ordentliche Beschreibung des Closters und Hospitals zu Haina in Hessen gelegen. Auffs newe ubersehen und verbessert. Mühlhausen, Ger., 1588.

Lorich, Jodocus. Aberglaub: Das ist, kurtzlicher bericht, Von Verbottenen Segen, Artzneyen, Künsten, vermeinten und anderen spöttlichen beredungen ... von newen ubersehen und gemehrt. Freiburg im Breisgau, 1593.

Luther, Martin. D. Martin Luthers Werke: Kritische Gesamtausgabe. 101 vols. to date. Weimar, 1883-. Cited as WA.

___. Briefwechsel. Cited as WABr.

___. Tischreden. Cited as WATR.

— . Works ("The American Edition"). Edited by Helmut T. Lehmann and Jaroslav J. Pelikan. 55 vols. St. Louis, 1955–86. Cited as LW.

Marbach, Johann. Von Mirackeln und Wunderzeichen. Augsburg, 1571.

Melanchthon, Philipp. Commentarius de Anima. Wittenberg, 1548.

Menghi, Girolamo. Fustis daemonum. In Thesaurus exorcismorum atque coniurationum terribilium potentissimorum, efficacissimorum cum practica probatissima, pp. 433–616. Cologne, 1626.

Menochius, Jacobus. Consiliorum tomi XIII. Frankfurt a/M, 1676.

. De arbitriis iudicum quaestionibus et causis centuriae sex. Geneva, 1630.

Moegling, Daniel (praeside), and Johann Kuhn (Cuno) (respondent). Theses de Phrenetide. Heidelberg, 1584.

Mörlin, David. Sanct Salvator Zu Bettbrunn in Bayern: Das ist: Von der alten heiligen Capellen und wirdigem hoch brühmbten Gottshauß . . . S. Salvators zu Bettbrunn. In-golstadt, 1597.

Mons Sanctus Andechs, Das ist: Kurtzer Begriff oder Innhalt von den Gnadenreichen H.

Berg Andechs. Munich, 1682.

Montanus, Ioannis Baptista. Consultationes medicae. Edited by Johann Crato Vrati- slavensis [Crato von Kraftheim]. [Basel?] 1583.

Neue Zeitung und beschreibung, Was sich mit Anna Barbara, vom Stain geboren, von kuniglichen stamb ... ist worden ... wie sie ... mit 9. Teuflen besessen, auch wider ledig ist worden. Constance, 1608.

Newe Zeytung, Von einem Megdlein das entzuckt ist gewest, und was wunderbarliche Redes gethan hat. Nuremberg, 1560.

Newkirch, Melchior. Andechtige Christliche gebete, wider die Teuffel in dem armen besessenen leuten. Helmstedt, Ger., 1596.

Nutton, Vivian. "The Rise of Medicine." In The Cambridge Illustrated History of Medicine, ed. Roy Porter, pp. 52–81. Cambridge, 1996.

Oldecop, Justus. Observationes criminales practicae congestae et in quinque titulos . . .

tributae. 1654. Frankfurt a/O, 1685.

Operae horarum subcisivarum, sive meditations historicae: Centuria altera. Frankfurt a/M, 1601.

Paracelsus [Philippus Aureolus Theophrastus Bombast von Hohenheim]. Sämtliche Werke. Pt. 1: Medizinische, naturwissenschaftliche und philosophische Schriften. Edited by Karl Sudhoff. Munich and Berlin, 1922–33. Pt. 2: Die theologischen und religionsphilosophischen Schriften. Edited by Wilhelm Matthiessen and Kurt Goldammer. Munich and Stuttgart, 1923–. Cited as SW.

—. Four Treatises of Theophrastus von Hohenheim, called Paracelsus. Edited by Henry Sigerist. Baltimore, 1941.

___. Theophrastus Paracelsus: Werke. Edited by Will-Erich Peuckert. 5 vols. Basel, 1965-68.

___. Register (Indices) der Wörter, Begriffe, Namen und Bibelstellen zu den Bänden IV bis VII (Auslegungen zum Alten Testament). Edited by Kurt Goldammer et al. Stuttgart, 1995.

Pauli, Johannes, O.F.M. Schimpf und Ernst. 1522. Edited by Johannes Bolte. 2 vols. Berlin, 1924. Reprint, Hildesheim, 1972.

Planer, Andreas (praeside), and Johann Feber (Schmidt) (respondent). De morbo Saturnino seu melancholia. Tübingen, 1593.

Planer, Andreas (praeside), and Helias Waldner (respondent). Disputatio medica de capite et cerebro hominis. Tübingen, 1580.

Planer, Andreas (praeside), and Thomas Schlaier (respondent). Disputatio medica de morbis temperamenti. Tübingen: 1586.

Platter, Felix. Praxeos seu de cognoscendis, praedicandis, praecavendis, curandisque affectibus homini incommodantibus tractatus. Basel, 1609.

___. Observationum, in hominis affectibus plerisque corpori et animo libri tres. Basel, 1614.

___. Observationes: Krankheitsbeobachtangen in drei Büchern. Translated by Günter Goldschmidt. Edited by Heinrich Buess. Bern, 1963.

___. Tagebuch (Lebensbeschreibung), 1536–1567. Edited by Valentin Lötscher. Basel, 1976.

Porta, Giambattista della. Magia naturalis. Naples, 1558.

___. Magiae naturalis libri viginti. Naples, 1589.

Pratensis, Jason. De cerebri morbis. Basel, 1549.

Radbruch, Gustav, ed. Die peinliche Gerichtsordnung Kaiser Karls V. von 1532 (Carolina). Stuttgart, 1962.

Rösch, Wendel. Warhaftige und Erschröckenliche geschicht, welche sich begeben und zugetragen hat. Tübingen, 1590.

Ryff, Walther Hermann. Warhaffige künstliche und gerechte underweisung und anzeygung, Alle Latwegen, Confect, Conserven, eynbeytzungen und einmachungen . . . wie solche in den Apotheken gemacht. Strasbourg, 1540.

S. Leonhardus: Etliche gedenckwirdige Miracul und Wunderzeichen. Munich, 1585.

Schenck, Johann. Observationes medicae de capite humano. Basel, 1584.

—. Observationum medicarum, rararum, novarum, admirabilium, et monstrosarum.

7 books in 2 vols. Frankfurt a/M, 1600.

Scherer, Georg, S.J. Christliche Erinnerung Bey der Historien von jüngst beschehener Erledigung einer Junckfrawen, die mit zwölftausent sechs hundert zwey und fünftzig Teufel besessen gewesen. Ingolstadt, 1583.

Schickhard, Philipp. Zwo christliche Predigten über Buß unnd Belehrung eines Jünglings, welcher sich ... dem bösen Geist auff siben Jahr lang, mit Leib und Seel ergeben gehabt. Stuttgart, 1615.

Schnabel, Johann, and Simon Marius. Warhaftige und erschröckliche Geschicht welche sich newlicher Zeit zugetragen hat, mit einem Jungen Handtwercks und Schmidtsgesellen, Hansen Schmidt genandt. Würzburg, 1589.

Scholtz, Lorenz. Consiliorum medicinalium. Frankfurt a/M, 1598.

Schreckliche Zeitung, warhaftiger und gründtlicher Bericht was sich zugetragen hat mit einem Wirten im Düringerlandt. Erfurt, 1560.

Sedelius [Seidel], Wolfgang. Wie sich ain Christenlicher Herr, so Lundt unnd Leüt zuo Regieren under im hat, vor schedlicher Phantasey verhueten, unnd in allen noeten troesten soll. Munich, 1547.

Seiler, Tobias. Daemonomania: Uberaus schreckliche Historia, von einem bessessenen zwelffahrigen Jungfräwlein, zu Lewenberg in Schlesien. Wittenberg, 1605.

Sohm, Walter. Territorium und Reformation in der hessischen Geschichte. Urkundliche Quellen zur hessischen Reformationsgeschichte, ed. Günther Franz, vol. 1. Marburg, 1957.

Staupitz, Johann von. Sämtliche Werke. In Deutsche Schriften, vol. 1. Edited by J. K. F. Knaake. Potsdam, 1867.

___. Libellus de exsecutione aeternae praedestinationis (1517). Edited by Lothar Graf zu Dohna and Richard Wetzel. Vol. 14 of Spätmittelalter und Reformation, ed. Heiko A. Oberman. Berlin, 1979.

Stenzel, Karl, ed. Die Straßburger Chronik des elsässischen Humanisten Hieronymus Gebwiler. Berlin, 1926.

Stryk, Samuel. "Disputatio octava inauguralis de dementia et melancholia (March 8, 1672)." In Opera omnia. 14 vols. Frankfurt a/M and Leipzig, 1743-53.

Tengler, Ulrich. Lagen Spiegel: Von rechtmässigen ordnungen in burgerlichen und peinlichen regimenten. Augsburg, 1509. Rev. ed., Strasbourg, 1582.

——. Der neu Layenspiegel. Augsburg, 1512.

Thyraeus, Petrus. Daemoniaci, Hoc est: de obsessis a spiritibus daemoniorum hominibus liber unus. Cologne, 1598.

Tollat von Vochenberg, Johann. Margarita medicine, ein meisterlichs usserlesens biechlin der artzny für mancherley kranckheit und siechtagen der menschen. 1497. Strasbourg, 1507.

Tuntenhausen unser lieben frawen Gotzhaus. N.p. Editions consulted: 1506, 1527, 1530, 1532, 1533, 1534 (two eds.), 1535, 1536 (two eds.), 1537, 1538, 1539, 1544, 1547, 1551, 1555, 1561, 1564, 1567, 1569, 1574, 1577, 1579, 1581, 1583, 1584, 1589, 1597.

Umbstendig und warhafter Bericht was sich zu end def 1602 und 1603 gantze Jahr bey S.

Benno in München für Wunderwerck begeben. Munich, 1603.

Utenhovius, Carolus. Xenia seu. Ad illustrium aliquos Europae hominum nomina, Allusionum (intertextiis alicubi Ioach. Bellaii eiusdem argumenti versibus) Liber primus. N.p. [Basel?], n.d. [1570?].

Verzaichnus etlicher furnemmer wunderwerck so sich bey S. Bennonis Heilthumb zu Munchen im Jahr 1601 und 1602 begeben. Munich, 1604.

Vilerley gedenckwürdige Miracula, so sich zugetragen von Anno 99 bis ad Annum sexcentissimum quintum. Munich, 1606.

Wagner, Tobias. Der Kohlschwartze Teuffel ... über einem schröcklichen Fall einer Mannsperson die sich in Schwermuth dem Teuffel mit eignem Blut verschrieben. Ulm, 1643.

Walther, George. Krancken Büchlein: Woher alle Kranckheiten kommen, Item, warumb uns Gott damit heimsuche: Und wie man sich darinnen Christlich verhalten und in allerley anfechtungen trösten sol. Wittenberg, 1579.

Weyer, Johann. Medicarum observationum rararum liber 1. Basel, 1567.

___. De ira morbo, ejusdem curatione philosophica, medica, et theologica, liber. Basel 1577.

—. De lamiis liber: Item de commentitiis jejuniis. Basel, 1577.

___. Artzney Buch: Von etlichen biß anher unbekandten unnd unbeschriebenen Kranck-heiten. Frankfurt a/M, 1583.

___. De praestigiis daemonum, et incantationibus ac veneficiis Libri sex, postrema editione sexta aucti et recogniti. 6th ed. Basel, 1583.

___. Witches, Devils, and Doctors in the Renaissance: Johann Weyer, "De praestigis daemonum." Edited by George Mora et al. Binghamton, N.Y., 1991.

___ . On Witchcraft. Edited by Benjamin G. Kohl and H. C. Erik Midelfort. Asheville, N.C. In press.

Widl, Adam. Divus Sebastianus Eberspergae Boiorum propitius. Munich, 1688.

Wundergeschicht, Offenbarung und Geschichte einer entzuckten Kindbetterin welche zwelfstunden ist Todt geligen unnd vom Geist umbher gefiret, darnach wider lebendig wor- den. Augsburg, [1569].

Wunderlich, Werner, ed. Das Lalebuch: In Abbildung des Drucks von 1597. Göppingen, Ger., 1982.

—, ed. Das Lalebuch herausgegeben und in unsere Sprache übertragen. Stuttgart, 1982.

——, ed. Deutsche Schwankliteratur. 2 vols. Frankfurt a/M, 1992.

Zacchia, Paolo. Quaestiones medico-legales. 1621, 1630, 1634, 1651, 1654. 3 vols. in 1.

Lyon, 1701.

Zacharias, F. "Complementum artis exorcisticae." In Thesaurus exorcismorum atque coniurationum terribilium potentissimorum, efficacissimorum cum practica probatissima, pp. 617–983. Cologne, 1626.

SECONDARY SOURCES

Zimmern, Froben Christof, Graf von, and Wilhelm Wernher, Graf von. Die Chronik der Grafen von Zimmern. Edited by Hans-Martin Decker-Hauff and Rudolf Seigel. 3 vols. Constance, 1964-.

Aa, A. J. van der. Biographisch Woordenboek der Nederlanden. Haarlem, 1852–78. Reprint, Amsterdam, 1969.

Abel, Wilhelm. Massenarmut und Hungerkrisen im vorindustriellen Deutschland. 2d ed.

Göttingen, 1977.

Ackerknecht, Erwin. Kurze Geschichte der Psychiatrie. 2d ed. Stuttgart, 1967.

___. A Short History of Psychiatry. Translated by Sula Wolff. 2d ed. New York, 1968.

___. A Short History of Medicine. Baltimore, 1982.

Alsheimer, Rainer. "Katalog protestantischer Teufelserzählungen." In Volkserzählung und Reformation: Ein Handbuch zur Tradierung und Funktion von Erzählstoffen und Erzählliteratur im Protestantismus, ed. Wolfgang Brückner, pp. 417–519. Berlin, 1974.

Amelunxen, Clemens. Zur Rechtsgeschichte der Hofnarren. Schriftenreihe der Juristischen Gesellschaft zu Berlin, no. 124. Berlin, 1991.

Amereller, Almut. Votif-Bilder: Volkskunst als Dokument menschlicher Hilfsbedürftigkeit, dargestellt am Beispiel der Votif-Bilder des Klosters Andechs. Munich, 1965.

Andree, Richard. "Katholische Überlebsel beim evangelischen Volke." Zeitschrift des Vereins für Volkskunde 21 (1911): 113–25.

Anglo, Sydney. “Melancholia and Witchcraft: The Debate Between Wier, Bodin, and Scot.” In Folie et déraison à la Renaissance, pp. 209–22. Brussels, 1976.

——, ed. The Damned Art. London, 1977.

___. "Reginald Scot's Discoverie of Witchcraft: Scepticism and Sadduceeism." In Damned Art, ed. id., pp. 106–39.

Arnold, Klaus. Niklashhausen, 1476: Quellen und Untersuchungen zur sozialreligiösen Bewegung des Hans Behem und zur Agrarstruktur eines spätmittelalterlichen Dorfes. Baden-Baden, 1980.

Audibert, Adrien. Études sur l'histoire du droit Romain, vol. 1: La folie et la prodigalité. Paris, 1892.

Baader, Berndt Ph. Der bayerische Renaissancehof Herzog Wilhelms V. (1568–1579): Ein Beitrag zur bayerischen und deutschen Kulturgeschichte des 16. Jahrhunderts. Leipzig, 1943.

Babb, Lawrence. The Elizabethan Malady: A Study of Melancholia in English Literature from 1580 to 1642. East Lansing, Mich., 1951.

Bach, Hermann. "Mirakelbücher bayerischer Wallfahrtsorte. Untersuchung ihrer literarischen Form und ihrer Stellung innerhalb der Literatur der Zeit." Ph.D. diss., Munich, 1963.

Bachmann, Hanns. Das Mirakelbuch der Wallfahrtskirche Mariastein in Tirol als Quelle zur Kulturgeschichte (1678–1742). Innsbruck, 1973.

Bächtold-Stäubli, Hanns, and E. Hoffmann-Krayer, eds. Handwörterbuch des deutschen Aberglaubens. 10 vols. Berlin and Leipzig, 1929-42.

Backman, E. Louis. Religious Dances in the Christian Church and in Popular Medicine. Translated by E. Classen. London, 1951.

Bankston, William, B. H. David Allen, and David S. Cunningham. "Religion and Suicide: A Research Note on Sociology's 'One Law,'" Social Forces 62 (1983): 521–28.

Bark, N. M. "Did Shakespeare Know Schizophrenia? The Case of Poor Mad Tom in King Lear." British Journal of Psychiatry 146 (1985): 436–38.

Barnes, Robin B. Prophecy and Gnosis: Apocalypticism in the Wake of the Lutheran Re-formation. Stanford, 1988.

Bart, Pauline B. "Social Structure and Vocabularies of Discomfort: What Happened to Female Hysteria?" Journal of Health and Human Behavior 9 (1968): 188–93.

Barth, Hans-Martin. Der Teufel und Jesus Christus in der Theologie Martin Luthers. Göttingen, 1967.

Baschnagel, Georg. "Narrenschiff" und "Lob der Torheit": Zusammenhänge und Beziehungen. Bern, 1979.

Bates, D. G. "Thomas Sydenham." In Dictionary of Scientific Biography, ed. C. C. Gillispie, 13: 213–15. 16 vols. New York, 1970–80.

——“Thomas Sydenham: The Development of His Thought, 1666–1674.” Ph.D.

diss., Johns Hopkins University, 1975.

Battegay, Raymond. "Felix Platter und die Psychiatrie." In Felix Platter (1536–1614) in seiner Zeit, ed. Ulrich Tröhler, pp. 35–43. Basel, 1991.

Bauer, Anton. "Wallfahrten zum Anastasiahaupt in Benediktbeuern." Heimatbote vom Isarwinkel, 1936, no. 8.

___. "Die ehemalige Marienwallfahrt Neubeuern am Inn." Das bayerische InnOberland 33 (1963): 51–94.

Bauer, Karl. Regensburg: Aus Kunst-Kultur- und Sittengeschichte. Regensburg, 1980.

Bauer, Robert. "Das älteste gedruckte Mirakelbüchlein von Altötting." Ostbairische Grenzmarken: Passauer Jahrbuch für Geschichte, Kunst und Volkskunde 5 (1961): 144–51.

___. "Das Altöttinger Mirakelbüchlein von 1540." Ostbairische Grenzmarken 6 (1962–63): 241–48.

___. "Das Büchlein der Zuflucht zu Maria: Altöttinger Mirakelberichte von

Jacobus Issickemer." Ostbairische Grenzmarken 7 (1964–65): 206–36.

___. Bayerische Wallfahrt Altötting: Geschichte, Kunst, Volksbrauch. 2d ed. Munich, 1980.

Bauerreiss, Romuald. Pie Jesu. Munich, 1931.

Bäumer, Remigius, ed. Von Konstanz nach Trient: Beiträge zur Geschichte der Kirche von den Reformkonzilien bis zum Tridentinum. Festgabe für August Franzen. Munich, 1972.

Bausinger, Hermann. "Schildbürgergeschichten: Betrachtungen zum Schwank." In Wunderseltsame Geschichten: Interpretationen zu Schildbürgern und Lalebuch, ed. Werner Wunderlich, pp. 25–58. Göppingen, 1983.

Baxter, Christopher. "Jean Bodin's 'De la démonomanie des sorciers': The Logic of Persecution." In Damned Art, ed. Anglo, pp. 76–105. London, 1977.

___. "Johann Weyer's 'De praestigis daemonum': Unsystematic Psychopathology." In Damned Art, ed. Anglo, pp. 53–75. London, 1977.

Baylor, Michael. Action and Person: Conscience in Late Scholasticism and the Young Luther. Leiden, 1977.

Beecher, Donald A. "Erotic Love and the Inquisition: Jacques Ferrand and the Tribunal of Toulouse, 1620." Sixteenth Century Journal 20 (1989): 41–53.

Beek, H. H. Waanzin in de Middeleeuwen: Beeld van de Gestoorde en Bemoeienis mit de Zieke. Nijkerk, Neth., 1969.

Behringer, Wolfgang. Hexenverfolgung in Bayern: Volksmagie, Glaubenseifer und Staatsräson in der Frühen Neuzeit. Munich, 1987.

——. Chonrad Stoeckhlin und die Nachtschar. Eine Geschichte aus der frühen Neuzeit.

Munich, 1994.

——“Zur Geschichte der Hexenforschung.” In Hexen und Hexenverfolgung im deutschen Südwesten, ed. Sönke Lorenz, pp. 93–146. Ostfildern, Ger., 1994.

Beitl, Richard, ed. Wörterbuch der deutschen Volkskunde. 2d ed. Stuttgart, 1955.

Beizer, Janet. Ventriloquized Bodies: Narratives of Hysteria in Nineteenth-Century France. Ithaca, N.Y., 1994.

Bell, Rudolf M. Holy Anorexia. Chicago, 1985.

Bergsten, Torsten. Balthasar Hubmaier, Anabaptist Theologian and Martyr. Translated by W. R. Estep, Jr. Valley Forge, Pa., 1978.

Bers, Günter. "Das Miraculöß Mariä Bildlein zu Aldenhoven": Geschichte einer rheinischen Wallfahrt, 1655–1985. Cologne, 1986.

Bessmer, Julius, S.J. "Luthers Anschauungen über die Geisteskrankheiten und die katholische Lehre." Stimmen aus Maria-Laach: Katholische Blätter 84 (1913): 444–45, 474–76.

Beyer, Christel. "Hexen-Leut, so zu Würzburg gerichtet": Der Umgang mit Sprache und Wirklichkeit in Inquisitionsprozessen wegen Hexerei. Frankfurt a/M, 1986.

Beyer, Jürgen. "Wahrhafte Wundergeschicht von neuen Propheten die alle Welt zu rechtschaffener Buße und Besserung aufrufen: Lutherske folkelige profeter i 1500-og 1600-tallet." M.A. thesis, University of Copenhagen, 1990.

Bietenholz, Peter. "Mino Celsi and the Toleration Controversy of the Sixteenth Century." Bibliothèque d'Humanisme et Renaissance 34 (1972): 31–47.

Binding, Karl. Die Schuld im deutschen Strafrecht: Vorsatz, Irrtum, Fahrlässigkeit. Kurzes

Lehrbuch. Leipzig, 1919.

Binz, Carl. Doctor Johann Weyer: Ein rheinischer Arzt, der erste Bekämpfer des Hexenwahns. Bonn, 1885. 2d ed., Berlin, 1896.

Blasius, Dirk. Der verwaltete Wahnsinn: Eine Sozialgeschichte des Irrenhauses. Frankfurt a/M, 1980.

Blécourt, Willem de. "Spuren einer Volkskultur oder Dämonisierung? Kritische Bemerkungen zu Ginzburgs 'Benandanti,'" Kea: Zeitschrift für Kulturwissenschaften 5 (1993): 17–30.

Bloom, Harold. The Western Canon: The Books and School of the Ages. New York, 1994.

Böck, Robert. "Die Verehrung des hl. Benno in München." Bayerisches Jahrbuch für Volkskunde, 1958: 53–73.

Boerner, Peter. Tagebuch. Stuttgart, 1969.

Boss, Jeffrey M. N. "The Seventeenth-Century Transformation of the Hysteric Af- fection and Sydenham's Baconian Medicine." Psychological Medicine 9 (1979): 221–34.

Brain, W. Russell. "The Concept of Hysteria in the Time of William Harvey." Proceedings of the Royal Society of Medicine 56, no. 4 (April 1963): 317–24.

Brann, Noel. "The Renaissance Passion of Melancholy: The Paradox of Its Cultivation and Resistance." Ph.D. diss., Stanford University, 1965.

Brecht, M. "Der 'Schimpfer' Martin Luther." Luther 52 (1981): 97–113.

Browe, Peter. "Die Ausbreitung des Fronleichnamsfestes." Jahrbuch für Liturgiewissenschaft 8 (1928): 107–43.

Brown, William J., et al. Syphilis and Other Venereal Diseases. Cambridge, Mass., 1970.

Brückner, Wolfgang. "Forschungsprobleme der Satanologie und Teufelserzählungen." In Volkserzählung und Reformation: Ein Handbuch zur Tradierung und Funktion von Erzahlstoffen und Erzahlliteratur im Protestantismus, ed. id., pp. 393–416. Berlin, 1974.

Brumberg, Joan Jacobs. Fasting Girls: The Emergence of Anorexia Nervosa as a Modern Disease. Cambridge, Mass., 1988.

Brunner, Hugo. "Behandlung einer Geisteskranken im Jahre 1575." Zeitschrift des Vereins für hessische Geschichte und Landeskunde, n.s., 24 (1901): 403–4.

Buchwald, Georg. "Lutherana: Notizen aus Rechnungsbüchern des Thüringischen Staatsarchivs zu Weimar." Archiv für Reformationsgeschichte 25 (1928): 1–98.

Buckland, W. W. A Text-Book of Roman Law from Augustus to Justinian. Cambridge, 1921.

Burke, Peter. "Witchcraft and Magic in Renaissance Italy: Gianfrancesco Pico and His Strix." In Damned Art, ed. Anglo, pp. 32–52. London, 1977.

——.Popular Culture in Early Modern Europe. New York, 1978.

Burns, R. M. The Great Debate on Miracles: From Joseph Glanvill to David Hume. Lewisburg, Pa., 1981.

Busfield, Joan. "The Female Malady: Men, Women and Madness in Nineteenth-Century Britain." Sociology 28 (1994): 259–77.

Carolsfeld, Franz Schnorr von. "Ueber Klaus Narr und M. Wolfgang Bütner." Archiv für Litteratur-Geschichte 6 (1877): 277–328.

Carroll, Michael. Madonna's That Maim: Popular Catholicism in Italy Since the Fifteenth Century. Baltimore, 1992.

Céard, Jean. "Folie et démonologie au XVIe siècle." In Folie et déraison à la Renaissance, pp. 129-47. Brussels, 1976.

——. La nature et les prodiges: L'insolite au XVIe siècle, en France. Geneva, 1977.

Cellard, André. Histoire de la folie au Québec de 1600 à 1850. Montréal, 1991.

Certeau, Michel de. La possession de Loudun. Paris, 1970.

Charcot, Jean-Martin, and Paul Richer. Die Besessenen in der Kunst. Translated by Willi Hendrichs. Edited by Manfred Schneider and Wolfgang Tietze. Göttingen, 1988.

Christian, William. Apparitions in Late Medieval and Renaissance Spain. Princeton, 1981.

——. Local Religion in Sixteenth-Century Spain. Princeton, 1981.

Christoffel, H. "Psychiatrie und Psychologie bei Felix Platter (1536–1614)." Monats-schrift für Psychiatrie und Neurologie 127 (1954): 213–27.

___. “Eine systematische Psychiatrie des Barock: Felix Platters ‘laesiones mentis,’ 1602–1736.” Schweizer Archiv für Neurologie und Psychiatrie 77 (1956): 15–24.

Churchland, Paul. The Engine of Reason, the Seat of the Soul: A Philosophical Essay on the Brain. Cambridge, Mass., 1995.

Clark, Stuart. Thinking with Demons: The Idea of Witchcraft in Early Modern Europe. Oxford, 1997.

Clarke, Basil. Mental Disorder in Earlier Britain: Exploratory Studies. Cardiff, 1975.

Cocchiara, Giuseppe. The History of Folklore in Europe. Translated by John N. McDaniel. Philadelphia, 1981.

Cohn, Norman. Europe's Inner Demons: An Enquiry Inspired by the Great Witch-Hunt. London, 1975.

Cranefield, Paul. "Psychology as an English Word." American Notes and Queries 4 (1966): 116–17.

Cranz, F. Edward, and Charles B. Schmitt. A Bibliography of Aristotle Editions, 1501-1600. 2d rev. ed. Baden-Baden, 1984.

Credner, Karl August, ed. Philipps des Grossmütigen Hessische KirchenreformationsOrdnung. Giessen, Ger., 1852.

Crick, Francis. The Astonishing Hypothesis: The Scientific Search for the Soul. New York, 1994.

Crisciani, Chiara. "History, Novelty, and Progress in Scholastic Medicine." In Renaissance Medical Learning: Evolution of a Tradition, ed. Michael R. McVaugh and Nancy Siraisi, pp. 118–39. Osiris, 2d ser., vol. 6 (1990).

Cunningham, Andrew. "Fabricius and the 'Aristotle project' in Anatomical Teaching and Research at Padua." In The Medical Renaissance of the Sixteenth Century, ed. A. Wear, R. K. French, and I. M. Lonie, pp. 195–222. Cambridge, 1985.

Curry, Patrick. "Revisions of Science and Magic." History of Science 23 (1985): 299–325.

Dahm, Georg. Das Strafrecht Italiens im ausgehenden Mittelalter: Untersuchungen über die Beziehungen zwischen Theorie und Praxis im Strafrecht des Spätmittelalters, namentlich im XIV. Jahrhundert. Berlin, 1931.

Damasio, Antonio. Descartes' Error: Emotion, Reason, and the Human Brain. New York, 1994.

Daube, David. Roman Law: Linguistic, Social, and Philosophical Aspects. Edinburgh, 1969.

Debus, Allen G. The Chemical Philosophy: Paracelsan Science and Medicine in the Sixteenth and Seventeenth Centuries. 2 vols. New York, 1977.

—. The French Paracelsians: The Chemical Challenge to Medical and Scientific Tradition in Early Modern France. Cambridge, 1991.

Demandt, Carl E. Geschichte des Landes Hessen. 2d ed. Kassel, 1972.

Dennie, Charles C. A History of Syphilis. Springfield, Ill., 1962.

Deufert, Wilfried. Narr, Moral und Gesellschaft: Grundtendenzen im Prosaschwank des 16. Jahrhunderts. Bern, 1975.

Devereux, Georges. "Schizophrenia: An Ethnic Psychosis, or, Schizophrenia Without Tears." In id., Basic Problems of Ethnopsychiatry. Translated by Basia Miller Gullati and Georges Devereux, pp. 214–36. Chicago, 1980.

Diepgen, Paul. Deutsche Volksmedizin: Wissenschaftliche Heilkunde und Kultur. Stuttgart, 1935.

Diethelm, Oskar, and Thomas F. Hefferman. "Felix Platter and Psychiatry." Journal of the History of the Behavioral Sciences 1 (1965): 10–23.

Diethelm, Oskar. Medical Dissertations of Psychiatric Interest Printed Before 1750. Basel, 1971.

Dilg, Peter, and Hartmut Rudolph, eds. Resultate und Desiderate der Paracelsus-Forschung. Stuttgart, 1993.

Dinges, Martin. "Frühneuzeitliche Armenfürsorge als Sozialdisziplinierung? Probleme mit einem Konzept." Geschichte und Gesellschaft 17 (1991): 5–29.

Diosdi, György. Contract in Roman Law from the Twelve Tables to the Glossators. Budapest, 1981.

Dols, Michael W. "The Origins of the Islamic Hospital: Myth and Reality." Bulletin of the History of Medicine 61 (1987): 367–90.

Doob, Penelope B. R. Nebuchadnezzar's Children: Conventions of Madness in Middle English Literature. New Haven, 1974.

Dopsch, Heinz, Kurt Goldammer, and Peter F. Kramml, eds. Paracelsus (1493–1541): Keines andern Knecht. Salzburg, 1993.

Dörner, Klaus. Madmen and the Bourgeoisie: A Social History of Insanity and Psychiatry. Cambridge, 1984.

Duerr, Hans-Peter. Dreamtime: Concerning the Boundary Between Wilderness and Civilization. Translated by Felicitas Goodman. Oxford, 1985.

___, ed. Die Wilde Seele: Zur Ethnopsychoanalyse von Georges Devereux. Frankfurt a/M, 1987.

Dülmen, Richard van. "Volksfrömmigkeit und konfessionelles Christentum in 16. und 17. Jahrhundert." In Volksreligiosität in der modernen Sozialgeschichte, ed. Wolfgang Schieder, pp. 14–30. Geschichte und Gesellschaft, special no., 11. Göttingen, 1986.

___. “Imaginationen des Teuflischen: Nächtliche Zusammenkünfte, Hexentänze, Teufelsabbate.” In id., Hexenwelten: Magie und Imagination vom 16–20. Jahrhundert, pp. 94–130. Frankfurt a/M, 1988.

Dupont-Bouchat, Sylvie, Willem Frijhoff, and Robert Muchembled. Prophètes et sorciers dans les Pays-Bas (XVIIe-XVIIIe siècle). Paris, 1978.

Durling, Richard. "A Chronological Census of Renaissance Editions and Translations of Galen." Journal of the Warburg and Courtauld Institutes 24 (1961): 230–305.

——. A Catalog of Sixteenth-Century Printed Books in the National Library of Medicine. Bethesda, Md., 1967.

Ebeling, Friedrich W. Friedrich Taubmann: Ein Kulturbild. 3d ed. Leipzig, 1884.

Edelson, Marshall. The Idea of a Mental Illness. New Haven, 1971.

Edmundson, Mark. Towards Reading Freud: Self-Creation in Milton, Wordsworth, Emerson, and Sigmund Freud. Princeton, 1990.

Edwards, Mark U. Luther and the False Brethren. Stanford, 1975.

——. Luther's Last Battles: Politics and Polemics, 1531–1546. Ithaca, N.Y., 1983.

Eis, Gerhard. Vor und nach Paracelsus: Untersuchungen über Hohenheims Traditionsverbundenheit und Nachrichten über seine Anhänger. Stuttgart, 1965.

Eisenberg, Leon. "The Social Construction of Mental Illness" (editorial). Psychological Medicine 18 (1988): 1–9.

Ellard, John. "Did Schizophrenia Exist Before the Eighteenth Century?" Australian and New Zealand Journal of Psychiatry 21 (1987): 306–14.

Ellenberger, Henri F. The Discovery of the Unconscious: The History and Evolution of Dynamic Psychiatry. New York, 1970.

Engelmann, Woldemar. Die Schuldlehre der Postglossatoren und ihre Fortentwicklung.

___. "Der geistige Urheber des Verbrechens nach dem italienischen Recht des Mittelalters." In Festschrift für Karl Binding, 2: 387–610. Leipzig, 1911.

___. Irrtum und Schuld nach der italienischen Lehre und Praxis des Mittelalters.

Berlin, 1922.

Erikson, Erik. Young Man Luther: A Study in Psychoanalysis and History. New York, 1958.

Ernst, Cécile. Teufelaustreibungen: Die Praxis der katholischen Kirche im 16. und 17. Jahrhundert. Bern, 1972.

Ertz, Stefan. Aufbau und Sinn des Lalebuchs. Cologne, 1965.

Estes, Leland L. "The Medical Origins of the European Witch Craze: A Hypothesis." Journal of Social History 17 (1983): 271–84.

___. "Reginald Scot and His Discoverie of Witchcraft: Religion and Science in the Opposition to the European Witch Craze." Church History 52 (1983): 444–56.

Evans, Martha Noel. Fits and Starts: A Genealogy of Hysteria in Modern France. Ithaca, N.Y., 1991.

Falk, Franz. "Die Druckkunst im Dienste der Kirche zunächst in Deutschland bis zum Jahre 1520." Görres Gesellschaft zur Pflege der Wissenschaft im katholischen Deutschland, no. 2. Cologne, 1879.

Faupel, Charles E., Gregory S. Kowalski, and Paul D. Starr. "Sociology's One Law: Religion and Suicide in the Urban Context." Journal for the Scientific Study of Religion 26 (1987): 523–34.

Febvre, Lucien. Life in Renaissance France. Cambridge, Mass., 1977.

Fimpel, Ludwig. Mino Celsis Traktat gegen die Ketzertötung: Ein Beitrag zum Toleranzproblem des 16. Jahrhunderts. Basel, 1967.

Fingarette, Herbert. The Meaning of Criminal Insanity. Berkeley and Los Angeles, 1972.

Fingarette, Herbert, and Ann Fingarette Hasse. Mental Disabilities and Criminal Responsibility. Berkeley and Los Angeles, 1979.

Fischer-Homberger, Esther. Hypochondrie: Melancholie bis Neurose: Krankheiten und Zustandsbilder. Bern, 1970.

Flashar, Helmut. Melancholie und Melancholiker in den medizinischen Theorien der Antike. Berlin, 1966.

Flögel, Karl Friedrich. Geschichte der Hofnarren. Liegnitz and Leipzig, 1789.

Foucault, Michel. Histoire de la folie à l'âge classique: Folie et déraison. Paris, 1961. 2d ed., 1972.

—. Madness and Civilization: A History of Insanity in the Age of Reason. New York, 1965.

Fox, Sanford J. Science and Justice: The Massachusetts Witch Trials. Baltimore, 1968.

Franck, J. "Kunz von der Rosen." In Allgemeine deutsche Biographie, 29 (1889): 195–97.

56 vols. Leipzig, 1875–1912.

Franz, Adolf. Die kirchlichen Benediktionen im Mittelalter. 2 vols. Freiburg im Breisgau, 1909.

Freedberg, David. The Power of Images: Studies in the History and Theory of Response. Chicago, 1989.

French, R. K., I. M. Lonie, and Andrew Wear, eds. The Medical Renaissance of the Six-teenth Century. Cambridge, 1985.

Freud, Sigmund. "A Seventeenth-Century Demonological Neurosis." In The Stan- dard Edition of the Complete Psychological Works of Sigmund Freud, trans. and ed. James Strachey et al., 19: 67–105. London, 1961.

Freytag, Gustav. "Der deutsche Teufel im 16. Jahrhundert." In Bilder aus der deutschen Vergangenheit, 2: 114–42. Berlin, 1927.

Friedreich, J. B. Versuch einer Literärgeschichte der Pathologie und Therapie der psychischen Krankheiten von den ältesten Zeiten bis zum 19. Jahrhundert. Würzburg, 1830.

. Systematische Literatur der ärztlichen und gerichtlichen Psychologie. Berlin, 1833.

Fritz, Jean-Marie. Le discours du fou au Moyen-Âge: Étude comparée des discours littéraire, médical, juridique et théologique de la folie. Paris, 1992.

Gäbler, Ulrich. "Die Kinderwallfahrten aus Deutschland und der Schweiz zum Mont St. Michel, 1456–1459." Zeitschrift für schweizerische Kirchengeschichte 63 (1969): 221–331.

Galdston, Iago. "The Psychiatry of Paracelsus." In Psychiatry and the Human Condition, pp. 377–89. New York, 1976.

Garzarolli-Thurnlackh, Karl. "Die Holzschnitte der Mariazeller Wunder: Ihre Vorläufer und Meister." Phaidros 1 (1947): 181–89.

Gates, Barbara T. Victorian Suicide: Mad Crimes and Sad Histories. Princeton, 1988.

Gause, Ute. Paracelsus (1493–1541): Genese und Entfaltung seiner frühen Theologie.

Tübingen, 1993.

Geerk, Frank. Paracelsus—Arzt unserer Zeit: Leben, Werk und Wirkungsgeschichte des Teophrastus von Hohenheim. Zurich, 1992.

Geertz, Clifford. "Found in Translation: On the Social History of the Moral Imagination." In id., Local Knowledge: Further Essays in Interpretive Anthropology, pp. 36–54. New York, 1983.

Gellner, David N. "Priests, Healers, Mediums, and Witches: The Context of Possession in Kathmandu Valley, Nepal." Man 29 (1994): 27–48.

Gerrish, Brian. Grace and Reason: A Study in the Theology of Luther. Oxford, 1962.

Gierl, Irmgard. Bauernleben und Bauernwallfahrt in Altbayern: Eine kulturkundliche Studie auf Grund der Tuntenhausener Mirakelbücher. Beiträge zur altbayerischen Kirchengeschichte, vol. 21, 2. Munich, 1960.

Gilly, Carlos. "'Theophrastia Sancta': Der Paracelsismus als Religion im Streit mit den offiziellen Kirchen." In Analecta Paracelsica: Studien zum Nachleben Theophrast von Hohenheims im deutschen Kulturgebiet der frühen Neuzeit, ed. Joachim Telle, pp. 425–88. Stuttgart, 1994.

Gilman, Sander L., Helen King, Roy Porter, G. S. Rousseau, and Elaine Showalter, eds. Hysteria Beyond Freud. Berkeley and Los Angeles, 1993.

Ginzburg, Carlo. Ecstasies: Deciphering the Witches' Sabbath. London, 1990.

Glück, Gustav. Bruegels Gemälde. Vienna, 1932.

Goddu, André. "The Failure of Exorcism in the Middle Ages." In Soziale Ordnungen im Selbstverständnis des Mittelalters, ed. Albert Zimmermann and Gudrun Vuillemin-Diem, pp. 540–57. Miscellanea Mediaevalia, vol. 12/2. Berlin, 1980.

Goertz, Hans Jürgen. Profiles of Radical Reformers: Biographical Sketches from Thomas Müntzer to Paracelsus. Translated by Walter Klaassen. Scottsdale, Pa., 1982.

Goethe, Johann Wolfgang von. The Sorrows of Young Werther. New York, 1774. Reprint, 1989.

Goldammer, Kurt. Paracelsus: Natur und Offenbarung. Hannover, 1953.

___. "Der choleriche Kriegsmann und der melancholische Ketzer: Psychologie und Pathologie von Krieg, Glaubenskampf und Martyrium in der Sicht des Paracelsus." In Psychiatrie und Gesellschaft: Ergebnisse und Probleme der Sozialpsychiatrie. Festschrift für Werner Villinger, ed. H. Erhardt, D. Ploog, and H. Stutte, pp. 90–101. Bern and Stuttgart, 1958.

Goodman, Felicitas D. "Visions." In The Encyclopedia of Religion, ed. Mircea Eliade, 15: 282–88. New York, 1987.

——. How About Demons? Possession and Exorcism in the Modern World. Bloomington, Ill., 1988.

Gordon, Colin. "Histoire de la folie: An Unknown Book by Michel Foucault." History of the Human Sciences 3 (1990): 3–26.

Gottesman, Irving I. Schizophrenia Genesis: The Origins of Madness. New York, 1991.

Graf, Klaus. "Carlo Ginzburgs 'Hexensabbat': Herausforderung an die Methoden-diskussion der Geschichtswissenschaft." Kea: Zeitschrift für Kulturwissenschaften 5 (1993): 1–17.

Grimm, Heinrich. "Die deutschen ‘Teufelbücher’ des 16. Jahrhunderts: Ihre Rolle im Buchwesen und ihre Bedeutung." Archiv für Geschichte des Buchwesens 16 (1959): 1733–90.

Gritsch, Eric W. "Martin Luther and Violence: A Reappraisal of a Neuralgic Theme." Sixteenth Century Journal 3 (1972): 37–55.

——. Martin: God's Court Jester. Philadelphia, 1983.

Groß, Angelika. "La folie": Wahnsinn und Narrheit im spätmittelalterlichen Text und Bild. Heidelberg, 1990.

Gugitz, Gustav. Österreichs Gnadenstätten in Kult und Brauch. 5 vols. Vienna, 1955–58.

Guinsburg, Arlene Miller. "The Counterthrust to Sixteenth-Century Misogyny: The Work of Agrippa and Paracelsus." Historical Reflections 8 (1981): 3–28.

Gunnoe, Charles D., Jr. "Thomas Erastus and His Circle of Anti-Paracelsians." In Analecta Paracelsica: Studien zum Nachleben Theophrast von Hohenheims im deutschen Kulturgebiet der frühen Neuzeit, ed. Joachim Telle, pp. 127–48. Stuttgart, 1994.

Gutting, Gary. "Foucault and the History of Madness." In The Cambridge Companion to Foucault, ed. id., pp. 47–70. Cambridge, 1994.

Habermas, Rebekka. "Wunder, Wunderliches, Wunderbares: Zur Profanisierung eines Deutungsmusters in der frühen Neuzeit." In Armut, Liebe, Ehre: Studien zur historischen Kulturforschung, ed. Richard van Dülmen, pp. 38–66, 278–80. Frankfurt a/M, 1988.

Hacking, Ian. Rewriting the Soul: Multiple Personality and the Sciences of Memory. Princeton, 1995.

Haile, Harry G. Luther: An Experiment in Biography. Garden City, N.Y., 1980.

Hallerstein, Helmut, Freiherr Haller von, and Ernst Eichhorn. Das Pilgrimspital zum Heiligen Kreuz vor Nürnberg. Nuremberg, 1969.

Halm, Philipp Maria. "Die Mirakelbilder zu Altötting." Bayerischer Heimatschutz 21 (1925): 1–25.

Hanlon, Gregory. "Piété populaire et intervention des moines dans les miracles et les sanctuaires miraculeux en Agenais-Condomois au XVIIe siècle." Annales du Midi 97 (1985): 115–27.

Hansen, Joseph. Quellen und Untersuchungen zur Geschichte des Hexenwahns und der Hexenverfolgung im Mittelalter. Bonn, 1901.

Hare, Edward H. "Was Insanity on the Increase?" British Journal of Psychiatry 142 (1983): 439–66.

___. "Schizophrenia as a Recent Disease." British Journal of Psychiatry 153 (1988): 521–31.

___. "Schizophrenia Before 1800? The Case of the Revd. George Trosse." Psychological Medicine 18 (1988): 279–85.

Harley, David. "Explaining Salem: Calvinist Psychology and the Diagnosis of Post-session." American Historical Review 101 (1996): 306–30.

Harline, Craig. The Burdens of Sister Margaret: Private Lives in a Seventeenth-Century Convent. Garden City, N.Y., 1994.

Harmening, Dieter. "Fränkische Mirakelbücher: Quellen und Untersuchungen zur historischen Volkskunde und Geschichte der Volksfrömmigkeit." Würzbürger Diözesangeschichtsblätter 28 (1966): 25–240.

Hartig, Michael. Inchenhofen. 2d ed., Munich, 1955.

Harvey, E. Ruth. The Inward Wits: Psychological Theory in the Middle Ages and the Renaissance. London, 1975.

Haustein, Jörg. Martin Luthers Stellung zum Zauber- und Hexenwesen. Stuttgart, 1990.

Hayden, Hiram. The Counter Renaissance. New York, 1950.

Hecker, J. F. C. Die grossen Volkskrankheiten des Mittelalters. Historisch-pathologische Untersuchungen, ed. August Hirsch. Berlin, 1865.

Heilfurth, G., and I. M. Greverus. Bergbau und Bergmann in der deutschsprachigen Sagenüberlieferung Mitteleuropas. Vol. 1. Marburg, 1967.

Heiltum und Wallfahrt. Innsbruck, 1988.

Heinemeyer, Walter, and Tilman Pünder, eds. 450 Jahre Psychiatrie in Hessen. Marburg, 1983.

Helms, Margarete. "Die psychopathologischen Anschauungen bei Paulus Zacchias in Hinsicht auf den Beginn einer forensischen Psychiatrie." M.D. diss., Munich, 1957.

Hemleben, Johannes. Paracelsus: Revolutionär, Artzt und Christ. Stuttgart, 1973.

Heyd, Michael. "The Reaction to Enthusiasm." Journal of Modern History 53 (1981): 258–80.

Hillerbrand, Hans J. Landgrave Philipp of Hesse, 1504–1567: Religion and Politics in the Reformation. Reformation Essays and Studies, no. 1. St. Louis, 1967.

His, Rudolf. Das Strafrecht des deutschen Mittelalters, erster Teil: Die Verbrechen und ihre Folgen in allgemeinen. Leipzig, 1920.

Hocke, Gustav René. Das europäische Tagebuch. Wiesbaden, 1978.

Holl, Karl. "Martin Luther on Luther." Translated by H. C. Erik Midelfort. In Interpreters of Luther: Essays in Honor of Wilhelm Pauck, ed. Jaroslav J. Pelikan, pp. 9–34. Philadelphia, 1968.

Holthausen, Paul. Das Landeshospital Haina in Hessen, eine Stiftung Landgraf Philipps des Grossmütigen, von 1527–1907. Frankenberg i. H., 1907.

Horn, Ewald. Die Disputationen und Promotionen an den deutschen Universitäten vornehmlich seit dem 16. Jahrhundert. Leipzig, 1893.

Hsia, Ronnie Po-chia. Society and Religion in Münster, 1535–1618. New Haven, 1984. ___ . The Myth of Ritual Murder: Jews and Magic in Reformation Germany. New Haven, 1988.

——. Social Discipline in the Reformation: Central Europe, 1500-1750. London, 1989.

Hunter, Richard, and Ida Macalpine. Schizophrenia 1677: A Psychiatric Study of an Illustrated Autobiographical Record of Demoniacal Possession. London, 1956.

Huppert, George. After the Black Death. A Social History of Early Modern Europe. Bloomington, Ind., 1986.

Hüttl, Ludwig. Marianische Wallfahrten im süddeutsch-österreichischen Raum. Analysen von der Reformations- bis zur Aufklärungsepoche. Cologne, 1985.

Imaginair Museum Hugo van der Goes. Ghent, 1982.

Jackson, Stanley W. "Melancholia and the Waning of the Humoral Theory." Journal of the History of Medicine and Allied Sciences 33 (1978): 367–76.

___. Melancholia and Depression: From Hippocratic Times to Modern Times. New Haven, 1986.

Jacob, Mechtild Josephi. "Die Hexenlehre des Paracelsus und ihre Bedeutung für die modernen Hexenprozesse: Ein Beitrag zur Geschichte der Entwicklung des Hexenglaubens seit dem Mittelalter unter besonderer Berücksichtigung der Überlieferung aus dem Raum Gifhorn (Braunschweig)." Ph.D. diss., Göttingen University, 1959.

Jacquart, Danielle. "Theory, Everyday Practice, and Three Fifteenth-Century Physicians." In Renaissance Medical Learning: Evolution of a Tradition, ed. Michael R. McVaugh and Nancy Siraisi, pp. 140–160. Osiris, 2d. ser., vol. 6 (1990).

Jaeger, C. Stephen. "Melancholie und Studium: Zum Begriff ‘Arbeitsethik,’ seinen Vorläufern und seinem Weiterleben in Medizin und Literatur." In Literatur, Artes und Philosophie, ed. Walter Haug and Burghart Wachinger, pp. 117–40. Tübingen, 1992.

Janssen, Johannes. Geschichte des deutschen Volkes seit dem Ausgang des Mittelalters. 8 vols. Freiburg im Breisgau, 1883–94.

Jessewitsch, Rolf Dieter. Das "Ständebuch" des Jost Amman (1568). Münster, 1987.

Jeste, D. V., R. del Carmen, J. B. Lohr, and R. J. Wyatt. "Did Schizophrenia Exist Before the Eighteenth Century?" Comprehensive Psychiatry 26 (1985): 493–503.

Jetter, Dieter. "Zur Entwicklung der Irrenfürsorge im Donauraum." Medizinhistorisches Journal 6 (1971): 189–99.

___. Zur Typologie des Irrenhauses in Frankreich und Deutschland (1780–1840). Wiesbaden, 1971.

——. Das europäische Hospital, von der Spätantike bis 1800. Cologne, 1986.

Jobe, T. H. "Medical Theories of Melancholia in the Seventeenth and Early Eighth-teenth Centuries." Clio Medica 19 (1976): 217–31.

Jones, Colin. The Charitable Imperative: Hospitals and Nursing in Ancien Régime and Revolutionary France. London, 1989.

——“Medicine, Madness, and Mayhem from the Roi Soleil to the Golden Age of Hysteria (17th–19th Centuries),” French History 4 (1990): 378–88.

Jones, Colin, and Roy Porter, eds. Reassessing Foucault: Power, Medicine, and the Body. London, 1994.

Justi, Carl Wilhelm. Das Hospital zu Haina: Versuch einer Darstellung seiner ehemaligen und gegenwärtigen Beschaffenkeit. Marburg, 1803.

Jütte, Robert. Obrigkeitliche Armenfürsorge in deutschen Reichsstädten der Frühen

Neuzeit: Städtisches Armenwesen in Frankfurt am Main und Köln. Cologne, 1984.

Kalkofen, Rupert. "Lalebuch oder Schiltbürger, Anonymus oder Fischart? Die buchgeschichtlichen Untersuchungen von Peter Honegger und Stefan Ertz im Vergleich." Wirkendes Wort: Deutsche Sprache und Literatur in Forschung und Lehre 41 (1991): 363–77.

Kämmerer, Ernst Wilhelm. Das Leib-Seele-Geist-Problem bei Paracelsus und einigen Autoren des 17. Jahrhunderts. Wiesbaden, 1971.

___. “Mensch und Krankheit bei Paracelsus.” In Paracelsus: Werke und Wirkung. Festgabe für Kurt Goldammer zum 60. Geburtstag, ed. Sepp Domandl, pp. 119–124. Vienna, 1975.

Kantorowicz, Hermann. Albertus Gandinus und das Strafrecht der Scholastik. 2 vols. Berlin, 1907–26.

Kaplan, Benjamin. "Possessed by the Devil? A Very Public Dispute in Utrecht." Renaissance Quarterly 49 (1996): 738–59.

Karcher, J. Felix Platter: Lebensbild des Basler Stadttarztes, 1536–1614. Basel, 1949.

Kelly, H. A. The Devil at Baptism: Ritual, Theology and Drama. Ithaca, N.Y., 1985.

Kemp, S., and K. Williams. "Demonic Possession and Mental Disorder in Medieval and Early Modern Europe." Psychological Medicine 17 (1987): 21–29.

Kieckhefer, Richard. European Witch-Trials: Their Foundations in Popular and Learned Culture, 1300–1500. London, 1976.

King, Helen. "Once upon a Text: Hysteria from Hippocrates." In Hysteria Beyond Freud, ed. Gilman et al., pp. 3–90. Berkeley and Los Angeles, 1993.

Kirchhoff, Theodor. Grundriß einer Geschichte der deutschen Irrenpflege. Berlin, 1890.

Kittelson, James. "Successes and Failures in the German Reformation: The Report from Strasbourg." Archiv für Reformationsgeschichte 73 (1982): 153-75.

Kleinman, Arthur. "Anthropology and Psychiatry: The Role of Culture in Cross-Cultural Research on Illness." British Journal of Psychiatry 151 (1987): 447–54.

———. Rethinking Psychiatry. New York, 1988.

Klibansky, Raymond, Fritz Saxl, and Erwin Panofsky. Saturn and Melancholy: Studies in the History of Natural Philosophy, Religion, and Art. New York, 1964.

Köhler, E. Arme und Irre: Die liberale Fürsorgepolitik des Bürgertums. Berlin, 1977.

Koldewey, Friedrich. Der Exorzismus im Herzogtum Braunschweig seit den Tagen der Reformation. Ph.D. diss., Jena, 1893.

König, Maria Angela. Weihegaben an U.L. Frau von Altötting. 2 vols. Munich, 1939.

Könneker, Barbara. Wesen und Wandlung der Narrenidee im Zeitalter des Humanismus: Brant, Murner, Erasmus. Wiesbaden, 1966.

Korff, Gottfried. Heiligenverehrung in der Gegenwart: Empirische Untersuchungen in der Diözese Rottenburg. Tübingen, 1970.

Koslow, Susan. "The Impact of Hugo van der Goes's Mental Illness and Late Medieval Religious Attitudes on the Death of the Virgin." In Healing and History: Essays for George Rosen, ed. Charles E. Rosenberg, pp. 27–50. Folkestone, Kent, 1979.

Kramer, Karl-Sigismund. "Die Mirakelbücher der Wallfahrt Grafrath." Bayerisches Jahrbuch für Volkskunde, 1951, pp. 80–102.

___. "Typologie und Entwicklungsbedingungen nachmittelalterlicher Nahwall-fahrten." Rheinisches Jahrbuch für Volkskunde 11 (1960): 195–211.

Krenn, Peter. "Der große Mariazeller Wunderaltar von 1519 und sein Meister."

Jahrbuch des Kunsthistorischen Instituts der Universität Graz 2 (1966–67): 31–51.

___. "Die Wunder von Mariazell und Steiermark." In Die Kunst der Donauschule, 1490–1540: Ausstellung des Landes Oberösterreich, ed. Otto Wutzel, pp. 164–68. Linz, 1965.

Kreutzer, Hans Joachim. Der Mythos vom Volksbuch. Stuttgart, 1977.

Kriss, Rudolf, and Lenz Rettenbeck. Wallfahrtsorte Europas. Munich, 1950.

Kriss-Rettenbeck, Lenz. Ex voto. Zurich, 1972.

Kromm, Jane E. 'The Feminization of Madness in Visual Representation." Feminist Studies 20 (1994): 507–35.

Kühnel, Harry. "Integrative Aspekte der Pilgerfahrten." In Europa 1500: Regionen, Personenverbände, Christenheit, ed. Ferdinand Seibt and Winfried Eberhard, pp. 496–509. Stuttgart, 1987.

Kunze, Michael. Der Prozess Pappenheimer. Ebelsbach, 1981.

Kusukawa, Sachiko. The Transformation of Natural Philosophy: The Case of Philip Melanchthon. Cambridge, 1995.

Kuttner, Stephan. Kanonistische Schuldlehre von Gratian bis auf die Dekretalen Gregors

IX. Vatican City, 1935.

Labouvie, Eva. "Hexenspuk und Hexenabwehr. Volksmagie und volkstümlicher Hexenglaube." In Hexenwelten, Magie und Imagination, ed. Richard van Dülmen, pp. 49–93. Frankfurt a/M, 1987.

___ . Zauberei und Hexenwerk: Ländlicher Hexenglaube in der frühen Neuzeit. Frankfurt a/M. 1991

—. Verbotene Künste: Volksmagie und ländlicher Aberglaube in den Dorfgemeinden des Saarraumes (16.-19. Jahrhundert). St. Ingbert, Ger., 1992.

Laehr, Heinrich. Die Literatur der Psychiatrie, Neurologie, und Psychologie von 1459–1799. 4 vols. Berlin, 1900.

Laignel-Lavastine, Maxime, and Jean Vinchon. Les malades de l'esprit et leurs médecins du XVIe au XIXe siècle: Les étapes des connaissances psychiatriques de la Renaissance à Pinel. Paris, 1930.

Lain Entralgo, Pedro. Enfermidad y pecado. Barcelona, 1961.

Langholf, Volker. Medical Theories in Hippocrates: Early Texts and the "Epidemics." Berlin, 1990.

Larner, Christina. Enemies of God: The Witch-Hunt in Scotland. Baltimore, 1981.

Lerner, Robert A. H. Water into Wine? An Investigation of the Concept of Miracle. Montreal, 1988.

Lederer, David L. "Reforming the Spirit: Society, Madness, and Suicide in Central Europe, 1517–1809." Ph.D. diss., New York University, 1995.

Lefebvre, Joel. Les fols et la folie: Étude sur les genres du comique et la création littéraire en Allemagne pendant la Renaissance. Paris, 1968.

Lehmann, Hartmut. "Frömmigkeitsgeschichtliche Auswirkungen der 'kleinen Eiszeit.'" In Volksreligiosität in der modernen Sozialgeschichte, ed. Wolfgang Schieder, pp. 31–50. Geschichte und Gesellschaft, special no., 11. Göttingen, 1986.

Lehnert, Hans. Kirchengut und Reformation: Eine Kirchenrechtliche Studie. Erlanger Abhandlungen zur mittleren und neueren Geschichte, vol. 20. Erlangen, 1935.

Leibbrand, Werner, and Annemarie Wettley. Der Wahnsinn: Geschichte der abendländischen Psychopathologie. Freiburg im Breisgau, 1961.

Leibbrand-Wettley, Annemarie. "Zur Psychopathologie und Dämonologie bei Paracelsus und Johannes Weyer." In Melemata: Festschrift für Werner Leibbrand zum siebzigsten Geburtstag, ed. Joseph Schumacher, pp. 65–73. Mannheim, 1967.

Lepenies, Wolf. Melancholy and Society. Translated by Jeremy Gaines and Doris Jones. Cambridge, Mass., 1992.

Le Roy Ladurie, Emmanuel. The Beggar and the Professor: A Sixteenth-Century Family Saga. Translated by Arthur Goldhammer. Chicago, 1997.

Leutenbauer, Siegfried. Hexerei- und Zaubereidelikt in der Literatur von 1450 bis 1530.

Berlin, 1972.

Levack, Brian. The Witch Hunt in Early Modern Europe. London, 1987.

Lewinstein, S. R. "The Historical Development of Insanity as a Defense in Criminal Actions." Journal of Forensic Science 14 (1969): 275–93.

Lewis, I. M. Ecstatic Religion: A Study of Shamanism and Spirit Possession. 2d ed. London, 1989.

Liebscher, Hellmuth. "Ein kartographischer Beitrag zur Geschichte der Tanzwut." M.D. diss., Leipzig, 1931.

Lloyd, Daniel Edward. " 'Natura,' 'Ratio,' and 'Usus': The Thematic Unity of the Lalebuch." Ph.D. diss., University of Wisconsin, 1991.

Lorenz, Sönke. "Johann Georg Godelmann—ein Gegner des Hexenwahns?" In Beiträge zur Pommerschen und Mecklenburgischen Geschichte, ed. Roderich Schmidt, pp. 61–105. Marburg, 1981.

. Aktenversendung und Hexenprozeß: Dargestellt am Beispiel der Juristenfakultäten

Rostock und Greifswald (1570/82-1630). 2 vols. Frankfurt a/M, 1982-83.

___, ed. Hexen und Hexenverfolgungen im deutschen Südwesten: Aufsatzband. Karlsruhe and Ostfildern, Ger., 1994.

Lottin, Alain. Lille, citadelle de la contre-reforme? (1598–1668). Dunkirk, 1984.

Lubbers, Franz. Die Geschichte der Zurechnungsfähigkeit von Carpzow bis zur Gegenwart unter besonderer Berücksichtigung der Doktrin des gemeinen Rechts. Diss., Jena, 1936. Breslau-Neukirch, 1938.

Lutz, C. "Aufnahme und Verpflegung von Geisteskranken und Epileptikern im Juliushospitale." In Die Psychiatrie in Würzburg von 1583–1893, ed. C. Rieger. Verhandlungen der Phys.- med. Gesellschaft, n.s., 27 (1894): 33–37. Reprinted in Erster Bericht vom Jahre 1899 aus der psychiatrischen Klinik (Würzburg, 1899), pp. 89–93.

Lutz, Gerhard. "Volkskunde und Geschichte: Zur Frage einer als ‘historische Wissenschaft’ verstandene Volkskunde." In Volkskultur und Geschichte: Festgabe für Josef Dünninger zum 65. Geburtstag, ed. Dieter Harmening et al., pp. 14–26. Berlin, 1970.

MacDonald, Michael. Mystical Bedlam: Madness, Anxiety and Healing in Seventeenth-Century England. Cambridge, 1981.

—, ed. Witchcraft and Hysteria in Elizabethan London: Edward Jorden and the Mary Glover Case. London, 1991.

Macfarlane, A. D. J. Witchcraft in Tudor and Stuart England. London, 1970.

Mader, Franz. Wallfahrten im Bistum Passau. Munich, 1984.

Maloney, Gilles, and R. Savoie. Cinq cent ans de bibliographie hippocratique, 1473–1982. St.-Jean-Chrysostome, Quebec, 1982.

Mälzer, Gottfried. Julius Echter: Leben und Werk. Würzburg, 1989.

Mandrou, Robert. Magistrats et sorciers en France au XVIIe siècle: Une analyse de psychologie historique. Paris, 1968.

Martin, Alfred. "Geschichte der Tanzkrankheit in Deutschland." Zeitschrift des Reins für Volkskunde 24 (1914): 113–34, 225–39.

Martino, Ernesto di. La terra del rimorso. Rome, 1961.

Maurer, Wilhelm. "Die heilige Elisabeth und ihr Marburger Hospital." In Kirche und Geschichte: Gesammelte Aufsätze, vol. 2: Beiträge zu Grundsatzfragen und zur Frömmigkeitsgeschichte, ed. E. W. Kohls and O. Müller, pp. 284–319. Göttingen, 1970.

___. "Zum Verständnis der heiligen Elisabeth von Thüringen." In Kirche und Geschichte: Gesammelte Aufsätze, vol. 2: Beiträge zu Grundsatzfragen und zur Fröm- Moeller, B. "Piety in Germany Around 1500." In The Reformation in Medieval Perspective, ed. Steven E. Ozment, pp. 50–75. Chicago, 1971.

McAlister, Neil Harding. "The Dancing Pilgrims at Muelebeek." Journal of the History of Medicine and Allied Sciences 32 (1977): 315–19.

McCants, Anne. "Monotonous but not Meagre: The Diet of Burgher Orphans in Early Modern Amsterdam." Research in Economic History 14 (1992), ed. Roger Ransom, 69–116.

——“Consumer Behaviour in an Early Modern Dutch Orphanage: A Wealth of Choice.” Journal of European Economic History 22 (1993): 121–42.

McCloy, William A. "The Ofhuys Chronicle and Hugo van der Goes." Ph.D. diss., State University of Iowa, 1958.

Megill, Allan. Prophets of Extremity: Nietzsche, Heidegger, Foucault, Derrida. Berkeley and Los Angeles, 1985.

___. "The Reception of Foucault by Historians." Journal of the History of Ideas 48 (1987): 117–41.

Meingast, Fritz. Marienwallfahrten in Bayern und Österreich. Munich, 1979.

Merkel, Friedemann. Geschichte des evangelischen Bekentnisses in Baden von der Reformation bis zur Union. Karlsruhe, 1960.

Merrill, James. Divine Comedies. New York, 1976.

Merskey, Harold, and Paul Potter. "The Womb Lay Still in Ancient Egypt." British Journal of Psychiatry 154 (1989): 751–53.

Mezger, Werner. Hofnarren im Mittelalter: Vom tieferen Sinn eines seltsamen Amts. Constance, 1981.

Micale, Mark S. Approaching Hysteria: Disease and Its Interpretations. Princeton, 1995.

Midelfort, H. C. Erik. Witch Hunting in Southwestern Germany, 1562–1684: The Social and Intellectual Foundations. Stanford, 1972.

“Madness and Civilization in Early Modern Europe: A Reappraisal of Michel Foucault.” In After the Reformation. Essays in Honor of J. H. Hexter, ed. Barbara Malament, pp. 247–66. Philadelphia, 1980.

___. "Madness and the Problem of Psychological History in the Sixteenth Century." Sixteenth Century Journal 12 (1981): 5–12.

——“Catholic and Lutheran Reactions to Demon Possession in the Late Seventeenth Century: Two Case Histories.” Daphnis 15 (1986): 623–48.

——“Johann Weyer in medizinischer, theologischer, und rechtsgeschichtlicher Hinsicht.” In Vom Unfug der Hexenprozesse: Gegner der Hexenverfolgung von Johann Weyer bis Friedrich Spee, ed. Hartmut Lehmann and Otto Ulbricht, pp. 53–64. Wolfenbütteler Forschungen, vol. 55. Wiesbaden, 1992.

——. Mad Princes of Renaissance Germany. Charlottesville, Va., 1994.

“Religious Melancholy and Suicide: On the Reformation Origins of a Sociological Stereotype.” In Madness, Melancholy, and the Limits of the Self, ed. Andrew D. Weiner and Leonard V. Kaplan, pp. 41–56. Vol. 3 of Graven Images. Madison, Wis., 1996.

Miller, David B. "The Dissolution of the Religious Houses of Hesse During the Re-formation." Ph.D. diss., Yale University, 1971.

Miller, Timothy. The Birth of the Hospital in the Byzantine Empire. Baltimore, 1985.

Mitterwieser, Alois. Geschichte der Fronleichnamsprozession in Bayern. Munich, 1930.

Moehsen, J. C. W. Geschichte der Wissenschaften in der Mark Brandenburg, besonders der

Arzneiwissenschaft. Vol. 1. Berlin and Leipzig, 1781.

Moeller, B. "Piety in Germany Around 1500." In The Reformation in Medieval Perspective, ed. Steven E. Ozment, pp. 50–75. Chicago, 1971.

Mommsen, Theodor. Römisches Strafrecht. Leipzig, 1899.

Monter, E. William. "Inflation and Witchcraft: The Case of Jean Bodin." In Action and Conviction in Early Modern Europe, ed. T. K. Rabb, pp. 371–89. Princeton, 1969.

——“Law, Medicine, and the Acceptance of Witchcraft, 1560–1580.” In id., European Witchcraft, pp. 55–71. New York, 1969.

——.Witchcraft in France and Switzerland: The Borderlands During the Reformation. Ithaca, N.Y., 1976.

Moran, Bruce T. The Alchemical World of the German Court: Occult Philosophy and Chemical Medicine in the Circle of Moritz of Hessen (1572–1632). Stuttgart, 1992.

Morgenthaler, W. Bernisches Irrenwesen: Von den Anfängen bis zur Eröffnung des Tollhauses 1749. Bern, 1915.

Möseneder, Karl. Feste in Regensburg: Von der Reformation bis in die Gegenwart. Regensburg, 1986.

Muchembled, Robert. Culture populaire et culture des élites dans la France moderne.

Paris, 1978.

—-. Sorcières: Justice et société aux 16e et 17e siècles. Paris, 1987.

Mummenhoff, Ernst. "Die öffentliche Gesundheits- und Krankenpflege im alten Nürnberg." In Festschrift zur Eröffnung des neuen Krankenhauses der Stadt Nürnberg. Nuremberg, 1898.

Muschka, Wilhelm. Opfergang einer Frau: Lebensbild der Herzogin Jakobe von Jülich-Kleve-Berg, geborene Markgräfin von Baden. Baden-Baden, 1987.

Nahl, Rudolf van. Zauberglaube und Hexenwahn im Gebiet von Rhein und Maas: Spätmittelalterlicher Volksglaube im Werk Johan Weyers (1515–1588). Bonn, 1983.

Nauert, Charles. Agrippa and the Crisis of Renaissance Thought. Urbana, Ill., 1965.

Neaman, Judith. Suggestion of the Devil: The Origins of Madness. Garden City, N.Y., 1975.

Needham, Rodney. "Percussion and Transition." Man 2 (1967): 606-14.

Neely, Carol T. "Recent Work in Renaissance Studies. Psychology: Did Madness Have a Renaissance?" Renaissance Quarterly 44 (1991): 776–90.

Neher, Andrew. "A Physiological Explanation of Unusual Behavior in Ceremonies Involving Drums." Human Biology 4 (1962): 151–60.

Nischan, Bodo. "The Exorcism Controversy and Baptism in the Late Reformation." Sixteenth Century Journal 18 (1987): 31–51.

——. Prince, People and Confession: The Second Reformation in Brandenburg. Philadelphia, 1994.

Nolan, Mary, and Sidney Nolan. Christian Pilgrimage in Modern Western Europe. Chapel Hill, N.C., 1989.

Nowotny, Ernst. Geschichte des Wiener Hofspitals. Vienna, 1978.

Nussbaum, Martha C. "The Oedipus Rex and the Ancient Unconscious." In Freud and Forbidden Knowledge, ed. Peter L. Rudnytsky and Ellen Handler Spitz, pp. 42-71. New York, 1994.

——. The Therapy of Desire: Theory and Practice in Hellenistic Ethics. Princeton, 1994. Obendiek, Harmannus. Der Teufel bei Martin Luther. Berlin, 1931.

Oberman, Heiko A. Masters of the Reformation: The Emergence of a New Intellectual Climate in Europe. Translated by Dennis Martin. Cambridge, 1981.

___. The Roots of Antisemitism in the Age of Renaissance and Reformation. Translated by James I. Porter. Philadelphia, 1984.

___. "Teufelsdreck: Eschatology and Scatology in the 'Old' Luther." Sixteenth Century Journal 19 (1988): 435–50.

—. Luther: Man Between God and the Devil. Translated by Eileen WalliserSchwarzbart. New Haven, 1989.

Obermayer, Peter. "Der Wiener Hexenprozess des Jahres 1583." Ph.D. diss., University of Vienna, 1963.

Ohse, Bernhard. "Die Teufelliteratur zwischen Brant und Luther." Ph.D. diss., Freie Universität Berlin, 1961.

Olsson, Herbert. Schöpfung, Vernunft und Gesetz in Luthers Theologie. Uppsala, 1971.

Osborn, Max. Die Teufelliteratur des XVI. Jahrhunderts. Acta Germanica, vol. 3, no. 3.

Berlin, 1893.

Ottosson, Per-Gunnar. Scholastic Medicine and Philosophy: A Study of Commentaries on Galen's Tegni, ca. 1300–1450. Naples, 1984.

Ozment, Steven. "The Social History of the Reformation: What Can We Learn from Pamphlets?" In Flugschriften als Massenmedium der Reformationszeit, ed. Hans-Joachim Köhler. Stuttgart, 1981.

—. When Fathers Ruled: Family Life in Reformation Europe. Cambridge, Mass., 1983.

Pagel, Walter. Das medizinische Weltbild des Paracelsus: Seine Zusammenhänge mit Neuplatonismus und Gnosis. Wiesbaden, 1962.

“Paracelsus: Traditionalism and Medieval Sources.” In Medicine, Science and Culture: Historical Essays in Honor of Owsei Temkin, ed. Lloyd Stevenson and Robert P. Multhauf, pp. 50–75. Baltimore, 1968.

___. Paracelsus: An Introduction to Philosophical Medicine in the Era of the Renaissance. Basel, 1958. 2d. ed., Basel, 1982.

Palis, James, Evangelos Rossopoulos, and Lazaros Triarhou. "The Hippocratic Concept of Hysteria: A Translation of the Original Texts." Integrative Psychiatry 3, no. 3 (September 1985): 226–28.

Panofsky, Erwin. Early Netherlandish Painting: Its Origins and Character. Cambridge, Mass., 1958.

Park, Katherine, and J. Henderson. "The First Hospital Among Christians: The Ospedale de Santa Maria Nuova in Early Sixteenth-Century Florence." Medical History 35 (1991): 164–88.

Pelikan, Jaroslav. Obedient Rebels: Catholic Substance and Protestant Principle in Luther's Reformation. New York, 1964.

Pestronk, Alan. "The First Neurology Book, De cerebri morbis (1549) by Jason Pratensis." Archives of Neurology 45 (1988): 341–44.

Pigeaud, Jackie. La maladie de l'âme: Étude sur la relation de l'âme et du corps dans la tradition médico-philosophique antique. Paris, 1981.

Pilet, P. E. "Felix Platter." In Dictionary of Scientific Biography, ed. Charles C. Gillispie, 11 (1975): 33. 18 vols. New York, 1970–90.

Pollack, Linda. Forgotten Children: Parent-Child Relations from 1500 to 1900. Cambridge, 1983.

Pölnitz, Götz, Freiherr von. Julius Echter von Mespelbrunn. Schriftenreihe zur bayerischen Landesgeschichte, no. 17. Munich, 1934.

Pompey, H. Die Bedeutung der Medizin für die kirchliche Seelsorge im Selbstverständnis der sogenannten Pastoralmedizin: Eine bibliographische-historische Untersuchung bis Mitte des 19. Jahrhunderts. Freiburg im Breisgau, 1968.

Pope, W., and N. Danigelis. "Sociology's 'One Law.'" Social Forces 60 (1981): 495–516.

Porter, Roy. Mind-Forg'd Manacles: A History of Madness in England from the Restoration to the Regency. Cambridge, Mass., 1987.

“The Body and the Mind, the Doctor and the Patient: Negotiating Hysteria.”

In Gilman et al., Hysteria Beyond Freud, pp. 225–85. Berkeley and Los Angeles, 1993.

Pötzl, Walter. Mirakel-Geschichten aus dem Landkreis Augsburg. Augsburg, 1979.

Quétel, Claude. History of Syphilis. Translated by Judith Braddock and Brian Pike. Originally titled Le mal de Naples. Baltimore, 1990.

Quadflieg, Ralph. Filaretes Ospedale Maggiore in Mailand: Zur Rezeption islamischen Hospitalwesens in der italienischen Frührenaissance. Veröffentlichung der Abteilung Architektur des Kunsthistorischen Instituts der Universität Köln, no. 20. Ph.D. diss., Cologne, 1981.

Reed, Edward S. From Soul to Mind: The Emergence of Psychology from Erasmus Darwin to William James. New Haven, 1997.

Reiter, Günther. "Heiligenverehrung und Wallfahrtswesen im Schrifttum von Reformation und katholischer Restauration." Ph.D. diss., University of Würzburg, 1970.

Reiter, Paul J. Martin Luthers Umwelt und Psychose, sowie die Bedeutung dieser Faktoren für seine Entwicklung und Lehre: Eine historisch-psychiatrische Studie. Copenhagen, 1937.

Ribon, Pierre. Guérisseurs et remèdes populaires dans la France ancienne: Vivarais

Cévennes. Paris, 1983.

Ridderbos, Bernhard. De melancholie van de kunstenaar: Hugo van der Goes en de

Oudnederlandse schilderkunst. The Hague, 1991.

Rieger, C., ed. Die Psychiatrie in Würzburg von 1583–1893. Verhandlungen der Phys. med. Gesellschaft, n.s., 27 (1894). Reprinted in Erster Bericht vom Jahre 1899 aus der psychiatrischen Klinik (Würzburg, 1899).

———. Zweiter Bericht (vom Jahre 1905) aus der Psychiatrischen Klinik der Universität Würzburg. Würzburg, 1905.

Roccatagliata, Giuseppe. A History of Ancient Psychiatry. Westport, Conn., 1986.

Rohde, Johann Jürgen. Soziologie des Krankenhauses: Zur Einführung in die Soziologie der Medizin. Stuttgart, 1962.

Romeo, Giovanni. Inquisitori, esorcisti e streghe nell'Italia della controriforma. Florence, 1990.

Rosen, George. Madness in Society: Chapters in the Historical Sociology of Mental Illness. New York, 1969.

Rosenberger, Ludwig. Narrenkabinett: Galerie von Hofnarren und lustigen Räten. St. Michael, Austria, 1978.

Roth, Hans. "Die Mirakelüberlieferungen von St. Walburg in Eichstätt aus dem 17. and 18. Jahrhundert." Sammelblatt des Historischen Vereins Eichstätt 71–72 (1978–79): 81–110.

Rouget, Gilbert. Music and Trance: A Theory of the Relations of Music and Possession. Paris, 1980. Translated by Brunhilde Biebuyck. Chicago, 1985.

Rousseau, G. S. "'A Strange Pathology': Hysteria in the Early Modern World, 1500–1800." In Gilman et al., Hysteria Beyond Freud, pp. 91–221. Berkeley and Los Angeles, 1993.

Rubin, Julius H. Religious Melancholy and Protestant Experience in America. New York, 1994.

Rubin, Miri. Corpus Christi: The Eucharist in Late Medieval Culture. Cambridge, 1991.

Rublack, Hans-Christoph. Gescheiterte Reformation: Friihreformatorische und protestische Bewegungen in süd- und westdeutschen geistlichen Residenzen. Spätmittelalter und frühe Neuzeit, vol. 4. Stuttgart, 1978.

Rudolph, Hartmut. "Einige Gesichtspunkte zum Thema 'Paracelsus und Luther.' "

Archiv für Reformationsgeschichte 72 (1981): 34–53.

Rudolph, Hartmut, and Peter Dilg, eds. Resultate und Desiderate der Paracelsus-Forschung. Stuttgart, 1993.

Rummel, Walter. "Gutenberg, der Teufel und die Muttergottes von Eberhards-klausen: Erste Hexenverfolung im Trierer Land." In Ketzer, Zauberer, Hexen: Die Anfänge der europäischen Hexenverfolgungen, ed. Andreas Blauert, pp. 91–117. Frankfurt a/M, 1990.

___. Bauern, Hexen und Herren: Studien zur Sozialgeschichte sponheimischer und kurtrierischer Hexenprozesse, 1574–1664. Göttingen, 1991.

Russell, Jean Fago. "Tarantism." Medical History 23 (1974): 404–25.

Russell, Jeffrey B. Mephistopheles: The Devil in the Modern World. Ithaca, N.Y., 1986.

Safley, Thomas Max. Charity and Economy in the Orphanages of Early Modern Augsburg. Atlantic Highlands, N.J., 1997.

Sander, H. J. "Beiträge zur Biographie Hughes van der Goes und zur Chronologie seiner Werke." Repertorium für Kunstwissenschaft 35 (1912): 519–45.

Sargent, Steven D. "Religion and Society in Late Medieval Bavaria: The Cult of St. Leonard, 1258–1500." Ph.D. diss., University of Pennsylvania, 1982.

___. "Miracle Books and Pilgrimage Shrines in Late Medieval Bavaria." Historical Reflections 13 (1986): 455–71.

Sarton, George. Six Wings: Men of Science in the Renaissance. Bloomington, Ind., 1957.

Sass, Louis. Madness and Modernism: Insanity in the Light of Modern Art, Literature, and Thought. New York, 1992.

___. "Civilized Madness: Schizophrenia, Self-Consciousness and the Modern Mind." History of the Human Sciences 7 (1994): 83–120.

Satow, Roberta. "Where Has All the Hysteria Gone?" Psychoanalytic Review 66 (1979): 463–77.

Saunders, A. C. de C. M. "The Life and Humour of Joao de Sá Panasco, o Negro, Former Slave, Court Jester and Gentleman of the Portuguese Royal Household (fl. 1524–1567)." In Medieval and Renaissance Studies on Spain and Portugal in Honour of P. E. Russell, ed. F. W. Hodcroft et al., pp. 180–91. Oxford, 1981.

Schäfer, F. W. "Adam Krafft, der Reformator Hessens." Archiv für hessische Geschichte und Altertumskunde, n.s., 8 (1912): 1–46, 67–110.

Schaffstein, Friedrich. Die allgemeinen Lehren vom Verbrechen in ihrer Entwicklung durch die Wissenschaft des gemeinen Strafrechts. Beiträge zur Strafrechtsentwicklung von der Carolina bis Carpzov. Berlin, 1930.

Schalk, Carl. Luther on Music: Paradigms of Praise. St. Louis, 1988.

Schär, Markus. Seelennöte der Untertanen: Selbstmord, Melancholie und Religion im Alten Zürich, 1500–1800. Zurich, 1985.

Scheper-Hughes, Nancy. Saints, Scholars, and Schizophrenics: Mental Illness in Rural Ireland. Berkeley and Los Angeles, 1979.

Schestag, Franz. "Kaiser Maximilian I. Triumph." Jahrbuch der kunsthistorischen Sammlungen des allerhöchsten Kaiserhauses 1 (1883): 154–81.

Schiesari, Julia. The Gendering of Melancholia: Feminism, Psychoanalysis, and the Symbolics of Loss in Renaissance Literature. Ithaca, N.Y., 1992.

Schiewek, Ingrid. "Zur Autobiographie des Basler Stadtarztes Felix Platter." Forschungen und Fortschritte 38, no. 12 (Berlin 1964): 368–72.

Schilling, Heinz. "Job Fincel und die Zeichen der Endzeit." In Volkserzählung und Re-formation, ed. Brückner, pp. 325–92. Berlin, 1974.

Schings, Hans-Jürgen. Melancholie und Aufklärung: Melancholiker und ihre Kritiker in Erfahrungsseelenkunde und Literatur des 18. Jahrhunderts. Stuttgart, 1977.

Schipperges, Heinrich. Paracelsus: Der Mensch in der Licht der Natur. Stuttgart, 1974.

Schleiner, Winfried. Melancholy, Genius, and Utopia in the Renaissance. Wiesbaden, 1991.

——. Medical Ethics in the Renaissance. Washington, D.C., 1995.

Schmidt, Eberhard. Einführung in die Geschichte der deutschen Strafrechtspflege. 2d ed.

Göttingen, 1951.

Schmidt, Gustav Lebrecht. Justus Menius, der Reformator Thüringens. 2 vols., Gotha, 1867.

Schmidt, Leopold. Volksglaube und Volksbrauch: Gestalten, Gebilde, Gebärden. Berlin, 1966.

“Via sacra: Zur Geschichte der ‘Heiligen Straße’ zwischen Wien und Mariazell.” In Via sacra: Das Wallfahrtsmuseum in Kleinmariazell, ed. Helene Grünn, pp. 73–83. Veröffentlichungen des österreichischen Museums für Volkskunde, vol. 15. Vienna, 1977.

Schmitt, Charles B. Aristotle and the Renaissance. Cambridge, Mass., 1983.

Schmitz, Heinz-Günter. Physiologie des Scherzes: Bedeutung und Rechtfertigung der Ars locandi im 16. Jahrhundert. Hildesheim, 1972.

——“Consuetudo und simulatio: Zur Thematik des Lalebuchs.” In Festschrift für Gerhard Cordes zum 65. Geburtstag, ed. Friedhelm Debus and Joachim Hartig, 1:160-76. Neumünster, 1973. Reprinted in Wunderlich, ed., Wunderseltsame Geschichten, pp. 121-41. Göppingen, 1983.

___. "Das Melancholieproblem in Wissenschaft und Kunst der frühen Neuzeit."

Sudhoffs Archiv 60 (1976): 135–62.

—, ed. Wolfgang Büttners Volksbuch von Claus Narr: Mit einem Beitrag zur Sprache der Eisleber Erstausgabe von 1572. Hildesheim, 1990.

Schmitz-Cliever, Egonand Herta. "Zur Darstellung des Heiltanzes in der Malerei um 1500." Medizinhistorisches Journal 10 (1975): 307–16.

Schneider, Marius. "Tarantella." In Die Musik in Geschichte und Gegenwart. Kassel, 1949–86.

Schoeneman, Thomas J., Suzanne Segerstrom, Paul Griffin, and David Gresham. "The Psychiatric Nosology of Everyday Life: Categories in Implicit Abnormal Psychology." Journal of Social and Clinical Psychology 12 (1993): 429–53.

Schormann, Gerhard. Hexenprozesse in Deutschland. Göttingen, 1981.

Schreiber, Georg. "Strukturwandel der Wallfahrt." In Wallfahrt und Volkstum in Geschichte und Leben, ed. id., pp. 1–183. Forschungen zur Volkskunde, vols. 16–17. Düsseldorf, 1934.

——. Deutsche Mirakelbücher: Zur Quellenkunde und Sinngebung. Forschungen zur Volkskunde, vols. 31–32. Düsseldorf, 1938.

___. Alpine Bergwerkskultur: Bergleute zwischen Graubünden und Tirol in den letzten vier Jahrhunderten. Innsbruck, 1956.

Schryver, Antoine de. “Hugo van der Goes’ laatste jaren te Gent.” Genter Bijdragen tot Kunstgeschiedenis 16 (1955–56): 193–211.

Schubert, Ernst. "Julius Echter von Mespelbrunn (1545–1617)." In Fränkische Lebensbilder, ed. Gerhard Pfeiffer, 3: 158–93. Würzburg, 1969.

___. Materielle und organisatorische Grundlagen der Würzburger Universitätsentwick- lung, 1582–1821. Quellen und Beiträge zur Geschichte der Universität Würzburg, vol. 4. Neustadt an der Aisch, Ger., 1973.

Schuh, Barbara. "Von vilen und mancherlay seltzamen Wunderzaichen": Die Analyse von Mirakelbüchern und Wallfahrtsquellen. St. Katharinen, Ger., 1989.

Schumacher, Josef. Die seelischen Volkskrankheiten im deutschen Mittelalter und ihre Darstellung in der bildenden Kunst. Berlin, 1937.

Schwammberger, Adolf. "Von Hofnarren in und aus Franken." Jahrbuch für fränkische Landesforschung 34–35 (1974–75): 975–81.

Schweinsberg, Gustav, Freiherr Schenk zu. "Aus der Jugendzeit Landgraf Philipps des Grossmütigen." In Philipp der Grossmütige: Beiträge zur Geschichte seines Lebens und seiner Zeit, ed. Historischer Verein für das Grossherzogtum Hessen, pp. 73–143. Marburg, 1904.

Schwerdfeger, Gerhard O. "Die Erbanlagen bei Ludwig II. und Otto von Bayern aus genealogischer Sicht: Eine kritische Bestandsaufnahme und neue Forschungs- ergebnisse." Genealogisches Jahrbuch 35 (1995): 11–42.

Screech, Michael. Ecstasy and the Praise of Folly. London, 1980.

“The ‘Mad’ Christ of Erasmus and the Legal Duties of his Brethren.” In Essays on Early French Literature Presented to Barbara M. Craig, ed. N. J. Lacy and J. C. Nash, pp. 119–27. York, S.C., 1982.

“Good Madness in Christendom.” In The Anatomy of Madness: Essays in the History of Psychiatry, vol. 1: People and Ideas, ed. W. F. Bynum, Roy Porter, and Michael Shepherd, pp. 25–39. London, 1985.

Scribner, Robert. Popular Culture and Popular Movements in Reformation Germany. London, 1987.

Scull, Andrew. The Most Solitary of Afflictions: Madness and Society in Britain, 1700–1900. New Haven, 1993.

650 Jahre Bürgerspital zum Heiligen Geist Würzburg. Würzburg, 1969.

Sharp, Leslie A. "Exorcists, Psychiatrists, and the Problems of Possession in Northwest Madagascar." Social Science & Medicine 38 (1994): 525–42.

Shorter, Edward. From Paralysis to Fatigue: A History of Psychosomatic Illness in the Modern Era. New York, 1992.

___. From the Mind into the Body: The Cultural Origins of Psychosomatic Symptoms. New York, 1994.

Showalter, Elaine. Hystories: Hysterical Epidemics and Modern Culture. New York, 1997.

Siefert, Helmut. "Kloster und Hospital Haina: Eine medizin-historische Skizze." Hessisches Ärzteblatt 32 (1971): 963–83.

Sigal, Pierre-André. L'homme et le miracle dans la France médiévale: XIe-XIIe siècle. Paris, 1985.

Sigerist, Henry. "The Story of Tarantism." In Music and Medicine, ed. Dorothy M. Schullian and Max Schoen, pp. 96–116. New York, 1948.

Siraisi, Nancy G. Avicenna in Renaissance Italy: The Canon and Medical Teaching in Italian Universities After 1500. Princeton, 1987.

—. Medieval and Early Renaissance Medicine: An Introduction to Knowledge and Practice. Chicago, 1990.

Skalnik, James V. "Ramus and Reform: The End of the Renaissance and the Origins of the Old Regime in France." Ph.D. diss., University of Virginia, 1990.

Sluhovsky, Moshe. "A Divine Apparition or Demonic Possession? Female Agency and Church Authority on Demonic Possession in Sixteenth-Century France." Sixteenth Century Journal 27 (1996): 1039–55.

Smith, Pamela H. The Business of Alchemy: Science and Culture in the Holy Roman Empire. Princeton, 1994.

Soergel, Philip. "Wondrous in His Saints: Popular Pilgrimage and Catholic Propaganda in Bavaria, 1470–1620." Ph.D. diss., University of Michigan, 1988.

___. Wondrous in His Saints: Counter-Reformation Propaganda in Bavaria. Berkeley and Los Angeles, 1993.

Solleder, Fridolin. "Markgräfin Susanna und ihr Narr." Das Bayerland 47 (1936): 686–89.

Sontag, Susan. Illness as Metaphor. New York, 1978.

Spangenberg, Peter-Michael. Maria ist immer und überall: Die Alltagswelten des spätmittelalterlichen Mirakels. Frankfurt a/M, 1987.

Speak, Gill. "An Odd Kind of Melancholy: Reflections on the Glass Delusion in Europe (1440–1680)." History of Psychiatry 1 (1990): 191–206.

Spirkner, B. "Kulturgeschichtliches aus dem Mirakelbuche der Wallfahrt zum hl. Valentin in Diepoldskirchen (1420–1691)." Verhandlungen des historischen Vereins für Niederbayern 42 (1906): 173–96.

Staber, Josef. Volksfrömmigkeit und Wallfahrtswesen des Spätmittelalters im Bistum Freising. Munich, 1955.

Stahl, Gerlinde. "Die Wallfahrt zur Schönen Maria in Regensburg." Beiträge zur Geschichte des Bistums Regensburg 2 (1968): 35–282.

Stalnaker, John C. "The Emergence of the Protestant Clergy in Central Germany: The Case of Hesse." Ph.D. diss., University of California at Berkeley, 1970.

Stambaugh, Ria, ed. Teufelbücher in Auswahl. 5 vols. Berlin, 1970–80.

Stechow, W. Northern Renaissance Art, 1400–1600: Sources and Documents. Englewood Cliffs, N.J., 1966.

Stella, Gerhard. "Das Mirakelbuch von Kirchwald bei Nußdorf: Eine Handschrift in der Bayerischen Staatsbibliothek München (Kloeckeliana 606b)." Das Bayerische Inn-Oberland 42 (1980): 65–111.

Stevenson, Ian. "Possession and Exorcism: An Essay Review." Journal of Parapsychology 59 (1995): 69–77.

Still, Arthur and Irving Velody, eds. Rewriting the History of Madness: Studies in Foucault's "Histoire de la folie." London, 1992.

Stintzing, Roderich. Geschichte der populären Literatur des römisch-kanonischen Rechts in Deutschland am Ende des fünfzehnten und im Anfang des sechzehnten Jahrhunderts. Leipzig, 1867.

Stone, Lawrence. The Family, Sex and Marriage in England, 1500-1800. London, 1977.

Strauss, Gerald. "Comment." In Religion and Culture in the Renaissance and Reformation, ed. Steven Ozment, pp. 121–30. Kirksville, Mo., 1989.

Stutte, H. "Landgraf Philipp der Grossmütige von Hessen aus medizinischer Sicht." Hessisches Ärzteblatt 30 (1969): 1085–97.

Sudhoff, Karl. Versuch einer Kritik der Echtheit der Paracelsischen Schriften. Berlin, 1894-99.

———. Bibliographica Paracelsica. Graz, 1958.

Sumption, Jonathan. Pilgrimage: An Image of Mediaeval Religion. Totowa, N.J., 1975.

Sushrut, Jadhav. "The Cultural Origins of Western Depression." International Journal of Social Psychiatry 42 (1996): 269–86.

Swain, Barbara. Fools and Folly During the Middle Ages and the Renaissance. New York, 1932. Reprint, Folcroft, Pa., 1976.

Talbot, Charles and Alan Shestack, eds. Prints and Drawings of the Danube School. New Haven, 1969.

Temkin, Owsei. "The Elusiveness of Paracelsus." Bulletin of the History of Medicine 26 (1952): 201–17.

——. The Falling Sickness: A History of Epilepsy. 2d ed., Baltimore, 1971.

——. Galenism: The Rise and Decline of a Medical Philosophy. Ithaca, N.Y., 1973.

Terrisse, Arnaud. "La psychiatrie en France dans le miroir de la thèse: L'évolution des thèses de médecine psychiatrique françaises du début du XVIIe siècle à 1934 d'après le fichier des thèses de médecine de la Bibliothèque nationale." Histoire, Économie et Société 3 (1984): 247-92.

Theobald, Wilhelm. Votiftafeln und Medizin: Kulturgeschichte und Heilkunst im Spiegel der Votifmalerei. Munich, 1978.

——. Mirakel-Heilung Zwischen Wissenschaft und Glauben. Munich, 1983.

Thomas, Keith. Religion and the Decline of Magic. New York, 1971.

Thompson, Colin, and Lorne Campbell. Hugo van der Goes and the Trinity Panels in Edinburgh. London, 1974.

Thompson, Ewa M. Understanding Russia: The Holy Fool in Russian Culture. New York, 1987.

Thompson, Stith. Motif Index of Folk Literature. Bloomington, Ind., 1957.

Thorndike, Lynn. A History of Magic and Experimental Science. 8 vols. New York, 1923–58.

Timken-Zinkann, R. F. "Black Bile. A Review of Recent Attempts to Trace the Origin of the Teachings on Melancholia to Medical Observations." Medical History 12 (1968): 288–92.

Tiroler Landesausstellung. Heiltum und Wallfahrt. Innsbruck, 1988.

Trusty, Ann. "The Devil's Altar: Drinking and Society in Early Modern Augsburg." Ph. D. diss., University of Maryland, 1994.

Torrey, E. Fuller. Schizophrenia and Civilization. New York, 1980.

Trevor-Roper, H. R. The European Witch-Craze of the Sixteenth and Seventeenth Centuries and Other Essays. New York, 1969.

___. "The Court Physician and Paracelsianism." In Medicine at the Courts of Europe, 1500–1837, ed. Vivian Nutton, pp. 79–94. London, 1990.

Trillat, Étienne. Histoire de l'hystérie. Paris, 1986.

Tröhler, Ulrich, ed. Felix Platter (1536–1614) in seiner Zeit. Basel, 1991.

Trossbach, Werner. "'Klee-Skrupel': Melancholie und Ökonomie in der deutschen Spätaufklärung." In Die Kehrseite des Schönen, ed. Karl Eibl (Aufklärung 8, no. 1): 91–120.

Ulbricht, Otto, and Hartmut Lehmann, eds. Vom Unfug des Hexen-Processes: Gegner der Hexenverfolgung von Johann Weyer bis Friedrich Spee. Wiesbaden, 1992.

Universitätsbibliotheken Basel und Freiburg im Breisgau et al., eds. Sébastien Brant: 500° anniversaire de 'La Nef des folz,' 1494–1994; 'Das Narren Schyff,' zum 500jährigen Jubiläum des Buches von Sebastian Brant, 1494–1994. Exhibition catalogue. Cover title: La Nef des folz = Dás Narren Schiff. Basel, 1994.

Van Cleve, John. Brant's "The Ship of Fools" in Critical Perspective, 1800–1991. Columbia, S.C., 1993.

Vandendriessche, Gaston. The Parapraxis in the Haizmann Case of Sigmund Freud. Louvain, 1965.

Veit, Ludwig Andreas, and Ludwig Lenhart. Kirche und Volksfrömmigkeit im Zeitalter des Barock. Freiburg im Breisgau, 1956.

Veith, Ilsa. Hysteria: The History of a Disease. Chicago, 1965.

Venard, Marc. "Le démon controversiste." In La controverse religieuse (XVIe-XIXe siècles), 2: 45–60. Montpelier, 1980.

Vernant, Jean-Pierre. "Oedipus Without the Complex." In id. and Pierre Vidal-Naquet, Myth and Tragedy in Ancient Greece, pp. 85–111. Translated by J. Lloyd. New York, 1988.

Vicari, Patricia. The View from Minerva's Tower: Learning and Imagination in "The Anatomy of Melancholy." Toronto, 1989.

Völker, Ludwig, ed. "Komm, heilige Melancholie": Eine Anthologie deutscher Melancholie-Gedichte mit Ausblicken auf die europäische Melancholie-Tradition in Literatur- und Kunstgeschichte. Stuttgart, 1983.

Volkert, Wilhelm. "Die Regensburger Juden im Spätmittelalter und das Ende der Judengemeinde." In Crossroads of Medieval Civilization: The City of Regensburg and Its Intellectual Milieu: A Collection of Essays, ed. Edelgard E. DuBruck and Karl Heinz Göller, pp. 139–71. Medieval and Renaissance Monograph Series, vol. 5. Detroit, 1984.

Walker, Anita M., and Edmund H. Dickerman. "'A Woman Under the Influence': A Case of Alleged Possession in Sixteenth-Century France." Sixteenth Century Journal 22 (1991): 534–54.

Walker, D. P. Spiritual and Demonic Magic from Ficino to Campanella. London, 1958.

——. Unclean Spirits: Possession and Exorcism in England and France in the Late Sixteenth and Early Seventeenth Centuries. Philadelphia, 1981.

___. “Demonic Possession Used as Propaganda in the Later Sixteenth Century.” In Istituto nazionale di studi sul Rinascimento, Scienze, credenze occulte, livelli di cultura: Convegno internazionale di studi, Firenze, 26–30 giugno 1980, pp. 237–48. Florence, 1982.

——. Music, Spirit and Language in the Renaissance. London, 1985.

___. "The Cessation of Miracles." In Hermeticism and the Renaissance: Intellectual History and the Occult in Early Modern Europe, ed. Ingrid Merkel and Allen G. Debus, pp. 111–24. Washington, D.C., 1988.

Walker, Nigel. Crime and Insanity in England. Vol. 1: The Historical Perspective. Edinburgh, 1967.

Walton, John, Paul B. Beeson, and Ronald Bodley Scott, eds. The Oxford Companion to Medicine. 2 vols. Oxford, 1986.

Walz, Rainer. Hexenglaube und magische Kommunikation im Dorf der frühen Neuzeit: Die Verfolgungen in der Grafschaft Lippe. Paderborn, Ger., 1993.

Ward, Benedicta. Miracles and the Medieval Mind: Theory, Record, and Event, 1000-1215. Philadelphia, 1982.

Weber, Karl von. Aus vier Jahrhunderten: Mitteilungen aus dem Haupt-Staatsarchiv zu Dresden. N.S. Leipzig, 1861.

Weber, Wolfgang. "Im Kampf mit Saturn: Zur Bedeutung der Melancholie im anthropologischen Modernisierungsprozess des 16. und 17. Jahrhunderts." Zeitschrift für historische Forschung 17 (1990): 155–92.

Webster, Charles. From Paracelsus to Newton: Magic and the Making of Modern Science. Cambridge, 1982.

___. "Paracelsus and Demons: Science as a Synthesis of Popular Belief." In Istituto nazionale di studi sul Rinascimento, Scienze, credenze occulte, livelli di cultura: Convegno internazionale di studi, Firenze, 26–30 giugno 1980, pp. 3–20. Florence, 1982.

Weeks, Andrew, Paracelsus: Speculative Theory and the Crisis of the Early Reformation.

Albany, N.Y., 1997.

Weimann, Karl-Heinz. Paracelsus-Bibliographie 1932–1960, mit einem Verzeichnis neun deckter Paracelsus-Handschriften (1900–1960). Wiesbaden, 1963.

Welker, Klaus. "Die Inchenhofener Mirakelaufzeichnungen, 1506–1657: Ihr Beitrag zur nachtridentinischen Verehrung des hl. Leonhard als Viehpatron." In Von Konstanz nach Trient, ed. Bäumer, pp. 635–57. Munich, 1972.

Welsford, Enid. The Fool: His Social and Literary History. London, 1935.

Wendehorst, Alfred. "Die Juliusspitalpfarrei und ihre Bedeutung für die Gegenreformation." In Julius Echter und seine Zeit: Gedenkschrift aus Anlass des 400. Jahrestages der Wahl des Stifters der Alma Julia zum Fürstbischof von Würzburg am 1. Dezember 1573, ed. Friedrich Merzbacher, pp. 349–74. Würzburg, 1973.

——. Das Juliusspital in Würzburg. Vol. 1: Kulturgeschichte. Würzburg, 1976.

Wickel, Carl. Gründung und Beschreibung des Zisterzienser-Klosters Haina in Hessen, sowie einiges aus der Geschichte des Klosters und der Anstalt. 2d ed. Frankenberg i. H., 1929.

Wiebel-Fanderl, Oliva. Die Wallfahrt Altötting: Kultformen und Wallfahrtsleben im 19. Jahrhundert. Passau, Ger., 1982.

Wilbertz, Gisela, Gerd Schwerhoff, and Jürgen Scheffer, eds. Hexenverfolgung und Regionalgeschichte: Die Grafschaft Lippe im Vergleich. Bielefeld, Ger., 1994.

Wilda, Wilhelm Eduard. Geschichte des deutschen Strafrechts, vol. 1: Das Strafrecht der Germanen. 1842. Reprint, Aalen, Ger., 1960.

Wilhelmi, Thomas. Sebastian Brant Bibliographie. Bern, 1990.

Wilkinson, Catherine. "The Hospital of Cardinal Tavera in Toledo: A Documentary and Stylistic Study of Spanish Architecture in the Mid-Sixteenth Century." Ph.D. diss., Yale University, 1968.

Williams, Gerhild Scholz. "Gelächter vor Gott: Mensch und Kosmos bei Franck und Paracelsus." Daphnis 15 (1986): 463–81.

Windholz, George. "The Case of the Renaissance Psychiatrist Peter Mair." Sixteenth Century Journal 22 (1991): 163–72.

Winzinger, Franz. "Zum Werk Wolf Hubers, Georg Lembergers und des Meisters der Wunder von Maria Zell." Zeitschrift für Kunstwissenschaft 12 (1958): 71–73.

___. Albrecht Altdorfer: Graphik. Holzschnitte, Kupferstiche, Radierungen. Gesamtausgabe. Munich, 1963.

. Wolf Huber: Das Gesamtwerk. 2 vols. Munich, 1979.

Wittkower, Rudolf, and Margot Wittkower. Born Under Saturn: The Character and Conduct of Artists. A Documented History from Antiquity to the French Revolution. New York, 1963.

Wolf, Erik. Grosse Rechtsdenker der deutschen Geistesgeschichte. 4th ed. Tübingen, 1963.

Wolf, Gustav. "Über den Hofnarren Kaiser Karls V., genannt El Conde don Frances de Zuñiga und seine Chronik." Sitzungsberichte der kaiserlichen Akademie der Wissenschaften. Philosophisch-historische Classe, vol. 5, sec. 2 (1850), Heft 6–10, pp. 21–63.

Wolf, Margery. A Thrice-Told Tale: Feminism, Postmodernism, and Ethnographic Responsibility. Stanford, 1992.

Wolfersdorf, P. "Die dämonischen Gestalten der schwäbischen Volksüberlieferung." Ph.D. diss., Tübingen, 1949.

Wright, William J. "Reformation Contributions to the Development of Public Welfare Policy in Hesse." Journal of Modern History 49 (1977), D1145 (on demand article).

—. Capitalism, the State, and the Lutheran Reformation: Sixteenth-Century Hesse. Athens, Ohio, 1988.

Wunderlich, Werner. "'Schildbürgerstreiche': Bericht zur Lalebuch- und Schildbürgerforschung." Deutsche Vierteljahrsschrift für Literaturwissenschaft und Geistesgeschichte 56 (1982): 641–85.

___. Wunderseltsame Geschichten: Interpretationen zu Schildbürgern und Lalebuch.

Göppingen, 1983.

Wynands, Dieter P. J. Geschichte der Wallfahrten im Bistum Aachen. Aachen, 1986.

Zambelli, Paola. "Magic and Radical Reformation in Agrippa of Nettesheim." Journal of the Warburg and Courtauld Institute 39 (1976): 69–103.

___. "Scholastiker und Humanisten: Agrippa und Trithemius zur Hexerei. Die natürliche Magie und die Entstehung kritischen Denkens." Archiv für Kulturgeschichte 67 (1985): 41–80.

——. L'ambigua natura della magica: Filosofi, streghe, riti nel Rinascimento. Milan, 1991.

Zedler, Johann Heinrich. Grosses vollständiges Universal-Lexikon. 64 vols. Leipzig and Halle, 1732–50.

Zeeden, Ernst Walter. Katholische Überlieferungen in den lutherischen Kirchenordnungen des 16. Jahrhunderts. Münster, 1959.

Zender, Matthias. "Mirakelbücher als Quelle für das Volksleben im Rheinland." Rheinische Vierteljahrsblätter 41 (1977): 108–23.

Zika, Charles. "Hosts, Processions and Pilgrimages: Controlling the Sacred in Fifteenth-Century Germany." Past & Present, no. 118 (Feb. 1988): 25–64.

Zoepfl, Friedrich. "Nacktwallfahrten." In Wallfahrt und Volkstum in Geschichte, pp. 266–72. Forschungen zur Volkskunde, 16–17. Düsseldorf, 1934.

i . -i n " ' N -__' , _I' i N r A 1 i . . .‘- | o i . B 1 i ' N - -F- i 0 | i e SR ., YT e L RS B A g I"l'r 'W S—— - 4 } i I , ] 5 = P il s Lt e ) | RIS el e .Jil:_th_kml'ﬂ .-i_"'t';i'-'--h L r‘-“']- ] BE A . - : R é-” ||-i{ r- '3 1|'1' r _’L‘W~J N B 2 - e o ‘ | . Hd""lw r""” L | .* | W B e, g Sl e it !-i-'lm'tll-‘:.ﬁwh,mﬁ"} iyl ' - ' - i [P - B L SR T S ) B '!'1-~ i _“I‘:__l:__l.-.r._f L. m .H.il i . -i n " ' N -__' , _I' i N r A 1 i . . .‘- | o i . B 1 i ' N - -F- i 0 | i e SR ., YT e L RS B A g I"l'r 'W S—— - 4 } i I , ] 5 = P il s Lt e ) | RIS el e .Jil:_th_kml'ﬂ .-i_"'t';i'-'--h L r‘-“']- ] BE A . - : R é-” ||-i{ r- '3 1|'1' r _’L‘W~J N B 2 - e o ‘ | . Hd""lw r""” L | .* | W B e, g Sl e it !-i-'lm'tll-‘:.ﬁwh,mﬁ"} iyl ' - ' - i [P - B L SR T S ) B '!'1-~ i _“I‘:__l:__l.-.r._f L. m .H.il
