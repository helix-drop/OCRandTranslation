## Index

In this index an "f" after a number indicates a separate reference on the next page, and an "ff" indicates separate references on the next two pages. A continuous discussion over two or more pages is indicated by a span of page numbers, e.g., "57-59." Passim is used for a cluster of references in close but not consecutive sequence.

Aachen, St. Vitus' dance in, 33

Abel, 93

Abersee, 302

Accursius, 191

Ackermann, Peter, 254-62

Adam, 94

Agricola, Johann, 259

Agrippa of Nettesheim, Heinrich Cor-

nelius, 173, 198f, 201, 204

Alberti, Michael, 226

Albrecht Friedrich, duke of Prussia,

164

alchemy,108,114

Alciati, Andrea, 192

Aldehens, widow, 361

Alexendrius, Julius, 166

Alddorfer, Albrecht, 305

Altenstaig, Johannes, 71

Altötting, 62, 292–304, 307, 318

Altzenbach, Gerhard, 248f

Amman,Jost,243-48

Ammenheusser, Anna, 358

Amsterdam, demonic possession in, 70

Anabaptism, 123, 311f

anaesthesia, symptoms of, 5, 49

Andechs, 283, 290, 307

Angelus (Engel), Andreas, 55

Andreae, Johannes, 189

Anhalt, Joachim prince of, 105

Anhalt, St. Vitus' dance in, 37

Anna, countess of Tecklenburg, 199

Anna, duchess of Mecklenburg, 324

Anna Barbara of Stein am Rhein, 76

Ansbach, 270

Ansbach, Georg Friedrich margrave of,

272

antisemitism, 304

apocalypse, madness and, 98

apocalyptic ideas, Luther's, 98, 101

Aquinas, Thomas, 83

Arab medicine,144,166f

Arcularius, Caspar, 360

Aretinus, Angelus, 191

Aristotle, physicians and, 140, 146, 149, 198

Aristotle (pseudo-), Problems, 23, 140, 154, 171

Arnhem, 173

Arnswalde (Choszczno), 50f

artists, madness of, 26ff

asceticism, madness and, 89-90, 107

Aschner, Bernhard, 109

astrology, 108, 144

Aufkirchen am Würmsee, 283, 291
