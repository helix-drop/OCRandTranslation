## References

References

Addis, D. R., Wong, A. T. and Schacter, D. L. (2007). Remembering the past and imagining the future: common and distinct neural substrates during event construction and elaboration. Neuropsychologia, 45(7), 1363–1377.

Akins, K. (2001). Of sensory systems and the “aboutness” of mental states. In: Bechtel, W., Mandik, P., Mundale, J. and Stufflebeam, R. S., eds. Philosophy and the Neurosciences, pp. 156–178. Oxford: Blackwell Publishers.

Albert, N. B., Robertson, E. M. and Miall, R. C. (2009). The resting human brain and motor learning. Current Biology, 19, 1023–1027.

Alcaro, A. et al. (2010). Is subcortical-cortical midline activity in depression mediated by glutamate and GABA? A cross-species translational approach. Neuroscience and Biobehavioral Reviews, 34(4), 592–605.

Alcaro, A., Huber, R. and Panksepp, J. (2007). Behavioral functions of the mesolimbic dopaminergic system: an affective neuroethological perspective. Brain Research Reviews, 56(2), 283–321.

Aleman, A. et al. (2005). The functional neuroanatomy of metrical stress evaluation of perceived and imagined spoken words. Cerebral Cortex, 15(2), 221–228.

Allen, P, Aleman, A. and McGuire, P. K. (2007a). Inner speech models of auditory verbal hallucinations: evidence from behavioural and neuroimaging studies. International Review of Psychiatry, 19(4), 407–415.

Allen, P. et al. (2007b). Neural correlates of the misattribution of speech in psychosis. British Journal of Psychiatry, 190, 162–169.

Allen, P., Laroi, F., McGuire, P. K. and Aleman, A. (2008). The hallucinating brain: a review of structural and functional neuroimaging studies of hallucinations. Neuroscience and Biobehavioral Reviews, 32(1), 175–191.

Allison, H. E. (1983). Kant's Transcendental Idealism. New Haven, CT: Yale University Press.

Ameriks, K. (2000). Kant and the Fate of Autonomy: problems in the appropriation of the critical philosophy. Cambridge: Cambridge University Press.

Arieli, A. et al. (1996). Dynamics of ongoing activity: explanation of the large variability in evoked cortical responses. Science, 273, 1868–1871.

Baars, B. J. (2005). Global workspace theory of consciousness: toward a cognitive neuroscience of human experience. Progress in Brain Research, 150, 45–53.

Bacal, H. A. (1987). British object-relations theorists and self psychology: some critical reflections. International Journal of Psychoanalysis, 68(1), 81–98.

Barry, R. J. et al. (2007). EEG differences between eyes-closed and eyes-open resting conditions. Clinical Neurophysiology, 118, 2765–2773.

Bechara, A. (2004). The role of emotion in decision-making: evidence from neurological patients with orbitofrontal damage. Brain and Cognition, 55(1), 30–40.

Beckmann, C. F., DeLuca, M., Devlin, J. T. and Smith, S. M. (2005). Investigations into resting-state connectivity using independent component analysis. Philosophical Transactions of the Royal Society of London. Series B, Biological Sciences, 360, 1001–1013.

Benedetti, G. (1983). Todeslandschaften der Seele. Göttingen: Vandenhoeck and Ruprecht.

Benes, F. M. (2007). Searching for unique endophenotypes for schizophrenia and bipolar disorder within neural circuits and their molecular regulatory mechanisms. Schizophrenia Bulletin, 33(4), 932–936.

Benes, F. M. et al. (2008). Circuitry-based gene expression profiles in GABA cells of the trisynaptic pathway in schizophrenia versus bipolaris. Proceedings of the National Academy of Sciences of the United States of America, 105, 20935–20940.

Ben-Simon, E. et al. (2008). Never resting brain: simultaneous representation of two alpha related processes in humans. PLoS One, 3(12), e3984.

Bennett, A. O. M. (2008). Consciousness and hallucinations in schizophrenia: the role of synapse regression. Australian and New Zealand Journal of Psychiatry, 42(11), 915–931.

Bennett, M. and Hacker, P. M. (2003). Philosophical Foundations of Neuroscience. New York: Basic Books.

Bermpohl, F. et al. (2009). Attentional modulation of emotional stimulus processing in patients with major depression—alterations in prefrontal cortical regions. Neuroscience Letters, 463(2), 108–113.

Berretta, S., Gisabella, B. and Benes, F. M. (2009). A rodent model of schizophrenia derived from postmortem studies. Behavioural Brain Research, 204(2), 363–368.

Berridge, K. C. and Winkielman, P. (2003). What is an unconscious emotion? (The case for unconscious “liking”). Cognition and Emotion, 17(2), 181–211.

Berze, J (1914). Die Primare Insuffizienz der Psychischen Aktivitat. Leipzig: Franz Deuticke.

Bickle, J. and Mandik, B. (2006). The Philosophy of Neuroscience. The Stanford Encyclopedia of Philosophy. http://plato.stanford.edu/entries/neuroscience/.

Bin Kimura, B. (1997). Cogito et je. L'Evolution Psychiatrique, 62, 335–348.

Birbaumer, N., Hinterberger, T., Kübler, A. and Neumann, N. (2003). The thought-translation device (TTD): neurobehavioral mechanisms and clinical outcome. IEEE Transactions on Neural Systems and Rehabilitation Engineering, 11(2), 120–123.

Birnbacher, D. (2005). Schopenhauer und die moderne Neurophilosophie. In: Birnbacher, D. and Koßler, M., eds. Die Bedeutung Schopenhauers für das moderne Bild des Menschen, pp. 34–55. Würzburg: Schopenhauer-Jahrbuch.

Blakemore, S. and Frith, C. (2003). Disorders of self-monitoring and symptoms of schizophrenia.

In: Kircher, T. and David, A., eds. The Self in Neuroscience and Psychiatry, pp. 407–425. Cambridge: Cambridge University Press.

Blakemore, S. J., Goodbody, S. J. and Wolpert, D. M. (1998). Predicting the consequences of our own actions: the role of sensorimotor context estimation. Journal of Neuroscience, 18, 7511–7518.

Blankenburg, W. (1969). Ansatze zu einer Psychopathologie des "common sense." Confinía Psychiatrica, 12, 144–163.

Blass, R. B. and Carmeli, Z. (2007). Reply to Drs Mancia and Pugh. International Journal of Psychoanalysis, 88, 1068–1070.

Blatt, S. J. (1998). Contributions of psychoanalysis to the understanding and treatment of depression. Journal of the American Psychoanalytic Association, 46, 723–752.

Bleichmar, H. B. (1996). Some subtypes of depression and their implications for psychoanalytic treatment. International Journal of Psychoanalysis, 77, 935.

Bleichmar, H. (2010). Rethinking pathological mourning: multiple types and therapeutic approaches. Psychoanalytic Quarterly, 79(1), 71–93.

Bleuler, E. (1911). Dementia Praecox or the Group of Schizophrenias. New York: International Universities Press.

Bleuler, E. (1916). Lehrbuch der Psychiatrie. Berlin: Springer.

Böker, H. and Northoff, G. (2005). Desymbolisierung in der schweren Depression und das Problem der Hemmung: Ein neuropsychoanalytisches Modell der Störung des emotionalen Selbstbezuges Depressiver. Psyche – Zeitschrift für Psychoanalyse und ihre Anwendungen, 59, 964–989.

Böker, H. and Northoff, G. (2010). Die Entkopplung des Selbst in der Depression: Empirische Befunde und neuropsychodynamische Hypothesen. Psyche – Zeitschrift für Psychoanalyse und ihre Anwendungen, 64, 934–976.

Böker, H. et al. (2000). [Self concept and object relations of patients with affective disorders —individual centered diagnosis with the repertory-grid technique] [article in German]. Psychotherapie, Psychosomatik, Medizinische Psychologie, 50(8), 328–334.

Boly, M. et al. (2007). Baseline brain activity fluctuations predict somatosensory perception in humans. Proceedings of the National Academy of Sciences of the United States of America, 104(29), 12187–12192.

Boly, M. et al. (2008a). Intrinsic brain activity in altered states of consciousness: how conscious is the default mode of brain function? Annals of the New York Academy of Sciences, 1129, 119–129.

Boly, M. et al. (2008b). Consciousness and cerebral baseline activity fluctuations. Human Brain Mapping, 29(7), 868–874.

Braun, C. M. J. et al. (2003). Brain modules of hallucination: an analysis of multiple patients with brain lesions. Journal of Psychiatry and Neuroscience, 28(6), 432–449.

Brockman, R. (2002). Self, object, neurobiology. Neuropsychoanalysis, 4, 87–99.

Brook, A. (1994). Kant and the Mind. Cambridge: Cambridge University Press.

Brook, A. (1998). Neuroscience versus Psychology in Freud. Annals of the New York Academy of Sciences, 843(1), 66–79.

Brook, A. (2003). Kant and Freud. Ottawa: Carleton University.

Broyd, S. J. et al. (2009). Default-mode brain dysfunction in mental disorders: a systematic review. Neuroscience and Biobehavioral Reviews, 33(3), 279–296.

Buckner, R. L., Andrews-Hanna, J. R. and Schacter, D. L. (2008). The brain’s default network: anatomy, function, and relevance to disease. Annals of the New York Academy of Sciences, 1124, 1–38.

Busch, N. A., Dubois, J. and VanRullen, R. (2009). The phase of ongoing EEG oscillations predicts visual perception. Journal of Neuroscience, 29, 7869–7876.

Buzsaki, G. (2006). Rhythms of the Brain. New York: Oxford University Press.

Buzsaki, G. and Draguhn, A. (2004). Neuronal oscillations in cortical networks. Science, 304, 1926–1929.

Cain, N. M., Pincus, L. A. and Ansell, E. B. (2008). Narcissism at the crossroads: phenotypic description of pathological narcissism across clinical theory, social/personality psychology, and psychiatric diagnosis. Clinical Psychology Review, 28, 638–656.

Calhoun, V. D., Maciejewski, P. K., Pearlson, G. D. and Kiehl, K. A. (2008). Temporal lobe and “default” hemodynamic brain modes discriminate between psychosis and bipolar disorder. Human Brain Mapping, 29(11), 1265–1275.

Camerer, C. F. and Fehr, E. (2006). When does “economic man” dominate social behavior? Science, 311, 47–52.

Canli, T. et al. (2004). Brain activation to emotional words in depressed vs healthy subjects. Neuroreport, 15, 2585–2588.

Canli, T. et al. (2005). Amygdala reactivity to emotional faces predicts improvement in major depression. Neuroreport, 16(12), 1267–1270.

Carhart-Harris, R. L. and Friston, K. J. (2010). The default-mode, ego-functions and free-energy: a neurobiological account of Freudian ideas. Brain, 133, 1265–1283.

Carhart-Harris, R. L., Mayberg, H. S., Malizia, A. L. and Nutt. D. (2008). Mourning and melancholia revisited: correspondences between principles of Freudian metapsychology and empirical findings in neuropsychiatry. Annals of General Psychiatry, 24, 7–9.

Christoff, K. et al. (2009). Experience sampling during fMRI reveals default network and executive system contributions to mind wandering. Proceedings of the National Academy of Sciences of the United States of America, 106, 8719–8724.

Churchland, P. (1986). Neurophilosophy. Cambridge, MA: MIT Press.

Churchland, P. S. (2002). Self-representation in nervous systems. Science, 296, 308–310.

Clark, A. (2003). Natural-Born Cyborgs: minds, technologies, and the future of human intelligence. Oxford: Oxford University Press.

Collins, A. C. (1999). Possible Experience: understanding Kant's Critique of Pure Reason. London: University of California Press.

Corlett, P. R., Krystal, J. H., Taylor, J. R. and Fletcher, P. C. (2009). Why do delusions persist? Frontiers in Human Neuroscience, 3, 12.

Craig, A. D. (2002). How do you feel? Interoception: the sense of the physiological condition of the body. Nature Reviews. Neuroscience, 3(8), 655–666.

Craig, A. D. (2003). Interoception: the sense of the physiological condition of the body. Current Opinion in Neurobiology, 13, 500–505.

Craig, A. D. (2004). Human feelings: why are some more aware than others? Trends in Cognitive Sciences, 8(6), 239–241.

Craig, A. D. (2005). Forebrain emotional asymmetry: a neuroanatomical basis? Trends in Cognitive Sciences, 9(12), 566–571.

Craig, A. D. (2009). How do you feel—now? The anterior insula and human awareness. Nature Reviews. Neuroscience, 10(1), 59–70.

Cramer, P. (2000). Defense mechanisms in psychology today. Further processes for adaptation. American Psychologist, 55(6), 637–646.

Crick, F. (1994). The Astonishing Hypothesis: the scientific search for the soul. New York: Simon & Schuster.

Crick, F., Koch, C., Kreiman, G. and Fried, I. (2004). Consciousness and neurosurgery. Neurosurgery, 55(2), 273–81; discussion 281–282.

Critchley, H. D. (2005). Neural mechanisms of autonomic, affective, and cognitive integration. Journal of Comparative Neurology, 493(1), 154–166.

Critchley, H. D. et al. (2004). Neural systems supporting interoceptive awareness. Nature Neuroscience, 7(2), 189–195.

Critchley, H. D. et al. (2005). Activity in the human brain predicting differential heart rate responses to emotional facial expressions. NeuroImage, 24(3), 751–762.

Czisch, M. et al. (2004). Functional MRI during sleep: BOLD signal decreases and their electrophysiological correlates. European Journal of Neuroscience, 20(2), 566–574.

Dalgleish, T. (2004). The emotional brain. Nature Reviews. Neuroscience, 5(7), 583–589.

Damasio, A. (1999). The Feeling of What Happens: body and emotion in the making of consciousness. Orlando, FL: Harcourt Brace & Company.

Damasio, A. (2003a). Feelings of emotion and the self. Annals of the New York Academy of Sciences, 1001, 253–261.

Damasio, A. (2003b). Mental self: the person within. Nature, 423, 227.

Damoiseaux, J. S. et al. (2006). Consistent resting-state networks across healthy subjects. Proceedings of the National Academy of Sciences of the United States of America, 103, 13848–13853.

Dannlowski, U. et al. (2010). Emotion-specific modulation of automatic amygdala responses by 5-HTTLPR genotype. NeuroImage, 53, 893–898.

D'Argembeau, A. et al. (2005). Self-referential reflective activity and its relationship with rest: a PET study. NeuroImage, 25(2), 616–624.

Davidson, R. J. et al. (2003). The neural substrates of affective processing in depressed patients treated with venlafaxine. American Journal of Psychiatry, 160(1), 64–75.

deCharms, R. C. and Zador, A. (2000). Neural representation and the cortical code. Annual Review of Neuroscience, 23, 613–647.

de Greck, M. et al. (2008). Is our self-based on reward? Self-relatedness recruits neural activity in the reward system. NeuroImage, 39(4), 2066–2075.

de Greck, M. et al. (2010). Decreased neuronal activity in reward circuitry of pathological gamblers during processing of personal relevant stimuli. Human Brain Mapping, 31, 1802–1812.

Demertzi, A. et al. (2008). Is there anybody in there? Detecting awareness in disorders of consciousness. Expert Review of Neurotherapeutics, 8(11), 1719–1730.

Dennett, D. (1978). Brainstorms: philosophical essays on mind and psychology. Cambridge, MA: MIT Press.

Desseilles, M. et al. (2009). Abnormal neural filtering of irrelevant visual information in depression. Journal of Neuroscience, 29(5), 1395–1403.

Di Cristo, G. (2007). Development of cortical GABAergic circuits and its implications for neurodevelopmental disorders. Clinical Genetics, 72(1), 1–8.

Dierks, T. et al. (1999). Activation of Heschl's gyrus during auditory hallucinations. Neuron, 22(3), 615–621.

Dimaggio, G., Fiore, D., Salvatore, G. and Carcione, A. (2007a). Dialogical relationship patterns in narcissistic personalities: session analysis and treatment implications. Journal of Constructivist Psychology, 20, 1–29.

Dimaggio, G. et al. (2007b). Poor metacognition in narcissistic and avoidant personality disorders: four psychotherapy patients analysed using the Metacognition Assessment Scale. Clinical Psychology and Psychotherapy, 14, 386–401.

Dimaggio, G. et al. (2008a). Know yourself and you shall know the other … to a certain extent: multiple paths of influence of self-reflection on mindreading. Consciousness and Cognition, 17, 778–789.

Dimaggio, G. et al. (2008b). States of minds in narcissistic personality disorder: three psychotherapies analyzed using the grid of problematic states. Psychotherapy Research, 18(4), 466–480.

Dimaggio, G. et al. (2009a). Impaired decentration in personality disorder: a series of single cases analysed with the Metacognition Assessment Scale. Clinical Psychology and Psychotherapy, 16(5), 450–462.

Dimaggio, G. et al. (2010). A rational model for maximizing the effects of therapeutic relationship regulation in personality disorders with poor metacognition and over-regulation of affects. Psychology and Psychotherapy, 83, 363–384.

Dimaggio, M. D. (2009b). Impaired self-reflection in psychiatric disorders among adults: a proposal for the existence of a network of semi independent functions. Consciousness and Cognition, 18, 653–664.

Donahue, M. J. et al. (2009). Cerebral blood flow, blood volume, and oxygen metabolism dynamics in human visual and motor cortex as measured by whole-brain multi-modal magnetic resonance imaging. Journal of Cerebral Blood Flow and Metabolism, 29(11), 1856–1866.

Drevets, W. C., Price, J. L. and Furey, M. L. (2008a). Brain structural and functional abnormalities in mood disorders: implications for neurocircuitry models of depression. Brain Structure and Function, 213, 93–118.

Drevets, W. C., Savitz, J. and Trimble M. (2008b). The subgenual anterior cingulate cortex in mood disorders. CNS Spectrums, 13(8), 663–681.

Dümpelmann, M. (2002a). Psychosen und affektive Störungen nach Traumatisierung. In: Böker, H. and Hell, D., eds. Therapie der affektiven Störungen, pp. 66–90. Stuttgart: Schattauer.

Dümpelmann, M. (2002b). Trauma und Psychose-Trauma oder Psychose? In: Ardjomandi, M. E., Berghaus, A. and Knauss, W., eds. Jahrbuch der Gruppenanalyse, pp. 195–218. Göttingen: Vandenhoeck und Ruprecht.

Dümpelmann, M. (2004). Wie lässt sich praktisch anwenden, was psychoanalytische Augen erfassen? In: Machleidt, W., Garlipp, P. and Haltenhof, H., eds. Schizophrenie – Behandlungspraxis zwischen speziellen Methoden und integrativen Konzepten, pp. 148–154. Stuttgart: Schattauer.

Dümpelmann, M. (2009). Kontingenzerfahrung und Affektentwicklung. In: Wuensch, S., ed. Entwicklungspsychologische Ansätze in der Psychotherapie von Psychosen, pp. 78–96. Hamburg: Dokumentation zum 10jährigen Jubiläum der RPK Hamburg.

Dümpelmann, M. (2010). Zur Bedeutung der Affektentwicklung für die Behandlung von Psychosen. In: Böker, H., ed. Psychoanalyse im Dialog mi den Nachbarwissenschaften, pp. 481–501. Giessen: Psychosozial-Verlag.

Edelman, G. M. (2003). Naturalizing consciousness: a theoretical framework. Proceedings of the National Academy of Sciences of the United States of America, 100(9), 5520–5524.

Edelman, G. M. and Tononi, G. (2000). A Universe of Consciousness: how matter becomes imagination. New York: Basic Books.

Elliott, R. et al. (1998). Abnormal neural response to feedback on planning and guessing tasks in patients with unipolar depression. Psychological Medicine, 28, 559–571.

Elliott, R., Rubinsztein, J. S., Sahakian, B. J. and Dolan, R. J. (2002). The neural basis of mood-congruent processing biases in depression. Archives of General Psychiatry, 59(7), 597–604.

Ellison-Wright, I. and Bullmore, E. (2009). Meta-analysis of diffusion tensor imaging studies in schizophrenia. Schizophrenia Research, 108, 3–10.

Engel, A. K., Fries, P. and Singer, W. (2001). Dynamic predictions: oscillations and synchrony in top–down processing. Nature Reviews. Neuroscience, 2, 704–716.

Enzi, B. et al. (2009). Is our self nothing but reward? Neuronal overlap and distinction between reward and personal relevance and its relation to human personality. PLoS One, 4, e8429.

Ersner-Hershfield, H., Wimmer, G. E. and Knutson, B. (2009). Saving for the future self: neural measures of future self-continuity predict temporal discounting. Social Cognitive and Affective Neuroscience, 4(1), 85–92.

Eshel, N. and Roiser, J. P. (2010). Reward and punishment processing in depression. Biological Psychiatry, 68(2), 118–124.

Fair, S. B. Gilbert, J. A., Matthys, D. R. and Lindner, C. H. (2000). Development of a phase-displacement equation for panoramic interferometry. Applied Optics, 39, 3289–3294.

Fan, Y. et al. (2010). The narcissistic self and its psychological and neural correlates: an exploratory fMRI study. Psychological Medicine, 13, 1–10.

Federn, P. (1952). Ego Psychology and the Psychoses. New York: Basic Books.

Fehr, E. and Camerer, C. F. (2007). Social neuroeconomics: the neutral circuitry of social preferences. Trends in Cognitive Sciences, 11, 419–427.

Feinberg, I. and Guazzelli, M. (1999). Schizophrenia – a disorder of the corollary discharge systems that integrate the motor systems of thought with the sensory systems of consciousness. British Journal of Psychiatry 174, 196–204.

Feinberg, T. E. (2001). Altered Egos: how the brain creates the self. New York: Oxford University Press.

Feinberg, T. E. (2009). From Axons to Identity: neurological explorations of the nature of the self. Norton Series on Interpersonal Neurobiology. New York: W. W. Norton and Company.

Feinberg, T. E. (2010). Neuropathologies of the self: a general theory. Neuropsychoanalysis, 12, 133–158.

Fiorillo, C. D. (2008). Towards a general theory of neural computation based on prediction by single neurons. PLoS One, 3(10), e3298.

Fiser, J., Chiu, C. and Weliky, M. (2004). Small modulation of ongoing cortical dynamics by sensory input during natural vision. Nature, 431, 573–578.

Fitzgerald, P. B. et al. (2006). An analysis of functional neuroimaging studies of dorsolateral prefrontal cortical activity in depression. Psychiatry Research, 148(1), 33–45.

Fitzgerald, P. B. et al. (2007). A functional magnetic resonance imaging study of the effects of low frequency right prefrontal transcranial magnetic stimulation in depression. Journal of Clinical Psychopharmacology, 27(5), 488–492.

Fletcher, P. C. and Frith, C. D. (2009). Perceiving is believing: a Bayesian approach to explaining the positive symptoms of schizophrenia. Nature Reviews. Neuroscience, 10, 48–58.

Fliessbach, K. et al. (2007). Social comparison affects reward-related brain activity in the human ventral striatum. Science, 318, 1305–1308.

Fonagy, P. (2003). Psychoanalysis today. World Psychiatry, 2(2), 73–80.

Fonagy, P., Gergely, G. and Target, M. (2007). The parent–infant dyad and the construction of the subjective self. Journal of Child Psychology and Psychiatry, 48, 288–328.

Ford, J. M. et al. (2002). Reduced communication between frontal and temporal lobes during talking in schizophrenia. Biological Psychiatry, 51(6), 485–492.

Ford, J. M. et al. (2007). Synch before you speak: auditory hallucinations in schizophrenia. American Journal of Psychiatry, 164(3), 458–466.

Ford, J. M. et al. (2008). Out-of-synch and out-of-sorts: dysfunction of motor-sensory communication in schizophrenia. Biological Psychiatry, 63(8), 736–743.

Ford, J. M. et al. (2009). Tuning in to the voices: a multisite FMRI study of auditory hallucinations. Schizophrenia Bulletin, 35(1), 58–66.

Fosshage, J. L. (2009). Some key features in the evolution of self psychology and psychoanalysis. Annals of the New York Academy of Sciences, 1159, 1–18.

Fox, M. D. and Raichle, M. E. (2007). Spontaneous fluctuations in brain activity observed with functional magnetic resonance imaging. Nature Reviews. Neuroscience, 8(9), 700–711.

Fox, M. D. et al. (2005). The human brain is intrinsically organized into dynamic, anticorrelated functional networks. Proceedings of the National Academy of Sciences of the United States of America, 102, 9673–9678.

Fox, M. D. et al. (2006). Coherent spontaneous activity accounts for trial-to-trial variability in human evoked brain responses. Nature Neuroscience, 9, 23–25.

Fransson, P. (2005). Spontaneous low-frequency BOLD signal fluctuations: an fMRI investigation of the resting-state default mode of brain function hypothesis. Human Brain Mapping, 26(1), 15–29.

Fransson, P. and Marrelec, G. (2008). The precuneus/posterior cingulate cortex plays a pivotal role in the default mode network: evidence from a partial correlation network analysis. NeuroImage, 42(3), 1178–1184.

Freud, S. (1891). Zur Auffassung der Aphasien. Leipzig: Franz Deuticke.

Freud, S. (1894). The Neuro-Psychoses of Defence. Standard Edition of the Complete Psychological Works of Sigmund Freud. London: Hogarth Press.

Freud, S. (1895). Project for a Scientific Psychology. Standard Edition of the Complete Psychological Works of Sigmund Freud. London: Hogarth Press.

Freud, S. (1900). Die Traumdeutung. Leipzig: Franz Deuticke.

Freud, S. (1905). Three Essays on the Theory of Sexuality, tr. J. Strachey. New York: Basic Books (1962 edition).

Freud, S. (1910). Leonardo da Vinci and a Memory of his Childhood. Standard Edition. New York: W. W. Norton.

Freud, S. (1911). Psychoanalytic Notes on an Autobiographical Account of a Case of Paranoia. Standard Edition, Volume 12. London: Hogarth Press.

Freud, S. (1914). Zur Einführung des Narzissmus. Jahrbuch der Psychoanalyse, 6, 1–24.

Freud, S. (1915). The Unconscious. Standard Edition, Volume 14. London: Hogarth Press.

Freud, S. (1917). Mourning and Melancholia. On the History of the Psycho-Analytic Movement. Papers on Metapsychology and Other Works. Standard Edition, Volume 14.

Freud, S. (1921). Massenpsychologie und Ich-Analyse. Wien: Internationaler Psychoanalytischer Verlag.

Freud, S. (1923a). Das Ich und das Es. Leipzig: Internationaler Psychoanalytischer Verlag.

Freud, S. (1923b). Encyclopedia articles. In: Psychoanalysis: an empirical science. London: Vintage.

Freud, S. (1924). Neurosis and Psychosis. Standard Edition, Volume 19. London: Hogarth Press.

Freud, S. (1926). Inhibitions, Symptoms and Anxiety. Standard Edition, Volume 20. London: Hogarth Press.

Freud, S. (1933). New Introductory Lectures on Psycho-Analysis. London: L. Woolf and V. Woolf at the Hogarth Press, and the Institute of Psycho-analysis.

Freud, S. (1940). An Outline of Psychoanalysis. Standard Edition, Volume 23. London: Hogarth Press.

Freud, S. (1946). The Ego and the Mechanisms of Defence. New York: International Universities Press (originally published 1936).

Fries, P. et al. (2001). Modulation of oscillatory neuronal synchronization by selective visual attention. Science, 291, 1560–1563.

Fries, P., Nikolic, D. and Singer, W. (2007). The gamma cycle. Trends in Neurosciences, 30, 309–316.

Friston, K. (2005). Disconnection and cognitive dysmetria in schizophrenia. American Journal of Psychiatry, 162(3), 429–432.

Friston, K. and Kiebel, S. (2009). Predictive coding under the free-energy principle. Philosophical Transactions of the Royal Society of London. Series B, Biological Sciences, 364, 1211–1221.

Frith, C. (1999). How hallucinations make themselves heard. Neuron, 22(3), 414–415.

Frith, C. D. (1992). The Cognitive Neuropsychology of Schizophrenia. Hove, Sussex: Lawrence Erlbaum Associates.

Frith, C. D. and Done, D. J. (1988). Towards a neuropsychology of schizophrenia. British Journal of Psychiatry, 153, 437–443.

Frith, C. D. and Frith, U. (2008). Implicit and explicit processes in social cognition. Neuron, 60(3), 503–510.

Frith, C. D., Friston, K. J., Liddle, P. F. and Frackowiak, R. S. (1992). PET imaging and cognition in schizophrenia. Journal of the Royal Society of Medicine, 85(4), 222–224.

Fu, C. and McGuire, P. K. (2003). Hearing voices or hearing the self in disguise? Revealing the neural correlates of auditory hallucinations in schizophrenia. In: Kircher, T. and David, A., eds. The Self in Neuroscience and Psychiatry, pp. 425–436. Cambridge: Cambridge University Press.

Fu, C. H. et al. (2004). Attenuation of the neural response to sad faces in major depression by antidepressant treatment: a prospective, event-related functional magnetic resonance imaging study. Archives of General Psychiatry, 61(9), 877–889.

Fu, C. H. et al. (2006). An fMRI study of verbal self-monitoring: neural correlates of auditory verbal feedback. Cerebral Cortex, 16(7), 969–977.

Gabbard, G. O. (1992). Psychodynamic psychiatry in the “decade of the brain.” American Journal of Psychiatry, 149(8), 991–998.

Gabbard, G. O. (2005a). Psychodynamic Psychiatry in Clinical Practice. Arlington, VA: American Psychiatric Press, Inc.

Gabbard, G. O. (2005b). Mind, brain, and personality disorders. American Journal of Psychiatry, 162(4), 648–655.

Gallagher, H. L. and Frith, C. D. (2003). Functional imaging of “theory of mind.” Trends in Cognitive Sciences, 7(2), 77–83.

Gallagher, S. (2000). Philosophical conceptions of the self: implications for cognitive science. Trends in Cognitive Sciences, 4(1), 14–21.

Garfield, S. L. (1995). Psychotherapy: an eclectic-integrative approach. 2nd edn. New York: John Wiley & Sons, Inc.

Garrido, M. I. et al. (2009). The mismatch negativity: a review of underlying mechanisms. Clinical Neurophysiology, 120(3), 453–463.

Gazzaniga, M. S., Ivry, R. B. and Mangun, G. R. (2008). Cognitive Neuroscience: the biology of the mind. New York: W. W. Norton & Company, Inc.

Gehrie, M. J. (2009). The evolution of the psychology of the self: toward a mature narcissism. Annals of the New York Academy of Sciences, 1159, 31–50.

Georgopoulos, A.P. et al. (1989). Mental rotation of the neuronal population vector. Science, 243, 234–236.

Gilbert, C. et al. (2000). Interactions between attention, context and learning in primary visual cortex. Vision Research, 40, 1217–1226.

Gillihan, S. J. and Farah, M. J. (2005). Is self special? A critical review of evidence from experimental psychology and cognitive neuroscience. Psychological Bulletin, 131, 76–97.

Goel, V. and Dolan, R. J. (2003). Reciprocal neural response within lateral and ventral medial prefrontal cortex during hot and cold reasoning. NeuroImage, 20(4), 2314–2321.

Golomb, J. D. et al. (2009). Enhanced visual motion perception in major depressive disorder. Journal of Neuroscience, 29, 9072–9077.

Gonzalez-Burgos, G. and Lewis, D. A. (2008). GABA neurons and the mechanisms of network oscillations: implications for understanding cortical dysfunction in schizophrenia. Schizophrenia Bulletin, 34(5), 944–961.

Grammont, F. and Riehle, A. (2003). Spike synchronization and firing rate in a population of motor cortical neurons in relation to movement direction and reaction time. Biological Cybernetics, 88(5), 360–373.

Green, A. (2001). Advice to psychoanalysts: “cognitive psychology is good for you.” Neuropsychoanalysis, 3, 16–19.

Greicius, M. (2008). Resting-state functional connectivity in neuropsychiatric disorders. Current Opinion in Neurology, 21(4), 424–430.

Greicius, M. D. et al. (2004). Default-mode network activity distinguishes Alzheimer's disease from healthy aging: evidence from functional MRI. Proceedings of the National Academy of Sciences of the United States of America, 101, 4637–4642.

Greicius, M. D. et al. (2009). Resting-state functional connectivity reflects structural connectivity in the default mode network. Cerebral Cortex, 19(1), 72–78.

Grimm, S. et al. (2008). Imbalance between left and right dorsolateral prefrontal cortex in major depression is linked to negative emotional judgment: an fMRI study in severe major depressive disorder. Biological Psychiatry, 63(4), 369–376.

Grimm, S. et al. (2009). Altered negative BOLD responses in the default-mode network during emotion processing in depressed subjects. Neuropsychopharmacology, 34, 932–843.

Grimm, S. et al. (2011). Reduced negative BOLD responses in the default-mode network and increased self-focus in depression. World Journal of Biological Psychiatry. [Epub ahead of print]

Grunebaum, M. F. et al. (2005). Symptom components of standard depression scales and past suicidal behavior. Journal of Affective Disorders, 87(1), 73–82.

Gur, R. E. et al. (1995). Resting cerebral glucose metabolism in first-episode and previously treated patients with schizophrenia relates to clinical features. Archives of General Psychiatry, 52(8), 657–667.

Halari, R. and Kumari, V. (2005). Comparable cortical activation with inferior performance in women during a novel cognitive inhibition task. Behavioural Brain Research, 158(1), 167–173.

Hartmann, H. P. (2009). Self and systems explorations in contemporary self psychology. Annals of the New York Academy of Sciences, 1159, 86–105.

Hartwich, P. (2006). Schizophrenie. Zur Defekt- und Konfliktinteraktion. In: Böker, H., ed. Psychoanalyse und Psychiatrie, pp. 45–69. Berlin: Springer.

Hasler, G. et al. (2009). Reward processing after catecholamine depletion in unmedicated, remitted subjects with major depressive disorder. Biological Psychiatry, 66(3), 201–205.

He, B. J. and Raichle, M. E. (2009). The fMRI signal, slow cortical potential and consciousness. Trends in Cognitive Sciences, 13(7), 302–309.

He, B. J. et al. (2008). Electrophysiological correlates of the brain’s intrinsic large-scale functional architecture. Proceedings of the National Academy of Sciences of the United States of America, 105(41), 16039–16044.

Heimer, L. (2003). A new anatomical framework for neuropsychiatric disorders and drug abuse. American Journal of Psychiatry, 160, 1726–1739.

Heinzel, A. et al. (2006). Self-related processing in the sexual domain: a parametric event-related fMRI study reveals neural activity in ventral cortical midline structures. Social Neuroscience, 1(1), 41–51.

Heinzel, A. et al. (2009). Segregated neural representation of psychological and somatic-vegetative symptoms in severe major depression. Neuroscience Letters, 456(2), 49–53.

Heller, A. S. et al. (2009). Reduced capacity to sustain positive emotion in major depression reflects diminished maintenance of fronto-striatal brain activation. Proceedings of the National Academy of Sciences of the United States of America, 106, 22445–22450.

Henningsen, P. (1998). [Self-recognition in the mirror of another? On the significance of cognitive neuroscience for psychoanalysis] [article in German]. Psychotherapie, Psychosomatik, Medizinische Psychologie, 48 (3–4), 78–87.

Henningsen, P. and Kirmayer, L. J. (2000). Mind beyond the net: implications of cognitive neuroscience for cultural psychiatry. Transcultural Psychiatry, 37(4), 467–494.

Herculano-Houzel, S. et al. (1999). Precisely synchronized oscillatory firing patterns require electroencephalographic activation. Journal of Neuroscience, 19(10), 3992–4010.

Hesselmann, G. et al. (2008). Spontaneous local variations in ongoing neural activity bias perceptual decisions. Proceedings of the National Academy of Sciences of the United States of America, 105, 10984–10989.

Hobson, J. A. (2009). REM sleep and dreaming: towards a theory of protoconsciousness. Nature Reviews. Neuroscience, 10(11), 803–813.

Hoffer, P. T. (2005). Reflections on cathexis. The Psychoanalytic Quarterly, 74, 1127–1135.

Hoffman, R. E. (2007). A social deafferentiation hypothesis for induction of active schizophrenia. Schizophrenia Bulletin, 33(5), 1066–1070.

Hoffman, R. E. (2010). Revisiting Arieti’s “listening attitude” and hallucinated voices. Schizophrenia Bulletin, 36(3), 440–442.

Hoffman, R. E. et al. (2007). Probing the pathophysiology of auditory/verbal hallucinations by combining functional magnetic resonance imaging and transcranial magnetic stimulation. Cerebral Cortex, 17(11), 2733–2743.

Hoffman, R. E. et al. (2008). Time course of regional brain activation associated with onset of auditory/verbal hallucinations. British Journal of Psychiatry, 193(5), 424–425.

Holstege, G., Bandler, R. and Saper, C. B. (1996). The emotional motor system. Progress in Brain Research, 107, 3–6.

Holt, R. R. (1962). A critical examination of Freud's concept of bound vs. free cathexis. Journal of the American Psychoanalytic Association, 10, 475–525.

Hopfinger, J. B., Buonocore, M. H. and Mangun, G. R. (2000). The neural mechanisms of top-down attentional control. Nature Neuroscience, 3(3), 284–291.

Hoptman, M. J. et al. (2010). Amplitude of low-frequency oscillations in schizophrenia: a resting state fMRI study. Schizophrenia Research, 117(1), 13–20.

Hubl, D. et al. (2004). Pathways that make voices: white matter changes in auditory hallucinations. Archives of General Psychiatry, 61(7), 658–668.

Hunter, M. D. et al. (2006). Neural activity in speech-sensitive auditory cortex during silence. Proceedings of the National Academy of Sciences of the United States of America, 103, 189–194.

Husserl, E. (1989). Ideas Pertaining to a Pure Phenomenology and to a Phenomenological Philosophy. Dordrecht: Kluwer Academic Publishers.

Ikemoto, S. and Panksepp, J. (1999). The role of nucleus accumbens dopamine in motivated behavior: a unifying interpretation with special reference to reward-seeking. Brain Research Reviews, 31(1), 6–41

Ingram, R. E. (1990). Self-focused attention in clinical disorders: review and a conceptual model. Psychological Bulletin, 107(2), 156–176.

Isomura, Y. et al. (2006). Integration and segregation of activity in entorhinal-hippocampal subregions by neocortical slow oscillations. Neuron, 52(5), 871–882.

Jafri, M. J. et al. (2008). A method for functional network connectivity among spatially independent resting-state components in schizophrenia. NeuroImage, 39(4), 1666–1681.

James, W. (1884). What is an emotion? Mind, 9, 185–205.

Jaspers, K. (1962a). Kant. San Diego, CA: Harcourt Brace & Company.

Jaspers, K. (1962b). General Psychopathology, tr. J. Hoenig and M. W. Hamilton. Manchester: Manchester University Press.

Javitt, D. C. (2008). Phenomenology, aetiology and treatment of schizophrenia. Novartis Foundation Symposium, 289, 4–16; discussion 17–22, 87–93.

Javitt, D. C. (2009). When doors of perception close: bottom-up models of disrupted cognition in psychosis. Annual Review of Clinical Psychology, 5, 249–275.

Jeannerod, M. (1999). To act or not to act: perspectives on the representation of actions. Quarterly Journal of Experimental Psychology: Human Experimental Psychology 52(1), 1–29.

Kandel, E. R. (1998). A new intellectual framework for psychiatry. American Journal of Psychiatry, 155(4), 457–469.

Kandel, E. R., Schwartz, J. H. and Jessell, T. M. (2000). Principles of Neural Science. New York: McGraw-Hill Companies.

Kant, G. J. and Meyerhoff, J. L. (1977). Release of endogenous norepinephrine from rat hypothalamus in vitro. Life Sciences, 20(1), 149–153.

Kant, I. (1783). Prolegomena to Any Future Metaphysics. Indianapolis, IN: Hackett Publishing Company (1972 edition).

Kant, I. (1998). Critique of Pure Reason Translated into English In: Guyer, P. and Wood, A., eds.

Critique of Pure Reason. Cambridge Edition of the Works of Immanuel Kant. Cambridge: Cambridge University Press.

Kaplan-Solms, K. and Solms, M. (2000). Clinical Studies in Neuro-Psychoanalysis: introduction to a depth neuropsychology. London: Karnac Books.

Kaufmann, C. et al. (2006). Brain activation and hypothalamic functional connectivity during human non-rapid eye movement sleep: an EEG/fMRI study. Brain, 129(3), 655–667.

Keedwell, P. A. et al. (2005). The neural correlates of anhedonia in major depressive disorder. Biological Psychiatry, 58(11), 843–853.

Keedwell, P. A. et al. (2010). Subgenual cingulate and visual cortex responses to sad faces predict clinical outcome during antidepressant treatment for depression. Journal of Affective Disorders, 120(1–3), 120–125.

Keenan, J. P. et al. (2003). Self-face processing in a callosotomy patient. European Journal of Neuroscience, 18(8), 2391–2395.

Kelley, W. M. et al. (2002). Finding the self? An event-related fMRI study. Journal of Cognitive Neuroscience, 14(5), 785–794.

Kenet, T. et al. (2003). Spontaneously emerging cortical representations of visual attributes. Nature, 425, 954–956.

Kernberg, O. (1966). Structural derivatives of object relationships. International Journal of Psychoanalysis, 47(2), 236–253.

Kernberg, O. F. (1984). Severe Personality Disorders. New Haven, CT: Yale University Press.

Kernberg, O. F. (1998). Pathological narcissism and narcissistic personality disorder: theoretical background and diagnostic classification. In: Ronningstam, E. F., ed. Disorders of Narcissism: diagnostic, clinical, and empirical implications, pp. 67–95. Washington, DC: American Psychiatric Press, Inc.

Kihlstroem, J. E. (1987). The cognitive unconscious. Science, 237, 1445–1452.

Kihlstroem, J., Barnhardt, T. M. and Tataryn, D. (1992). The psychological unconscious: found, lost, and regained. American Psychologist, 47(6), 788–791.

Kim, D. I. et al. (2009). Dysregulation of working memory and default-mode networks in schizophrenia using independent component analysis, an fBIRN and MCIC study. Human Brain Mapping, 30(11), 3795–3811.

Kipper, L. et al. (2004). Brazilian patients with panic disorder: the use of defense mechanisms and their association with severity. Journal of Nervous and Mental Disease, 192(1), 58–64.

Kircher, T. and David, A., eds (2003). The Self in Neuroscience and Psychiatry. Cambridge: Cambridge University Press.

Kirshner, L. A. (1991). The concept of the self in psychoanalytic theory and its philosophical foundations. Journal of the American Psychoanalytic Association, 39(1), 157–182.

Kitcher, P. (1990). Kant's Transcendental Psychology. New York: Oxford University Press.

Kitcher, P. (1992). The naturalists return. Philosophical Review, 101(1), 53–114.

Klein, M. (1935). A contribution to the psychogenesis of manic-depressive states. International Journal of Psychoanalysis, 16, 145–174.

Klein, M. (1955). On Identification. New York: Basic Books.

Knutson, B. et al. (2008a). Neural antecedents of the endowment effect. Neuron, 58(5), 814–822.

Knutson, B. et al. (2008b). Nucleus accumbens activation mediates the influence of reward cues on financial risk taking. NeuroReport, 19(5), 509–513.

Koch, C. (2004). The Quest for Consciousness: a neurobiological approach. Greenwood Village, CO: Roberts & Company Publishers.

Koch, G. et al. (2005). Modulation of excitatory and inhibitory circuits for visual awareness in the human right parietal cortex. Experimental Brain Research, 160(4), 510–516.

Kohut, H. (1971). The Analysis of the Self: a systematic approach to the psychoanalytic treatment of narcissistic personality disorders. New York: International Universities Press.

Kohut, H. (1977). The Restoration of the Self. New York: International Universities Press.

Kohut, H. (1984). How Does Analysis Cure? Chicago: University of Chicago Press.

Kohut, H. and Wolf, E. S. (1978). The disorders of the self and their treatment. International Journal of Psychoanalysis, 59, 414–425.

Kraepelin, E (1913). Ein Lehrbuch für Studierende und Arzte. Leipzig: Barth.

Krueger, F., Grafman, J. and McCabe, K. (2008). Neural correlates of economic game playing. Philosophical Transactions of the Royal Society of London. Series B, Biological Sciences, 363, 3859–3874.

Kumar, P. et al. (2008). Abnormal temporal difference reward-learning signals in major depression. Brain, 131(8), 2084–2093.

Kumari, V. et al. (2003). Neural abnormalities during cognitive generation of affect in treatment-resistant depression. Biological Psychiatry, 54(8), 777–791.

Kumari, V. et al. (2008). Uncontrollable voices and their relationship to gating deficits in schizophrenia. Schizophrenia Research, 101(1–3), 185–194.

Lambie, J. A., and Marcel, A. J. (2002). Consciousness and the varieties of emotion experience: a theoretical framework. Psychological Review, 109(2), 219–259.

Larson-Prior, L. J. et al. (2009). Cortical network functional connectivity in the descent to sleep. Proceedings of the National Academy of Sciences of the United States of America, 106(11), 4489–4494.

Lawrence, N. S. et al. (2004). Subcortical and ventral prefrontal cortical neural responses to facial expressions distinguish patients with bipolar disorder and major depression. Biological Psychiatry, 55(6), 578–587.

LeDoux, J. (2002). Synaptic Self: how our brains become who we are. New York: Viking.

Legrand, D. (2005). Being a body (book review of Shaun Gallagher: How the Body Shapes the Mind). Trends in Cognitive Sciences, 9(9), 413–414.

Legrand, D. (2007). Pre-reflective self-as-subject from experiential and empirical perspectives. Consciousness and Cognition, 16, 583–599.

Legrand, D. and Grammont, F. (2005). A matter of facts (commentary on Bickle Philosophy and Neuroscience). Phenomenology and the Cognitive Sciences, 4(4), 249–257.

Legrand, D. and Ruby, P. (2009). What is self-specific? Theoretical investigation and critical review of neuroimaging results. Psychological Review, 116(1), 252–282.

Lemogne, C. et al. (2009). In search of the depressive self: extended medial prefrontal network during self-referential processing in major depression. Social Cognitive and Affective Neuroscience, 4(3), 305–312.

Lemogne, C. et al. (2010). Self-referential processing and the prefrontal cortex over the course of depression: a pilot study. Journal of Affective Disorders, 124(1–2), 196–201.

Lennox, B. R. et al. (1999). Spatial and temporal mapping of neural activity associated with auditory hallucinations. Lancet, 353, 644.

Levins, R. (2003). Whose scientific method? Scientific methods for a complex world. New Solutions, 13(3), 261–274.

Lewis, C. M. et al. (2009). Learning sculpts the spontaneous activity of the resting human brain. Proceedings of the National Academy of Sciences of the United States of America, 106(41), 17558–17563.

Lewis, D. A. (2009). Neuroplasticity of excitatory and inhibitory cortical circuits in schizophrenia. Dialogues in Clinical Neuroscience, 11(3), 269–280.

Lewis, D.A. and Levitt, P. (2002). Schizophrenia as a disorder of neurodevelopment. Annual Review of Neuroscience, 25, 409–432.

Lewis, D. A. and Gonzalez-Burgos, G. (2008). Neuroplasticity of neocortical circuits in schizophrenia. Neuropsychopharmacology, 33(1), 141–165.

Lewis, D. A., Hashimoto, T. and Volk, D. W. (2005). Cortical inhibitory neurons and schizophrenia. Nature Reviews. Neuroscience, 6(4), 312–324.

Lichtenberg, J. D. and Wolf, E. (1997). General principles of self psychology: a position statement. Journal of the American Psychoanalytic Association, 45(2), 531–543.

Liddle, P. F. (1992). Regional brain abnormalities associated with specific syndromes of persistent schizophrenia symptoms. Clinical Neuropharmacology 15(Suppl. 1, Part A), 401A–402A.

Lin, S. H., Yu, C. Y. and Pai, M. C. (2006). The occipital white matter lesions in Alzheimer's disease patients with visual hallucinations. Clinical Imaging, 30(6), 388–393.

Liotti, M. et al. (2002). Unmasking disease-specific cerebral blood flow abnormalities: mood challenge in patients with remitted unipolar depression. American Journal of Psychiatry, 159(11), 1830–1840.

Lipska, B. K. and Weinberger, D. R. (2000). To model a psychiatric disorder in animals: schizophrenia as a reality test. Neuropsychopharmacology, 23(3), 223–239.

Lisman, J. E. et al. (2008). Circuit-based framework for understanding neurotransmitter and risk gene interactions in psychosis. Trends in Neurosciences, 31(5), 234–242.

Llewellyn, S. (2009). In two minds? Is schizophrenia a state "trapped" between waking and dreaming? Medical Hypotheses, 73, 572–579.

Llinás, R. R. (1988). The intrinsic electrophysiological properties of mammalian neurons: insights into central nervous system function. Science, 242, 1654–1664.

Llinás, R. R. (2001) I of the Vortex: from neurons to self. Cambridge, MA: MIT Press.

Llinás, R. and Ribary, U. (2001). Consciousness and the brain. The thalamocortical dialogue in health and disease. Annals of the New York Academy of Sciences, 929, 166–175.

Llinás, R. et al. (1998). The neuronal basis for consciousness. Philosophical Transactions of the Royal Society of London. Series B, Biological Sciences, 353, 1841–1849.

Lurija, A. R. (1973). The Working Brain. New York: Basic Books.

Maandag, N. J. et al. (2007). Energetics of neuronal signaling and fMRI activity. Proceedings of the National Academy of Sciences of the United States of America, 104, 20546–20551.

Macaluso, E., Frith, C. D. and Driver, J. (2000). Modulation of human visual cortex by crossmodal spatial attention. Science, 289, 1206–1208.

Macdiarmid, D. (1989). Self-cathexis and other-cathexis. Vicissitudes in the history of an observation. British Journal of Psychiatry, 154, 844–852.

McDowell, J. E. et al. (2002). Neural correlates of refixation saccades and antisaccades in normal and schizophrenia subjects. Biological Psychiatry, 51(3), 216–223.

McGinn, C. (1991). The Problem of Consciousness: essays towards a resolution. Oxford: Blackwell Publishers Ltd.

McGinn, C. J. and Kinsella, T. J. (1991). Combined modality therapy. Current Opinion in Oncology, 3, 1049–1054.

McGlashan, T. H. (2009). Psychosis as a disorder of reduced cathectic capacity: Freud's analysis of the Schreber case revisited, Schizophrenia Bulletin, 35(3), 476–481.

McGuire, P. K. et al. (1996a). The neural correlates of inner speech and auditory verbal imagery in schizophrenia: relationship to auditory verbal hallucinations. British Journal of Psychiatry, 169(2), 148–159.

McGuire, P. K., Silbersweig, D. A. and Frith, C. D. (1996b). Functional neuroanatomy of verbal self-monitoring. Brain, 119(3), 907–917.

McIntosh, D. (1986). The ego and the self in the thought of Sigmund Freud. International Journal of Psychoanalysis, 67(4), 429–448.

McIntosh, D. (1993). Cathexes and their objects in the thought of Sigmund Freud. Journal of the American Psychoanalytic Association, 41(3), 679–709.

McKiernan, K. A., D'Angelo, B. R., Kaufman, J. N. and Binder, J. R. (2006). Interrupting the “stream of consciousness”: an fMRI investigation. NeuroImage, 29(4), 1185–1191.

Maciag, D. et al. (2010). Reduced density of calbindin immunoreactive GABAergic neurons in the occipital cortex in major depression: relevance to neuroimaging studies. Biological Psychiatry, 67(5), 465–470.

Mäki, P. et al. (2005). Predictors of schizophrenia—a review. British Medical Bulletin, 73–74, 1–15.

Malancharuvil, J. M. (2004). Projection, introjection, and projective identification: a reformulation. American Journal of Psychoanalysis, 64(4), 375–382.

Mancia, M. (2004). The dream between neuroscience and psychoanalysis. Archives Italiennes de Biologie, 142(4), 525–531.

Mancia, M., ed. (2006a). Psychoanalysis and Neuroscience. Milan: Springer.

Mancia, M. (2006b). Implicit memory and early unrepressed unconscious: their role in the therapeutic process (how the neurosciences can contribute to psychoanalysis). International Journal of Psychoanalysis, 87(Pt 1), 83–103.

Mancia, M. (2006c). Introduction: how the neurosciences can contribute to psychoanalysis. In: Mancia, M., ed. Psychoanalysis and Neuroscience, pp. 1–15. Milan: Springer.

Mannell, M. V. et al. (2010). Resting state and task-induced deactivation: a methodological comparison in patients with schizophrenia and healthy controls. Human Brain Mapping, 31(3), 424–437.

Marcel, A. J. and Lambie, J. A. (2004). How many selves in emotion experience? Reply to Dalgleish and Power (2004). Psychological Review, 111(3), 820–826.

Mareschal, D. et al. (2007). Neuroconstructivism. Volume 1. How the brain constructs cognition. Oxford: Oxford University Press.

Martinez, A., Hillyard, S. A., Dias, E. C. et al. (2008). Magnocellular pathway impairment in schizophrenia: evidence from functional magnetic resonance imaging. Journal of Neuroscience, 28, 7492–7500.

Matthias, E. et al. (2009). On the relationship between interoceptive awareness and the attentional processing of visual stimuli. International Journal of Psychophysiology, 72(2), 154–159.

Mayberg, H. (2002). Depression, II: Localization of pathophysiology. American Journal of Psychiatry, 159, 1979.

Mayberg, H. S. (2003a). Positron emission tomography imaging in depression: a neural systems perspective. Neuroimaging Clinics of North America, 13(4), 805–815.

Mayberg, H. S. (2003b). Modulating dysfunctional limbic-cortical circuits in depression: towards development of brain-based algorithms for diagnosis and optimised treatment. British Medical Bulletin, 65, 193–207.

Mayberg, H. S. (2009). Targeted electrode-based modulation of neural circuits for depression. Journal of Clinical Investigation, 119(4), 717–725.

Mayberg, H. S. et al. (1999). Reciprocal limbic-cortical function and negative mood: converging PET findings in depression and normal sadness. American Journal of Psychiatry, 156(5), 675–682.

Mechelli, A. et al. (2007). Misattribution of speech and impaired connectivity in patients with auditory verbal hallucinations. Human Brain Mapping, 28(11), 1213–1222.

Meerbote, R. (1989). Kant's functionalism. In: Smith, J. C., ed. Historical Foundations of Cognitive Science, pp. 65–78. Dordrecht: Kluwer Academic Publishers.

Meissner, W. W. (2003a). Mind, brain, and self in psychoanalysis: III. Psychoanalytic perspectives after Freud. Psychoanalysis and Contemporary Thought, 26, 345–386.

Meissner, W. W. (2003b). Mind, brain, and self in psychoanalysis: I. Problems and attempted solutions. Psychoanalysis and Contemporary Thought, 26, 279–320.

Meissner, W. W. (2007). Mind, brain, and self in psychoanalysis: therapeutic implications of the mind–body relation. Psychoanalytic Psychology, 24, 333–354.

Mentzos, S. (1991). Psychodynamische Modelle der Psychiatrie. Göttingen: Vandenhoeck & Ruprecht.

Mentzos, S. (1992). Psychose und Konflikt. Göttingen: Vandenhoeck & Ruprecht.

Merleau-Ponty, M. (1962). Phenomenology of Perception. London: Routledge.

Merleau-Ponty, M. (1965). Phanomenologie der Wahrnehmung. Berlin: Walter de Gruyter.

Mesulam, M. M. (2000). Principles of Behavioral and Cognitive Neurology, 2nd edn. New York: Oxford University Press.

Metzinger, T. (2003). Being No One. Cambridge, MA: MIT Press.

Metzinger, T. and Gallese, V. (2003). The emergence of a shared action ontology: building blocks for a theory. Consciousness and Cognition, 12(4), 549–571.

Milch, W. (2001). Lehrbuch der Selbstpsychologie. Stuttgart: Kohlhammer.

Milrod, D. (2002a). The superego. Its formation, structure, and functioning. The Psychoanalytic Study of the Child, 57, 131–148.

Milrod, D. (2002b). The concept of the self and the self representation. Neuropsychoanalysis, 4(1), 7–23.

Mishara, A. L. (2010). Klaus Conrad (1905–1961): delusional mood, psychosis, and beginning schizophrenia. Schizophrenia Bulletin, 36, 9–13.

Montague, P. R. (2007). Neuroeconomics: a view from neuroscience. Functional Neurology, 22, 219–234.

Montague, P. R. and Berns, G. S. (2002). Neural economics and the biological substrates of valuation. Neuron, 36, 265–284.

Moore, G. E. (1903). Principia Ethica. Cambridge: Cambridge University Press.

Moran, J. M. et al. (2006). Neuroanatomical evidence for distinct cognitive and affective components of self. Journal of Cognitive Neuroscience, 18(9), 1586–1594.

Morcom, A. M. and Fletcher, P. C. (2007). Does the brain have a baseline? Why we should be resisting a rest. NeuroImage, 37, 1073–1082.

Morgane, P. J. and Mokler, D. J. (2006). The limbic brain: continuing resolution. Neuroscience and Biobehavioral Reviews, 30(2), 119–125.

Morgane, P. J., Galler, J. R. and Mokler, D. J. (2005). A review of systems and networks of the limbic forebrain/limbic midbrain. Progress in Neurobiology, 75(2), 143–160.

Muthukumaraswamy, S. D. et al. (2009). Resting GABA concentration predicts peak gamma frequency and fMRI amplitude in response to visual stimulation in humans. Proceedings of the National Academy of Sciences of the United States of America, 106(20), 8356–8361.

Naatanen, R. et al. (2007). The mismatch negativity (MMN) in basic research of central auditory processing: a review. Clinical Neurophysiology, 118(12), 2544–2590.

Nagel, T. (1998). Conceiving the impossible and the mind-body problem. Philosophy, 73, 337–352.

Nase, G. et al. (2003). Features of neuronal synchrony in mouse visual cortex. Journal of Neurophysiology, 90(2), 1115–1123.

Niedenthal, P. M. (2007). Embodying emotion. Science, 316, 1002–1005.

Nieuwenhuys, R. (1996). The greater limbic system, the emotional motor system and the brain. Progress in Brain Research, 107, 551–580.

J. G. and van Domburg, P. (1988). Core and paracores; some new chemoarchitectural entities in the mammalian neuraxis. Acta Morphologica Neerlando-Scandinavica, 26(2–3), 131–163.

Nir, Y. and Tononi, G. (2010). Dreaming and the brain: from phenomenology to neurophysiology. Trends in Cognitive Sciences, 14(2), 88–100.

Northoff, G. (2001). Personale Identitaet und operative Eingriffe in das Gehirn. Paderborn: Schoening.

Northoff, G. (2004a). Why do we need a philosophy of the brain? Trends in Cognitive Sciences, 8(11), 484–485.

Northoff, G. (2004b). Philosophy of the Brain: the brain problem. Philadelphia, PA: John Benjamins Publishing Co.

Northoff, G. (2007). Psychopathology and pathophysiology of the self in depression—neuropsychiatric hypothesis. Journal of Affective Disorders, 104(1–3), 1–14.

Northoff, G. (2008). Are our emotional feelings relational? A neurophilosophical investigation of the James–Lange theory. Phenomenology and the Cognitive Sciences, 7, 501–527.

Northoff, G. (2010). Humans, brains, and their environment: marriage between neuroscience and anthropology? Neuron, 65(6), 748–751.

Northoff, G. and Bermpohl, F. (2004). Cortical midline structures and the self. Trends in Cognitive Sciences, 8(3), 102–107.

Northoff, G. and Boeker, H. (2006). Principles of neuronal integration and defense mechanisms: neuropsychoanalytic hypothesis. Neuropsychoanalysis, 8, 69–84.

Northoff, G. and Musholt, K. (2006). How can Searle avoid property dualism? Epistemic-ontological inference and autoepistemic limitation. Philosophical Psychology, 19(5), 1–17.

Northoff, G. and Panksepp, J. (2008). The trans-species concept of self and the subcortical-cortical midline system. Trends in Cognitive Sciences, 12(7), 259–264.

Northoff, G. et al. (2000). Functional dissociation between medial and lateral prefrontal cortical spatiotemporal activation in negative and positive emotions: a combined fMRI/MEG study. Cerebral Cortex, 10(1), 93–107.

Northoff, G. et al. (2004). Reciprocal modulation and attenuation in the prefrontal cortex: an fMRI study on emotional-cognitive interaction. Human Brain Mapping, 21(3), 202–212.

Northoff, G. et al. (2006). Self-referential processing in our brain—a meta-analysis of imaging studies on the self. NeuroImage, 31(1), 440–457.

Northoff, G., Bermpohl, F., Schoeneich, F. and Boeker, H. (2007a). How can we bridge between psychoanalysis and neuroscience? First-person neuroscience. Psychotherapy and Psychosomatics, 76, 141–153.

Northoff, G. et al. (2007b). GABA concentrations in the human anterior cingulate cortex predict negative BOLD responses in fMRI. Nature Neuroscience, 10(12), 1515–1517.

Northoff, G. et al. (2007c). How does our brain constitute defense mechanisms? First-person neuroscience and psychoanalysis. Psychotherapy and Psychosomatics, 76(3), 141–153.

Northoff, G. et al. (2008). Differential parametric modulation of self-relatedness and emotions in different brain regions. Human Brain Mapping, 30, 369–382.

Northoff, G. et al. (2009). Differential parametric modulation of self-relatedness and emotions in different brain regions. Human Brain Mapping, 30(2), 369–382.

Northoff, G., Qin, P. and Nakao, T. (2010). Rest-stimulus interaction in the brain: a review. Trends in Neurosciences, 33, 277–284.

Northoff, G. et al. (2011). The ‘resting-state hypothesis’ of major depressive disorder—a translational subcortical-cortical framework for a system disorder. Neuroscience and Biobehavioral Reviews, [E-pub ahead of print].

Nunberg, H. and Federn, E. (1977). Protokolle der Wiener Psychoanalytischen Vereinigung. Frankfurt: M. Fischer.

Ornston, D. G. (1985). The invention of “cathexis” and Strachey’s strategy. International Review of Psychoanalysis, 12, 391–398.

Pacherie, E., Green, M. and Bayne, T. (2006). Phenomenology and delusions: who put the “alien” in alien control? Consciousness and Cognition, 15, 566–577.

Pally, R. (2006). The predicting brain: psychoanalysis and repeating the past in the present. International Journal of Psychoanalysis, 88(4), 861–881.

Panksepp, J. (1998). Affective Neuroscience: the foundations of human and animal emotions. New York: Oxford University Press.

Panksepp, J. (2003). At the interface of the affective, behavioral, and cognitive neurosciences: decoding the emotional feelings of the brain. Brain and Cognition, 52(1), 4–14.

Panksepp, J. (2005). Affective consciousness: core emotional feelings in animals and humans. Consciousness and Cognition, 14(1), 30–80.

Panksepp, J. (2007). The neuroevolutionary and neuroaffective psychobiology of the prosocial brain. In: Dunbar, R. I. M. and Barrett, L., eds. The Oxford Handbook of Evolutionary Psychology, pp. 145–162. Oxford: Oxford University Press.

Panksepp, J. and Northoff, G. (2009). The trans-species core SELF: the emergence of active cultural and neuro-ecological agents through self-related processing within subcortical-cortical midline networks. Consciousness and Cognition, 18, 193–215.

Park, I. H. et al. (2009). Medial prefrontal default-mode hypoactivity affecting trait physical anhedonia in schizophrenia. Psychiatry Research, 171(3), 155–165.

Parnas, J. (2003). Self and schizophrenia: a phenomenological perspective. In: Kircher, T. and David, A., eds.: The Self in Neuroscience and Psychiatry, pp. 217–242. Cambridge: Cambridge University Press.

Parnas, J. and Handest, P. (2003). Phenomenology of anomalous self-experience in early schizophrenia. Comprehensive Psychiatry, 44(2), 121–134.

Parnas, J. et al. (1998). Self-experience in the prodromal phases of schizophrenia. Neurology, Psychiatry and Brain Research, 6, 97–106.

Parnas, J. et al. (2001). Visual binding abilities in the initial and advanced stages of schizophrenia. Acta Psychiatrica Scandinavica, 103(3), 171–180.

Parnas, J. et al. (2003). Anomalies of subjective experience in schizophrenia and psychotic bipolar illness. Acta Psychiatrica Scandinavica, 108(2), 126–133.

Paulus, M. P. and Stein, M. B. (2006). An insular view of anxiety. Biological Psychiatry, 60(4), 383–387.

Peled, A. (2008). NeuroAnalysis: the missing link between psychoanalysis and neuroscience. New York: Routledge.

Peled, N. et al. (2008). Increased erythrocyte adhesiveness and aggregation in obstructive sleep apnea syndrome. Thrombosis Research, 121(5), 631–636.

Perry, J. C. and Cooper, S. H. (1989). An empirical study of defense mechanisms. I. Clinical interview and life vignette ratings. Archives of General Psychiatry, 46(5), 444–452.

Phan, K. L. et al. (2002). Functional neuroanatomy of emotion: a meta-analysis of emotion activation studies in PET and fMRI. NeuroImage, 16(2), 331–348.

Phan, K. L. et al. (2004). Neural correlates of individual ratings of emotional salience: a trial-related fMRI study. NeuroImage, 21(2), 768–780.

Phillips, M. L. et al. (2003). Neurobiology of emotion perception I: The neural basis of normal emotion perception. Biological Psychiatry, 54(5), 504–514.

Pizzagalli, D. A. et al. (2009). Reduced caudate and nucleus accumbens response to rewards in unmedicated individuals with major depressive disorder. American Journal of Psychiatry, 166(6), 702–710.

Pollatos, O. et al. (2007a). Interoceptive awareness mediates the relationship between anxiety and the intensity of unpleasant feelings. Journal of Anxiety Disorders, 21(7), 931–943.

Pollatos, O., Schandry, R., Auer, D. P. and Kaufmann, C. (2007b). Brain structures mediating cardiovascular arousal and interoceptive awareness. Brain Research, 1141, 178–187.

Pollatos, O., Herbert, B. M., Matthias, E. and Schandry, R. (2007c). Heart rate response after emotional picture presentation is modulated by interoceptive awareness. International Journal of Psychophysiology, 63(1), 117–124.

Pollatos, O., Gramann, K. and Schandry, R. (2007d). Neural systems connecting interoceptive awareness and feelings. Human Brain Mapping, 28(1), 9–18.

Pollatos, O. et al. (2008). Reduced perception of bodily signals in anorexia nervosa. Eating Behaviors, 9(4), 381–388.

Pollatos, O., Traut-Mattausch, E. and Schandry, R. (2009). Differential effects of anxiety and depression on interoceptive accuracy. Depression and Anxiety, 26(2), 167–173.

Pomarol-Clotet, E. et al. (2008). Failure to deactivate in the prefrontal cortex in schizophrenia: dysfunction of the default mode network? Psychological Medicine, 38, 1185–1193.

Powell, C. T. (1990). Kant's Theory of Self-Consciousness. Oxford: Oxford University Press.

Price, J. L. and Drevets, W. C. (2010). Neurocircuitry of mood disorders. Neuropsychopharmacology, 35, 192–216.

Prinz, J. (2000). A neurofunctional theory of visual consciousness. Consciousness and Cognition, 9(2 Part 1), 243–259.

Pugh, G. (2006). Cooperation not incorporation. In: Mancia, M., ed. Psychoanalysis and Neuroscience, pp. 54–56. Milan: Springer.

Pulver, S. E. (1970). Narcissism. The term and the concept. Journal of the American Psychoanalytic Association, 18(2), 319–341.

Pyka, M. et al. (2009). Impact of working memory load on FMRI resting state pattern in subsequent resting phases. PLoS One, 4(9), e7198.

Qin, P. and Northoff, G. (2011). How is our self related to midline regions and the default-mode network? NeuroImage, [E-pub ahead of print].

Qin, P. et al. (2008). Mismatch negativity to the patient's own name in chronic disorders of consciousness. Neuroscience Letters, 448(1), 24–28.

Qin, P. et al. (2010). Anterior cingulate activity and the self in disorders of consciousness. Human Brain Mapping, 31(12), 1993–2002.

Qin, P. et al. (2011). Dissociation between anterior and posterior cortical regions during self-specificity and familiarity: a combined fMRI–meta-analytic study. Human Brain Mapping, in press.

Raichle, M. E. (2009). A brief history of human brain mapping. Trends in Neurosciences, 32(2), 118–126.

Raichle, M. E. and Mintun, M. A. (2006). Brain work and brain imaging. Annual Review of Neuroscience, 29, 449–476.

Raichle, M. E. et al. (2001). A default mode of brain function. Proceedings of the National Academy of Sciences of the United States of America, 98, 676–682.

Raij, T. T. et al. (2009). Reality of auditory verbal hallucinations. Brain, 132, 2994–3001.

Rangel, A., Camerer, C. and Montague, P. R. (2008). A framework for studying the neurobiology of value-based decision making. Nature Reviews. Neuroscience, 9, 545–556.

Raskin, R. and Novacek, J. (1991). Narcissism and the use of fantasy. Journal of Clinical Psychology, 47(4), 490–499.

Revonsuo, A. (2005). The self in dreams. In: Feinberg, T. E. and Keenan, J. P., eds. The Lost Self: pathologies of the brain and identity, pp. 206–219. New York: Oxford University Press.

Revonsuo, A. (2006). Inner Presence: consciousness as a biological phenomenon. Cambridge, MA: MIT Press.

Reznikova, T. N. et al. (2004). [Positron emission tomography of the human brain in relation to psychological defense mechanisms in patients with multiple sclerosis] [article in Russian]. Fiziologiya Cheloveka, 30(4), 25–31.

Richards, A. D. (1982). The superordinate self in psychoanalytic theory and in the self psychologies. Journal of the American Psychoanalytic Association, 30, 938–957.

Richter, A., Grimm, S. and Northoff, G. (2010). Lorazepam modulates orbitofrontal signal changes during emotional processing in catatonia. Human Psychopharmacology, 25(1), 55–62.

Rilling, J. K. et al. (2007). A comparison of resting-state brain activity in humans and chimpanzees. Proceedings of the National Academy of Sciences of the United States of America, 104(43), 17146–17151.

Rimes, K. A. and Watkins, E. (2005). The effects of self-focused rumination on global negative self-judgements in depression. Behaviour Research and Therapy, 43(12), 1673–1681.

Ritter, K. and Lammers, C. H. (2007). [Narcissism—variable of personality and personality disorder] [article in German]. Psychotherapie, Psychosomatik, Medizinische Psychologie, 57(2), 53–60.

Rolls, E. T., Tovee, M. J. and Panzeri, S. (1999). The neurophysiology of backward visual masking: information analysis. Journal of Cognitive Neuroscience, 11(3), 300–311.

Rose, E. J., Simonotto, E. and Ebmeier, K. P. (2006). Limbic over-activity in depression during preserved performance on the n-back task. Neuroimage, 29(1), 203–215.

Rosenbaum, B. and Harder, S. (2007). Psychosis and the dynamics of the psychotherapy process. International Review of Psychiatry, 19(1), 13–23.

Rosenbaum, R. S. et al. (2005). “Where to?” Remote memory for spatial relations and landmark identity in former taxi drivers with Alzheimer’s disease and encephalitis. Journal of Cognitive Neuroscience, 17, 446–462.

Rotarska-Jagiela, A. et al. (2010). Resting-state functional network correlates of psychotic symptoms in schizophrenia. Schizophrenia Research, 117(1), 21–30.

Sadaghiani, S, Ugurbil, K. and Uludag, K. (2009). Neural activity-induced modulation of BOLD poststimulus undershoot independent of the positive signal. Magnetic Resonance Imaging, 27(8), 1030–1038.

Sajonz, B. et al. (2010). Delineating self-referential processing from episodic memory retrieval: common and dissociable networks. NeuroImage, 50(4), 1606–1617.

Sanacora, G. et al. (1999). Reduced cortical gamma-aminobutyric acid levels in depressed patients determined by proton magnetic resonance spectroscopy. Archives of General Psychiatry, 56(11), 1043–1047.

Sanfey, A. G. et al. (2006). Neuroeconomics: cross-currents in research on decision-making. Trends in Cognitive Sciences, 10(3), 108–116.

Sapir, A. et al. (2004). Parietal lobe lesions disrupt saccadic remapping of inhibitory location tagging. Journal of Cognitive Neuroscience, 16(4), 503–509.

Sass, L. A. (1996). “The catastrophes of heaven”: modernism, primitivism, and the madness of Antonin Artaud. Modernism/Modernity, 3, 73–92.

Sass, L. A. (2000). Schizophrenia, self-experience, and the so-called “negative symptoms.” In: Zahavi, D, ed.: Exploring the Self: philosophical and psychopathological perspectives on self-experience, pp. 149–182. Amsterdam: John Benjamins Publishing.

Sass, L. A. (2003). Self-disturbance in schizophrenia: hyperreflexivity and diminished self-affection. In: Kircher, T. and David, A., eds. The Self in Neuroscience and Psychiatry, pp. 242–272. Cambridge: Cambridge University Press.

Sass, L. A. and Parnas, J. (2001). Phenomenology of self-disturbances in schizophrenia: some research findings and directions. Philosophy, Psychiatry, and Psychology, 8, 347–356.

Sass, L. A. and Parnas, J. (2003). Schizophrenia, consciousness, and the self. Schizophrenia Bulletin, 29(3), 427–444.

Savitz, J. B. and Drevets, W. C. (2009). Imaging phenotypes of major depressive disorder: genetic correlates. Neuroscience, 164(1), 300–330.

Scarone, S. et al. (2008). The dream as a model for psychosis: an experimental approach using bizarreness as a cognitive marker. Schizophrenia Bulletin, 34(3), 515–522.

Schacter, D. L. and Addis, D. R. (2007a). The cognitive neuroscience of constructive memory: remembering the past and imagining the future. Philosophical Transactions of the Royal Society of London. Series B, Biological Sciences, 362, 773–786.

Schacter, D. L. and Addis, D. R. (2007b). Constructive memory: the ghosts of past and future. Nature, 445, 27.

Schaefer, R. (1972). Internalization: process or fantasy? Psychoanalytic Study of the Child, 27, 411–436.

Scharfetter, C. (1996). The self-experience of schizophrenia. In: Empirical Studies of the Ego/Self in Schizophrenia, Borderline Disorders and Depression, 2nd edn, pp. 34–54. Zurich: University of Zurich.

Scharfetter, C (2003). The self-experience of schizophrenia. In: Kircher, T. and David, A., eds.: The Self in Neuroscience and Psychiatry, pp. 272–293. Cambridge: Cambridge University Press.

Schlicht, T. (2007). Erkenntnistheoretischer Dualismus. Das Problem der Erklärungslücke in Geist-Gehirn-Theorien. Paderborn: Mentis-Verlag.

Schmidt, K. E., Singer, W. and Galuske, R. A. (2004). Processing deficits in primary visual cortex of amblyopic cats. Journal of Neurophysiology, 91(4), 1661–1671.

Schmidt-Hellerau, C. (1995). [The birth of metapsychology. On the current interpretation of “Entwurf einer Psychologie” (1895)] [article in German]. Psyche, 49(12), 1156–1195.

Schneider, F. et al. (2008). The resting brain and our self: self-relatedness modulates resting state neural activity in cortical midline structures. Neuroscience, 157(1), 120–131.

Schneider, K. (1959). Allgemeine Psychopathologie. Stuttgart: Thieme Verlag.

Schneider, P. (2006). Psychoanalyse und Neurowissenschaft: Inkompatbilaitaet! In: Böker, H., ed. Psychoanalyse und Psychiatrie, pp. 293–300. Heidelberg: Springer.

Schopenhauer, A. (1966). The World as Will and Representation. Volume II. New York: Dover Publications, Inc.

Schuessler, G. (2002). Aktuelle Konzepte des Unbewussten. Zeitschrift für Psychosomatische Medizin und Psychotherapie, 48, 192–214.

Searle, J. (2004). Mind: a brief introduction. New York: Oxford University Press.

Sedikides, C. et al. (2004). Are normal narcissists psychologically healthy?: Self-esteem matters. Journal of Personality and Social Psychology, 87(3), 400–416.

Sellars, W. (2007). Selected Works. Cambridge, MA: Harvard University Press.

Seth, A. K. et al. (2006). Theories and measures of consciousness: an extended framework. Proceedings of the National Academy of Sciences of the United States of America, 103(28), 10799–10804.

Shapley, R., Hawken, M. and Ringach, M. D. L. (2003). Dynamics of orientation selectivity in the primary visual cortex and the importance of cortical inhibition. Neuron, 5(38), 689–699.

Shedler, J. and Westen, D. (2004). Refining personality disorder diagnosis: integrating science and practice. American Journal of Psychiatry, 161(8), 1350–1365.

Sheline, Y. I. et al. (2009). The default mode network and self-referential processes in depression. Proceedings of the National Academy of Sciences of the United States of America, 106, 1942–1947.

Shergill, S. S. et al. (2000a). Functional anatomy of auditory verbal imagery in schizophrenic patients with auditory hallucinations. American Journal of Psychiatry 157(10), 1691–1693.

Shergill, S. S. et al. (2000b). Mapping auditory hallucinations in schizophrenia using functional magnetic resonance imaging. Archives of General Psychiatry, 57(11), 1033–1038.

Shergill, S. S. et al. (2003). Engagement of brain areas implicated in processing inner speech in people with auditory hallucinations. British Journal of Psychiatry, 182, 525–531.

Shergill, S. S. et al. (2004). Temporal course of auditory hallucinations. British Journal of Psychiatry, 185, 516–517.

Shergill, S. S. et al. (2007). A diffusion tensor imaging study of fasciculi in schizophrenia. American Journal of Psychiatry, 164(3), 467–473.

Shin, S. E. et al. (2005). Segmented volumes of cerebrum and cerebellum in first episode schizophrenia with auditory hallucinations. Psychiatry Research, 138(1), 33–42.

Shore, A. (1996). The experience-dependent maturation of a regulatory system in the orbital prefrontal cortex and the origin of developmental psychopathology. Development and Psychopathology, 8, 59–87.

Shore, A. N. (2003). Affect Regulation and the Repair of the Self. New York: W.W. Norton.

Shore, S. E., El Kashlan, H. and Lu, J. (2003). Effects of trigeminal ganglion stimulation on unit activity of ventral cochlear nucleus neurons. Neuroscience, 119(4), 1085–1101.

Shulman, G. L. et al. (1997a). Common blood flow changes across visual tasks: I. Increases in subcortical structures and cerebellum but not in nonvisual cortex. Journal of Cognitive Neuroscience, 9(5), 624–647.

Shulman, G. L. et al. (1997b). Searching for activations that generalize over tasks. Human Brain Mapping, 5(4), 317–322.

Shulman, R. G. et al. (2004). Energetic basis of brain activity: implications for neuroimaging. Trends in Neurosciences, 27(8), 489–495.

Shulman, R. G., Hyder, F. and Rothman, D. L. (2009). Baseline brain energy supports the state of consciousness. Proceedings of the National Academy of Sciences of the United States of America 106, 11096–11101.

Simpson, J. R. Jr et al. (2001). Emotion-induced changes in human medial prefrontal cortex: I. During cognitive task performance. Proceedings of the National Academy of Sciences of the United States of America, 98(2), 683–687.

Smith, A. T., Singh, K. D. and Greenlee, M. W. (2000). Attentional suppression of activity in the human visual cortex. Neuroreport, 11(2), 271–277.

Solms, M. (1995). Is the brain more real than the mind? Psychoanalytic Psychotherapy, 9(2), 107–120.

Solms, M. (1996). [What are affects?] [article in German]. Psyche, 50(6), 485–522.

Solms, M. (1997). What is consciousness? Journal of the American Psychoanalytic Association, 45(3), 681–703.

Solms, M. (1998). Psychoanalytische Beobachtungen an vier Patienten mit ventromesialen Frontalhirnlasionen. Psyche, 52, 919–962.

Solms, M. (1999). The deep psychological functions of the right cerebral hemisphere. Bulletin of the British Psychoanalytical Society, 35(1), 9–29.

Solms, M. (2000). Dreaming and REM sleep are controlled by different brain mechanisms. Behavioral and Brain Sciences, 23(6), 843–850; discussion 904–1121.

Solms, M. (2004). Freud returns. Scientific American, 290(5), 82–88.

Solms, M. (2006). "Freud" and Bullitt: an unknown manuscript. Journal of the American Psychoanalytic Association, 54(4), 1263–1298.

Solms, M. and Saling, M. (1986). On psychoanalysis and neuroscience: Freud's attitude to the localizationist tradition. International Journal of Psychoanalysis, 67(4), 397–416.

Solms, M. and Turnbull, O. (2002). The Brain and the Inner World: an introduction to the neuroscience of subjective experience. New York: Other Press.

Solms, M. et al. (1998). Rotated drawing: the range of performance and anatomical correlates in a series of 16 patients. Brain and Cognition, 38(3), 358–368.

Somers, D. C. et al. (1999). Functional MRI reveals spatially specific attentional modulation in human primary visual cortex. Proceedings of the National Academy of Sciences of the United States of America, 96(4), 1663–1668.

Sommer, I. E. C. et al. (2008). Auditory verbal hallucinations predominantly activate the right inferior frontal area. Brain, 131, 3169–3177.

Sommerfield, C. et al. (2006). Predictive codes for forthcoming perception in the frontal cortex. Science, 314, 1311–1314.

Stanghellini, G. (2009). Embodiment and schizophrenia. World Psychiatry, 8(1), 56–59.

Stanghellini, G. and Ballerini, M. (2007). Criterion B (social dysfunction) in persons with schizophrenia: the puzzle. Current Opinion in Psychiatry, 20(6), 582–587.

Stanghellini, G. and Ballerini, M. (2008). Qualitative analysis. Its use in psychopathological research. Acta Psychiatrica Scandinavica, 117(3), 161–163.

Steele, J. D. and Lawrie, S. M. (2004). Segregation of cognitive and emotional function in the prefrontal cortex: a stereotactic meta-analysis. NeuroImage, 21(3), 868–875.

Stephan, K. E., Friston, K. J. and Frith, C. D. (2009). Dysconnection in schizophrenia: from abnormal synaptic plasticity to failures of self-monitoring. Schizophrenia Bulletin, 35(3), 509–527.

Stephane, M., Barton, S. and Boutros, N. N. (2001). Auditory verbal hallucinations and dysfunction of the neural substrates of speech. Schizophrenia Research, 50, 61–78.

Stern, D. (1985). Die Lebenserfahrung des Sauglings. Stuttgart: Klett-Cotta.

Stewart, J. L. et al. (2010). Attentional bias to negative emotion as a function of approach and withdrawal anger styles: an ERP investigation. International Journal of Psychophysiology, 76(1), 9–18.

Stolorow, R. D. (1993). An intersubjective view of the therapeutic process. Bulletin of the Menninger Clinic, 57(4), 450–457.

Stolorow, R. D. and Atwood, G. F. (1997). Deconstructing the myth of the neutral analyst: an alternative from intersubjective systems theory. Psychoanalytic Quarterly, 66(3), 431–449.

Strachey, J. (1967). An unknown review by Freud. International Journal of Psychoanalysis, 48(2), 319–320.

Strawson, G. (1994). Mental Reality. Cambridge, MA: MIT Press.

Stuss, D. T., Gallup, G. G. Jr and Alexander, M. P. (2001). The frontal lobes are necessary for “theory of mind.” Brain, 124(2), 279–286.

Sullivan, H. S. (1962). Schizophrenia as a Human Process. New York: W. W. Norton.

Surguladze, S. A. et al. (2005). Recognition accuracy and response bias to happy and sad facial expressions in patients with major depression. Neuropsychology, 18, 212–218.

Svare, E. (2006). Kant and Embodiment. Oslo: Oslo University Press.

Talvitie, V. and Ihanus, J. (2006). The psychic apparatus, metapsychology, and neuroscience. Neuropsychoanalysis, 8, 85–98.

Tauber, A. I. (2009). Freud's dreams of reason: the Kantian structure of psychoanalysis. History of the Human Sciences, 22(4), 1–29.

Taylor, C. B. and Chang, V. Y. (2008). Issues in the dissemination of cognitive-behavior therapy. Nordic Journal of Psychiatry, 62(Suppl. 47), 37–44.

Thomaes, S. et al. (2009). What makes narcissists bloom? A framework for research on the etiology and development of narcissism. Development and Psychopathology, 21(4), 1233–1247.

Thompson, E. (2007). Mind in Life: biology, phenomenology, and the sciences of mind. Cambridge, MA: Harvard University Press.

Thompson, J. C. et al. (2007). Common and distinct brain activation to viewing dynamic sequences of face and hand movements. NeuroImage, 37(3), 966–973.

1) Ienari, P. (1991). Interaction between genetic vulnerability and family environment. Acta Psychiatrica Scandinavica, 84, 460–465.

Tononi, G. (2008). Consciousness as integrated information: a provisional manifesto. Biological Bulletin, 215(3), 216–242.

Tononi, G. and Koch, C. (2008). The neural correlates of consciousness: an update. Annals of the New York Academy of Sciences, 1124, 239–261.

Tregellas, J. R. et al. (2009). Increased hippocampal, thalamic, and prefrontal hemodynamic response to an urban noise stimulus in schizophrenia. American Journal of Psychiatry, 166(3), 354–360.

Treynor, W., Gonzalez, R. and Nolen-Hoeksema, S. (2003). Rumination reconsidered: a psychometric analysis. Cognitive Therapy and Research, 27, 247–259.

Tsodyks, M. et al. (1999). Linking spontaneous activity of single cortical neurons and the underlying functional architecture. Science, 286, 1943–1946.

Turetsky, B. I. et al. (2007). Neurophysiological endophenotypes of schizophrenia: the viability of selected candidate measures. Schizophrenia Bulletin, 33(1), 69–94.

Turk, D. J. et al. (2002). Mike or me? Self-recognition in a split-brain patient. Nature Neuroscience, 5(9), 841–842.

Turk, D. J. et al. (2003). Out of contact, out of mind: the distributed nature of the self. Annals of the New York Academy of Sciences, 1001, 65–78.

Tye, M. (1995). Ten Problems of Consciousness. Cambridge, MA: MIT Press.

Uddin, L. Q., Iacoboni, M., Lange, C. and Keenan, J. P. (2007). The self and social cognition: the role of cortical midline structures and mirror neurons. Trends in Cognitive Sciences, 11(4), 153–157.

Uhlhaas, P. J. and Singer, W. (2010). Abnormal neural oscillations and synchrony in schizophrenia. Nature Reviews. Neuroscience, 11(2), 100–113.

Uhlhaas, P. J. et al. (2009a). The development of neural synchrony reflects late maturation and restructuring of functional networks in humans. Proceedings of the National Academy of Sciences of the United States of America, 106(24), 9866–9871.

Uhlhaas, P. J. et al. (2009b). Neural synchrony in cortical networks: history, concept and current status. Frontiers in Integrative Neuroscience, 3, 17.

Uhlhaas, P. J. et al. (2010). Neural synchrony and the development of cortical networks. Trends in Cognitive Sciences, 14(2), 72–80.

Ulman, J. S. (2005). Introduction: Becoming aware of the new unconscious. In: Hassin, G. and Ulman, J. S., eds. The Unconscious, pp. 1–12. Cambridge, MA: MIT Press.

Vaillant, G. (1992). Ego Mechanisms of Defence. Washington, DC: American Psychiatric Press.

Vaillant, G. E. (1993). Is alcoholism more often the cause or the result of depression? Harvard Review of Psychiatry, 1(2), 94–99.

van de Ven, V. G. et al. (2005). The spatiotemporal pattern of auditory cortical responses during verbal hallucinations. NeuroImage 27(3), 644–655.

van Eijsden, P. et al. (2009). Neurophysiology of functional imaging. NeuroImage, 45, 1047–1054.

Varela, F. and Shear, J. (1999). First-person methodologies: what, why, how? Journal of Consciousness Studies, 6(2–3), 1–14.

Varela, F. et al. (2001). The brainweb: phase synchronization and large-scale integration. Nature Reviews. Neuroscience, 2(4), 229–239.

Vincent, J. L. et al. (2007). Intrinsic functional architecture in the anaesthetized monkey brain. Nature, 447, 83–86.

Vincent, J. L. et al. (2008). Evidence for a frontoparietal control system revealed by intrinsic functional connectivity. Journal of Neurophysiology, 100(6), 3328–3342.

Vogeley, K. (2003). Schizophrenia as disturbance of the self-construct. In: Kircher, T. and David, A., eds. The Self in Neuroscience and Psychiatry, pp. 361–380. Cambridge: Cambridge University Press.

Vogeley, K. and Fink, G. R. (2003). Neural correlates of the first-person perspective. Trends in Cognitive Sciences, 7(1), 38–42.

Volkan, V. D. (1976). Primitive Internalized Object Relations: a clinical study of schizophrenic, borderline, and narcissistic patients. New York: International Universities Press.

Volkan, V. D. (1981). Linking Object Relations and Linking Phenomena. New York: International Universities Press.

Wagner, C. and Stucki, J. W. (2002). Construction of an associative memory using unstable periodic orbits of a chaotic attractor. Journal of Theoretical Biology, 215(3), 375–384.

Wahlberg, K. E. et al. (1997). Gene–environment interaction in vulnerability to schizophrenia: findings from the Finnish Adoptive Family Study of Schizophrenia. American Journal of Psychiatry, 154, 355–362.

Walker, M. P. (2009a). The role of sleep in cognition and emotion. Annals of the New York Academy of Sciences, 1156, 168–197.

Walker, M. P. (2009b). The role of slow wave sleep in memory processing. Journal of Clinical Sleep Medicine, 5(2 Suppl.), S20–26.

Walker, M. P. and van der Helm, E. (2009). Overnight therapy? The role of sleep in emotional brain processing. Psychological Bulletin, 135(5), 731–748.

Walter, H. (2002). Neurophilosophy of Free Will. Cambridge, MA: MIT Press.

Walter, M. et al. (2008). Preceding attention and the dorsomedial prefrontal cortex: process specificity versus domain dependence. Human Brain Mapping, 30(1), 312–326.

Wang, K. et al. (2008). Spontaneous activity associated with primary visual cortex: a resting-state FMRI study. Cerebral Cortex, 18(3), 697–704.

Wehrle, R. et al. (2005). Rapid eye movement-related brain activation in human sleep: a functional magnetic resonance imaging study. Neuroreport, 16(8), 853–857.

Wehrle, R. et al. (2007). Functional microstates within human REM sleep: first evidence from fMRI of a thalamocortical network specific for phasic REM periods. European Journal of Neuroscience, 25(3), 863–871.

Weinryb, R. M. and Rossel, R. J. (1991). Karolinska Psychodynamic Profile. KAPP. Acta Psychiatrica Scandinavica, 83(Suppl. 363), 1–23.

Weinstein, E. A. and Kahn, R. L. (1959). Symbolic reorganization in brain injuries. In: Arieti, S., ed. American Handbook of Psychiatry. Volume 1, pp. 34–54. New York: Basic Books.

Weissman, D. H. et al. (2006). The neural bases of momentary lapses in attention. Nature Neuroscience, 9(7), 971–978.

Westen, D. (1999). The scientific status of unconscious processes: is Freud really dead? Journal of the American Psychoanalytic Association, 47(4), 1061–1106.

Whitfield-Gabrieli, S. et al. (2009). Hyperactivity and hyperconnectivity of the default network in schizophrenia and in first-degree relatives of persons with schizophrenia. Proceedings of the National Academy of Sciences of the United States of America, 106(4), 1279–1284.

Wible, C. G. et al. (2009). fMRI activity correlated with auditory hallucinations during performance of a working memory task: data from the FBIRN consortium study. Schizophrenia Bulletin, 35(1), 47–57.

Wicker, B., Ruby, P., Royet, J. P. and Fonlupt, P. (2003). A relation between rest and the self in the brain? Brain Research Reviews, 43(2), 224–230.

Wiebking, C. et al. (2010). Abnormal body perception and neural activity in the insula in depression: an fMRI study of the depressed “material me.” World Journal of Biological Psychiatry, 11(3), 538–549.

Wiebking, C., de Greck, M., Tempelmann, C. and Northoff, G. (2011). Are emotions associated with activity during rest or interoception? An exploratory fMRI study in healthy subjects. Neuroscience Letters, 491(1), 87–92.

Williamson, P. (2007). Are anticorrelated networks in the brain relevant to schizophrenia? Schizophrenia Bulletin, 33(4), 994–1003.

Wink, P. (1991). Self- and object-directedness in adult women. Journal of Personality, 59(4), 769–791.

Winnicott, D. W. (1965). The Maturational Processes and the Facilitating Environment. Madison, CT: International Universities Press.

Winnicott, D. W. (1971). Playing and Reality. New York: Basic Books.

Winnicott, D. W. (1975). Through Paediatrics to Psychoanalysis. New York: Basic Books.

Wittgenstein, L. (1994). On Certainty. Cambridge: Cambridge University Press (originally published 1969).

Wolf, E. S. (1980) On the developmental line of self-object relations. In: Goldberg, A., ed. Advances in Self Psychology, pp. 117–130. New York: International Universities Press.

Wolf, E. S. (1988) Treating the Self. New York: Guilford.

Wolf, N. S., Gales, M., Shane, E. and Shane, M. (2000). Mirror neurons, procedural learning, and the positive new experience: a developmental systems self psychology approach. Journal of the American Academy of Psychoanalysis, 28(3), 409–430.

Womelsdorf, T. et al. (2006). Gamma-band synchronization in visual cortex predicts speed of change detection. Nature, 439, 733–736.

Woo, T. U. et al. (2008). N-methyl-D-aspartate receptor and calbindin-containing neurons in the anterior cingulate cortex in schizophrenia and bipolar disorder. Biological Psychiatry, 64(9), 803–809.

Woodruff, C. C., Uncapher, M. R. and Rugg, M. D. (2006). Neural correlates of differential retrieval orientation: sustained and item-related components. Neuropsychologia, 44(14), 3000–3010.

Yao, Z. et al. (2009). Regional homogeneity in depression and its relationship with separate depressive symptom clusters: a resting-state fMRI study. Journal of Affective Disorders, 115(3), 430–438.

Yoo, S. S. et al. (2003). Neural substrates of tactile imagery: a functional MRI study. Neuroreport, 14(4), 581–585.

Yoo, S. S. et al. (2007). The human emotional brain without sleep—a prefrontal amygdala disconnect. Current Biology, 17, R877–878.

Yoon, J. H. et al. (2010). GABA concentration is reduced in visual cortex in schizophrenia and correlates with orientation-specific surround suppression. Journal of Neuroscience, 30(10), 3777–3781.

Young, C. and Brook, A. (1994). Schopenhauer and Freud. International Journal of Psychoanalysis, 75, 101–118.

Zahavi, D. (2005). Subjectivity and Selfhood: investigating the first-person perspective. Cambridge, MA: MIT Press.

Zahn R. et al. (2008). The neural basis of human social values: evidence from functional MRI. Cerebral Cortex, 19, 276–283.
