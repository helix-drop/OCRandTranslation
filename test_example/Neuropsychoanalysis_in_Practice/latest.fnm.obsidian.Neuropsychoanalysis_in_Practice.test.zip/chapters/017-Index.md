## Index

## Index

act intentionality 110

activation baseline 94

adaptive functions 134

admiration 171

affective assignment 173, 175–8, 196, 269

abnormal in depression 351–3

psychological and neural findings 173–5

affective attunement 171

affective function 2

affective-cognitive tasks 158

affects 41, 139–42, 172, 177

decathexis of 301

in dreams 196–8

encoding problem of 174

negative 241–3, 245, 256–9

and self-objects 269

alexithymia 174–5

Ameriks, Karl 37

amygdala 102

in major depressive disorder 247

analytical self-focus 245

anastrophe 307

anhedonia 253

anosognosia 179

delusional 178

anterior cingulate cortex 96, 301–2

auditory verbal hallucinations 290

resting-state activity 93

anticathexis 88, 100

antisocial personality disorder 177–8

aphasia 34, 130–1, 133

apophany 307

aperception 38

applied logic 26

archaic self 165, 166

arousal baseline 94

asomatognosia 178

attachment 219, 228, 231

attention deficit hyperactivity disorder 93

attunement 267–9, 288

auditory cortex 127

auditory verbal hallucinations 288–90, 292–3, 296

autobiographical memory retrieval 248–9

autobiographical self 214–15

autoepistemic capacity of body 51

autoepistemic closure 53, 55

autoepistemic limitation 50–1, 53, 55, 64

autoeroticism 163

autoplastic adaptation 167, 179

awareness of self 224

background input 94

bad self-objects 270, 278, 297, 305

basic relation 276

Beck Depression Inventory (BDI) 245

Beck Hopelessness Scale (BHS) 260

behavioral unconscious 187

belongingness 227

Bennett, Maxwell 50

Berze, Joseph 273

Besetzung 87

Bickle, John 61

biological-social differentiation 281, 316

bizarre self in dreams 198–200

bodily awareness 153

bodily objects 156

body

as first self-object 183

li¦ed di\ ea\ aef–g\ bgc

objective 51, 156, 229, 273

phenomenal 51

subjective 273

Body Perception Questionnaire 258

body-focus, increased 244

BOLD response

negative 7, 93, 99, 102, 129

perigenual anterior cingulate cortex 99

positive 93, 99

self and reward 159

subcortical-cortical midline system 221

bottom-up differentiation 104

bottom-up modulation 101

brain

concepts of 43–6, 77–9, 234–5

differentiation of 316

energy 87–107

and environment 333–4

function-based approach 3

hierarchical organization 100–3

hyperactivity of 93

insensate 51

intrinsic activity see resting-state activity

knowledge of 328–9

localization-based approach 3, 332–3

neural structure/organization 100–3

oxygen consumption 7, 92–3

psychic input 31–3

psychosomatosis of 316

subjectivity and 330–2

transcendental/empirical views 325–6

see also individual regions

brain confusion 79

brain as experienced 43–5, 46, 56

brain as functioning 43–53, 55, 56, 63, 64

unknowability of 49–56

brain as object of cognition 47, 49

brain as observed 43–5, 46, 49, 52–3, 56, 63

brain as subject of cognition 47, 49

brain–mental apparatus dilemma 40–3

brain–mind differentiation 62
