## Epilogue: The Beauty of Transdisciplinary Failure —A Trialogue

The Beauty of Transdisciplinary Failure—A Trialogue

In lieu of a Conclusion, there now follows a dialog between a psychoanalyst (PS), a neuroscientist (NS), and a philosopher (PH) about neuropsychoanalysis.

Philosophy is not opposed to science, it behaves itself as if it were a science, and to a certain extent it makes use of the same methods; but it parts company with science, in that it clings to the illusion that it can produce a complete and coherent picture of the universe, though in fact that picture must fall to pieces with every new advance in our knowledge. Its methodological error lies in the fact that it over-estimates the epistemological value of our logical operations, and to a certain extent admits the validity of other sources of knowledge, such as intuition. (Freud, 1933)

Transcendental and empirical views of the brain

PH: While I am not really entitled and able to judge the second and third empirical parts of the book, I am certainly qualified enough to comment on the theoretical chapters. The transcendental view of the brain still smells like a category error to me.

NS: What do you mean by that?

PH: People and their minds acquire knowledge. This is an epistemic feature. The author's error lies in the fact that he relates such an epistemic feature to the brain and its neuronal states as a mere empirical feature. However, this is to confuse people with brains, and thus to confuse epistemic and empirical categories. Isn't that an error?

PS: But wouldn't the person be unable to acquire knowledge at all without a brain? People are their minds—and minds are brains. Therefore the person is nothing but his brain. What you call different categories thus implode once one considers reality.

PH: You don’t know how much it hurts to see an intelligent person like yourself making such a simple mistake. Of course you are right in saying that we could not acquire any knowledge without the brain. How though do you describe your observations? You use concepts, don’t you? The observations themselves are not the same as the concepts that you use to describe them. Observations refer to the brain, concepts refer to the person.

NS: Don’t they both refer to the brain? Concepts merely describe what we observe in the brain. Isn’t that a purely artificial distinction?

PH: No. It becomes relevant in the distinction between the author's transcendental and empirical views of the brain. The transcendental view describes knowledge acquisition, an epistemic feature that can only be associated with people, whereas the empirical view concerns mere observations of the brain's neuronal states.

Since the transcendental view refers to people rather than brains, it is senseless to speak of a transcendental view of the brain. The only transcendental view we can take is of people. The author confuses people and brains when he claims a transcendental view of the brain—a clear instance of a category error!

PS: Objection! You may be right in diagnosing a category error when the empirical view of the brain is associated with a person's knowledge acquisition. But does that hold also for the transcendental view of the brain?

NS: Can anyone finally explain me what is meant by “transcendental view of the brain”?

PS: As I understand it, the transcendental view of the brain concerns those features of the brain that originate from within the brain itself—the “brain’s input,” as the author says. But there is another input yet—the observer’s input, what the observer himself puts into his own observation of the brain. Our observation of the brain in the empirical view is thus a combination of the brain’s input and the observer’s input. How can we grasp the brain’s input itself as distinct from the observer’s input? For that, the author argues, we need to take a transcendental view of the brain that will lay bare the brain’s input itself.

NS: Nice chimerical fantasies. What on earth is this “brain’s input” if not the neuronal states that we observe? What I observe is nothing but the brain itself and its neuronal states. I do not put anything into the observation of the brain by myself. There is no observer’s input that is distinct from the brain’s input. If, however, there is nothing but the brain’s input in our observation of the brain, we do not need any transcendental view of the brain. The empirical view tells us everything there is. What the author calls “transcendental view of the brain” turns out to be a mere fantasy.

PH: Well reasoned, but flawed nevertheless, Mr. Neuroscientist. Kant argued that a transcendental view of the mind allows us to reveal the mind's input to our cognition and knowledge. His concern was a truly epistemic one, that asks for the conditions of our knowledge of the mind and the world. Following Kant, Schopenhauer replaced the mind by the brain when he characterized the brain rather than the mind as the subject of cognition. However, this is to confuse not only empirical and epistemic concerns but also the subject and object of cognition. The brain can only be an object of cognition—it is an object of our knowledge—whereas the brain cannot be a subject of cognition, since only people but not brains can acquire knowledge. Our brain is a mere gray pulpy mass, as Schopenhauer himself called it once, and nothing else. Do you really think that such a gray pulpy mass can acquire knowledge and lead dialogs like this?

PS: You mean then that a transcendental view of the brain is impossible because that would be to presuppose the brain as subject of cognition?

PH: Yes, that is exactly what I mean. The brain cannot be the subject of our knowledge. The brain is only an object of our knowledge, which precludes any transcendental view of it. Kant got it right. Schopenhauer and our poor author got it wrong. They confused the object and the subject of cognition. Our brain's gray pulpy mass is nothing but an object of cognition and can never be its subject.

PS: Impressive reasoning. I concede, though only in this case.

NS: Impressive reasoning. Yes certainly so. But is it really relevant? Who cares whether the brain is the subject or the object of cognition? That is pure logic, play with concepts. Reality is what counts. You cannot infer reality from your concepts. Reality is not logical reality. Reality is what you observe out there in the world, reality is empirical reality. What I observe in empirical reality is the starting point for acquiring knowledge about the world! To start otherwise with mere concepts is to infer empirical reality from the logical world of concepts. That will give you knowledge only about your concepts and their logical rules, whereas it will not provide any knowledge about the world itself. Who cares about your concepts if my observation of the brain tells me everything there is?

Brain, mind, and the psychic apparatus

PS: I have another objection to the category error. The error does not concern the confusion between empirical and epistemic domains, but between neuronal and psychodynamic categories. This is most apparent in the author's concepts of brain–self and brain–object differentiation. He here confuses the neuronal category of the brain with the psychodynamic one of self and objects. How can brain and self/objects differentiate from each other if they belong to different categories? The concepts of brain–self and brain–object differentiation are thus as nonsensical as the transcendental view of the brain.

PH: You learned your introductory philosophical lesson rather well and quickly. Yes, the concepts of brain—self and brain—object differentiation do certainly suffer from a category error. What you describe as confusion between self/object and brain surfaces as confusion between mind and brain in the philosophical context. Analogous to your case, the concept of brain—mind differentiation is a rather hybrid concept: On the one hand, the concept of the brain is purely mechanical and thus scientific, and as such does not carry any meaning in itself. On the other hand, the concept of mind refers to meaning when describing meaningful contents, so is hermeneutical rather than scientific.

NS: Well described. But that does not prevent the brain from constituting the very meaning you exclusively associate with the mind or the self and its objects.

PH: I again feel sensations of mental pain. Are you blind? How can you confuse the meaningful with the meaningless? How can you reduce hermeneutics to science? These are two fundamentally different categories. To reduce hermeneutics to science is to replace the meaningful with the meaningless.

PS: I don’t understand. Could you be a little more concrete?

PH: Differentiation presupposes some kind of common origin, as otherwise differentiation would be impossible. By assuming brain–self and brain–object differentiation, our author implicitly presupposes some kind of common origin.

PS: Now, I understand what you mean by mental pain. Freud would have indeed shaken his head. Self and objects do not differentiate from the brain. Instead, self and objects differentiate from what Freud called the “psychic apparatus.” Our author got it wrong. He needs to replace his concepts of brain-self and brain-object differentiation with those of “psychic apparatus-self differentiation” and “psychic apparatus-object differentiation.”

NS: You are always so quick to sweep over the facts with one glance. How foolish can one be in not seeing that what Freud called the “psychic apparatus” is nothing but the brain and its neural apparatus? The psychic apparatus is the brain. Our author got it right here. Freud’s psychoanalysis needs to be traced back to neuroscience.

PH: Strangely, this may be the first time in my life I have ever agreed with a neuroscientist. Our author claims that Freud's psychic apparatus corresponds to what he calls the "brain as functioning" as distinct from the "brain as observed." And, as I understand him, he assumes that brain-self and brain-object differentiation concern the differentiation between the "brain as observed" and self/objects with the "brain as functioning" as their common origin.

PS: My dear philosophical and neuroscientific colleagues, don't you see empirical reality? Brain remains brain, whatever concept (and view) you use to describe it. Since any concept of the brain cannot but refer to the brain, the "brain as functioning" is just a conceptual disguise for the "brain as observed." Neither can account for the meaningful contents associated with psychodynamic concepts such as self and objects and the psychic apparatus. Self and objects do not differentiate from the brain – they differentiate from each other as well as from the psychic apparatus. Whereas the author's concepts of brain–self and brain–object differentiation need to be discarded.

PH: I agree with this. Brain is brain, whether it is described as brain as observed or brain as functioning. Since the brain remains the brain in either concept, it is also impossible to associate the brain with any kind of hermeneutics. The brain remains nothing but a purely physical and material organ, and thus meaningless by itself. The brain is nothing but a gray pulpy mass! Such a gray pulpy mass has nothing to do with either the epistemic or hermeneutical domain.

NS: Surprisingly so, but I agree here, though for different reasons. Brain is brain, no one can dispute that. However, I disagree that mind, as the philosopher seems to call it, or psychic apparatus, as the psychoanalyst prefers to say, are largely different from the brain. Brain is brain, which means that mind or psychic apparatus is nothing but the brain, too. To put it philosophically, the concept of the brain implies all of the features and meanings originally attributed to mind or psychic apparatus, as you call your chimerical entities. The concepts of brain—self and brain—object differentiation should be replaced by those of “self—brain and object—brain reduction.” To assume otherwise is as superfluous as adding a fifth wheel to your car. Or doesn’t your car already drive well on four wheels?

PS: Now I do not only understand but even feel sensations of pain in the same way as Mr. Philosopher expressed before. How can one sweep away the meaningful contents of objects and the self that were so richly and colorfully described by Freud and replace them with the mere gray pulpy mass of the brain? What a brutal act of scientific arrogance!

NS: You confuse me with reality. I am not brutal—I merely describe reality. Reality itself is brutal!

PS: No, it is you who confuse things. You confuse the hybrid nature of the psychic apparatus with the brain. Freud regarded the concept of the psychic apparatus as truly hybrid by its very nature. On the one hand, the psychic apparatus describes purely mechanical and meaningless processes, while on the other it constitutes meaningful contents as objects and self. To reduce the psychic apparatus to the brain is to disregard the latter, the meaningful contents, in favor of the purely mechanical and meaningless processes. However, that would be like moving a bridge from across the river and placing it to one side of the river. Wouldn't that defeat the purpose of the bridge, if you are no longer able to cross to the other side? Now you know what our author does to the psychic apparatus if he reduces it to the brain.

PH: I disagree, Miss Psychoanalysis. Yes, the concept of the psychic apparatus is hybrid, but it is hybrid not by its very nature but due to your conceptual confusion. Hermeneutics and science are two different categories. They are not like two sides of the same river that can be bridged. They are not like two different centres which can be connected by airplanes. Instead, they are two different universes that cannot be connected. Your hybrid concept of the psychic apparatus is thus nothing but conceptual confusion. The concept of the psychic apparatus is indeed as superfluous as a fifth wheel on a car. Our author is therefore right in replacing the concept of the psychic apparatus with the one of the brain. He even presents an interesting alternative to the mind–brain problem. The current mind–brain discussion focuses on revising the concept of mind to make it amenable with the one of the brain. One may call this the “mind path.” By discussing different concepts of the brain, our author tackles the mind–brain problem from the opposite end of the brain, a “brain path” as one may want to call it.

PS: “Brain path” or “mind path”? You don’t need any of these concepts. All you need is the psychic apparatus. The psychic apparatus is neither mind nor brain. The psychic apparatus is psychological reality. You cannot start with some concepts like mind or brain and then infer psychological reality from them. You have to start with psychological reality itself. You have to take the “psychic apparatus path.” Your “mind path” and “brain path” are utterly flawed conceptual fantasies that you imprint on the psychological reality of the poor psychic apparatus. Nonsense, sheer conceptual nonsense.

Knowledge of the brain

PS: As much as it hurts to admit it, our confused author converges with Freud on another point. Both argue that we may suffer from an epistemic limitation with regard to either the psychic apparatus (Freud) or the brain (the author). We may not be able to completely and directly know the brain as functioning, which therefore may not be identical to the brain as observed. What's up, Mr. Neuroscientist?

NS: I decline to comment. Why comment on something that is nonsense? We observe neuronal processes which make the brain functioning. The brain as observed is the brain as functioning. End of story! To assume otherwise is to assume some non-neuronal properties of the brain that cannot be observed. However, there is nothing more to the brain than what we can observe. The author's doubling of the concept of the brain is consequently utterly flawed and nonsensical.

PS: That's not a very friendly comment. We have to understand, though. Who likes to admit borders to a kingdom, the kingdom of neuroscience, that claims to cover the whole universe and thus to be without borders? Freud already knew. The narcissistic fantasies of grandeur do not like to be spoiled by something as trivial and contingent as borders.

NS: I am almost certain that this is nothing but a projection on your side, Miss Psychoanalysis.

PS: Now he is getting personal.

NS: Who is projecting here upon whom? Aren't you projecting your own fantasies about the psychic apparatus upon me as neuroscientist? You should be thankful that I serve as the projection surface behind which you can hide your own narcissism. Maybe I should demand a psychotherapeutic fee?

PH: Let us be serious again. Yes, the emphasis on epistemic limitation in our possible knowledge of the brain is indeed interesting. That reminds me a little of the claims of philosophers like Colin McGinn, who argue that we suffer from a primary inability to fully know the brain. However, they assume some additional ontological properties as distinct from both mental and physical properties. The exact nature of these properties remains unclear, though, which makes them rather mysterious. Our author seems to be prone to the same problem. How does he characterize the brain as functioning? Either he assumes some additional properties, which makes him rather mysterious, or he refrains from assuming additional properties, in which case his brain as functioning can no longer be distinguished from the brain as observed.

PS: Cold logic, nothing but cold logic and empty concepts, Mr. Prosecutor. Yes or no. All or nothing. That is all you can think. The concept of the psychic apparatus is exactly what you are looking for. It does not assume any additional rather mysterious properties because it refers to nothing but psychological reality. While at the same time it is more than we can observe when describing the psychological structure and organization rather than specific psychological contents. You describe such a concept of the psychic apparatus as hybrid and logically flawed. I describe it as psychological reality and empirical.

NS: Strange, very strange. You accept empirical reality as hybrid in the case of the psychic apparatus, whereas you reject it for the brain. The psychic apparatus can integrate and link mechanical meaningless processes and meaningful contents, but the brain cannot. You accept that psychological reality is hybrid but you reject neuronal reality. Strange, very strange. Our author does exactly the same as you. The only difference is that he extends your beloved psychological reality of the psychological apparatus to the neuronal reality of the brain. How can you reject the latter while at the same time embracing the former?

PS: It's very simple. The psychic apparatus can be characterized by mental states while it does not include any neuronal states. Doesn't that provide enough evidence that there may be some transition between mind and psychic apparatus while the latter is not continuous with the brain? Even worse, you go beyond your own knowledge boundaries. How can you know that the psychic apparatus is nothing but the brain if you cannot have complete and direct knowledge of the psychic apparatus itself? You seem to stubbornly resist the assumption that you may suffer from a limitation in your knowledge of the brain. The blind spot in your knowledge of the brain is in exactly the same place as the psychic apparatus is located.

NS: You and your psychic apparatus. Enshrine it and pray at least five times a day to it. You suffer from a limitation, not me. Your limitation is that you do not see your own illusion. Your concept of a psychic apparatus is nothing but an illusion. What you call a limitation is based on an illusion that there is more to empirical reality than you can observe. The psychic apparatus is nothing but the brain as we can observe, nothing less and nothing more. To deny that is not only to ignore the neuroscientific data but, even worse, to deny the brain and reality altogether.

PH: Naivety, pure naivety, the mentality of a two-year-old. How could I ever have expected a neuroscientist to see the difference between observation and knowledge, between empirical and epistemic domains? Rather than rejecting epistemic limitation, he only illustrates to me how limited we are in our knowledge.

NS: Of course, not being used to reality in his ivory tower, the philosopher cannot do other than simply invent something mysterious. One needs to understand. If he was to admit empirical reality, his ivory tower would be demolished. He must be mysterious in order to survive!

PS: Well analyzed. But let us go back to our author. The limitation he is talking about does not concern some mysterious properties, as our detached philosopher says. Rather it refers to what Freud called the psychological structure and organization. Our author now extends this to the brain. He argues that the brain's neural structure and organization cannot be accessed and known directly as such. He speaks of autoepistemic limitation. Since he assumes that the brain's neural structure and organization constitute mental states, autoepistemic limitation prevents us from accessing and knowing the relationship between neural and mental states. Most interestingly, he associates such "neuronal–mental transformation" with neuronal mechanisms such as a specific neural code.

PH: Is that true? This provides a novel philosophical approach to the perennial mind–brain problem which motivates me to get back into it . . .

NS: Are you sure? Maybe I need to read the book again ...

Subjectivity and the brain

PS: Another interesting issue is the method suggested here, namely neuropsychodynamic iterativity. The author attempts to out psychodynamic concepts within the context of neuroscientific concepts, and vice versa.

PH: To be honest there is nothing innovative. Worse this method is flawed and naive. The author is apparently not aware of the basic distinction between hermeneutics and science which was long ago established. This is the bedrock foundation for the distinction between humanities and science. How can he mix the two in such a naive and childish way?

PS: Mr. Philosopher, you are always so quick to denounce anything that does not fit your pre-established categories. Everything is nothing but conceptual confusion and category error. Have you ever thought of questioning the categories themselves?

PH: I’m appalled. How can you doubt the bedrock foundation of our disciplinary divisions? Are you self-destructive? Your own discipline, psychoanalysis, would not exist if hermeneutics could not be distinguished from science. You could not even get started with your psychoanalytic confusions if hermeneutics could not be distinguished from science. How can you saw off the very branch that you are sitting on?

PS: This shows me even more clearly that you have no sensitivity to context. The psychological context is different from your conceptual–logical one. Take, for instance, the concept of cathexis, which Freud himself introduced to describe the discharge of psychic energy. This concept is clearly bound to the psychological context, whereas it would make no sense in your conceptual–logical context. To understand the concept of cathexis, you thus need to consider its specific context. You cannot detach concepts from their specific contexts, including the categories associated with the respective context.

NS: Why not simply replace the concept of psychic energy with the concept of neuronal energy? You simply change the context from a psychological one to a neuroscientific one. What Freud described as cathexis is then nothing but the brain’s resting state, its intrinsic activity.

PH: My dear Mr. Neuroscientist, I'm amazed how naive you are. You cannot simply translate one concept into another in a one-to-one manner. The philosopher Quine argued that one-to-one translation of one concept into another is doomed to fail because of their contextual differences. And there you go and just claim to translate the psychodynamic concept of cathexis into a neuroscientific concept.

NS: Why not? Where is the problem with that?

PH: The problem is that the psychological context of the psychodynamic concept of cathexis as psychic energy is different from the neuroscientific context of your concept of the brain’s resting-state activity.

NS: I don’t understand. In both cases the concept of cathexis refers to discharge of energy. Does it matter at all whether the energy refers to psychic energy or neuronal energy?

PS: You cannot imagine how much that hurts, your conceptual naivite disturbs me. Cathexis is psychic energy, not neuronal energy. We should go back to Freud himself and his intentions. Freud aimed to describe subjective processes by using objective terms. Processes are subjective in that they can be accessed only by an individual person from their particular first- (or second-) person perspective. For instance, the concept of the id is an objective third-person-based concept that aims to refer to highly subjective processes from a first-person perspective, such as sexual desire. In short, psychodynamic concepts describe first-person processes in third-person terms.

PH: Yes, now it is clearer to me. That is exactly why they are conceptually confused. You cannot link first- and third-person aspects within one concept. Either you deal with facts that are observable from third-person perspective as in neuroscience, which excludes meaning, context and first-person perspective. This is what science and more specifically neuroscience is all about. Or you deal with concepts rather than facts. However, this brings context, meaning and the first-person perspective into play. This is accounted for by herme-neutics. Do you really want to deny this primary difference when saying that Freud aimed to link first- and third-person perspectives in his concepts?

PS: Be care, Mr. Philosopher. Linkage is not denial. Linking first- and third-person perspectives does not mean that I deny their distinction. You seem to confuse linkage with reduction. To make you aware again, I am the psychoanalyst, not the neuroscientist.

NS: Linkage is not denial? I don't care. Facts are relevant, not concepts. The recent neuroscientific facts tell me that what you call first-person perspective can well be accounted for by specific neuronal states as observed from third-person perspective. Your heralded difference between first- and third-person perspectives is thus relevant only on paper, conceptually as you say, whereas it has no empirical relevance. Why then consider this difference at all?

PS: I again feel a sensation of mental pain. How can someone as intelligent as you completely disregard all of the personal meanings from first-person perspective that Freud tried to capture in his ingenuous descriptions of his patients? You will never get the same information from mere observation from third-person perspective.

PH: Let us be clear. The neuroscientist aims to colonize the first-person perspective with the third-person perspective. How can he be so naive? These are different ways of accessing reality and do therefore require different methods. To link both in the discipline of neuropsychoanalysis is to simple ignore these boundaries and to confuse psychoanalysis as hermeneutics with neuroscience as science.

PS: Bravo! This needed to be stated clearly. Thank you so much.

NS: You must be emotionally unstable. Now you suddenly side with the philosopher whom you were fighting just a couple of minutes ago. Apart from that, I still do not understand the fuss about the first-person perspective. If it can be explained in terms of the third-person perspective, why not embrace the latter? Why leave a broken wheel on the car when you have already replaced it with a new one?

PS: You are at least as blind as I am emotionally unstable. You do not see that the difference between first- and third-person perspectives goes along with a much deeper difference, the one between subjectivity and objectivity. Psychoanalysis targets subjective processes that involve a hermeneutics of mind, whereas neuroscience targets only objective processes and thus a science of the brain. If you reduce the former to the latter, you eradicate any trace of subjectivity. However, that means to completely abandon the basic subjective nature of our human existence.

NS: Now you’re becoming really dramatic. I can tell you, though, the real drama is what happens in the brain. What you call subjective is nothing but the work of the brain’s objective neuronal processes. To make it even more dramatic, those neuronal processes can well be observed from third-person perspective.

PH: Mr. Certainty, you seem to know everything. How can you know that the brain's objective neuronal processes bring forth subjective processes such as mental states? You must know everything to know that. You must be God.

NS: I think you are confusing yourself in your ivory tower with God. No wonder you don't see reality. The windows and doors of your ivory tower are closed, which prevents you from seeing the empirical reality. That empirical reality is nothing but neuronal reality. What you call mental is neuronal. What you call subjective is objective. To assume that the mental states as subjective must be traced back to something that is subjective by itself is logically flawed. You can access the mental states only in a subjective way from first-person perspective. Yes, you may be right about that. But does this mean that the neuronal states as accessible from third-person perspective must be subjective themselves? I don't need to tell you. That means to confuse access and states or, to put it in terms of your own categories, to confuse epistemic and empirical domains.

PH: Oh, now the neuroscientist is waxing philosophical. Did I ever argue for subjective processes to be described in objective terms? No, psychoanalysis does that. Psychoanalysis is a bad mixture of subjectivity and objectivity. But don't get complacent too soon. You do exactly the same when you claim that the objective neuronal processes cause subjective mental states. Subjectivity is not a matter of mere access, as you try to sideline it. Subjectivity is a basic dimension of human nature.

PS: When do I ever step into an ivory tower? Unlike you, Mr. Philosopher, I step out of it and see psychological reality. This is what psychoanalysis is all about—describing subjectivity in psychological reality. This is why Freud introduced the concept of the psychic apparatus. This is why he abandoned neuroanatomy.

PH: I have to distance myself from such confused attempts at colonization. To associate subjectivity with any kind of empirical reality whatsoever, be it psychological or neuronal, is to lose it. Subjectivity is not empirical, it is epistemic. Therefore subjectivity cannot be linked either with the psychic apparatus or with the brain, as our desperate author suggests. For the same reasons you cannot link the first-person perspective with observations from third-person perspective. This means that all attempts to do so—however sophisticated—are doomed to fail.

NS: Strange. You two seem to be the only ones who still adhere to the rather mysterious claim that subjectivity has nothing to do with the brain. Meanwhile everybody else knows this all too well. Changes in my brain go along with changes in my subjectivity. How can you deny something so obvious? I'm sorry, I was forgetting that you are both sitting in ivory towers called psychoanalysis and philosophy.

Localization and the brain

PS: Another reason why the extension of psychoanalysis into neuropsychoanalysis must fail is the peculiar nature of psychological functions. Although Freud was initially a neuroanatomist, he considered the localization of psychological functions in specific regions of the brain to be impossible.

NS: Why exactly did he abandon neuroanatomy and venture into the rather mysterious territory of psychoanalysis?

PS: He was frustrated with the neuroscience of his time. He aimed for a brain-based scientific psychology in his famous writing from 1895. However, he observed in that writing that the complex psychological functions cannot be localized in specific regions of the brain. This led him to abandon neuroanatomy and to develop psychoanalysis.

NS: Why did he deem any localization of psychological functions in the brain to be impossible?

PS: Because of the complexity of the psychological contents that are subjective, personally relevant, and individual. Something as subjective, personally relevant, and individual as psychological contents cannot be localized in something as objective, personally irrelevant, and non-individual as the neural activity of a specific brain region. Or do you think that your current emotional feelings of contempt for the philosopher can be found in a specific region of your brain?

NS: Wait! That may have been true for the neuroscience in Freud's time. Now we know better. We know, for instance, which regions are active during the feeling of contempt. Even more complex functions like consciousness and the self can be associated with specific regions in the brain.

PS: No, no, it is not only a matter of time. We cannot trace the personal relevance, individuality, and subjectivity of your feeling of contempt to the activity in certain brain regions. You will only see neural activity changes in the brain's regions, but no personal relevance, individuality, and subjectivity. Or are you suffering from hallucinations?

NS: Apparently you are not fully up to date with the latest breakthroughs in neuroscience. The self has been shown convincingly in several brain imaging studies to recruit specific regions in the midline of the brain—the so-called cortical midline structures. And you tell me that we cannot locate the self in the brain? You are wrong, I don’t suffer from hallucinations. You, however, must be diagnosed with ignorance.

PS: You are conceptually confused. You talk about the self when I mean the ego. Ego and self are not identical. Freud considered the concept of the self to be only part of the ego.

NS: This is a mere conceptual playground, I know. Our author cites another psychoanalyst, Kohut, who regards the self as central. I hope you enjoy playing with concepts. Do these concepts matter? No! In the future, I am sure, erroneous psychodynamic concepts like self and ego will be replaced by neuronal ones like the cortical midline structures. Do you refer to some mysterious entity when you talk about your digestive problems? Would you? I am almost certain that you don't. Instead, you speak of your stomach, don't you? Why then are you still using mysterious concepts like self and ego instead of cortical midline structures?

PH: I do not need to say that I hate to side with a conceptually confused person such as a psychoanalyst, but here I must agree with her. You are not only talking about different concepts—the concept of the ego and the concept of the self. You also presuppose a rather erroneous fallacy which has recently been termed “mereological fallacy” by Bennett and Hacker. The discipline of mereology describes the relationship between parts and wholes, as for instance between brains and people. The brain is a part of the person as a whole. If you now trace back the features of the person, their self and ego, to the brain and its cortical midline structures, you explain the whole by one of its parts. This, though, is erroneous in very much the same way as when you explain a car in terms of one of its wheels.

PS: Mr. Neuroscientist, isn't this clear? Everybody knows that a car cannot be explained by one of its wheels. Apparently you do not. Otherwise you would not localize psychological functions like ego and self in specific regions of the brain.

NS: How naive do you think we as neuroscientists are?

PS: Very naive, and blinded by neuronal reality.

NS: We do not associate a concept as complex as the ego with the activity of one region. There are multiple connections between different regions. There are so-called re-entrant connections where regions return their information. And there is a global operational workspace in the brain that allows recruitment and operation of different regions at the same time. Localization nowadays does not mean the same as it did in Freud's time. In his time, localization meant one specific region as one part of the brain, whereas nowadays localization refers to complex neural networks encompassing multiple regions, if not the whole of the brain. And you still accuse me of part-whole confusion?

PH: No matter how sophisticated your concept of localization may be, to consider the brain as a whole by itself is to simply ignore the fact that the brain is part of your body and that the body is only part of you as a person. This would amount to the claim that you are nothing but your brain, “I am my brain,” which is utterly absurd, Mr. Neuroscientist. You have to accept your limits and boundaries. There is no escape. Best give up and surrender. Unless you claim that you yourself are nothing but your brain. Although I was not aware that I was talking to a brain . . .

Brain and environment

NS: Who tells you that there is any difference between people and brains? Isn't a person what their brain is? Am I not nothing but my brain?

PS: You are so refreshingly naive. Psychoanalysis showed very convincingly that there is more to the person. There is the environment and more specifically attachment to specific people or objects within that environment. Without the environment you are nothing. You need the environment in order to flourish in the same way that you need air for breathing in order to survive. To claim that people are nothing but their brains is to completely disregard the environment. Arrogance, ignorance, and all that because of some gray pulpy mass in your skull.

NS: This is another instance of projection. You are too embarrassed to admit your lack of knowledge about current neuroscience but, being a psychoanalyst, you of course know how to hide it. The best shelter is still behind the back of other people, and that is why you attribute your own ignorance and arrogance to me. To bring it back into your own awareness. You ignore all of the neuroscientific data about neural plasticity, the adaptive changes of the brain's cells and neural activity in response to challenges from the environment. The activity in your cortical midline structures may, for instance, change when you are exposed to plenty of stimuli that are highly personally relevant and meaningful to you.

PS: Well reported. But that still does not capture what Freud meant. He argued that the constitution of the psychological structure and organization is itself dependent on the environment. Only when we interact with the environment are we able to develop the skills and abilities that are necessary to distinguish between self and objects (i.e. self-other differentiation), as they are for instance attributed to the ego. I have no doubt that the brain and its neuronal states can be modulated and influenced by the environment. But the idea that neuronal states themselves are organized and structured by the environment? No, that remains impossible, and it holds only for the psychic apparatus.

NS: Isn’t that exactly what the findings concerning the neural plasticity of the brain show when, for example, demonstrating the impact of social interaction or the use of certain skills on our brain’s structure and function?

PS: No, they only show that the neuronal states can be modulated by the environmental context. Following our author, one may distinguish between “constitutive context dependence” and “modulatory context dependence.” Contrary to the author, though, I assume that constitutive context dependence holds only for the psychic apparatus, but not for the brain.

NS: Holy concepts. Another instance of a conceptual difference that remains empirically irrelevant.

PH: You are wrong again. The concept of constitutive context dependence seems to describe a causal and necessary effect of the environmental context on the brain’s neural structure and function, while the concept of modulatory context dependence does not attribute a causal and necessary role to the environmental context in shaping and constituting the brain’s neural structure and function. Isn’t that empirically relevant?

NS: It is conceptual sophistication, nothing else. Every modulatory impact is causal, otherwise it would not lead to changes in the brain. Your distinction between modulatory and constitutive context dependence is therefore only conceptually relevant, not empirically so. But what can one expect from a philosopher whose discipline moved into an ivory tower 3000 years ago and has stayed there ever since?

PH: Before being finally banished to my ivory tower, I want to step out one last time. Doesn’t the author himself claim that he bases his distinction between modulatory and constitutive context dependence on empirical data?

NS: Yes, it would appear so. But all the evidence that he cites could equally well support modulatory context dependence. Isn't that proof enough that there is no difference between modulatory and constitutive context dependence? Our author imposed a conceptual distinction upon the empirical data. Instead of imposing his concepts, he would have done better to have started with the actual data. This example again demonstrates that we need fewer concepts and more facts. And these facts will tell us that the mind is nothing but the brain. The more facts, the more brain, and the less mysterious concepts like mind and psychic apparatus.

PH: I cannot but pull up the drawbridge to my philosophical ivory tower when I hear that.

PS: Completely devoid of any traces of meaning and subjectivity. What an oblivious view of people and the world—and, I’m afraid, of brains.

Neural predisposition and difference-based coding

NS: There is yet another interesting distinction, namely that between neural predisposition and neural correlates.

PH: Yet another one of those neuroscientific artifacts, but this time a conceptual one.

NS: Dear Mr. Philosopher, I would be more than delighted to explain this conceptual difference using your own terminology. Could that help to make you understand? Neural correlates concern those neural conditions that are sufficient to induce a specific psychological content or mental state. However, as you may well know, not every sufficient condition is also necessary. In addition to the neural correlates, the author therefore speaks of neural predispositions that describe the necessary but non-sufficient neural conditions of mental states.

PH: Welcome to my ivory tower. You got the distinction between necessary and sufficient conditions right. You successfully passed the first entrance door.

PS: How long did you spend in the philosopher’s ivory tower? Now it’s clear to me why you were infected by the philosophical virus and sound as abstract and lofty as the philosopher.

NS: To bring it down to your level, Miss Psychoanalysis. Neural correlates concern those neuronal mechanisms that underlie specific psychological contents as objects or self. Whereas neural predispositions refer to those structures and functions that, like the ego, enable and predispose to the constitution of psychological contents.

PH: Oh my goodness, you have a point. Freud indeed saw the ego as psychological structure and organization that enables and predisposes one to acquire specific psychological contents. He may have spoken thus of psychological predisposition and distinguished it from mere psychological correlates.

NS: You finally see my point?

PS: Don’t get too carried away yet. You again disregard the fact that the ego refers to the psychic apparatus rather than the brain. One can speak of psychological predispositions, but neural predispositions? No, that is impossible. One cannot replace the psychic apparatus by the brain.

NS: You accept the predispositions but not the neural predispositions? That tells me that you really are locked into a prison, the prison of the psychic apparatus. Like all inmates of any kind of prison, you are not exposed to reality any more. No wonder that you do not notice that your beloved psychic apparatus has been replaced by the brain in the mean time. Now it is also becoming clear to me why you constantly speak of Freud. You have been imprisoned for quite some time and have never been released. I assume therefore that you must be dangerous.

PH: Happy world. He puts me in an ivory tower and you in a prison. But he himself is speaking out of a cave, the cave of the brain. Caves are dark, with at best only occasional rays of sun glinting through. All he then sees are shadows, and he mistakes them for the brain. Let us be serious again. Mr. Neuroscientist, you are the expert on the brain. Can you tell me in detail what the author's neural predisposition looks like?

NS: What a majestic visitor to my cave. The philosophical emperor has arrived in person. Let me prepare the tea. Neural predispositions refer to the specific way in which the brain codes all incoming information.

PH: Could I have more sugar please? What does this specific method of neural coding look like?

NS: The author shows that the brain’s neural activity results from coding differences. What is coded in neural activity is thus the difference between the brain’s intrinsic activity and intero- and exteroceptive stimuli from body and environment. Neural activity thus mirrors difference-based coding.

PH: Ha, there it is—the logical flaw. How could I ever have expected a neuroscientist to be logically coherent? How can a neuron code the difference between different stimuli if it does not code the single stimuli by themselves prior to that? How can the difference between different stimuli be calculated except on the basis of the values for each stimulus independent of the others? His suggestion of difference-based coding is circular and thus logically flawed.

NS: I hear the gloating tone in your voice. However, you forget that you are in my cave and not in your ivory tower. You forget the distinction between your own access and the brain itself. Yes, you are right, you can access differences only as differences between two values. Difference-based coding is then indeed circular and logically flawed. These are the logical–conceptual foundations upon which your ivory tower is built. But you forget that my cave is built on a different foundation, one where access and concepts are replaced by the brain itself and its empirical foundation. The brain itself tells us the truth, not you and your specific way of accessing the brain in terms of concepts.

PS: Now I am curious. What does the brain tell us?

PH: The brain does not tell us anything. The person who calls himself Mr. Neuroscientist tells us something about the brain. Or does your brain speak to us?

NS: I'll ignore these comments that are supposed to be amusing. What do the data tell us? The data do indeed show some support for neural activity being coded on the basis of neural differences between neural, interoceptive, and exteroceptive stimuli. Even more interesting, the author shows quite convincingly that the neural differences between these different stimuli predict the occurrence of the respective associated mental states.

PH: Does that amount to an empirical hypothesis about the relationship between difference-based coding and mental states?

NS: That is what the author seems to have in mind. For instance, he postulates that difference-based coding enables and predisposes to what he calls “neuronal–mental transformation.”

PS: That has major implications for psychoanalysis. Self and objects can be characterized by mental states. If so, both self and objects should be enabled and predisposed to by the brain’s difference-based coding.

NS: Exactly. The author devoted a whole chapter to how self and objects can be constituted on the basis of the brain's difference-based coding.
