## Dissidence ou démence ?

### DISSIDENCE OU DÉMENCE?

L'ambiguïté et la variété des « cas médicaux » relatifs au politique dans les registres des asiles exigent une lecture d'autant plus circonspecte que rien ne ressemble plus à un internement arbitraire qu'un certificat psychiatrique en bonne et due forme. Cela tient, pour partie, à la sécheresse de ces procès-verbaux, expédiant à l'asile des cas souvent peu documentés, où le jugement moral, servi par un vocabulaire suranné décrivant tel « fanatique royal, plein de jactance » ou tel « républicain exalté », se distingue mal du diagnostic médical. Notre lecture contemporaine, habituée à des termes plus « neutres » et, pour tout dire, rassurants, s'accommode mal de ces jugements de valeur intempestifs.

<div style="text-align: center;"><img src="imgs/img_in_image_box_0_70_684_559.jpg" alt="Image" width="98%" /></div>

1 Villeneuve, Réception de Louis Capet aux Enfers, 1793. Déposé par la barque de Charon, Louis XVI, sa tête fraîchement coupée sous le bras, est accueilli par Charles IX, « comme lui assassin des Français », les monarques européens, et quelques aristocrates, présentant leurs têtes détachées. Cet imaginaire de la décapitation coïncide avec les délires de nombreux patients, persuadés d’avoir perdu la tête » et de vivre avec une tête de remplacement.

<div style="text-align: center;"><img src="imgs/img_in_image_box_19_78_689_538.jpg" alt="Image" width="94%" /></div>

<div style="text-align: center;">2 La guillotine instaure la mort sérialisée et dépersonnalisée. Même le roi est réduit à « une » tête parmi d'autres et une absence, comme dans ce Dialogue glaçant daté de 1793 : Je perds une tête (dit une couronne) j'en trouve une (répond la guillotine).</div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_23_662_113_955.jpg" alt="Image" width="12%" /></div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_137_658_399_1069.jpg" alt="Image" width="36%" /></div>

3 Sous la Terreur, les produits dérivés de la guillotine font florès, comme ces boucles d'oreilles en or et métal doré figurant la « faux de l'égalité », surmontée d'un bonnet phrygien, et ornée d'une tête couronnée en guise de pendeloque.

4 Inventoriée sous le titre Exécution de Marie-Antoinette (entre 1793 et 1799), cette gravure passe également pour représenter Charlotte Corday, dont la tête, sortie du panier et souffletée par l'adjoint du bourreau, aurait « rougi d'indignation ». Cet épisode, qui serait ici figuré dans le ciel, viendra alimenter le débat sur la survie de la conscience après la décapitation.

<div style="text-align: center;"><img src="imgs/img_in_image_box_84_61_605_464.jpg" alt="Image" width="74%" /></div>

5 Sous le titre Les Formes acerbes (1796), cette eau-forte de Poirier de Dunckerque représente Joseph Le Bon, qui envoya à la guillotine des centaines de suspects dans la région d’Arras. L’image offre une puissante synthèse de l’épouvante suscitée par la décapitation, la mutilation des corps et la soif de sang des « terroristes ».

<div style="text-align: center;"><img src="imgs/img_in_image_box_78_598_600_945.jpg" alt="Image" width="75%" /></div>

### fin traguor on lavili xyzN

Kevins le le Imver. typ3 En la Flair de Livon XV.

Il nomme d'auteur des criminels that si ne devra le s'en preuve dire, par le barbeur de sauppeuple, et une dériveur vau-sont que le Clé du parf淑eux est mort.

- Très populaire, cette gravure anonyme d’origine allemande, intitulée Fin tragique de Louis XVI, xécuté le 21 janvier 1793 sur la place de Louis XV, met en valeur un moment crucial dans le rituel e la guillotine : la monstration de la tête comme exhibition d’un trophée.

<div style="text-align: center;"><img src="imgs/img_in_image_box_9_66_700_548.jpg" alt="Image" width="97%" /></div>

7 Le docteur P. Pinel faisant tomber les chaînes des aliénés, de Tony Robert-Fleury (1876), situe à la Salpêtrière un événement qui se serait déroulé sur plusieurs années à Bicêtre, sous l'impulsion du surveillant Pussin. Le tableau participe à la construction d'un mythe, qui fonde la naissance de la psychiatrie française sur un acte solennel du philanthrope Pinel.

8 L'Hôpital de Bicêtre, anonyme, 1710. En 1632, Louis XIII ordonne la création d'un hôpital destiné aux militaires sur les ruines du château de Bicêtre. Le bâtiment, transformé en hospice, prison d'État et asile d'aliénés, devient le symbole du « grand renfermement ». Pinel y prend ses fonctions en 1793.

9 Vue de l'hôpital de la Salpêtrière à Paris, Pérelle, 1680. Premier des bâtiments de l'hôpital général voulu par Louis XIV en 1656, la Salpêtrière est le plus grand établissement d'enfermement d'Europe pour femmes, mendiantes, prostituées ou folles. Véritable ville dans la ville, l'hospice compte dix mille détenues à la veille de la Révolution.

10 La Salpêtrière : loges d'aliénées construites par Viel en 1789, G. C. Guillain et P. Mathieu, 1925. À la fin du xviii<sup>e</sup> siècle, l'architecte Viel est chargé de reconstruire les loges destinées aux folles furieuses ou dangereuses, situées en rez-de-chaussée. Le bâtiment n'existe plus, mais ce document exceptionnel nous le montre tel que l'a connu Pinel à son arrivée en 1795.

<div style="text-align: center;"><img src="imgs/img_in_image_box_87_64_686_309.jpg" alt="Image" width="86%" /></div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_82_323_683_705.jpg" alt="Image" width="86%" /></div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_78_716_682_1060.jpg" alt="Image" width="86%" /></div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_0_13_715_1117.jpg" alt="Image" width="99%" /></div> AUJON, Jean Pierre.

Ontré Le 29 juillet 1802.

No. 1963.

No. 20. 1963. K. Eomigra. 1989. A. F. R. S. S. S. E

1798, in fui pire, amore'. Ecei & condaurer ' n' omos. Ima l'abatt Eche sint's; & conduit oman-tad, Daboro ayo, pite maitous, pici - l'hate Dine, & de a (hauite). de

Bicited to determine fit composite. K. Cocopas, Iain, 2000, "I demand of figure geologian, I'm to be a student of the "Festiv" J. J. M. M. (1985), "I want to go on some of of I'm a man on "Festiv Day, N. of the Plan before, I. V. Vangina, I'm to turn away to

Title X, "I'm a little good, the people, go on to turn a visit, I'm a man, I'm陵墓" — I'm a place, I'm example to want if I'm young, if I'm good, and I'm different of many of the "Big" men. I

You can:

Hutier d'Démonte, l'État d'État de l'État d'État (en 1887) (A.C.)

d’affaires d’une and des diques qui a déguise longtemps, Dostes plus dépenses et en, a lo maîtré de l’état du Fee plaisir, et a venait plaisé, année dans et est, plus tard, il est xui, puis répartie, et est alors quon les appliquera les signes distingés, de mère, il fait provision de petites bourles de pain qui fait riche, les manges, et les douceurs. Houseliques et propre à assiet le dattellement, d’un pas lucree, jus abandon de la haute idée de so-fras. de brie et tient program, et le saule physique excellente Cc. II aouf142g

11 - 12 Portrait de Jean-Pierre Laujon, dessiné par G.-F.-M. Gabriel, vers 1823, et page du registre de Charenton consacrée à son cas. Émigré en 1789, arrêté à la frontière suisse en 1796, Jean-Pierre Laujon avait été condamné à mort et en avait perdu la raison. À Charenton, il est occupé par une idée fixe : « Il s'imagine qu'on lui a coupé la tête & que sa tête est en Angleterre. »

Il participera aux spectacles donnés par le marquis de Sade.

<div style="text-align: center;"><img src="imgs/img_in_image_box_0_68_173_365.jpg" alt="Image" width="24%" /></div> <div style="text-align: center;">13</div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_75_405_366.jpg" alt="Image" width="29%" /></div> <div style="text-align: center;">14</div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_432_63_659_362.jpg" alt="Image" width="31%" /></div> <div style="text-align: center;">15</div>

<div style="text-align: center;">13 à 15 «Homme incorrigible», en «état perpétuel de démence libertine», le marquis de Sade (15) représenté sur fond de Bastille en flammes dans ce Portrait imaginaire de Man Ray (1938), est incarcéré à Charenton en 1803. Il y bénéficie de la protection du tout-puissant directeur, M. de Coulmier (14), qui l'encourage à monter des spectacles dans le théâtre de l'asile. L'arrivée, en 1806, de l'austère Antoine-Athanase Royer-Collard (13), médecin imposé par le gouvernement, va mettre fin à ces « libéralités ».</div>

<div style="text-align: center;"><img src="imgs/img_in_image_box_24_656_616_1007.jpg" alt="Image" width="82%" /></div>

<div style="text-align: center;">Charenton, au temps du marquis de Sade.</div> Mais c'est oublier que la science est, à toutes les époques, idéologique — l'histoire de l'hystérie ou de l'homosexualité, hier considérée comme une dégénérescence, en donne assez l'exemple[^1]. Et il y a fort à parier que l'historien du XXIII $ ^{e} $ siècle qui lira les études actuelles sur la schizophrénie s'étonnera des travaux de nos psychiatres, dont les conclusions, si objectives et de bonne foi soient-elles, sont inévitablement orientées.

L'interprétation des archives asilaires du xix<sup>e</sup> siècle souffre par ailleurs, depuis l'avènement de l'antipsychiatrie, des invectives répétées contre l'aliénisme qui, si elles sont parfois fondées, inclinent à une systématisation décervelée. Oui, les aliénistes ont participé à un dispositif gouvernemental de contrôle, coulé dans la morale autoritaire du siècle dans lequel ils vivaient. Non, ils n'ont pas été les geôliers sadiques de tous les délinquants de la terre. Comment rendre compte de cet écart, dont la frontière est plus difficile à tracer qu'il n'y paraît? En s'attachant non pas à chercher l'hypothétique réalité de la maladie mentale (quasiment impossible à déterminer à posteriori), mais en s'évertuant à éclairer les critères d'internement et le système complexe qui les ordonne.


Dans la légende noire de Napoléon, il existerait « un mythe de l’enfermement des opposants comme fous[^2] », pour reprendre le titre d’un article de Michael Sibalis, qui a traqué aux Archives nationales les dossiers relatifs à cet épineux sujet. Sa conclusion est contenue dans le titre de son article. La police se serait, en gros, opposée le plus souvent à des internements sommaires de dissidents politiques dans les asiles publics, en les faisant injustement passer pour fous. Seules des exceptions notables, comme le cas de l'abbé Fournier, confirmeraient la règle. Le jour de la Pentecôte en 1801, l'abbé avait fait allusion à la mort de Louis XVI dans son homélie à Saint-Germain-l'Auxerrois. En marge du rapport de police, le ministre avait écrit : « Si le fait est vrai, le mettre à Bicêtre comme fou. » Sa libération de l'asile quelques semaines plus tard, sur avis médical, rendrait hommage aux aliénistes, ni dupes ni complices du pouvoir. Mais que nous disent en retour les archives médicales sur ces têtes trop occupées de politique?


Elles sont parfois manquantes. Aucun document ne figure dans les dossiers psychiatriques, par exemple, sur Théodore Desorgues, poète, auteur de l'«Hymne à l'Être suprême», interné à Charenton en 1805, pour une chanson dont le refrain disait « Oui, le grand Napoléon / Est un grand caméléon » et à qui l'on attribuait cette boutade, lancée à un serveur qui lui proposait deux parfums (orange ou citron) pour la glace qu'il avait commandée dans un café : « Je n'aime pas l'écorce [les Corses]. » Dans ses Notes historiques, le Conventionnel Baudot raconte : « Je l'ai vu quelques jours avant son arrestation ; il n'y avait pas chez lui la plus légère apparence d'aliénation mentale, mais il ne se gérait pas pour déclamer contre l'usurpateur des libertés publiques, et il lisait ses vers anticorsiques à qui voulait les entendre. Et il fallait une raison droite pour les faire[^3]. » Desorgues a-t-il été déclaré fou « ex officio imperatoris », selon l’expression de Baudot, ou son interne- ment était-il justifié par « la bizarrerie et l’incohérence[^4] , de ses propos notés par la police, qui poussèrent les médecins du bureau central d’admission à confirmer son aliénation d’esprit? Voilà qui est impossible à trancher, les deux interprétations n’étant pas forcément incompatibles, surtout si l’accusé s’est défendu trop énergiquement pour crier au scandale. À partir de quel moment et selon quels critères s’écarte-t-on d’un discours politique « raisonnable »? À partir de quel moment et selon quels critères la dissidence s’accompagne-t-elle de débordements jugés « délirants »? Les atteintes aux libertés fondamentales sous l’Empire ont assez été étudiées pour ne pas soupçonner la fraude intellectuelle du pouvoir par rapport à ces détenus dont le cas est douteux, parmi lesquels on peut compter un ancien chirurgien de la marine, Victor Mariette, dit Wright, entré à Charenton le 12 mars 1806 :

Depuis 7 ans, rêveries métaphysiques et philosophiques sur la science, la politique, la morale, la religion, ayant voyagé aux États-Unis, propos contre Napoléon qu'il a appelé l'ante-christ, est en prison depuis 4 ans pour cela. Auteur d'un ouvrage de politique et de législation intitulé : Traité analytique de l'homme. [...] Pas d'agitation, air rêveur et préoccupé, manie de ne vouloir pas être appelé Mariette, son propre nom, mais Wright, nom qu'il a adopté. Taciturnité. L'été de 1806 il eut de l'insomnie, agitation secrète, mouvement nerveux, augmentation de la mélancolie. L'automne l'a fait revenir à son état antérieur dont il n'est pas sorti jusqu'à sa sortie[^5].

De quoi souffre cet homme, coupable de « rêveries » ou de « taciturnité » et dont la seule « manie » est de vouloir user d'un pseudonyme suggérant, du moins phonétiquement, sa conviction d'avoir raison et d'être dans son droit? Que sépare l'internement médical de l'emprisonnement pour propos contre l'empereur, dont le rappel historique se confond avec le commentaire étiologique ? Comment interpréter sa date de sortie (23 septembre 1815), « dans le même état qu'à son entrée », précise le médecin, sinon comme une libération politique, lorsque l'on sait que Napoléon a pris la route de Sainte-Hélène en août ? En tout, Victor « Wright », dont l'aliéniste s'abstient (ou refuse ?) de commenter la « mélancolie » sinon par des remarques extramédicales, aura passé treize ans enfermé, dont neuf à Charenton.


Le 14 février 1810, un autre personnage, lui aussi atteint de « rêveries » suspectes, rejoint Wright à Charenton. Il s'agit du fameux Jacob Dupont, qui prêcha l'athéisme au cours d'une discussion sur l'éducation à l'Assemblée, où il déclara fièrement, le 14 décembre 1792: « Je l'avouerai de bonne foi à la Convention, je suis athée[^6] » — à quoi Robespierre aurait répondu : « L'athéisme est aristocratique. »


Ancien doctrinaire, ancien député à l’assemblée législative et à la convention ; retiré dans un petit village près de Loches, il y est depuis 8 ans avec une sœur qui est morte depuis 6 mois. Réveries métaphysiques et révolutionnaires, fameuse proposition d’athéisme à la convention ; cours sur ce sujet fait publiquement sur la place Louis XV il y a 7 [ou 9?] ans. Beaucoup d’écrits pleins des mêmes folies. Point de violence, pas de délire sur les autres objets[^7].


C'est écrit en toutes lettres : l'athéisme est une folie. L'assertion, en soi, n'est pas surprenante, dans une société qui partage largement l'opinion de Louis Sébastien Mercier, pour qui l'athéisme était la « somme totale de toutes les monstruosités de l'esprit humain », « une manie destruc- tive [...] qui avoisine beaucoup la démence 34 ». Mais, cette fois, le jugement est un diagnostic, sous la plume d'un aliéniste qui, même s'il emploie le mot de « folies » au sens trivial, reconnaît que Jacob Dupont ne « délire [pas] sur les autres objets ». Le point est capital. Car il prouve, noir sur blanc, que des convictions philosophiques constituent la condition suffisante pour justifier l'internement. Le cas est d'autant plus remarquable que l'aliéniste, le docteur Royer-Collard dont on aura l'occasion de reparler, ignorait sans doute que Jacob Dupont avait été forcé à la démission de l'Assemblée en 1794 à cause de son état mental et avait été arrêté l'année suivante pour avoir violé une vieille femme aveugle[^8]. Les eût-il connus, ces éléments n'auraient fait, bien sûr, qu'aggraver un diagnostic dont la particularité est d'être uniquement fondé sur la dimension subversive d'un athéisme revendiqué. Les eût-il mentionnés sur le registre, que le cas de Jacob Dupont serait à classer parmi ces affaires ambiguës dont les archives sont noircies, quand il révèle là, dans sa franchise nue, non pas la santé psychique — impossible à prouver — d'un homme injustement envoyé à l'asile, mais, beaucoup plus déterminant, l'arbitraire assumé des critères de détention.


Tous les athées ne finissent pas à Charenton. À côté des mécréants, bon nombre d’internés atteints de «monomanies religieuses», d’une validité scientifique a priori tout aussi équivoque, grossissent les statistiques de la folie. À Bicêtre, le médecin-chef se plaint à la commission chargée des hospices de la présence des chapelains, dont les idées religieuses porteraient à son comble le désordre dans l’esprit des aliénés, et demande en conséquence leur éloignement. « La religion, écrit-il, a été reconnue par tous les médecins et par toutes les personnes qui ont l’habitude de voir des aliénés comme une des causes les plus fréquentes de la folie. » Un employé aurait remarqué qu’après chaque visite du chapelain un patient, ancien instituteur, tombe dans un accès d’épilepsie suivi de fureur pendant quinze jours. « Parmi les différentes sortes d’aliénation mentale, celle qui dépend de la religion a toujours paru la plus difficile à guérir, celle qui porte davantage à la fureur et à la cruauté. J’ai vu à l’hospice de Bicêtre un fou qui avait tué sa femme parce qu’elle s’était rendue trop tard à la messe[^9].»


À la Salpêtrière, Pinel, se fondant sur ses notes journalières, dresse un constat tout aussi alarmant. Les femmes indigentes, venues en dernier recours demander charité à leur paroisse, sont les premières victimes des ecclésiastiques qui, la Révolution passée, leur reprochent de s'être confessées auprès d'un prêtre asserné, d'avoir divorcié ou baptisé civilement leurs enfants. En leur refusant les secours de l'Église et en leur promettant les flammes éternelles, ils les précipitent dans une folie souvent incurable, nourrie d'hallucinations et de visions infernales. Pinel affirme même pouvoir « indiquer les quartiers de Paris où prédomine cette dévotion atrabilaire, tandis que dans d'autres une piété compatissante et éclairée a suspendu quelquefois le développement d'une aliénation prête à se déclarer [...] 37.

Dans tous les cas, ce que les aliénistes pointent d'un doigt accusateur, ce sont les prosélytes. En ce sens, la psychiatrie s'affirme comme une discipline moderne, soucieuse de se démarquer d'une religion qui a eu longtemps le monopole de la folie, mais qui a aussi condamné au bûcher la sorcière et l'héritique dont elle avait fabriqué de toutes pièces l'existence. Le sentiment religieux ne serait pas une folie en soi, puisqu'une « piété  compatissante ◦ peut au contraire calmer les esprits et les ramener sur le droit chemin. Le zèle fanatique et la propagande mystique, voilà ce qui, à l'aube du XIX<sup>e</sup> siècle, doit en revanche être séparé d'une science positive, rationnelle, et résolue à triompher de l'obscurantisme.

L'athéisme présente un danger tout autre, car la folie lui est consubstantielle : « L'insensé dit en son cœur : Il n'y a point de Dieu $ ^{38} $!», est-il écrit dans le Livre des Psaumes. Au Moyen Âge, l’athée, l’impie, est assimilé au fou. Mais, depuis la Déclaration des droits de l’homme, la France a entériné la liberté d’opinion religieuse à condition, toute-fois, qu’elle ne trouble pas l’ordre public. Le cas de Jacob Dupont est assez clair à cet égard : c’est pour avoir parlé, écrit et proféré l’athéisme dans l’espace public que le fau- teur de trouble est considéré comme aliéné, envoyé à Charenton. Charenton où, à la même époque, languit le plus illustres des « prisonniers » de cette institution et le plus athée des philosophes, le marquis de Sade.

### Ë cet homme nGest pas aliénéÛ Z sade à charenton

Sade, ce prisonnier que tout le monde réclame et dont aucune forteresse ne veut. Saumur, Pierre-Scise, Forl'Evêque, Miolans, Vincennes, la Bastille, Charenton, les Madelonnettes, les Carmes, Saint-Lazare, Picpus, Sainte-Pélagie, Bicêtre : Sade l'encombrant, qui embarrasse tous les régimes politiques, aura connu la plupart des grandes maisons de détention du royaume, de la République et de l'Empire. Plaintiffs, lettres de cachet ou ordres de police, on l'arrête, on le séquestre, on le transfère de prison en asile; jusqu'à ces geôliers, honteux d'abriter un homme aussi infâme, personne ne veut d'un pareil scélérat, en état d'insubordination permanente. « Littéralement et dans[^2]

### NOTES

[^1]: 1. Sur cette question des rapports entre l'idéologie et la science, je ne connais pas de meilleur livre que celui d'Anne Fausto-Sterling, Sexing the Body: Gender Politics and the Construction of Sexuality, New York, Basic Books, 2000.
[^2]: 2. Michael Sibalis, « Un aspect de la légende noire de Napoléon : le mythe de l'enfermement des opposants comme fous », Revue de l'Institut Napoléon, vol. I, n° 156, 1991, p. 9-24.
[^3]: 3. Marc-Antoine Baudot, Notes historiques sur la Convention nationale, le Directoire, l'Empire et l'exil des votants, publié sous les auspices du ministère de l'Instruction publique, Imprimerie D. Jouaust, 1893, p. 62-64. Voir également Michel Vovelle, « Notes complémentaires sur le poète Théodore Desorgues ou Quand les inconnus se font connaître », Annales historiques de la Révolution française, n° 265, 1986, p. 341-345.
[^4]: 4. Michael Sibalis, «L'enfermement de Théodore Desorgues: documents inédits», Annales historiques de la Révolution française, n° 284, 1991, p. 243-246. Je remercie Gisèle Sapiro de m'avoir indiqué cet article.
[^5]: 5. ADVDM, Charenton, Registre d'observations, hommes et femmes, 1799-1814, 4X681 (registre non folioté).
[^6]: 6. Gazette nationale ou Le Moniteur universel, n° 351, dimanche 16 décembre 1792, p. 744.
[^7]: 7. ADVDM, Charenton, Registre d'observations, hommes et femmes, 1799-1814, 4X681.
[^8]: 8. Auguste Kuscinski, Dictionnaire des Conventionnels, Société de l'histoire de la Révolution française, F. Rieder, 1916.
[^9]: 9. AN, F¹⁵, 2604-2605. Copie d’une lettre du docteur Lanefranque à M. Desportes, membre de la commission chargée des hospices, Bicêtre, 23 septembre 1807.
