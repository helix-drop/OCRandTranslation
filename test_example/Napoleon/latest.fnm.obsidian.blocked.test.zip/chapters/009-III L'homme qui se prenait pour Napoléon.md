## III. L'homme qui se prenait pour Napoléon

### Ⅲ

### L'homme qui se prenait pour Napoléon

Dans sa grande enquête sur Paris ou Les Sciences, les institutions et les mœurs au XIXe siècle, Alphonse Esquiros signalait, au détour d’une page, une conséquence inattendue du retour des cendres de Napoléon, le 15 décembre 1840 : « L’année où l’on ramena à Paris le cercueil de Napoléon, le docteur Voisin constata à Bicêtre l’entrée de treize à quatorze empereurs. [...] Cette présence de Napoléon parmi nous, les images, les signes extérieurs dont on entoura sa mémoire et qui semblaient pour ainsi dire multiplier sa figure, tout contribua à créer dans cet événement une cause particulière d’aliénation mentale[^1]. »

L'image du monomane coiffé d'un bicorne, la main dans sa redingote grise et le regard braqué sur un horizon de gloire, n'est-elle pas, encore de nos jours, associée à une phrase qui, au fond, n'est jamais interrogée : Tous les fous se prennent pour Napoléon ? Proverbiale, cette allégation a-t-elle pour autant un fondement historique ? L'empereur cristallise-t-il un délire particulier dans les archives des asiles, où les monarques se disputent la place des prophètes, où Jésus-Christ, Mahomet et Louis XVI suscitent déjà de multiples candidatures ? Si oui, en quoi et pour-quoi le personnage de Napoléon se prêterait-il plus volontiers à la mégalomanie que la figure de Charlemagne ou de Louis XIV ?

Sous ces questions, c'est en réalité un plus vaste débat qui se dessine autour des problèmes d'identité et de subjectivité, d'usurpation et de projection, dans les rapports de la folie à l'Histoire, entre être et s'imaginer être, se croire, prétendre à et se prendre pour. Si bien que l'interrogation ne serait pas tant le classique qui suis-je ? mais plutôt : suis-je bien celui pour qui je me prends ? — une question à laquelle Napoléon Bonaparte lui-même, ou plutôt Bonaparte et Napoléon, mérite d'être soumis. Mais avant d'atteindre ces régions, force est de comprendre comment la psychiatrie du XIXe siècle regarde et analyse la folie des grandeurs, qui pourrait bien détrôner la mélancolie au titre de mal<sup>5</sup> du siècle.

### la monomanie orgueilleuse ou le mal du siècle

Avatar de l'hybris (ou ubris) grecque, cette propension des hommes à défier les dieux, synonyme de démesure, la folie qui consiste à se prendre pour un grand personnage correspond au XIXe siècle à une maladie spécifique, la monomanie dite « orgueilleuse » ou « ambitieuse ». « Carac-

### NOTES

[^1]: 1. Alphonse Esquiros, Paris ou Les Sciences, les institutions et les mœurs au XIX $ ^{e} $ siècle, t. II, Au comptoir des imprimeurs unis, 1847, p. 118.
