## Liste des illustrations

Liste des illustrations

1. Fin tragique de Louis XVI, exécuté le 21 janvier 1793 sur la place de Louis XV, anonyme. Gravure. Paris, musée Carnavalet. © Musée Carnavalet / Roger-Violet

2. Dialogue : je perds une tête (dit une couronne) j'en trouve une (répond la guillotine) [exécution de Louis XVI, 21 janvier 1793], anonyme, 1793. Gravure à l'eau-forte coloriée, 11,2 cm × 16,2 cm. Bibliothèque nationale de France, Paris. © BnF

3. Boucles d'oreilles avec guillotine, époque révolutionnaire. Or et métal doré; 5,7 cm. Musée Carnavalet, Paris. © Michel Tournazet / Musée Carnavalet / Roger-Violet

4. Exécution de Marie Antoinette, anonyme, entre 1793 et 1799.

Eau-forte, 13,5 × 8,5 cm. Bibliothèque nationale de France, Paris. © BnF

5. Les Formes acerbes, Poirier de Dunckerque, 1796. Eau-forte coloriée, 34 cm × 38 cm. Bibliothèque nationale de France, Paris. © BnF

6. Réception de Louis Capet aux Enfers. [Exécution de Louis XVI, 21 janvier 1793], Villeneuve, 1793. Gravure à l'aquatinte, écusson au pointillé, 26,8 cm × 36,7 cm. Musée Carnavalet, Paris. © BnF

7. Le docteur P. Pinel faisant tomber les chaînes des aliénés, Tony

Robert-Fleury (1838-1911), 1876. Huile sur toile, 1876. Hôpital de la Salpêtrière, Paris. © RMN / Agence Bulloz

8. L'Hôpital de Bicêtre, gravure en couleurs, 1710. Bibliothèque nationale de France, Paris. © Archives Charmet / The Bridgeman Art Library

9. Planche 31 : Vue de l'hôpital[^31] de la Salpêtrière à Paris, Pérelle, gravure 1680. Gravure, 20 cm × 29 cm. Château de Versailles. © RMN[^32][^29] (Château de Versailles) / Gérard Blot

### NOTES

[^29]: 29. Faim, folie, crime, Antoine Wiertz, 1853-1854. Huile sur toile. Bruxelles, musées royaux des Beaux-Arts de Belgique, musée Antoine Wiertz, Inv.
[^31]: 31. Hydrothérapie. Hôpital Sainte-Anne. Paris. Jules Gaildreau,
[^32]: 32. La salle de bains du nouvel asile d'aliénés Sainte-Anne. Paris XIVe arrondissement, 1869. Gravure. © Roger-Viollet
