## Index

Index
ABRANTÈS, Laure Junot (duchesse

d’): 123. ADÉLAIDE DE FRANCE (dite Madame Adélaïde, tante de

Louis XVI) : 60. AGOULT, Marie Catherine Sophie de Flavigny (comtesse d’):

270, 272.

alexandre iii de macédoine
(roi de Macédoine, dit le

Grand): 216, 219.

Allix,Jules:329,330.

anastasia nikolaíevna de rusM

SIE: 185. ANGOULÈME, Marie-Thérèse de France (duchesse d’): 167, 186.

ANNE (sainte):301,302.

ANTOMMARCHI, Francesco (Dr) : 206, 208.

ARISTOTE: 203.

ARNOULD, Arthur: 330.

ARSÈNE (Mille, actrice): 108, 109. AUGUSTE (Octave, puis Octavien, puis, empereur romain) : 217. AUMALE, Henri d'Orléans (duc d’): 182, 253.

BABICK, Jules-Nicolas-André : 329. BAILLARGER, Jules Gabriel François (Dr) : 247, 248, 254. BALZAC, Honoré de: 15, 165, 174, 201.

BARBAROUX, Charles Jean Marie :

86. BARBÈS, Armand : 262, 265, 268, 270.

Bascans (Mme):124.

Bascans, Ferdinand: 124, 125. BAUDOT, Marc-Antoine : 130, 131.

BAUME (M., Dr): 326. BAYLE, Antoine Laurent Jessé

hD²iz qwpl qwqn

BEAUJEU,Maurice (Dr):214.

Beethoven, Ludwig van: 217. BELHOMME, Jacques: 59-61, 72, 111, 113-117, 119, 120, 125, 143, 246.

BELHOMME, Jacques-Étienne

hD²i z rtvl rtwl rtyl ruqn

BERADT, Charlotte : 14. BERGERET, Louis (Dr) : 259-261, 269.

BERTHIER, Pierre (Dr):294. BERTIER DE SAUVIGNY, BénigneLouis : 120, 121. BERTIER DE SAUVIGNY, Ferdinand : 120. BERTIER DE SAUVIGNY, Louis

Bénigne François : 120.

Billard, Max (Dr): 123.

BISMARCK, Otto (prince von):

295, 316.

BLANC, Louis Jean Joseph: 258, 260, 265. BLANQUI, Louis Auguste (dit l'Enfermé) : 265, 267, 268, 270, 304, 331.

BLEYNIE (M., Dr): 156.

BONNAFÉ, Lucien (Dr) : 336. BORDEAUX, Henri d'Artois (duc de, puis comte de Chambord) :

190.

BORGIA (les):211.

BOUCHEREAU, Louis Gustave (Dr) : 308, 309. BOUCHET, Jacques (Dr) : 278, 279.

BOURBONS h¬¥³i z qpul qrpl qxql rvun

BOURGES, Jacques (père) : 70. BOURRIENNE, Louis Antoine Fauvelet de : 212.

BOYER, Eusèbe (frère): 138.

Boze,Joseph:50. BRETEUIL, Louis Charles Auguste Le Tonnelier (baron de, et de

Preuilly) : 59. BRETEUIL (Mme de, dite Tonnelier): 115. BRIERRE [BRIÈRE] DE BOISMONT, Alexandre-Jacques-François (Dr) : 23, 210, 242, 249-252, 275-281, 319, 324, 325, 328.

Briquet, Paul: 272. BRISSOT, Jacques Pierre (dit de

Warville) : 226. BROUSSAIS, François-Joseph-Victor (Dr) : 169.

BRUNEAU,Mathurin:184,186.

BRUNET (M., Dr):113.

Burke, Edmund: 221.

Buzot, François Nicolas Léonard: 86. CABANÈS, Augustin (Dr): 213, 230.

CABANIS, Pierre-Jean-Georges (Dr) : 51, 53, 54, 57.

CABET, Étienne : 277, 278.

CADOUDAL,Georges:118,121.

CALAS, Jean : 70.

CALIGULA (empereur romain):

206.

CALMEIL, Louis-Florentin (Dr) : 171.

CAMUS (Mme):102.

CARRA, Pierre : 201, 202.

CARTWRIGHT, Samuel A. (Dr) :

16.

CARUTH, Cathy: 15.

CASTEL,Robert:23,58.

CAVAIGNAC, Louis Eugène (général) : 270, 292, 328.

CERVANTÈS, Miguel de : 30.

CHAPIRON (Mme): 195, 196. CHAPRON (M., secrétaire de

Coulmier): 154-156.

CHAPRON (Mme): 155.

CHARCOT, Jean-Martin (Dr): 68.

CHARLEMAGNE (roi des Francs):

164. CHARLES QUINT (empereur du

Saint-Empire romain germanique) : 212.

CHARLES IX (roi de France): 206. CHARLES X (comte d'Artois, puis roi de France): 120, 124, 243. CHATEAUBRIAND, François-René (vicomte de) : 48, 120, 174, 183, 221.

CHEVALIER, Louis : 281.

CHEVRIER, Alain : 274.

christophe HmileIZQUUN

CLAVIÈRE, Étienne : 86. COIGNARD, Eugène : 93, 113, 115. COLLINS, Hippolyte de : 142, 144, 145, 159.

Colombier,Jean (Dr):59. CONDÉ, Louis V Joseph (prince

DE BOURBON-): 103. CONDORCET, Marie Jean Antoine Nicolas de Caritat (marquis de): 61, 86, 127. CONSTANT DE REBECQUE, Benjamin: 201, 212. CONTAT, Louise-Jeanne-Françoise (actrice) : 49. CORDAY, Charlotte (Marie-AnneCharlotte de Corday d'Armont, dite): 54, 55, 107.

Corre(M.,Dr):212. CORTÈS, Juan Donoso (1er marquis de Valdegamas): 275.

COULMIER [COULMIERS], François Simonnet de: 137, 139-146, 148, 150-160.

Courbet, Gustave: 269.

COURNAND, Émilie : 155.

CULLEN, William (Dr): 61. CUVIER, Georges (Jean Léopold

Nicolas Frédéric Cuvier, dit) :

204.

dagonnet {dagonet}L henri HdrI Z SPWL SPXN

DAMIENS, Robert François : 47.

DANTON, Georges Jacques : 108. DAQUIN, Joseph (Dr): 98, 99, 159.

DAUMIER, Honoré : 124.

DAVID, Jacques-Louis : 200.

Davoine, Françoise : 15. DEBOUTEVILLE (Mme, mère du suivant) : 23. DEBOUTEVILLE, Lucien (Dr) : 22, 23.

DELACROIX, Eugène : 317. DELAVAU, Guy Louis Jean Baptiste : 120.

DELESCLUZE, Charles : 329.

DELEUZE, Gilles : 15.

DEROIN, Jeanne: 255.

DERRIDA,Jacques:31,32.

DESCARTES, René: 30.

Desmoulins, Camille : 49.

DESORGUES, Théodore: 130, 131.

DESPINE, Prosper (Dr): 326, 327.

Diderot, Denis : 203.

Dostoïevski, Fiodor Mikhaïlovitch: 212.

DOUBLET,François (Dr):59. DU BARRY, Jeanne Bécu (comtesse): 108, 109.

DU CAMP, Maxime: 318, 328-330.

DU CAMP, Théodore-Joseph (Dr) :

328.

DUBOIS, Louis-Nicolas : 120, 137.

DUBOIS, Paul-François : 124. Dubuisson, Claude-Henri Jacquelin (Dr) : 121. DUBUISSON, Jean-Baptiste-Rémy Jacquelin (Dr, neveu du précédent) : 123, 126.

DUCHEMIN (M., Dr): 215. DUFAURE, Jules-Armand-Stanislas: 331.

Dumas fils, Alexandre : 317. Dumas, Alexandre : 24, 107, 109, 256.

DUMOUSTIER hMniz quul quvn

DUPONT (Mille, sœur du suivant) :

133.

DUPONTl J¡£¯¢ z qsrmqstl qsvl qtyl rrtn

DUVEYRIER, Charles : 165.

ENGELS, Friedrich: 278.

Escourbiac,Adrien-Jean:113.

ESQUIROL, François-Antoine (frère du suivant) : 226, 227.

ESQUIROL, Jean-Étienne-Dominique (Dr) : 14, 16, 22, 23, 92, 119, 145, 146, 159, 165, 167, 178, 226-242, 244, 245, 248, 252, 278, 285, 286, 310, 325, 334, 338.

ESQUIROL (M., père du précédent) : 226. Esquiros, Henri-FrançoisAlphonse: 163

EUDES, Émile : 329. EUGÉNIE DE MONTIJO (impératrice des Français) : 289, 320.

EYMARD, Sylvain (Dr): 246.

FANON, Frantz: 15.

FERRÉ, Théophile : 329. FERRUS, Guillaume-Marie-André

hD²i z qsl qxyl rtwl rwyn

Flore (Mile, actrice): 103.

FLAUBERT, Gustave:212.

FLOURENS, Gustave (général) :

312, 313.

Foucault, Michel: 26, 29, 31-33. Fouché, Joseph (duc d'Otrante, comte) : 117, 120, 146, 149152, 156. FOUQUIER-TINVILLE (Antoine Quentin Fouquier de Tinville, dit) : 116, 117. FOURIER, François Marie

rha¡le¢i adb[ add[ ae_[ ag_]

Fournier (abbé): 130.

Foville,Achille:23. FREUD, Sigmund: 15, 222, 273, 298, 339. GABRIEL, Georges-Marie-François : 233.

GAILLION hMn ¤¥izqtrlqtslqtyn

GALL, Franz Joseph (Dr): 204-209.

GALVANI, Luigi (Dr): 53.

GASTALDY, Jean-Baptiste Joseph :

qsxl qtvl qurl quxn

GAUBERT,Henri:124.

GAUCHET, Marcel: 139.

GAUDILLÈRE, Jean-Max: 15.

GAY, Jeanne-Désirée (née Véret) :

255.

GEOFFROY, Louis (Louis-Napoléon Geoffroy-Château, dit) :

194.

GEORGET, Étienne (Dr) : 233. GÉRARD, François Pascal Simon

(baron): 206.

GÉRICAULT, Théodore : 233.

GiDE, André : 24. GILL, André (Louis-Alexandre Gosset de Guines, dit): 330, 331. Girard de Cailleux, Jacques

Henri (Dr) : 287.

GIRAUDY (M.):158.

Godineau, Dominique: 85.

GOLDSTEIN, Jan : 21.

Goncourt, Edmond Huot de :

317-318.

GOUGES, Marie-Olympe de (Marie Gouze, dite): 212, 226, 229.

Grêslon, Amédée Germain : 9. GRIESINGER, Wilhelm (Dr) : 251, 252.

GRODDECK, Carl Theodor: 273-276, 280.

GRODDECK, Walter Georg (Dr) : 273.

GUATTARI, Félix : 15.

Guidal, Joseph (général) : 121.

GUILLOTIN, Joseph-Ignace (Dr) : 51, 52, 54, 56, 57, 61.

HANOWERTH, Fanny: 153, 154. HAUSSMANN, Georges Eugène

(baron): 282. HEGEL, Georg Wilhelm Friedrich: 73, 197. HELVÉTITUS, Anne-Catherine (née de Ligniville d'Autricourt) : 57.

HENRI IV (roi de France): 263.

HERVAGAULT, Jean : 184. HOFFMANN, Ernst Theodor Amadeus: 108, 109.

Huber, Aloysius : 265.

HUGO, Victor: 26, 39, 50, 79, 93, 106, 174, 179, 184, 260, 264, 265.

Huschke, Emil (Dr): 321.

IONESCO, Eugène : 271.

Jacoby, Paul (Dr): 240.

JANIN, Jules : 106.

JEANNE D'ARC (sainte) : 302, 303, 315.

Jésus-Christ: 164. JOINVILLE, François d'Orléans

(prince de) : 182, 192, 196.

Joséphine de Beauharnais (Marie-Joséphe-Rose de Tascher de La Pagerie, dite, impératrice des Français et reine d'Italie) : 191, 200, 205, 206.

JULES CÉSAR (général et homme politique romain) : 212, 214, 215.

KAFKA, Franz: 15.

KANT, Emmanuel: 73. LABORDE, Jean-Baptiste Vincent

hD²i z srul srvn

LACAMBE, Cyrille (Dr) : 268. LACAN, Jacques-Marie Émile

hD²iz qul rqxl ssyn

LACASSAGNE, Alexandre (Dr) :

212.

LACOMBE, Claire (actrice, dite Rose): 229. LAFAYETTE, Marie-Joseph Paul Yves Roch Gilbert du Motier

(marquis de) : 180.

LAFON (abbé): 121, 123.

LAHORIE [LA HORIE], Victor-Claude-Alexandre Fanneau de (général) : 121.

LAMARQUE, Jean-Maximilien (général, comte) : 125. LAMARTINE, Alphonse Marie Louis de Prat de: 54, 258, 270. LAMBALLE, Marie-Thérèse Louise de Savoie-Carignan (princesse de) : 87. LAMENNAIS, Hugues-Félicité

Robert de : 253.

LANEFRANQUE, Jean Baptiste Pascal (Dr) : 134, 139.

LAROUSSE, Pierre : 216, 217. LAS CASES, Emmanuel (comte de): 218.

LASÈGUE, Ernest Charles (Dr):

qpul rxwl ryrn

LAUJON, Jean-Pierre : 103-105.

LAUJON, Pierre (chansonnier) :

103. LAUNAY, Bernard-René Jordan

(marquis de) : 65.

Laurent (M., Dr): 212. LEBAS [LE BAS], Philippe-François-Joseph: 86.

LEBLOND (M., Dr) : 187.

LEBLOND (M., père du précédent): 187.

LECLERC, Magdeleine: 152, 153.

LECOINTRE-PUYRAVEAU, Michel-Mathieu : 87. LEGRAND DU SAULLE, Henri

(Dr) : 303.

LÉLUT, Louis-Francisque (Dr) :

209.

LÉOPOLD II (empereur d'Autriche) : 225.

LE PLAY, Frédéric : 283.

LEROUX, Pierre : 253. LEURET, François (Dr) : 43, 173, 190, 219.

Lidsky, Paul: 328.

Lissaragay, Prosper-Olivier :

317.

LOMBROSO, Cesare (Dr): 211, 212.

Louis XI (roi de France): 203. Louis XIV (roi de France): 30, 47, 164.

LOUIS XVI (roi de France): 45-49, 52, 56, 57, 59, 60, 65, 71,

72, 74, 94, 95, 105, 108, 111, 130, 164, 168, 169, 183, 197. Louis XVIII (comte de Provence, puis roi de France): 22, 184.

Louis, Antoine (Dr): 52, 57. LOUIS-CHARLES DE FRANCE (duc de Normandie, puis dauphin de France, puis prince royal, dit

Louis XVII) : 65, 183-186.

louis napoléon bonaparte

(prince impérial) : 320. LOUIS-PHILIPPE Ier (roi des Français): 17, 124, 178-182, 187, 192, 198, 245, 257.

Lucas, Prosper (Dr): 287, 302, 307, 308.

LUNIER, Ludger (Dr):309,326.

LUTHER, Martin : 212.

MAGNAN, Valentin (Dr): 41, 300, 302, 307-309.

Маномет: 164, 219. MAINE DE BIRAN, Pierre (Marie François Pierre Gontier de

Biran, dit) : 149.

MALATESTA (les): 211.

MALEBRANCHE, Nicolas: 218. MALET, Claude-François (général d'Empire) : 121-124, 126.

MARAT,Jean-Paul:87,214,226. MARIE-AMÉLIE DE BOURBONSICILES (duchesse d'Orléans, puis reine des Français): 180, 190. MARIE-ANTOINETTE (reine de

France): 65, 229. MARIE-LOUISE D'AUTRICHE (impératrice des Français, puis duchesse de Parme, Plaisance et Guastalla) : 191.

MARIETTE, Victor (dit Wright):

131, 132. MARIVAUX, Pierre Carlet de

Chamblain de : 144.

}a¢¨\{a¢ljafa\aig\bgg\cbc^

MAUPASSANT, Guy de:24.

MAURRAS, Charles: 19.

MAUSELIÈRE (colonel de la) : 195.

MEILLET, Léo: 329. MERCIER, Louis Sébastien : 48, 79, 92, 133, 144.

Michaux,Henri:11.

MICHEL, Louise : 314, 317.

}ysxu|uT\ z¥le£ j be\ bf\ dc\ bae\ c`b^

MICHELET (M., père du précédent): 215.

MILIÈRE, Jean-Baptiste : 329. MIRABEAU, Honoré-Gabriel

Riquetti (comte de) : 219. MIRTIVIÉ, Jean-Étienne Frumance

(Dr) : 286, 287. MOLIÈRE (Jean-Baptiste Poquelin, dit) : 144.

MONTAIGNE, Michel Eyquem de :

203. MONTESQUIEU, Charles-Louis de Secondat (baron de La Brède et de) : 61.

Montfort (Mille):155. MONTMORENCY-LAVAL, Mathieu

Jean Félicité (duc de) : 120. MONTPENSIER, Antoine d'Orléans

(duc de) : 182. MOREAU DE TOURS, JacquesJoseph (Dr) : 210, 262, 339.

MOREL, Benedict-Augustin (Dr) :

rtxl ryyl srqmsrtl srwn

MURAT, Joachim (maréchal d'Empire, grand-duc de Berg et de Clèves, puis roi de Naples) : 190.

Musset, Alfred de: 172.

NAPOLÉON Ier (Napoléon Bonaparte, dit, général, premier consul, puis empereur des Français): 13, 14, 17, 18, 105, 118, 121, 122, 129-132, 151, 152, 163, 164, 170, 173, 174, 182-186, 188-219, 237, 335. NAPOLÉON II (prince impérial, roi de Rome, puis prince de Parme, puis duc de Reichstadt) : 122, 185, 191, 199. NAPOLÉON III (Louis-Napoléon Bonaparte, empereur des Français sous le nom de): 182, 192, 197-199, 290-293, 320.

NAUNDORFF, Karl-Wilhelm : 184. NEMOURS, Louis d'Orléans (duc de): 182.

NÉRON (empereur romain) : 206. NERVAL, Gérard de (Gérard

Labrunie, dit) : 176-178.

NiboYET, Eugénie: 255.

NIETZSCHE, Friedrich Wilhelm :

211.

NODIER, Charles: 106.

OELSNER, Conrad Engelbert : 54.

ORLÉANS (les) : 23, 181. ORLÉANS, Clémentine (princesse d', puis duchesse de SaxeCobourg-Kohary): 182. ORLÉANS, Ferdinand-Philippe (duc de Chartres, puis prince royal et duc d’): 182.

ORLÉANS, Louise (princesse d'

puis reine des Belges) : 182.

ORLÉANS, Louise Marie Adélaïde de Bourbon (dite Mademoiselle d'Ivry, puis de Penthièvre, duchesse de Chartres, puis d’): 117. ORLÉANS, Marie (princesse d', dite Mademoiselle de Beaujolais, puis duchesse de Wurtemberg) : 182.

ORWELL, George (Eric Arthur Blair, dit): 15.

OURY, Jean (Dr): 337.

PARDIGON, François: 271.

PARISET, Étienne (Dr) : 22.

PASCAL, Blaise : 209.

PASQUIER, Étienne-Denis : 122.

PAUL (SAINT): 212.

Peisse, Louis : 209.

Pelletier (M.):115. PENTHIÈVRE, Charles d'Orléans

(duc de) : 182.

pétion de villeneuveL jérôme Z

86. PHILIPPE-ÉGALITÉ (Louis Philippe Joseph d'Orléans, duc de

Chartres, puis d'Orléans, dit) :

117.

PHILIPPON, Charles: 124.

РНОЕНИХ, Joaquin : 140.

PIE VII (pape): 200, 237.

PíE IX (pape): 199.

PINDY, Jean-Louis : 329.

PINEL, Casimir (Dr): 124-126.

PINEL, Louis: 56, 71.

Py~u|\ Phili  e Xt¢Yj ag\ bb\ cd]cf\ d`\ ef\ eg\ ei]fd\ ff]gd\ gf]gi\ ha\ hc\ hh]ia\ id]ii\ a`a\ aaa\ aac\ aad\ abd\ abf]abh\ ace\ aci\ ade\ adf\ aeh]af`\ afh\ b`b]b`d\ bbf\ bbg\ be`\ bgi\ cci^ PO|yw~qs\ q¢mand z¥le£ }a¢ie

Héraclius (2° duc de) : 121. POLIGNAC, Jules Auguste Armand

Marie (prince, puis duc de) :

QRPL QRQN prince impérialZ voir louis napol

LÉON BONAPARTE.

PROUDHON, Pierre-Joseph: 265.

Proust, Marcel: 24. PUSSIN, Jean-Baptiste : 78, 81, 84, 100, 127, 128, 168, 250.

Pussin, Marguerite Jubline: 168.

Pyat, Félix: 329.

QUESNET, Marie-Constance (actrice) : 141, 147.

Rq}O~\ |^ z^ Xt¢Yj aeb\ aec^

RANVIER, Gabriel: 329. RAPP, Jean (comte, général d'Empire): 210. RASPAIL, François-Vincent : 265, 331.

RAVAILAC, François : 206.

REAGAN, Ronald Wilson: 337.

RENOUVIER, Charles : 194.

RICHARD Ier D'ANGLETERRE (roi d'Angleterre, duc de Normandie, duc d'Aquitaine, comte de Poitiers, comte du Maine et comte d'Anjou, dit Cœur de Lion): 206.

RICHARD, David (Dr) : 205, 208, 209.

richebracques Hmme reboulMIZ

121. RICHEMONT, Claude Perrin (ou

Henri Hébert, dit baron de):

184.

RIGAULT, Raoul:329. RIVET (Mme, née Brierre de Boismont) : 319. ROBESPIERRE, Augustin Bon Joseph de (dit le Jeune): 86, 132. ROBESPIERRE, Maximilien Marie

Isidore de : 51, 52, 56, 75, 91. ROLAND DE LA PLATIÈRE, Jean

Marie (vicomte) : 86.

ROLAND DE LA PLATIÈRE, Manon (ou Jeanne Marie, ou Manon Phlipon, vicomtesse, dite Madame) : 226, 229.

RoStY (Mme):257.

ROTHSCHILD, James (baron de):

290. ROUDINESCO, Élisabeth: 225, 234.

ROULHAC DUMAUPAS [DU MAUPAS], Simon Martin Grégoire de: 157.

ROUSSEAU, Jean-Jacques : 61, 85, 203, 214.

Roux,Jacques:86.

ROYER-COLLARD, Antoine-Athanase (Dr) : 133, 137, 146-152, 154, 156-158, 160, 279. ROYER-COLLARD (Pierre-Paul

Royer, dit) : 146.

SADE (les): 137, 140.

SADE, Donatien Alphonse François (comte, dit marquis de) : 56, 93, 103, 109, 136-153, 157-160, 333. SAINT-AUBIN, Stéphanie-Félicité du Crest de (comtesse de Genlis, marquise de Sillery) : 104.

SAINTE-COLOMBE, Marie : 113. SAINT-JUST, Louis Antoine Léon de: 113. SAINT-JUST, Marie-Anne (née

Robinot): 113. SAINT-SIMON, Claude-Henri de

Rouvroy (comte de) : 255.

SAND, George (Aurore Dupin, baronne Duelevant, dite): 176, 205, 255, 268.

SANSON, Charles-Henri: 45, 46, 48, 56.

SARKOZY, Nicolas : 338. SAVARY, Anne-Jean-Marie-René

(duc l'er de Rovigo) : 122.

Schmidt, Tobias: 52, 53.

Schopenhauer, Arthur: 203. SCHWEIGGER, August-Friedrich

(Dr): 145.

SCRIBE, Augustin Eugène : 166.

SENARD, Antoine Marie Jules :

331. SEPTIME SÉVÈRE (empereur romain): 206. SÉVIGNÉ, Marie de RabutinChantal (baronne de, dite marquise de) : 35.

SHAKESPEARE, William: 30.

SIBALIS, Michael: 129.

SOBRIER, Marie-Joseph : 265.

SOCRATE : 209. SÖMMERING, Samuel Thomas von

(Dr) : 53, 54.

SOURNIA, Jean-Charles : 116.

SPURZHEIM, Johann Gaspar (Dr) :

204.

STARCK, Carl (Dr):321,322.

STEIN, Gertrude: 24. SUE, Eugène (Marie-Joseph Sue, dit) : 54, 165, 253.

SUE,Jean-Joseph:54. SULEAU, François-Louis : 225, 229.

Swain, Gladys:33,139.

SYLLA (homme d'État romain):

206.

TAINE, Hippolyte Adolphe: 211.

TALLEYRAND, Gabriel de : 117. TALLEYRAND-PÉRIGORD, CharlesMaurice de (évêque d'Autun) :

117.

TALMA, François-Joseph (acteur):

56.

TENON, Jacques René (Dr): 59.

THÉROIGNE DE MÉRICOURT
(Anne-Joséphe Therwagne,
di¤eYj ah]ai\ bbd]bce\ bch\

239. THERWAGNE, Élisabeth (née

Lahaye): 224.

THERWAGNE (M., frère de Théroigne de Méricourt) : 226.

THERWAGNE, Pierre: 224.

THERWAGNE (2de Mme): 224.

THIERS, Adolphe: 123, 215, 304.

THOMAS, Émile : 266. TOCQUEVILLE, Alexis-HenriCharles Clérel (vicomte de) :

rvumrvxl rwpl rwsn

Tosquelles, François (Dr): 335. Trélat, Ulysse (Dr): 22, 169, 250, 265-267, 284, 288, 289.

Tréinitz (M. de, danseur) : 144.

TROCHU, Louis Jules (général) :

303.

UrBain, Raoul: 329. VALLÈS, Jules (Jules Louis Joseph

Vallez, dit) : 329-331.

VALLEZ, Jean-Louis : 330.

VALLEZ, Marie-Louise-Julie : 330.

VENTE (M., libraire): 94.

VERMERSCH, Eugène : 329. VICTOIRE DE FRANCE (dite Madame Victoire, tante de

Louis XVI) : 60.

VIGNY, Alfred Victor (comte de) :

272. VILLELE, Jean-Baptiste Guillaume Marie Anne Séraphin Joseph

(comte de) : 120.

Villiers de L'Isle-Adam, Jean-Marie-Mathias-Philippe-Auguste (dit le comte de, puis le marquis de): 106.

VILLOT, Amédée de (général) :

258.

Villot, Ciméa de : 258, 259.

VIIIOT (Mme de): 258. VIRCHOW, Rudolf Ludwig Karl

(Dr) : 322. VOISIN, Félix Auguste (Dr) : 163, 175, 236, 286, 287, 289. VOLNEY, Constantin-François Chassebœuf de La Giraudais

(comte): 117. VOLTAIRE (François Marie

Arouet, dit) : 109.

Weiner, Dora B.: 71.

Wilkormiski, Binjamin : 185.

ZELIE (Mille, danseuse) : 155.

ZOLA, Émile : 39, 41.
