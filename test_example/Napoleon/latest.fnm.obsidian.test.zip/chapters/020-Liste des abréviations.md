## Liste des abréviations

Liste des abréviations

AAP-HP: Archives de l'Assistance publique-Hôpitaux de Paris.

ADVDM: Archives départementales du Val-de-Marne.

AN: Archives nationales.

AP: Archives de Paris.

APPP: Archives de la préfecture de police de Paris.
