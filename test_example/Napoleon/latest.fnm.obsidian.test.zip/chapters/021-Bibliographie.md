## Bibliographie

Bibliographie sommaire

SOURCES MANUSCRITES

Archives de l'Assistance publique — Hôpitaux de Paris, Paris :

— Série R : Registres d'observations médicales de la Salpêtrière et de Bicêtre.

— Série Q : Registres de placements de la Salpêtrière et de Bicêtre.

— Fond Fossoyeux.

Archives départementales du Val-de-Marne, Créteil :

— Série X: Registres d'observations médicales de Charenton.

— Série Q: Registres de placements.

Archives nationales, Paris :

— Série F : sous-séries F7 (Police) et F15 (Hospices et secours).

Archives de Paris, Paris :

— Série X : Registres d'observations médicales de Sainte-Anne.

Archives de la Préfecture de Police, Paris :

— Série B, sous série B: Communards.

— Série C, sous série C^: Répertoires analytiques et registres d’inscription ou d’internement.

Bibliographie

Bibliothèque de l'Académie de médecine, Paris :

— Recueil d'observations prises dans le service de M. le Dr Trélat

(à la Salpêtrière) par J.-A. Fort, interne.

Bibliothèque nationale de France, cabinet des Estampes, Paris :

— Carnets de dessins de Georges-François-Marie Gabriel.

Louise M. Darling Biomedical Library, Special collections, UCLA, Los Angeles : — Registres de la maison Belhomme et de la maison Esquirol

SOURCES IMPRIMÉES

Tous les ouvrages cités ont été publiés à Paris, sauf mention contraire.

Sources primaires
Usuels

Annales médico-psychologiques, Masson, 1843-2011.

Annales d'hygiène publique et de médecine légale, Jean-Baptiste Baillière, 1829-1922.

Archives d'anthropologie criminelle, Masson, 1886-1914.

Dictionnaire encyclopédique des sciences médicales, publiée sous la dir. de M.-A. Dechambre, Asselin et Masson, 1864-1889.

100 vol.

Dictionnaire des sciences médicales, par une société de médecins et de chirurgiens, Panckoucke, 1812-1822, 60 vol.

Encyclopédie du XIXe siècle, répertoire universel des sciences, des lettres et des arts, 1838, 25 vol.

Grand Dictionnaire universel du XIXe siècle, par Pierre Larousse, 1865-1890, 17 vol. Études et ouvrages ANTOMMARCHI, Dr F., Derniers momens de Napoléon, Bruxelles, H. Tarlier libraire, 1825.

BAILLARGER, Jules, Essai de classification des maladies mentales, Victor Masson, 1854.

BEAUJEU, Maurice, Psychologie des premiers Césars, Lyon, A. Storck, 1893.

BELHOMME, Dr Jacques-Étienne, Influence des événements et des commotions politiques sur le développement de la folie, mémoire lu à l'Académie de médecine dans la séance du 2 mai 1848, suivi d'un rapport de M. Londe, dans la séance du 6 mars 1849, Librairie GermerBaillière, 1849.

BERTIER DE SAUVIGNY, Ferdinand, Souvenirs inédits d'un conspirateur, Tallandier, 1990.

BLANCHE, Esprit, Du danger des rigueurs corporelles dans le traitement de la folie, A. Gardembas, 1839.

BLOCH, C., L'Assistance publique. Instruction. Notes sur la législation et l'administration de l'Assistance de 1789 à l'an VIII. Recueil des principaux textes. Notes sur les sources aux Archives nationales, 1909.

BOURDIN, C. E., Étude médico-psychologiques : de l'influence des événements politiques sur la production de la folie, Adrien Delahaye, 1873.

BRIERRE DE BOISMONT, Alexandre, Des hallucinations ou Histoire raisonnée des apparitions, des visions, des songes, de l'extase, du magnétisme et du somnambulisme, G. Baillière, 1845.

BRIQUET, Paul, Traité clinique et thérapeutique de l'hystérie, J.-B. Baillière et fils, 1859.

BROUSSAIS, F.-J.-V., De l'irritation et de la folie, J.-B. Baillière, 1839.

BRU, Paul, Histoire de Bicêtre, Lecrosnié et Babé, 1890.

BUCHEZ, P.-J.-B., et ROUX, P.-C., Histoire de la Révolution française, ou Journal des Assemblées nationales depuis 1789 jusqu'en 1815, Paulin Libraire, 1836.

CABANÈS, Augustin, L'Histoire éclairée par la clinique, Albin Michel, 1921.

—, Au chevet de l'empereur, Albin Michel, 1958.

CABANÈS, A., et NASS, L., La Néurose révolutionnaire, Albin Michel, 1925.

CABANIS, Pierre-Jean-Georges, Note sur le supplice de la guillotine, an IV [1796], réimpr., Orléans, À l'Orient, 2007.

—, Rapports du physique et du moral de l'homme, Crapart, Caille et Ravier, an X-1802.

CALMEIL, L.-F., De la folie considérée sous le point de vue pathologique, philosophique, historique et judiciaire, J.-B. Baillière, 1845, 2 vol.

CHATEAUBRIAND François-René de, Mémoires d'outre-tombe, Gallimard, « Bibliothèque de la Pléiade », 1951, 2 vol.

COLINS, Hippolyte de, Notice sur l'établissement consacré au traitement de l'aliénation mentale établi à Charenton près Paris, juin 1812, repr. in Sade, Journal inédit, Gallimard, 1970.

COLOMBIER, Jean, et DOUBLET, François, * Instruction sur la manière de gouverner les insensés et de travailler à leur guérison dans les asyles qui leur sont destinés », in Observations faites dans le département des hôpitaux civils, 1785, p. 339-392.

CONSTANT-REBECQUE, Benjamin de, De l'esprit de conquête et de l'usurpation dans ses rapports avec la civilisation, Hanovre, Hahn, 1814.

DAQUIN, Joseph, La Philosophie de la folie, ou Essai philosophique sur le traitement des personnes attaquées de folie, Chambéry, Gorrin père et fils, 1791/ Paris, chez Née de La Rochelle, libraire, 1792.

—, La Philosophie de la folie, où l'on prouve que cette maladie doit plutôt être traitée par les secours moraux que par les secours physiques ; et que ceux qui en sont atteints, éprouvent d'une manière non équivoque l'influence de la lune, 2° édition revue, augmentée et appuyée sur un grand nombre de différentes observations, Chambéry, P. Cléaz, an XII-1804.

DESCURET, J.-B. F., La Médecine des passions, Labé, 1844.

DESPINE, Prosper, De la folie du point de vue philosophique, ou plus spécialement psychologique, étudiée chez le malade et l'homme de santé, Savy, 1875.

DESPORTES, Compte rendu au conseil général des hospices et hôpitaux civils de Paris sur le service des aliénés traités dans les hospices de la vieillesse (Hommes et Femmes) [Bicêtre et la Salpêtrière] pendant les années 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, Imprimerie de Mme Huzard, 1835.

DU CAMP, Maxime, Paris, ses organes, ses fonctions et sa vie dans la seconde moitié du XIXe siècle, Hachette, 1869-1876.

—, Les Convulsions de Paris, Hachette, 1878-1880, 4 vol.

DUMAS, Alexandre, Les Mille et Un Fantômes, précédé de La Femme au collier de velours [1849], éd. présentée, établie et annotée par Anne-Marie Callet-Bianco, Gallimard, « Folio », 2006.

ELLIS, W. C., Traité de l'aliénation mentale, trad. par Th. Archambaud et enrichi de notes par M. Esquirol, De Just Rouvier, 1840.

ESQUIROL, Jean-Étienne-Dominique, Des établissements des aliénés en France et des moyens d'améliorer le sort de ces infortunés, Imprimerie de Mme Huzard, 1819.

—, De la lypémanie ou mélancolie [1820], présentation par P. Fedida et J. Postel, Toulouse, Privat, 1977.

—, Des maladies mentales, considérées sous les rapports médical, hygiènique et médico-légal, Baillière, 1838, 2 vol.; rééd.: Des maladies mentales [1838], Frénésie éditions, 1989.

—, Des passions considérées comme causes, symptômes et moyens curatifs de l'aliénation mentale, Didot jeune, 1805.

—, « Introduction à l'étude des aliénations mentales (Fragments de la première leçon du cours clinique fait à la Salpêtrière sur ces maladies) », Revue médicale française et étrangère, n° 8, 1822.

ESQUIROS, Alphonse, Paris, ou Les Sciences, les institutions et les mœurs au XIXe siècle, Comptoir des imprimeurs unis, 1847.

ESTRÉES, Paul d', Le Théâtre sous la Terreur (théâtre de la peur), 1793-1794, d'après des publications récentes et d'après les documents révolutionnaires du temps, imprimés ou inédits, Émile-Paul frères, 1913.

SYLVAIN-EYMARD, docteur, La Politicomanie ou Coup d'œil critique sur la folie révolutionnaire qui a régné en Europe depuis 1789 jusqu'au 2 décembre 1851, 2° éd., Garnier frères, 1853.

FABRE, docteur François, Bibliothèque du médecin-praticien ou Résumé général de tous les ouvrages de clinique médicale et chirurgicale etc., vol. IX, Maladies de l'encéphale, maladies mentales, maladies nerveuses, J.-B. Baillière, 1849.

FALRET, Jean-Pierre, Des maladies mentales et des asiles d'aliénés, J.-B. Baillière et fils, 1864.

FLORE, MILLE, MÉMOIRES DE MILLE FLORE, COMPTOIR DES IMPRMEURS UNIS,

1845, 3 vol.

FODÉRÉ, François Emmanuel, Traité du délire, Croulebois, 1817.

GIRARD DE CAILLEUX, J. H., Études pratiques sur les maladies nerveuses et mentales, Baillière, 1863.

GIRAUDY, Charles-François, Mémoire sur la Maison nationale de Charrenton, Imprimerie de la Société de médecine, an XII - 1804.

GRIESINGER, Wilhelm, Traité des maladies mentales, trad. de l'allemand par le docteur Doumic, Adrien Delahaye, 1865.

GRODDECK, docteur, De la maladie démocratique, nouvelle espèce de folie, trad. de l'allemand, G. Baillière, 1850.

GUILLOIS, docteur A., Étude médico-psychologique sur Olympe de Gouges, Lyon, 1904.

HAMEL, Ernest, Histoire des deux conspirations du général Malet, Librairie de la Société des gens de lettres, 1873.

Hugo, Victor, Choses vues (1830-1848), Gallimard, «Folio », 1972.

—, Les Misérables [1862], Gallimard, « Bibliothèque de la Pléiade », 1951.

—, Quatrevingt-treize [1874], Gallimard, «Folio», 1979.

JACOBY, docteur Paul, Étude sur la sélection dans ses rapports avec l'héritédité chez l'homme, Germer-Baillière et Cie, 1881.

LABORDE, Jean-Baptiste-Vincent, Fragments médico-psychologiques.

Les hommes et les actes de l'insurrection de Paris devant la psychologie morbide, G. Baillière, 1872.

LAMARTINE, Alphonse de, Histoire de la révolution de 1848, Perrotin, 1849, 2 vol.

LA ROCHEFOUCAULD-LIANCOURT, duc de, Rapport, fait au nom du Comité de mendicité, des visites faites dans divers hôpitaux, hospices et maisons de charité de Paris, Imprimerie nationale, 1790.

LEGRAND DU SAULLE, Henri, Le Délire de persécution, Plon, 1871.

LÉLUT, Louis-Francisque, Du démon de Socrate, Trinquart, 1836.

—, L'Amulette de Pascal, J.-B. Baillière, 1846.

LE PLAY, Frédéric, Les Ouvriers des deux mondes : études sur les travaux, la vie domestique et la condition morale des populations ouvrières des diverses contrées et sur les rapports qui les unissent aux autres classes, Société internationale des études pratiques d'économie sociale, 1857-1885.

LEURET, François, Fragmens psychologiques sur la folie, Crochard, 1834.

—, Du traitement moral de la folie, J.-B. Baillière, 1840.

LISSAGARAY, Prosper-Olivier, Histoire de la Commune de 1871, Bruxelles, Librairie contemporaine de Henri Kistemaeckers, 1876.

LOMBROSO, Cesare, L'Homme de génie, trad. par Fr. Colonna d'Istria, Félix Alcan, 1889.

—, Le Crime politique et les révolutions par rapport au droit, à l'anthropologie criminelle et à la science du gouvernement, trad. par A. Bouchard, Félix Alcan, 1892, 2 vol.

LUNIER, L., De l'influence des grandes commotions politiques et sociales sur le développement des maladies mentales, F. Savy, 1874.

MACÉ, Louis-Victor, Traité pratique des maladies mentales, J.-B. Baillière et fils, 1862.

MERCIER, Louis Sébastien, Le Tableau de Paris [1788], La Découverte, «Poche», 1998.

—, Le Nouveau Paris, À Brunswick, chez les principaux libraires, 1800.

MICHEL, Louise, La Commune, Stock, 1898.

MICHELET, Jules, Histoire du XIXe siècle, Michel Lévy frères, 1875.

—, Ma jeunesse, Calmann-Lévy, 1884.

MIRABEAU, Observations d'un voyageur anglais sur la maison de force appellée Bicêtre, s. l., 1788.

MOREAU DE TOURS, J., La Psychologie morbide dans ses rapports avec la philosophie de l'histoire ou De l'influence des néuropathies sur le dynamisme intellectuel, Victor Masson, 1859.

MOREL, Benedict-Augustin, Traité des maladies mentales, Victor Masson, 1860.

MULLOIS, Isidore, La Charité et la misère à Paris, Paris et Lyon, 1856.

NERVAL, Gérard de, Œuvres complètes, t. II, Les Illuminés, Gallimard, « Bibliothèque de la Pléiade », 1984.

NODIER, Charles, Souvenirs, épisodes et portraits pour servir à l'histoire de la Révolution et de l'Empire. Alphonse Levasseur. 1831.

PARDIGON, François, Épisodes des journées de juin 1848, La Fabrique, 2008.

PIGEAUD, Jackie, Théroigne de Méricourt : la lettre-mélancolie, Lagrasse, Verdier/L'Éther vague, 2005.

[PINEL, Philippe], Lettres de Pinel, précédées d'une notice plus étendue sur sa vie, par son neveu le docteur Casimir Pinel, Victor Masson, 1859.

PINEL, Philippe, Nosographie philosophique, ou la méthode de l'analyse appliquée à la médecine, Maradan, an VI [1797], 2 vol.

—, Traité médico-philosophique sur l'aliénation mentale ou la manie, Richard, Caille et Ravier, an IX [1800].

—, Traité médico-philosophique sur l'aliénation mentale, 2° éd. entièrement refondue et très augmentée (1809), présenté et annoté par Jean Garrabé et Dora B. Weiner, Les Empêcheurs de penser en rond, 2005.

—, « Réflexions médicales sur l’état monastique », Journal gratuit, n° 6, 1790, p. 81-93.

—, «Variété», Journal de Paris, 18 janvier 1790, p. 70-72.

PINEL, Scipion, Physionomie de l'homme aliéné, Librairie des sciences médicales, 1833.

POTTER, Agathon de, « La peste démocratique (Morbus democraticus). Contribution à l'étude des maladies mentales », Philosophie de l'avenir, revue du socialisme rationnel, vol. X, 1885-1886, p. 1-99.

RICHARD, David, La Phrénologie et Napoléon, Imprimerie Pihan Delaforest, 1835.

RIVET, Mme, Les Aliénés dans la famille et la maison de santé : étude pour les gens du monde, Paris, 1875.

SACHAILE, Claude, Les Médecins de Paris jugés par leurs œuvres, ou Statistique scientifique morale des médecins de Paris, De la Barre, 1845.

SADE, D. A. F. de, Journal inédit, Gallimard, «Folio », 1994.

—, Lettres inédites et documents, correspondance publiée par Jean-Louis Debauve, 1900.

SANSON, Charles-Henry, Mémoires de Sanson (1739-1806), exécuteur des jugements criminels, Albin Michel, 1911.

STERN, Daniel [Marie d’Agoult], Histoire de la révolution de 1848, Gustave Sandré, 1850-1853, 3 vol.

SUE, Jean-Joseph, Essai sur le supplice de la guillotine et sur la douleur qui survit à la décollation, s. l., 1796.

TALMA, François-Joseph, Mémoire de F.-J. Talma [1849], écrit par lui-même et mis en ordre sur les papiers de sa famille par Alexandre Dumas ; rééd. Montréal, Le Joyeux Roger, 2006.

TENON, Jacques, Mémoire sur les hôpitaux de Paris, Ph.-D. Pierres, 1788.

THIERS, Adolphe, Histoire du Consulat et de l’Empire, Paulin [puis]

Paulin, Lheureux et Cie, [puis] Lheureux, 1845-1869, 21 vol.

Tocqueville, Alexis de, Souvenirs, Calmann-Lévy, 1893.

Trélat, Ulysse, La Folie lucide, Adrien Delahaye, 1861.

TUETEY, Alexandre, L'Assistance publique à Paris pendant la Révolution, t. I, Les Hôpitaux et hospices, Imprimerie nationale, 1845.

VOISIN, Auguste, Leçons cliniques sur les maladies mentales et sur les maladies nerveuses, J.-B. Baillière et fils, 1883.

—, Traité de paralysie générale des aliénés, J.-B. Baillière, 1879.

VOISIN, Félix, Des causes morales et physiques des maladies mentales, J.-B. Baillière, 1826.

Sources secondaires

Livres

ACKERKNECHT, Erwin H., La Médecine hospitalière à Paris (1794-1848), trad. par Françoise Blateau, Payot, 1986.

ARASSE, Daniel, La Guillotine et l'imaginaire de la Terreur, Flammarion, 1987.

AUBOIN, Michel, TEYSSIER, Arnaud, et TULARD, Jean, Histoire et dic- tionnaire de la police, du Moyen Âge à nos jours, Robert Laffont, « Bouquins », 2005.

BEAUVOIS, Delphine, La Criminalité féminine enregistrée au Dépôt de la préfecture de police de Paris sous le Second Empire (1853-1869), mémoire de maîtrise sous la dir. de Dominique Kalifa, université de Paris-VII, 1999.

BESSETTE, Jean-Michel, Il était une fois... la guillotine, Alternatives, 1982.

BILLARD, Max, La Conspiration de Malet, Perrin, 1907.

BOUKOVSKY, Vladimir, Une nouvelle maladie mentale en U.R.S.S.: l'opposition, Seuil, « Combats », 1971.

CAIRE, Michel, Contribution à l'histoire de l'hôpital Sainte-Anne (Paris): des origines au début du XXe siècle, thèse de médecine, Paris-V, Cochin-Port-Royal, n° 20, 1981, 160-VIII p.

CARUTH, Cathy, Unclaimed Experience: Trauma, Narratives, and History, Baltimore, The Johns Hopkins University Press, 1996.

CARUTH, Cathy (éd.), Trauma : Explorations in Memory, Baltimore, The Johns Hopkins University Press, 1995.

CASTEL, Pierre-Henri, L'Esprit malade. Cerveaux, folies, individus, Ithaque, 2009.

CASTEL, Robert, L'Ordre psychiatrique. L'âge d'or de l'aliénisme, Minuit, 1976.

CHEMLA, Patrick (sous la dir. de), Asile?, Ramonville-Sainte-Agne, Érès, 1999.

CHEVALIER, Louis, Classes laborieuses et classes dangereuses à Paris pendant la première moitié du XIX $ ^{e} $ siècle, Plon, 1958.

CLARKE, Joseph, Commemorating the Dead in Revolutionary France: Revolution and Remembrance, 1789-1799, Cambridge, Cambridge University Press, 2007.

CLERCQ, Michel de, et LÉBIGOT, François, Les Traumatismes psychiques, Masson, 2001.

COFFIN, Jean-Christophe, La Transmission de la folie : 1850-1914, L'Harmattan, 2003.

[COLLECTIF], Penser la folie. Essais sur Michel Foucault, Galilée, « Débats », 1992.

CROCQ, Louis, Les Traumatismes psychiques de guerre, Odile Jacob, 1999.

DADOUN, Roger (éd.), La Folie politique, Payot, « Traces », 1971.

DAVOINE, Françoise, et GAUDILLIÈRE, Jean-Max, Histoire et trauma.

La folie des guerres, Stock « L'autre pensée », 2006.

DELEUZE, Gilles, et GUATTARI, Félix, L'Anti-Œdipe. Capitalisme et schizophrénie 1, Minuit, 1972/1973.

DIDIER, Marie, Dans la nuit de Bicêtre, Gallimard, « L'un et l'autre », 2006.

FANON, Frantz, Les Damnés de la terre, Maspero, 1961.

FERRONI, A., Une maison de santé pour le traitement des aliénés à la fin du XVIIIe siècle : la maison Belhomme, Paris, thèse de médecine, 1954.

FLEISHMANN, Hector, La Guillotine en 1793, Librairie des publications modernes, 1908.

FOUCAULT, Michel, Folie et déraison. Histoire de la folie à l'âge classique, Plon, 1961.

—, Les Anormaux. Cours au Collège de France, 1974-1975, Gallimard/Seuil, « Hautes Études », 1999.

—, Dits et écrits, Gallimard, « Quarto », 2001, 2 vol.

—, Le Pouvoir psychiatrique. Cours au Collège de France, 1973-1974, Gallimard/Seuil, « Hautes Études », 2003.

FREUD, Sigmund, Essais de psychanalyse, Payot, 1968.

GARRABÉ, Jean (sous la dir. de), Philippe Pinel, Le Plessis-Robinson, Synthélabo/Les Empêcheurs de penser en rond, 1994.

GAUBERT, Henri, Conspirateurs au temps de Napoléon Ier, Flammarion, « L’Histoire », 1962.

GAUCHET, Marcel, et SWAIN, Gladys, La Pratique de l'esprit humain.

L'institution asilaire et la révolution démocratique, Gallimard, 1980.

GINESTE, Thierry, Le Lion de Florence. Sur l'imaginaire des fondateurs de la psychiatrie, Pinel (1745-1826) et Itard (1774-1838), Albin Michel, 2004.

GOFFMAN, Erving, Asiles, Minuit, 1968.

GOLDSTEIN, Jan, Consoler et classifier. L'essor de la psychiatrie française, trad. de l'anglais (États-Unis) par Françoise Bouillot, Le Plessis- Robinson, Synthélabo/Les Empêcheurs de penser en rond, MICALE, Mark S., et LERNER, Paul, Traumatic Pasts : History, Psychiatry and Trauma in the Modern Age, 1870-1930, Cambridge University Press, 2001.

GREER, Donald, The Incidence of the Terror during the Revolution: A Statistical Interpretation, Cambridge, Harvard University Press, 1935.

GRMEK, Mirko, Les Maladies à l'aube de la civilisation occidentale, Payot, 1983.

GUESLIN, André, et KALIFA, Dominique (sous la dir. de), Les Exclus en Europe. 1830-1930, Éd. de l'Atelier, 1999.

GULLICKSON, Gay L., Unruly Woman of Paris. Images of the Commune, Ithaca, Cornell University Press, 1996.

HAUSTGEN, Thierry, Observations & certificats psychiatriques au XIXe siècle, Rueil-Malmaison, Ciba, 1985.

KELLER, Richard C., Colonial Madness: Psychiatry in French North Africa, Chicago and Londres, The University of Chicago Press, 2007.

LACAN, Jacques, Écrits, Seuil, 1966, 2 vol.; rééd. 1999.

LANTÉRI-LAURA, Georges, Lecture des perversions : histoire de leur appropriation médicale, New York/Barcelone, Masson, 1979.

LE BRUN, Annie, Soudain un bloc d'abîme, Sade, Jean-Jacques Pauvert, 1986.

—, On n'enchaîne pas les volcans, Gallimard, 2006.

— (sous la dir. de), Petits et grands théâtres du marquis de Sade, Paris

Art Center, 1989.

LELY, Gilbert, Vie du marquis de Sade, nouv. éd. entièrement refondue, Jean-Jacques Pauvert, 1965.

LENORMAND, Frédéric, La Pension Belhomme. Une prison de luxe sous la Terreur, Fayard, 2002.

LENÔTRE, G., La Guillotine et les exécuteurs des arrêts criminels pendant la Révolution, d'après des documents inédits tirés des Archives de l'État, Librairie académique Perrin et Cie, 1910.

—, Paris révolutionnaire : vieilles maisons, vieux papiers, 3 $ ^{e} $ série, Librairie académique Perrin, 1922.

LEVER, Maurice, Donatien Alphonse François, marquis de Sade, Fayard, 1991.

LIDSKY, Paul, Les Écrivains contre la Commune, Maspero, 1970.

MICALE, Mark S., et LERNER, Paul, Traumatic Pasts : History, Psychiatry and Trauma in the Modern Age, 1870-1930, Cambridge University Press, 2001.

MOREL, Pierre, Dictionnaire biographique de la psychiatrie, Le Plessis-Robinson, Synthélabo/Les Empêcheurs de penser en rond, 1996.

PAUVERT, Jean-Jacques, Sade vivant, Robert Laffont, 1990, 3 vol.

PIGEAUD, Jackie, Aux portes de la psychiatrie. Pinel, l'Ancien et le Moderne, Aubier, 2001.

PINON, Pierre, L'Hospice de Charenton, Liège / Bruxelles, P. Mardaga, 1989.

POSTEL, Jacques, Genèse de la psychiatrie. Les premiers écrits de Philippe Pinel, Synthélabo/Les Empêcheurs de penser en rond, 1998.

—, Éléments pour une histoire de la psychiatrie occidentale, L'Harmattan, 2007.

POSTEL, Jacques, et QUÊTEL, Claude, Nouvelle histoire de la psychiatrie, Toulouse, Privat, 1983.

QUÉTEL, Claude, Histoire de la folie, de l'Antiquité à nos jours, Tallendier, 2009.

—, Images de la folie, Gallimard, 2010.

RENNEVILLE, Marc, Le Langage des crânes. Une histoire de la phrénologie, Institut d'édition Sanofi-Synthélabo / Les Empêcheurs de penser en rond, 2000.

— La Médecine du crime. Essai sur l'émergence d'un regard médical sur la criminalité en France (1785-1885), Presses universitaires du Septentrion. 2000, 2 vol.

RIOT-SARCET, Michèle, et GRIBAUDI, Maurizio, 1848, la révolution oubliée, La Découverte, 2008.

ROUDINESCO, Élisabeth, Théroigne de Méricourt. Une femme mélancolique sous la Révolution, Seuil, « Fiction et Cie », 1989.

SAUCEROTTE, Constant, Les Médecins pendant la Révolution, 1887.

SIRONI, Françoise, Psychologie des violences collectives. Essai de psychologie géopolitique clinique, Odile Jacob, 2007.

SOURNIA, Jean-Charles, La Médecine révolutionnaire, 1789-1799, Payot, « Médecine et société », 1989.

STAROBINSKI, Jean, Histoire du traitement de la mélancolie des origines à 1900, Bâle, Laboratoires Geigy, 1960.

SWAIN, Gladys, Le Sujet de la folie, Calmann-Lévy, 1977.

—, Dialogue avec l’insensé, Gallimard, « Bibliothèque des sciences humaines », 1994.

TULARD, Jean (sous la dir. de), Dictionnaire Napoléon, Fayard, 1987, nouv. éd. revue et augmentée, 1999.

— (sous la dir. de), Dictionnaire du Second Empire, Fayard, 1995.

WEINER, Dora B., Comprendre et soigner : Philippe Pinel (1745-1826) : la médecine de l'esprit, Fayard, « Penser la médecine », 1999.

Articles

ACKERKNECHT, Erwin H., «Political Prisoners in French Mental Institutions before 1789, during the Revolution, and under Napoleon I», Medical History, vol. XIX, n° 19, 3, juillet 1975, p. 250-255.

ADHÉMAR, Jean, « Un dessinateur passionné par le visage humain : Georges-François-Marie Gabriel (1775-1836) », in Omagiu lui George Oprescu, Bucarest, 1961.

BERNARD, Anne-Marie, et HOUDAILLE, Jacques, « Les internés de Charenton. 1800-1854 », Population, 49° année, n° 2, mars-avril 1994, p. 500-515.

BIGORRE, Alain, et BOLLOTTE, Gabriel, « L'assistance aux malades mentaux à Paris de 1789 à 1838 », Annales médico-psychologiques, vol. CXXIV, n° 4, 1966, p. 463-474.

BIRMES, Philippe, HATTON, Leah, BRUNET, Alain, et SCHMITT, Laurent, « Early Historical Literature for Post-Traumatic Symptomatology », Stress and Health, n° 19, 2003, p. 17-26.

BONNAT, Jean-Louis, « Gérard de Nerval, un précurseur du "stade du miroir" (ou l'irraison de la psychose, au service du gouvernement politique, "Le Roi de Bicêtre") », Cliniques méditerranéennes, n° 64, 2001, p. 273-284.

CAIRE, Michel, « Un état des fous de Bicêtre en 1792 », Nervure, n° 7, 1993, p. 62-67.

—, «Pussin, avant Pinel», L’Information psychiatrique, vol. LXIX, n° 6, 1993, p. 529-538.

—, « Du Morbus democraticus à l’Idéalisme passionné. Quelques réactions des aliénistes français aux lendemains de la Commune de Paris », Annales médico-psychologiques, n° 4, 1990, p. 379-386.

CHEMOUNI, Jacquy, « Psychopathologie de la démocratie », Frénésie, vol. II, n° 10, 1992, p. 265-282.

CHEVRIER, Alain, « Psychiatrie et politique : sur la réception en France de La Maladie démocratique de Carl Groddeck », L'Évolution psychiatrique, vol. LVIII, n° 3, 1993, p. 605-617.

FAUVEL, Aude, «Punition, dégénérescence ou malheur?», Revue d'histoire du XIXe siècle, n° 26-27, 2003, p. 277-304.

FAU-VINCENTI, Véronique, « De la maladie démocratique », Le Monde diplomatique, septembre 2010, p. 28.

FORZINETTI-MOTET, « L'hôtel Colbert et les débuts de la maison Belhomme », Histoire de la médecine, décembre 1952, p. 27-34.

—, «La maison Belhomme», Histoire de la médecine, janvier 1953, p. 47-64.

FROMENTIN, Clément, « Qu’est-ce qui s’écrit de la psychiatrie? Du “secrétaire de l’aliéné” aux archives de l’asile. Sainte-Anne : une approche de la littératie en psychiatrie», Psychiatrie, Sciences humaines, Neurosciences, n° 6, 2008, p. 215-224.

GILBRIN, E., « La lignée médicale des Pinel, leur aide aux prisonniers politiques sous la Terreur et pendant la Restauration », Histoire des sciences médicales, n° 11, 1977, p. 69-79.

GLAZER, Catherine, «De la Commune comme maladie mentale», Romantisme, n° 48, 1985, p. 63-70.

Godineau, Dominique, «Pratiques du suicide à Paris pendant la Révolution française», French History and Civilization, vol. I, 2005, p. 126-140.

GOURÉVTTCH, Michel, « Qui soignera le divin marquis ? Documents inédits sur les conflits de pouvoirs entre directeur et médecin à Charenton en 1812 », Perspectives psychiatriques, vol. II, n° 96, 1984, p. 85-91.

GRMEK, M. D., «Histoire des recherches sur les relations entre le génie et la maladie», Revue d’histoire des sciences et de leurs applications, t. XV, n° 1, 1962, p. 51-68.

GUÉRIN, J.-L., COLLET, F., et HOSTIOU, P., « Ulysse Trélat ou la tentation eugéniste », Revue française de psychiatrie et de psychologie médicale, janvier 2002.

GULLICKSON, Gay L., «La Pétroleuse: Representing Revolution», Feminist Studies, vol. XVII, n° 2, été 1991, p. 240-265.

Häustgen, Thierry, «Les débuts difficiles du Dr Royer-Collard à Charenton. État sommaire de la maison de Charenton sous le rapport du service médical et aperçu des réformes qui y sont nécessaires, Antoine-Athanase Royer-Collard, 1811 », Synapse, n° 58, 1989, p. 57-66.

JACOB, Françoise, « Madness and Politics: French Nineteenth-Century Alienists’ Response to Revolution », History of Psychiatry, n° 6, 1995, p. 421-429.

JEAN, Thierry, «La folie est-elle une question idéologique ?», Journal français de psychiatrie, n° 19, 2003, p. 4-8.

JORDANOVA, Ludmilla, «Medical Mediations: Mind, Body and the Guillotine», History Workshop, n° 28, automne 1989, p. 39-52.

JUCHET, Jack, «Jean-Baptiste Pussin, “Médecin des folles”», Soins.

Psychiatrie, n° 142-143, août-septembre 1992, p. 46-54.

KROMM, Jane, « “Marianne” and the Madwomen », Art Journal, vol. XLVI, nº 4, hiver 1987, p. 299-304.

MALL, Laurence, « Révolution, traumatisme et non-savoir : la “longue surprise” dans Le Nouveau Paris de Mercier », Études littéraires, vol. XXXVIII, n° 1, automne 2006, p. 11-23.

POSTEL, Jacques, « Les premières expériences psychiatriques de Philippe Pinel à la maison de santé Belhomme », Revue canadienne de psychiatrie, vol. XXVIII, n° 7, novembre 1983, p. 571-575.

QUÉTEL, Claude, et SIMON, Jean-Yves, « L'aliénation alcoolique en France (XIXe siècle et 1re moitié du XXe siècle) », Histoire, économie et société, 7e année, n° 4, 1988, p. 507-533.

REVERZY, Jean-François, « Sade à Charenton. Une scène primitive de l'aliénisme », L'Information psychiatrique, vol. LIII, n° 10, 1977, p. 1169-1181.

SIBALIS, Michael, «Un aspect de la légende noire de Napoléon : le mythe de l'enfermement des opposants comme fous», Revue de l'Institut Napoléon, vol. I, n° 156, 1991, p. 9-24.

—, « L’enfermement de Théodore Desorgues : documents inédits », Annales historiques de la Révolution française, n° 284, 1991, p. 243-246.

SOURNIA, Jean-Charles, « Révolution française et troubles mentaux

1789-1799 », Vesalius, vol. III, n° 2, décembre 1997, p. 67-73.

SZASZ, Thomas, «The Sane Slave: An Historical Note on the Use of Medical Diagnosis as Justificatory Rhetoric», American Journal of Psychotherapy, n° 25, 1971, p. 228-239.

VASAK, Anouchka, « Révolution et aliénation : aux origines du “mal du siècle” », in Romantisme et Révolution(s). Entretiens de la fondation des Treilles, Gallimard, 2010, p. 231-250.

VINCIENNE, Olivier, « La maison de santé Belhomme. Légende et réalité », Paris et Île-de-France. Mémoires publiés par la Fédération des sociétés historiques et archéologiques de Paris et de l’Île-de-France, vol. XXXVI, 1985, p. 135-208.

Vovelle, Michel, «Notes complémentaires sur le poète Théodore Desorgues ou quand les inconnus se font connaître», Annales historiques de la Révolution française, n° 265, 1986, p. 341-345.

WEINER, Dora B., «The Apprenticeship of Philippe Pinel: A New Document, “Observations of Citizen Pussin on the Insane”», American Journal of Psychiatry, vol. CXXXVI, n° 9, septembre 1979, p. 1128-1134.

—, « Philippe Pinel et l’abolition des chaînes : un document retrouvé », L’Information psychiatrique, vol. XLVI, n° 2, 1980, p. 245-253.

—, « Un registre inédit de la première clinique  psychiatrique à Paris entre 1802 et 1808: Jean Étienne Dominique Esquirol et ses malades », XXXIe Congrès international d'histoire de la médecine, Bologne, Monduzzi, 1988, p. 543-550.

—, « Philippe Pinel (1745-1826) clerc tonsuré », Annales médico-psychologiques, vol. CXLIX, n° 2, 1991, p. 169-173.

Williams, Roger L., «Revolution and Madness: Blanqui and Trélat», The Journal of the Historical Society, vol. V, n° 2, 2005, p. 227-252.

SITES INTERNET

Je ne recommanderai jamais assez le site de Michel Caire sur l'histoire de la psychiatrie en France (http://psychiatrie.histoire.free.fr/) et celui de la Bibliothèque interuniversitaire de médecine et d'odontologie (http://www.bium.univ-paris5.fr/histmed/) auxquels j'ai eu recours quotidiennement pour l'élaboration de ce livre. Criminocorpus, le portail sur l'histoire de la Justice, des crimes et des peines (http://www.criminocorpus.cnrs.fr/) m'a également été précieux.

The quick brown fox jumps over the lazy dog.
