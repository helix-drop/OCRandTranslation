# 目录

- [Introduction: Psychological Interiority versus Self-Talk](chapters/001-Introduction Psychological Interiority versus Self-Talk.md)
- [The Perils of Imagination at the End of the Old Regime](chapters/002-The Perils of Imagination at the End of the Old Regime.md)
- [The Revolutionary Schooling of Imagination](chapters/003-The Revolutionary Schooling of Imagination.md)
- [Is There a Self in This Mental Apparatus?](chapters/004-Is There a Self in This Mental Apparatus.md)
- [An A Priori Self for the Bourgeois Male: Victor Cousin's Project](chapters/005-An A Priori Self for the Bourgeois Male Victor Cousin's Project.md)
- [Cousinian Hegemony](chapters/006-Cousinian Hegemony.md)
- [Religious and Secular Access to the Vie Intérieure: Renan at the Crossroads](chapters/007-Religious and Secular Access to the Vie Intérieure Renan at the Crossroads.md)
- [A Palpable Self for the Socially Marginal: The Phrenological Alternative](chapters/008-A Palpable Self for the Socially Marginal The Phrenological Alternative.md)
- [Epilogue](chapters/009-Epilogue.md)
- [Note on Sources](chapters/010-Note on Sources.md)
- [Index](chapters/011-Index.md)
