# 目录

- [Introduction: Psychological Interiority versus Self-Talk](chapters/001-Introduction Psychological Interiority versus Self-Talk.md)
- [1 The Perils of Imagination at the End of the Old Regime](chapters/002-1 The Perils of Imagination at the End of the Old Regime.md)
- [2 The Revolutionary Schooling of Imagination](chapters/003-2 The Revolutionary Schooling of Imagination.md)
- [3 Is There a Self in This Mental Apparatus?](chapters/004-3 Is There a Self in This Mental Apparatus.md)
- [4 An A Priori Self for the Bourgeois Male: Victor Cousin's Project](chapters/005-4 An A Priori Self for the Bourgeois Male Victor Cousin's Project.md)
- [5 Cousinian Hegemony](chapters/006-5 Cousinian Hegemony.md)
- [6 Religious and Secular Access to the Vie Intérieure: Renan at the Crossroads](chapters/007-6 Religious and Secular Access to the Vie Intérieure Renan at the Crossroads.md)
- [7 A Palpable Self for the Socially Marginal: The Phrenological Alternative](chapters/008-7 A Palpable Self for the Socially Marginal The Phrenological Alternative.md)
- [Epilogue](chapters/009-Epilogue.md)
