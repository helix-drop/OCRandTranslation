## Index des notions

Index des notions
Abondance/ rareté : 50 n. 5

« mystère de l'abondance moderne » (Schultz)/ ressources rares 227 ; v. Robbins abus de la souveraineté 15 ; v. excès actions ordonnatrices : une « politique de « cadre », préfiguration du Marché Commun, Eucken et le plan Mansholt 145action pénale : environnementale 254 (néolibéralisme américain)

actions régularrices (objectif des - : contrôle de l'inflation, stabilité des prix : 144); v. interventionnisme néokantien âge d’une historicité économique : 56 âge de la politique : 20 âge des libertés : 68 âge du gouvernement frugal : 30 analyse des micro-pouvoirs, procédures de gouvernementalité : 192 analyse du néolibéralisme (sous l’angle de la moralité critique) : 192 anarcho-capitalisme américain : 139 anarcho-liberalisme (École de Chicago) : 12, 121, 166 anti-étatisme : 78 ; v. phobie d'État appareil(s) diplomatico-militaire(s) et pluralité des États : 7,8 ; v. limitation externe « arbitrage des consommateurs »; v. néolibéralisme (principes généraux du —); Rougier art de gouverner (à la vérité ; à la rationalité de l’État souverain, ordonné à la raison d’État, à la raison gouvernementale) : 3-8 ; v. limitation, autolimitation, raison gouvernementale ; (à la rationalité des agents économiques) 3-8 ; (à la rationalité des gouvernés 316 art libéral de gouverner (au xviiiè s.), 53, 62, 70, 106, 299; v. libéralisme [classique]

art néolibéral de gouverner (abandon du système de type keynésien, gestion de la liberté, doctrine de gouvernement comme critère de l'action gouvernementale) : 65, 106, 107, 108, 125, 137, 155 ; v. politique de société, style économique ; Erhard, Eucken, Röpke, Spiethof art de gouverner économiquement et art de gouverner juridiquement; v. limitation, autolimitation, société civile autolimitation, v. limitation Biopolitique 23-25, 30, 97 n. 5, 191, 323 bon prix 33,50,55;v.physiocrates

« Cadre »

(−, condition d'existence du marché [formalisme ordolibéral] : 145 (− de jeu 266 n. * (− politique et moral) [Röpke]; v. politique de cadre (− des actions ordonnatrices : 147

(− institutionnel de la société capitaliste) [Schumpeter] : 190 n. 40 (− de l'État de droit) : 178 calcul, ratio gouvernementale et pratique gouvernementale : 5, 13 ; v. autolimitation ; utilité (- mercantiliste) : 54

(- pénal, principe de rationalité appliqué au crime, XVIIIes. : (- planétaire(nouveau type de)) : 57 (- de l'équilibre européen) : 62 ; v. Metternich capital

(−, ce qui rend possible un revenu sur le critère de la compétence) ; v. théorie du capital humain (du − au capitalisme) : 109 ; v. crises capitalisation : 149 ; v. politique sociale privatisée (figures historiques du -): 169-170 (- et institution juridique) : 170 (- et monopole) [Schumpeter] : 182 v. histoire du capitalisme; rationalité;

(– économique du sujet individuel) : 257 (rationalité interne du – humain, objet d'analyse économique) [Robbins] : 229 ; v. théorie du capital humain (société productrice, consommatrice de – conformes) : 261 ; v. néolibéralisme américain

(la-, principe [néolibéral] de formalisation, jeu formel entre des inégalités) : 122-124; v. jeu; vs. donnée de nature, monopole

(−entre États, principe de limitation externe de la raison d'État 7-9, 16, 24; v. balance européenne, limitation (absence de − et inflation) 157 n. 10; vs. stabilité des prix ; v. Rueff (action régularice des mécanismes de−) : 125, 142 • concurrence et monopole conduite : 258

(-économique, de marché) : 271-272 ; v. travail conduction (principe de -, Führertum) 115 consommation socialisée, collective, 147 ; (- et redistribution permanente des revenus) : 203 ; v. politique sociale (contrat 11

(−, expression de la volonté juridique et de l’intérêt) [Hume] : 277 [selon Blackstone] : 277 (doctrine du - et sujet de droit) (théorie juridique du -) : 280 contrôle (procédures de -) 69; v. hébralisme (- et intervention) 69; v. intervention crime (héorie économique du - : limitation des externalités négatives); v. pénalité, utilité crise(s) (- contexte de développement du néolibéralisme) : 199

(- de gouvernementalité, du dispositif de gouvernementalité 70-72, 78

(- de l'économie libérale 69, 71, 121 (effets de - :dévaluation, inefficacité de la capitalisation individuelle, chômage, politique de plein emploi et couverture sociale) 203 ; v. politique sociale (- du capitalisme) : 71 (conscience de -) : 70 critique

(− interne de la raison gouvernementale) : 14 ; v. art de gouverner, limitation (− politique du savoir : 37 croissance (− indéfinie de l'État, expansionnisme endogène) : 192 (− de la demande judiciaire dans l'État de droit) 180 Danger (« pas de libéralisme sans culture du - ») 67, 68; v. mécanismes de sécurité/liberté : 67 despotisme

(le –, pouvoir sans limitation externe) : 16 (conception physiocratique du –) : 63 (critique du – au XVIII e s.) : 78 devoir-être de l’État, devoir-faire du gouvernement : 6 dissidence politique du XXe siècle (exil politique, politique de l’exil) : 78 doctrine libérale traditionnelle et néolibéralisme (déplacements et inversions : de l'échange à la concurrence) : 121-122 ; v. concurrence, échange, libéralisme

(le−, principe de limitation interne de la pratique gouvernementale selon la raison d'État): 9-11, 14, 15; v. art de gouverner, limitation, raison d'État (−administratif en formation): 45 (−cosmopolite): 59 (−international): 59 (−pénal [réformateurs du xviii° s.): calcul utilitaire à l'intérieur d'une structure juridique, pratique pénale sur le critère de l'utilité : 256; v. utilité (redéfinition du − par les ordolibéraux): 166; v. principe juridique d'État (−originaire/s): 11, 17, 42 (−public 11, 39, 40; (−en formation): 45 (−naturel): 11 (−naturels): 8, 40 (limitation des − principe du transfert): [Hume]

(– souverains) : 20 droits de l’homme : 41, 43; (axiomatique fondamentale des –) et calcul utilitaire de l’indépendance des gouvernés 44 droits fondamentaux : 42 ; (jeu complexe entre - et indépendance des gouvernés : 46 droits imprescriptibles : 41 Échange (l –, donnée de nature) : 123 (juste –) : 48 (– et effet-marchandise) (– et utilité) : 46 ; v. intérêt, libéralisme, utilitarisme de l'échange à la concurrence (principe du marché), de l'équivalence à l'inégalité : 103, 121-122, 152 v. mercantilisme ; vs. concurrence

(l’- comme jeu, jeu d’entreprises) : 178 (– de la criminalité, à effet oligopolistique, appliquée à la drogue aux États-Unis) : 262

(– de marché, principe organisateur et régulateur de l’État [programme ordolibéral] : 120, 123; (– sociale de marché) : 99 n. 19; v. Erhard; vs. politiques du laissez-faire

(– de pouvoir libéral) 67;

(– dirigée, en Allemagne) : 112-113 ; v. planification; v. Rathenau (– protectionniste, au XIXe s.) : 179 (libération de l’→ des contraintes étatiques 82 économie politique 15, 16, 17, 18, 19, 24, 31

(− et autolimitation de la raison gouvernementale, et limitation de la puissance publique : 15-19, 40 ; v. limitation (− et distribution des pouvoirs) : 15 économiste (application de la grille d’intelligibilité économiste - à des phénomènes non économiques) : 245-246, 249-253, 272 ;

(- aux phénomènes sociaux) : 245-246 ;

(- aux comportements non économiques : la criminalité) : 253 Empire 61; v. Etats empirisme anglais 2/5 enrichissement

(- collectif et enrichissement indéfini ) : 56

(- de l'État, objet de l'économie politique 16; (- par la politique de laissez-faire) : 106 (- de l'Europe) 56

((mécanisme d’— mutuel par la liberté du marché, mondialisation) : 55-56 entreprise : 152-153 (éthique sociale de l'−) : 153

(forme « entreprise » (démultiplication de la - à l'intérieur du corps social, enjeu de la politique néolibérale ; réin- formation de la société sur le modèle de l'−) : 247 (société d'−); v. société (unité entreprise) [programme ordolibéral] : 153 ; v. sujet environnement : 291n. 8 ; v. Skinner

(- social, die soziale Umwelt : aménagement de l'environnement, « déplacement du centre de gravité de l'action gouvernementale vers le bas », 152-153 [Röpke] ; v. politique de vie environnementale (technologie), environnementalité 266 n. * époque de la raison d'État : 42, 57 époque du mercantilisme : 57 équilibre européen : 54, 55 équilibres internationaux : 53 espace

(−de liberté des partenaires économiques et légitimation de l'État [Allemagne, 1948-], 110

(−de marché aterrorial); v. Ferguson (élaboration d'un − planétaire) : 58 (I'−, effet mobile d'un régime de gouvernementalités multiples) (I'−, objectif à construire) 5-6,7

(−bourgeois capitaliste [ordolibéraux : critique de Sombart] : 117-118, 120, 166 (−de droit); v. formalisation (−de justice); 9

(−de parti); 115-116, 196-197; v. conduction

(−de police); 7-10, 38, 57; (illimitation des objectifs internes de la gouvernementalité de l'−); 38-39; v. limitation de l'art de gouverner selon la raison d'État

(−économique [ordolibéraux] : objectif de rénovation du capitalisme) : 120, 167, 174-176, 181 ; v. liberté de marché, principe de régulation; v. État de police, interventionnisme administratif (−totalitaire); v. État de parti (arbitrage de l'−): 167; v. néolibéralisme (−et société civile) : 80; v. société civile

(spécificité plurielle de l'→): 7

(perte du statut de personnalité juridique de l'→ en régime national-socialiste); v. peuple étatisation (problème de l'→) 79 États (non-absorption des-dans l'Empire) Europe classique de la balance : 56 Europe comme région économique particulière : 62 Europe de l'enrichissement collectif : 56 Europe impériale et carolingienne : 56 Europe et marché mondial : 60 excès : 19

(– de gouvernement 15; v. abus; vs. limitation, radicalisme, raison gouvernementale (– d'interventionnisme 70)

Formalisation du cadre juridico-économique de l'État de droit : 178 frugalité gouvernementale (principe de la–): 265 n. *; v. gouvernement frugal Généalogie 50 généalogie de régimes véridictionnels : 37 Gesellschaftspolitik : v. politique de société gouvernement (–économique): 16

(–frugal: système de la raison du moindre État, xvnn s.) 30-31, 49 n. 1, 275, 327 (–intervenant): 141 (–selon la raison d'État): 8, v; art de gouverner (frontières de la compétence du→): 41 gouvernement des hommes 3, 14 (–libéral); (critère de l'utilité du→): 48; v. utilité gouvernementalité : 17, 31, 38, 43, 61, 65, 78, 79, 80, 88; v. art de gouverner, crises, Empire, État, nature (–allemande (1948-): 85 (–individualisante, en régime capitaliste): 265 n. * (–étatique intégrale 38; v. – et pure raison d'État (–libérale) [selon Turgot] : 80; – néolibérale, Économique-politique [selon Erhard et Schiller] : 80, 88-89, 91, 92 (–de parti) : 196-197; v. État totalitaire (–moderne) : 23; v. indépendance des gouvernés (–socialiste) : 93-94-95 (délimitation de la→): 41 (— et calcul de l'utilité) : 42, 53; v. utilitarisme

(— et droit public) : 39-40; v. limitation ; (— et droits de l'homme) : 41 (— et enjeux de la politique) 43

(— et liberté fondamentale) : 14; v. agenda et non agenda; Bentham (— et pure raison d'État : 38-39 (choses en soi de la -) : 47 (pratiques de -) et problème de l'État 79; v. crises hétérogénéité : 43, 44

(− entre doctrine du contrat et doctrine du sujet de droit) : 280 ; v. théorie juridique du contrat histoire de l'économie, par croisement de l'analyse historique des systèmes et de l'analyse formelle des processus économiques : 124 histoire de l'exil politique : 78 histoire de la gouvernementalité occidentale : 35 histoire de la puissance publique en Occident : 45 histoire de la véridiction, des régimes de véridiction : 37- 38 histoire de la vérité couplée avec une histoire du droit : 36 histoire de l'individu : 317 n. 6; v. Ferguson histoire du capitalisme : 169-171 histoire du droit : 36; (- du droit de la mer au XVIII e.s.): 58; (- du droit de propriété): 45 histoire du gouvernement : 5 histoire du libéralisme européen : 45, 80 histoire du marché juridictionnel puis véridictionnel : 35 histoire du monopole, 158 n. 40 historicisme : 5 ; v. universaux homo œconomicus 258, 272, 275, 297-299 homogénéisation de l'hétérogène (convergence des intérêts) : 281 Impôt négatif : 208-212, 219 n. 48 indépendance des gouvernés : 43 individu(s): 9, 43, 47 individus-sujets (du souverain): 9, 24 individualisation de et par la politique sociale [ordolibéraux]: 149; v. politique social privatisée inégalité (égalité de l'– [néolibéralisme] : épargne et investissement), 146-150

(- et couverture des risques) : 149-150 ; v. politique sociale inflation 125 n. 1; v. crise économique; v.

(- social ordolibéral, « à titre de condition historique et sociale de possibilité pour une économie de marché » : 165-166, 181, 184 non-interventionnisme politique dans le domaine économique (néolibéralisme) : 143 irrationalité économique (annulation de l'— par une nouvelle rationalité sociale) [École de Francfort] : 109-110 irrationalité sociale (annulation de l’- par une redéfinition de la rationalité économique) [École de Fribourg] : 109-110 ; v. wébérisme

Jeu » (- dans l'État de droit) : 178 (- de la concurrence) : 54 (- des intérêts) : 47 juridiction et véridiction (croisements entre) : 35 ; (juridictions de type policier, p. ex. institutions asilaires, pénales, et processus de véridiction ; passage de la pratique juridictionnelle aux pratiques véridictionnelles) : 36 juridification du monde : 58 ljuristes et législateurs de la Révolution française : 41 juste prix (justum pretium) : 32, 49 Légaliste (solution - au XVIII e.s.); v. droit pénal législation anti-monopole : 66 législation économique (formalisation de la), 40, 177 ; vs. planification ; v. Hayek légitimité du souverain (conditions de la) : 40 légitimité/ illégitimité : 19

(le – comme autolimitation de la raison gouvernementale) : 23-24 & n*, 25, 48, 53, 62, 63, 97 n. 5; v. limitation (–actuel) : 62

(—allemand contemporain (1948-) : 25 (—économique et libéralisme politique 96 n. * (—européen) : 43

(«— libéralisme positif » : 138-139; v. interventionnisme fédéral; Röpke (—sociologique) [Röpke] : 162 n. 51 (—des physiocrates) : 25

(—des utilitaristes anglais) : 25; (— et problème de l'utilité—) : 44 (—, utilité et valeur d'échange) : 48 (— et biopolitique) : 24

(— et équilibre européen : du jeu économique à somme nulle à l'enrichissement collectif et indéfini) : 56-57; v. marché (— et extension des procédures de contrôle) : 68

(— et liberté au xvîrr s., rapport de production/destruction) 65; (— et libertés) : 25, 42, 63-64, 66 (— et naturalisme, xvîrr) : 63; v. Kant, Adam Smith (— et question de la frugalité du gouvernement) : 31

liberté

(– Économique fondatrice et garante de l'État, dans la doctrine néolibérale de gouvernement) : 108, 120 (– fondamentale) : 14 (– individuelle, des individus) : 67-68 (– du comportement en régime libéral) : 66 liberté du commerce 65

(– du marché) 55, 56, 158 n. 14; (– du marché dans l'État de police : liberté de privilèges) : 105-106; v. politiques du laissez-faire; (– du marché et droit public 40; (– et législation antimonopoliste) 70

(conception juridique de la—) : 43

(conceptions hétérogènes, « radicale » et révolutionnaire, de la—) : 43 (consommation de—) : 65

(coût de fabrication de la — en régime libéral) 66; (définition du coût économique de l'exercice des—) : 70 (majoration des—) : 69 liberté et sécurité (le jeu) : 67 limites du droit de la souveraineté : 41 limitation : 39

(- intrinsèque à la raison gouvernementale, limitation (auto-) de l'art libéral de gouverner) :

(- de fait de la pratique gouvernementale, 12, 13, 15; (- par le calcul d'utilité) 53; - (par la technicisation [selon les ordolibéraux]) 118-119; v. nature (- de droit, extrinsèque à la raison d'État) : 11, 12, 16; (- juridique de la puissance publique, de l'exercice du pouvoir politique) : 40, 45 101(s) 43 (la – dans l'État de droit) : 178 (– de nature) : 18 (– fondamentales du royaume) : 10

(individualisation de la pratique de la –) : 266 ; v. tribunaux force de loi, enforcement of law, « enforcement » de la loi : 259-264 Loi et ordre, Law and order : 80 logique de la connexion de l'hétérogène : 44 logique de l’homogénéisation du contradictoire : 44

« Main invisible » (théorie de l'impossibilité d'une souveraineté économique, récusation de l'État de police, disqualification d'une raison politique qui serait indexée à l'État et à sa souveraineté) [Adam Smith] : 286-290 Marché 33, 44, 45, 62 marché (le - : branchement d'un régime de vérité sur la pratique gouvernementale) : 38-39 (−, régulateur économique et social); 145 (−, lieu de connexion de l'échange et de l'utilité) : 45-46

(−, lieu de juridiction, de la justice distributive) : 32, 34, 45, 55

(−, lieu de véridiction : de formation de vérité, de vérité, principe de véridiction, de vérification-falsification) : 31-35, 46, 40 n. 5, 55; v. Condillac

(−concurrentiel, dans la contradiction entre concurrence et monopole) : 171 (−européen, indéfini, mondial) : 56, 57-58 (codification des pratiques du −, xvi-xvii° s.) : 20-21

(principe économique du - dissocié du principe politique du laissez-faire) : 137; v. néolibéralisme allemand

(régulation du −, principe régulateur économique de la société [économie néolibérale] : 90, 152 mécanismes compensatoires de la liberté (inflation des) : 70 mécanismes concurrentiels (rôle régulateur des - dans la Gesellschaftspolitik) : 151 ; (formalisation des -) : 169 mécanismes de juridiction : 36 mécanismes d'intervention économique : 71 mécanismes de sécurité/liberté, du jeu sécurité/liberté : 67 mercantilisme : 7, 34, 54 méthode du conditionnement gouvernemental exhaustif : 23 n* méthode du résidu juridique nécessaire et suffisant : 23 n* méthodes de transaction : 23 n. $ ^{*} $; v. libéralisme milieu

(-environnemental et formation du capital humain 236; v. migration, théorie du capital humain (variables du—): 273-274 monarchie administrative : 64 monopole

(action du – sur le mécanisme régulateur de l'économie, sur les prix) : 142-143 (instabilité du –, jeu de variables) : 142

(limite des possibilités du –: champ d'action mondial) [Mises et Rüstow après Bismarck] : 141

(paradoxe du – en régime libéral) : 139, 140-143; v. Mises, North, Röpke; vs. concurrence (principe du –) 140 monopole et concurrence (rapports de compatibilité) : 141-142 Nationalisme : 96 n. *; v. List nature:18,19,58,59 nature (application à la société d'un schéma de rationalité propre à la—) 119; v. technicisation nature et exercice de la gouvernementalité

néolibéralisme français (conditions : la Libération); (débuts du - :système de dissociation entre fonctions écono- miques et sociale- 7 néomarginalisme autrichien : 78, 81 norme (la) : 265 n.* Ordolibéral (programme), Ordnungstheorie : 100 n. 28 ; v. Eucken ordolibéraux (Ecole de Fribourg) : 107-109, 112, 113 ordre

(- concurrentiel régulateur de l'économie 147 ; v. concurrence, programme libéral

(-économico-juridique, au niveau des rapports de production) : 168 ; v. « système » (- naturel, xviiie s.): 168 ordre de l'économie (Wirtschaftsordnung), ordre économique à la fois principe et effet de sa propre régulation : 173; v. ordolibéralisme; vs. État de droit, Rule of law

Peuple
(communauté de - : national-socialiste)
115-16; v. conduction
physiocrates 16, 25, 55, 63

planisme (critique du –) [Röpke]: 101 n. 34, 131 n. 38 & n. 39; v. Beveridge, Göring, Rathenau, Schacht plein emploi (−, objectif des politiques de société en temps de crise) : 205 (− et interventionnisme d'État) : 81, 97 n. 10; v. politique sociale; Keynes

(politique(s)) (− de cadre) [Eucken] : 145-147

(− de « laisser faire ») :

(− économique « active », « vigilante » : 157-158 n. 14; (−économique protectionniste [List, après l'échec du Zollverein]; (associée à une économie keynésienne) [Rathenau] : 111-113

(− économique protectionniste) [List]

(− nationale et économie libérale : problème de compatibilité) 111

(− sociale ; objectif, dans une économie de bien-être : « relative péréquation dans l'accès de chacun aux biens consommables »): 147; v. bien-être, consommation socialisée, interventionnisme social; vs. inégalité; vs. Röpke (− sociale individuelle : la capitalisation 149; v. individualisation; (− sociale ordolibérale et politique sociale bismarckienne) 111; v. Brentano; (− sociale individuelle et espace économique 149; v. risque(s) (− sociale privatisée, de transfert) : 150 (− sociale et crise : la Sécurité sociale en France, prélèvement des charges sur la masse salariale 119, 131 n. 38, 193-195, 204-206, 216-217, n. 25-32; v./vs. plein emploi; v. Laroque (enjuice de la : 47, 57.

politique de société, Gesellschaftspolitik (ordolibérale : annulation des mécanismes concurrentiels) : 147-148, 151, 165-166, 166; (réponse à une situation de crise économique) : 203 politique de la vie, Vitalpolitik [Rüstow] 153, 164 n. 62, 248 politique et économie (bipolarité, dissymétrique entre -) 22 :v. art de gouverner pouvoir politique (exercice du – sur les principes d’une économie de marché) 137 pouvoir royal 10, 11 principe du laissez-faire déduit de l'économie de marché (libéralisme classique) : 123 principe économique du marché dissocié du principe politique du laissez-faire (ordolibéralisme) : 123 principe juridique d’État : 167 [ordolibéraux] ; v. cadre légal, interventionnisme juridique principe de l’utilité marginale : 186 n. 21 ; v. utilité protectionnisme économique : 111, 130 n. 31 ; v. List, Röpke « prix de proportion » : 49 « prix de rigueur » : 49

«prix naturel»:[Boisguilbert]:33 « prix normal » : 33 Radicalisme (Angleterre); v. droits originaires; v. utilitarisme, utilité raison d'État [selon les juristes] : 11 (nouvelle - ) 55 (- et État de police, différence d'objectifs) : 9-11 raison du moindre Etat 30 raison gouvernementale 13-16 (- moderne) 12 raison juridique 11 raison libérale 24 rationalité (— européenne : critique de l'excès de — [École de Francfort] : 37

(— irrationnelle de la société capitaliste : 109 ; v. Max Weber (nouvelle — économique : annulation de l'irrationalité sociale) [École de Fribourg] : 110 (nouvelle — rationalité sociale : annulation de l'irrationalité économique [École de Francfort] : 109 rationnel (application du − à des conduites non rationnelles, aux variables du milieu)

[néolibéralisme américain] : 273; v. milieu règle de jeu, du jeu (économique) entre règle de la concurrence et la protection de l'individu, p. ex : impôt négatif : 207208; v. Stoléru régulation du marché, et par le marché : 58

« régulation interne » (par « transaction » entre gouvernants et gouvernés) : 1214; v. agenda/non agenda révoltes urbaines 20 révolutionnaire (axiomatique) 43

Sagesse du prince (principe d'autolimitation de la pratique gouvernementale) et « justice équitable » ; 19-20, 22, 315 savoir économique [physiocrates] : 289 ; vs.

« main invisible » [Adam Smith] sécurité : 150; v. planisme, politique sociale situationnisme, critique situationniste : 117 & 132 n. 46 socialisme (-passage au -) [Schumpeter] : 182 (problème de la gouvernementalité adéquate au -) : 95 société capitaliste [selon Sombart] : 116117 ; vs. État national-socialiste société civile, cible et objet de la gouvernementalité étatique : 193 mentalité étatique : 193 société d'entreprise

(−, indexée non pas sur la marchandise et l'uniformité de la marchandise, mais sur la multiplicité et la différentiation des entreprises) : 155 [selon Röpke]: 153; v. Schumpeter, Sombart, Weber (− et renforcement de l'institution judiciaire : 155 (− et Vitalpolitik [Rüstow] : 153 (d'une société soumise à l'effet marchandise à une −) société de vitesse [Sombart] : 152 sécurité

(stratégies de −, envers et condition même du libéralisme) : 67 liberté et sécurité (jeu) 67; v. intérêt

« style économique », Wirtschaftssstil [Spiethoff] ; art de gouverner économique : 127 n. 15 style gouvernemental (problème du −) : v. monopole, actions conformes, politique sociale) 139

« système (le) » [Eucken], ordre économico-juridique [Rougier], au niveau des rapports de production : 169; vs. ordre naturel

« système économique », Wirtschaftssystem [Sombart] : 127 n. 15 système keynesien souverain/sujets (système d'obédience) : 4, 6, 10, 14 souveraineté politique (exercice de la ) : 3, 4 sujet(s)

(− de droit 278; (−, limitatif de l'exercice du pouvoir souverain) 296

(− d'intérêt 278; (− d'intérêt individuel et « main invisible ») : 282 ; v. théorie de la « main invisible »

(−économique) : 264 n. *; (−économique « actif ») [néolibéralisme américain] : 229 (irréductibilité du -économique au sujet de droit) : 280 (− naturels 266 n. * (théorie du −) [Locke] : 275 Techniques comportementales (intégration des - à l'économie) 273274 ; v. comportement théorie du capital humain (conception néolibérale américaine) :225-239 et 242 n. 27, 243 n. 35 théorie du droit (Wirtschaftsordnung, Rule of law) de l’État : 10, 173-176 ; vs. tri-

Ricardo par les néolibéraux) : 226-227 ;

tribunaux administratifs (programme ordolibéral) : 176, 181, 189 n. 38

Universaux (la question des - et de l'historicisme) : 4, 5, 26 n. 4 utilitarisme, philosophie utilitariste : 18, 43 utilité (calcul d'−): 53 (principe de l'– marginale) 186; v. Walras Véridiction ; v. marché vérité (-, partage du vrai et du faux) : 21, 22 (couplage série de pratiques - régime de -) : 22 vérité insulaires et autonomes (systèmes de) : 37 wébérisme de l'École de Fribourg et de l'École de Francfort : 109-110
