## Index des noms de personnes

Index des noms de personnes
Abeille (L.-P.) 28 n. 14
Adenauer (K.) 99 n. 19, 101 n. 33, 108, 153, 328
Aftalion (F.) 240, 241
Allais (M.) 185
Allo (E.) 329
Anderson (H.A.) 241
Argenson (R.-L. de Voyer Fd') 22, 25, 2
n. 10 n. 13, 28 n. 16 & n. 17, 96 n. *
q¢on ach\ aeg n^ ab
Attali (J.) 240 n. 1
Attlee (C.R.) 100 n. 29
Auboin (R.) 157 n. 7
Audegean (P.) 51 n. 10
Austin (J. L.) 269 n. 29
Baader 187
Badinter(R.)189
Bähr (O.) 188
Baldwin (J.W.) 49
Bark (D.L.) 99 n. 19, 101 n. 31, 102 n. 44-45
Barre(R.)214,215Bauchet(P.)216
Baudin (L.) 138, 156 n. 6
Bauer (C.) 126 n. 7
Bazard (A.) 133 n. 48
Beaud (M.) 241

eccaria (Cesare Bonesana) 40, 47, 50-51 n. 10, 253, 254, 255, 256, 259

Becker (G.) 226, 229, 232, 241 n.12, 242 n.19, n.20, n.23, n.25, 243 n.28, n.31, 253, 256 n.58, 258, 262, 268, 269, 270-274, 290 n.3 Beckerath (E. von) 126 n. 7, 161 n. 48 Begault (P.) 217 n.10,253,254,255,256,259 Benoist (A. de) 132 n. 42, 185 n. 5 Bensen(D.H.)312,320

Bentham (J.) 14, 25, 26-27 n. 9, 40, 51 n. 12, 68-69, 74 n. 25, 75 n. 27, 253, 254, 255, 256, 259, 268, 292 Berenson 77, 97 n. 1 & n. 2 Bernholz (P.) 268 Bertani (B.) 26 n. 8

Beveridge (W.) 114, 131 n. 38 & 39, 147, 150, 195-196, 201, 213 n. 4, 214 n. 5, 217 n. 25 & n. 27 Bidault (G.) 98 n. 15

Bilger (F.) 98 n. 13, 99 n. 17 & n. 18-19, 101 n. 31, 125 n. 1 & 2, 126 n. 3, 126 n. 3, 127 n. 14, 128, n. 16 & n. 20, 130 n. 30, 133 n. 52 & n. 54, 158 n. 17, n. 18, n. 19, 159 n. 30, n. 31, n. 33-34, 160 n. 35 & n. 38-40, 161 n. 41-42 & n. 47, 162 n. 52, 163 n. 55, 164 n. 61 & n. 62, 186 n. 9-11, 187 n. 16, 267, 335
