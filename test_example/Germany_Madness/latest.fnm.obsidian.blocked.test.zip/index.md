# 目录

- [1 Historical Problems: Sin, St. Vitus, and the Devil](chapters/001-1 Historical Problems Sin, St Vitus, and the Devil.md)
- [2 Two Reformers and a World Gone Mad: Luther and Paracelsus](chapters/002-2 Two Reformers and a World Gone Mad Luther and Paracelsus.md)
- [3 Academic "Psychiatry" and the Rise of Galenic Observation](chapters/003-3 Academic Psychiatry and the Rise of Galenic Observation.md)
- [4 Witchcraft and the Melancholy Interpretation of the Insanity Defense](chapters/004-4 Witchcraft and the Melancholy Interpretation of the Insanity Defense.md)
- [5 Court Fools and Their Folly: Image and Social Reality](chapters/005-5 Court Fools and Their Folly Image and Social Reality.md)
- [6 Pilgrims in Search of Their Reason](chapters/006-6 Pilgrims in Search of Their Reason.md)
- [7 Madness as Helplessness: Two Hospitals in the Age of the Reformations](chapters/007-7 Madness as Helplessness Two Hospitals in the Age of the Reformations.md)
- [Epilogue](chapters/008-Epilogue.md)
