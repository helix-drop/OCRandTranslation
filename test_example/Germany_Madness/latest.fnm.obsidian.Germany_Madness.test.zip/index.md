# 目录

- [Historical Problems: Sin, St. Vitus, and the Devil](chapters/001-Historical Problems Sin, St Vitus, and the Devil.md)
- [Two Reformers and a World Gone Mad: Luther and Paracelsus](chapters/003-Two Reformers and a World Gone Mad Luther and Paracelsus.md)
- [Academic “Psychiatry” and the Rise of Galenic Observation](chapters/004-Academic “Psychiatry” and the Rise of Galenic Observation.md)
- [Witchcraft and the Melancholy Interpretation of the Insanity Defense](chapters/005-Witchcraft and the Melancholy Interpretation of the Insanity Defense.md)
- [Court Fools and Their Folly: Image and Social Reality](chapters/006-Court Fools and Their Folly Image and Social Reality.md)
- [Pilgrims in Search of Their Reason](chapters/007-Pilgrims in Search of Their Reason.md)
- [Madness as Helplessness: Two Hospitals in the Age of the Reformations](chapters/002-Madness as Helplessness Two Hospitals in the Age of the Reformations.md)
- [Epilogue](chapters/008-Epilogue.md)
