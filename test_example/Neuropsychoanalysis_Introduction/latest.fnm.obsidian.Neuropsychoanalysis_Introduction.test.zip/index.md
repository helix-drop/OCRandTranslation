# 目录

- [Introduction](chapters/001-Introduction.md)
- [Self and narcissism](chapters/002-Self and narcissism.md)
- [Attachment and trauma](chapters/003-Attachment and trauma.md)
- [Defense mechanisms and dissociation](chapters/004-Defense mechanisms and dissociation.md)
- [Cathexis and free energy](chapters/005-Cathexis and free energy.md)
- [Unconscious and conscious](chapters/006-Unconscious and conscious.md)
- [Dreams](chapters/007-Dreams.md)
- [Schizophrenia and depression](chapters/008-Schizophrenia and depression.md)
- [Conclusion](chapters/009-Conclusion.md)
