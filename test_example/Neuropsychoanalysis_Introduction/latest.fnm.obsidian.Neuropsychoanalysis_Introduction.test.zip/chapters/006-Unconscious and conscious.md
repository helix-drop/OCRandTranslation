## Unconscious and conscious

Unconscious and conscious

Introduction

Freud introduced the unconscious into psychology. While others like Arthur Schopenhauer and Friedrich Nietzsche had already thematized the unconsciousness in philosophy, Freud was the first to investigate it in a systematic and empirical (taken in a broad definition) way. For him the unconscious consists in innate, inherently sexual, and aggressive blind drives – we have no control over these drives. They are instinctual, non-rational, and strongly affective–emotional – psychoanalysis speaks therefore of primary process – this amounts to what Freud describes as “dynamic or repressed unconscious”.

More recently these primary processes have been associated with mainly subcortical regions and their various subcortical primary emotion systems like rage, seeking, fear, panic, care, play, and lust (Panksepp 1998; Solms 2015; Panksepp and Biven 2012). Mark Solms therefore associates these subcortical emotional systems with the dynamic unconscious and its Id (Solms 2015). The primary emotions remain largely unconscious, and we have barely access to them; they are evolutionarily imprinted, so we as humans share them with our ancestors, the non-human species (Panksepp 1998).

Freud’s concept of the dynamic unconscious has also been associated with the notion of the unconscious in psychology and cognitive neuroscience. Here, the unconscious has been associated with various functions like cognition, affect, behavior, memory, and so on—concepts like “cognitive unconscious” (Kihlstroem 1987), “emotional unconscious” (Kihlstroem et al. 1992), “behavioral unconscious”, “cognitive unconscious” (Uleman 2005), and “procedural unconscious” Schuessler 2002) (as well as various others). In this more cognitive context, the unconscious is associated with a particular function and its respective content, a cognitive content in the cognitive unconscious, an affective content in the emotional or affective unconscious, a motor content in the procedural unconscious, and so on.

Given the prominence of contents in this more cognitive form of unconscious as it prevails in current psychology and neuroscience, I speak of a “content-based unconscious” that signifies the unconscious in traditional psychology. The only difference of these content-based forms of the unconscious to the conscious is that these contents are not yet actually conscious but may occur and be possible at any time. What is called unconscious in current psychology and neuroscience, that is, content-based unconscious, may therefore resemble more what Freud and psychodynamics refer to as preconscious, as both include contents that may or may not become conscious.

The fact that these more recent cognitive notions of the unconscious are content based and entail the possibility of contents becoming conscious distinguishes them from Freud's concept of the dynamic unconscious. The dynamic unconscious is neither focused on specific content nor necessarily includes their possibility of becoming conscious. Instead, the Freudian concept of dynamic unconscious is, as in its name, focused on the dynamic, namely psychodynamic, that may or may not go along with specific contents.

As it extends beyond contents to dynamic, the dynamic unconscious covers a much broader and richer range than the current content-based unconscious. In order to relate the dynamic unconscious to the brain, we need to go beyond the neural correlates of conscious vs unconscious contents. We need to extend our view to a deeper layer of the brain's neural activity, its topography and dynamic. This is the main focus in this chapter: how the Freudian concept of the dynamic unconscious in terms of topography and dynamic relates to a more or less analogous topography and dynamic of the brain's neural activity.

Part I: preconscious and repression

Early vs late stimulus-induced activity – phenomenal and access consciousness

Within the context of neuroscience, consciousness is typically associated with specific contents. What is described as “neural correlates of consciousness” (NCC) (Koch 2004) indexes the neural features underlying the phenomenal experience of contents, the “what it is like” as the qualitative experience (“redness of red”). Such phenomenal consciousness is distinguished from becoming aware of the phenomenal experience as such – this is described as reflective or access consciousness (Block 2005; Northoff and Lamme 2020).

What are neural correlates of phenomenal and access consciousness? These are related to stimulus-induced or task-related activity including its early and late components. The bulk of the neuroscientific theories of consciousness like integrated information theory (IIT) (Tononi et al. 2016), global neuronal workspace theory (GNWT) (Mashour et al. 2020), recurrent processing theory (RPT) (Lamme 2018), and higher-order theory (HOT) (Lau and Rosenthal 2011), have focused on stimulus-induced or task-related activity.

They focus on various measures and particular regions. The IIT postulates that early changes like N100 and complexity (as measured by Lempel Zev complexity) in posterior cortical regions are key to contents becoming conscious in the sense of phenomenal consciousness, while others like HOT and GNWT postulate that later signs like P300 in prefrontal cortex are necessary for conscious contents – this has been related to reflective or access consciousness (Northoff and Lamme 2020). Without going into detail about these various measures and theories (see Northoff and Lamme 2020 for a recent detailed overview), we can see that the distinction of early (0–150 ms) and late (300–600 ms) stimulus-induced or task-related activity is associated with distinct forms of consciousness, that is, phenomenal and reflective/access consciousness.

Prestimulus activity shapes the contents of consciousness

The current neuroscientific discussion on consciousness focuses largely on stimulus-induced activity, including its early vs late components, the neural correlates of consciousness. This is well reflected in the prominence of GNWT, IIT, RPT, and HOT in the current discussion (Northoff and Lamme 2020). However, recent data show that stimulus-induced activity by itself cannot be exclusively related to consciousness. The activity prior to the stimulus, the prestimulus activity, has also been shown to play a key role in contents becoming conscious or, alternatively, remaining unconscious.

Various studies describe the impact of prestimulus activity levels on the contents and the level or state, that is, arousal of consciousness in both fMRI, EEG/MEG or single unit activity. Concerning the contents, fMRI studies showed that if the level of prestimulus activity in the fusiform face area (FFA) is high, subjects will perceive the stimulus as a face, whereas low prestimulus activity in FFA will bias subjects towards perceiving the same stimulus as a vase (Hesselmann et al. 2008; Sadaghiani et al. 2010).

The prestimulus power and phase synchrony of alpha oscillations (8–13 Hz) in the EEG strongly impacts whether one perceives a visual stimulus (Benwell et al. 2017; Dijk et al. 2008; Romei et al. 2010; Wolff et al. 2019). Other frequencies in the prestimulus period like slow cortical potentials (0.1 to 1 Hz) and delta, theta, and beta power, but also prestimulus functional connectivity, impact subsequent stimulus-related activity and its association with consciousness (Baria et al. 2017; Benwell et al. 2017; Podvalny et al. 2019; Sadaghiani et al. 2015, 2010). Finally, a recent MEG study demonstrates that prestimulus activity not only mediates specific contents of consciousness (as prestimulus activity levels predicted the subsequent contents) but also a more general process related to arousal (as indexed by pupil size) (Podvalny et al. 2019).

Prestimulus activity and preconscious

Together, these findings suggest that we need to broaden the concept of neural correlates of consciousness beyond the stimulus-induced activity itself. This has been described in neuroscience by the “neural prerequisites of consciousness” (NCC pre) (Aru et al. 2012; de Graaf et al. 2012; Northoff and Heiss 2015), namely those neural features that enable consciousness but are not by themselves sufficient for it, while psychologically, we suppose that the prestimulus activity dynamics is closely related to what Freud described as “preconscious”.

The preconscious includes those contents that can become conscious while not yet being actually conscious. The recent data show that prestimulus activity and its dynamic are key in mediating the transition from unconscious to conscious contents: if the prestimulus dynamic is in the “right” configuration and encounters the “right” external input, the respective content can become conscious. If, in contrast, the prestimulus activity shows the “wrong” dynamic configuration and/or encounters the “wrong” external input, the respective content will remain within the preconscious (or remain unconscious in the sense of content-based unconscious).

How can we further characterize the contents of such a prestimulus-based preconscious? These contents that are not yet actually conscious but can in principle become conscious – they reflect what is described as “cognitive unconscious” (Kihlstroem 1987), “emotional unconscious” (Kihlstroem et al. 1992), “behavioral unconscious” (Uleman 2005), and “procedural unconscious” Schuessler 2002). These are specific contents like memories of a particular event, specific emotions, or movement pattern during dancing that are not consciously experienced but remain unconscious. Importantly, the very same contents can, at any point in time, become conscious given the “right” circumstances: psychologically, this may refer to certain life events triggering the recall of those events in memory, while neuronally we suppose that prestimulus activity levels may play a key role here.

The impact of prestimulus activity on the contents of consciousness can be compared to the situation of a surfer riding on the ocean’s waves. The ocean’s waves can be characterized by power, high or low, speed/frequency, that is, slow or fast, and their phase angles, that is, sharp or smooth. The surfer staying afloat (conscious, in this metaphor) depends both on the activity of the surfer (stimulus-related activity), as on the waves of the ocean (prestimulus or ongoing activity). Specifically, the surfer (= stimulus-related activity) needs to adapt and integrate her/himself to the power, the speed/frequency, and the phase angle of the waves. Only if the two interact in a meaningful way does the surfer become “part of the waves” and stay erect (this showing consciousness).

In the same way, an external stimulus has to interact with ongoing activity such that the two get integrated into the current stream of consciousness. The external stimulus needs to be integrated within the power, the frequency/speed, and the phase of the ongoing spontaneous activity as measured in the prestimulus period. If the external stimulus is not integrated at all, it will not become conscious. This may occur, for instance, when a specific external stimulus “arrives” at the “wrong” point in time, like low power, too slow speed, and low excitable phase angle (like the peak rather than the trough; Huang et al. 2017) – the external stimulus may be processed but remain unconscious (“reception without perception”; Hudetz et al. 2015).

Repression and prestimulus dynamic – blocking access to the conscious

One of the key features of Freud's and others' psychodynamic view of consciousness is repression. There is an active repression mechanism. Freud assumed that this active repression mechanism is exerted by the conscious itself as it suppresses the conscious emergence of those contents of the Id threatening the ego. What exactly is repressed or inhibited? Following Freud, both action and language of the represented material that is its contents are repressed: "A representation which is not put into words, or a psychical act which is not hypercathected, remains thereafter in the unconscious" (Freud 1915, 186).

Psychologically, repression as feature of the dynamic unconscious can be tested by subliminal priming. Subliminal priming and processing allow probing for semantically meaningful association between contents that remain completely unconscious. This has been demonstrated for memory, language, motor action/control, and emotion and affect. The contents of these various function can all be suppressed or inhibited such that they cannot be put into action, words, or emotion by which they can enter the conscious. Instead, being blocked from moving to the conscious, they remain unconscious. That becomes especially strong in neurosis and its various symptoms that can be understood as “return of the repressed”, which now comes to the forefront in an indirect way, that is, through abnormal affective and cognitive function.

This line has been followed and extended to neuroscience more recently by Bazan (2012, 2017) and Shevrin (Shevrin et al. 2013). They suppose that, neuronally, the alpha power is associated with repression. When, for instance, shifting from prestimulus and/or rest states to task states, the degree of alpha power decreases. That has been shown for subliminal priming and unconscious material (Shevrin et al. 2013) – decrease or suppression of alpha power may therefore be key in repressing conflictual experience such that they cannot enter the conscious. Accordingly, alpha power being key in mediating the transition from rest or prestimulus to task states may modulate the transition from the unconscious contents of the preconscious to the conscious contents of phenomenal (and ultimately access or reflective) consciousness (Bazan 2012, 2017; Shevrin et al. 2013).

These data on alpha and repression are well in accordance with the observation that prestimulus alpha levels do indeed strongly impact whether a subsequent content becomes conscious or not (Benswell et al. 2017). Hence, alpha may indeed serve a strong neural candidate that “gates” the transition from the preconscious to the conscious. If the alpha gate “does not open”, the respective content remains preconscious and does not become conscious – it is thus “repressed”. If, in contrast, the alpha gate is opened by lowering alpha power, the preconscious content can become conscious and is no longer “repressed”.

Accordingly, what psychodynamically is described as repression may, tentatively hypothesized, correspond neuronally to the level or degree of prestimulus alpha power: how the latter is modulated, that is, decreased by the actual content of the preconscious may “decide” whether the “alpha gate” “releases” the content from its repression by “opening” the gate for the content to become conscious.

Part II: dynamic unconscious and nestedness

Temporal nestedness of stimulus-related activity within prestimulus and spontaneous activity

Prestimulus activity is just a short interval prior to the onset of the stimulus. As such, it reflects the ongoing dynamic of the brain's spontaneous activity as it can be measured in what is described as a "resting state", that is, the absence of any specific external input or stimuli. Various studies demonstrate that the resting state and thus spontaneous activity is by itself related to the level or state of consciousness.

Studies in altered states of consciousness like sleep, anesthesia or unresponsive wakefulness state (UWRS), or psychedelics show that changes in the level or state of consciousness go along with dynamic changes in the brain's spontaneous activity. For instance, the power of the slower frequencies becomes abnormally strong with weaker faster frequencies when one losses consciousness (Northoff and Lamme 2020 for overviews), while the opposite, with more power in the faster frequencies, can be observed when consciousness is enhanced, as during psychedelics (Northoff et al. 2020a, 2020b).

This can be measured by the power spectrum and especially its shape as it is operationalized by the power law exponent. Roughly, the PLE describes the shape or slope of the curve of the power spectrum with a steep decline from the strong power of slower frequencies to the weaker power of faster frequencies. This means that the weaker faster frequencies (with their shorter cycle durations) are nested and contained within the stronger slower frequencies (and their longer cycle durations). Changes in the slope of the power spectrum with altered balances towards either slower or faster frequencies thus entail shift in the slow–fast temporal dynamic including their degree of temporal nestedness.

The temporal nestedness of the power spectrum is also changed during the transition from resting state to stimulus-related activity. Stimulus-related activity induces a shift in the power spectrum towards enhancing the power of faster frequencies as measured by a decrease in the PLE (the curve of slow–fast frequencies is less steep). One can consequently say that stimulus-related activity is nested temporally within prestimulus activity which, in turn, is nested within the brain's resting state or spontaneous activity. Moreover, the data on altered states of consciousness (see previously and Northoff and Lamme 2020) strongly suggest that such temporal nestedness of stimulus-related activity within spontaneous activity is key for consciousness.

Neural correlates of consciousness and neural predispositions of consciousness

The data suggest that stimulus-related, prestimulus, and resting state activity take on different roles for consciousness. Measures of stimulus-related activity like P300 and Lempel Zev complexity (LZC) (and others; Northoff and Lamme 2020) are presumed to be sufficient neural correlates of either the phenomenal aspects of consciousness (NCC proper; Koch et al. 2016) or its cognitive aspects (by some called the consequences of consciousness: NCCcon; Aru et al. 2012). This distinguishes them from measures of prestimulus activity like prestimulus activity amplitude, synchrony, variability, or power spectrum that are supposed to enable consciousness (neural prerequisites of consciousness: preNCC; Aru et al. 2012, which used NCCpre as original transcription).

NCC and preNCC leave open more or less the role of the spontaneous activity as measured in resting state. Various studies in both healthy and neurologic/psychiatric subjects demonstrate involvement of spontaneous activity in consciousness (see previously). Its exact role remains unclear, though. Spontaneous activity by itself, that is, independent of specific stimuli or tasks as processed in stimulus-related or task-related activity, is not sufficient for the contents of consciousness. Becoming conscious of specific contents requires additional stimulus-related activity or, at least, neuronal changes in the resting state analogous to the former, amounting to "virtual" stimulus-related activity (Zhang et al. 2019, 2020).

Together, these and other findings (see previously) led to the assumption that spontaneous activity provides the necessary but not sufficient neural conditions of consciousness. Spontaneous activity provides the neural capacity or neural predisposition of consciousness

(NPC) (Northoff 2018; Northoff and Huang 2017; Northoff and Heiss 2015). Such a neural predisposition or capacity makes consciousness possible while not realizing its actual manifestation: in the absence of such a neural predisposition, consciousness will become altogether impossible, while its presence does not automatically guarantee the manifestation of actual consciousness (as additional neuronal mechanisms, that is, NCC, are required for that).

Dynamic unconscious – dynamic and topography

Spontaneous activity itself is not sufficient for consciousness while, at the same time, being necessary for it as neural predisposition. This suggests that spontaneous activity plays a key role in the unconscious, specifically, the dynamic unconscious. Roughly, giving a loose definition, the dynamic unconscious refers to the dynamic of mental contents and particular affective-cognitive constellations: these are related to the individual person or self but cannot be accessed as such by the person in their consciousness. Moreover, the mental contents and their affective constellations can change over time depending on the persons' life events and their perception of them. In other terms, one can speak of mental dynamic that as such remains largely unconscious entailing the "dynamic unconscious".

How can we support our assumption that the dynamic unconscious, as determined in psychoanalysis, is related to the neuronal dynamic of the brain’s spontaneous activity? Presupposing shared features of neural and unconscious activity, that is, “common currency” (Northoff et al. 2020a, 2020b), we assume they share their dynamic: the changes of unconscious contents and their affective-cognitive constellations may be related to (and thus shared by) a more or less corresponding temporal dynamic in neural activity. Let us provide a more concrete example.

We saw that the brain’s neural activity in characterized by a scale-free balance in the power of slow and fast frequencies, that is, the power law exponent. One would now assume that an analogous balance of slow and fast frequencies structures the unconscious contents, including their duration and changes. If, for instance, the brain’s slow frequencies are very powerful, one would expect more longer durations in the unconscious contents with less change in more or less corresponding frequency ranges, while predominance of the faster frequencies in the brain's power spectrum should be manifest in unconscious contents of shorter duration and increased change (see Vanhaudenhuyse et al. 2011; Hua et al. 2021 for first support). This went topographically with different balances in the relationship of default-mode network and visual network (Vanhaudenhuyse et al. 2011).

In sum, the dynamic unconscious may be based on the brain's temporal dynamic and its spatial topography. Both may feature nestedness in temporal terms like slow-fast balance in the power spectrum as well as by nestedness in spatial terms like small-world organization with core-periphery organization in topography (Northoff and Huang 2017; Golesorkhi et al. 2021a, 2021b). Rather than by specific contents as consciousness, the dynamic unconscious may then primarily be determined more by its topography and dynamic that, as we assume, are shared by brain and unconscious, that is, "common currency".

Topography and dynamic – nestedness on neuronal and psychological levels

We saw nestedness throughout this chapter. Different forms of neural activity like early and late stimulus-induced activity, prestimulus activity, and resting state activity are contained and nested within each other. They can be distinguished according to the spatiotemporal scales on which they operate: resting state activity includes the largest space-time scale, whereas late stimulus-induced activity operates on a much smaller scale.

Nestedness can also be seen in the brain's spatial topography. We have seen in the previous chapter that global brain activity can differentiate itself in distinct regions, with the latter's local activity thus nesting within the former's more global activity. This can also be seen in the small world organization of the brain and its core-periphery structure. Such nestedness on the spatial-topographic side is complemented by nestedness on the temporal side: the high power of slower frequencies nests and contains the lower power of faster frequencies. Hence, one can speak of temporo-spatial nestedness.

Just like different Russian dolls contain different scales, the different layers of the brain’s spatial topography and temporal dynamic are nested within each other according to their temporo-spatial scales.

Based on the empirical evidence presented previously, I now propose that such temporo-spatial nestedness of the various layers of the brain's neural activity is associated with corresponding layers of unconscious/consciousness on the psychological side. I speak of a nested hierarchy with different layers. The bottommost layer consists in the deep unconscious, followed by the dynamic unconsciousness, which, in turn, nests and contains the preconscious and the conscious.

It was one of the major insights of Freud to have recognized this more extended framework of the unconscious-conscious on the psychological level. This, albeit tentatively, can now be extended to the neuronal level of the brain and its temporo-spatial nestedness of both its topography and dynamic. Unconscious-conscious are consequently primarily spatial-topographic and temporal-dynamic features, as postulated in the temporo-spatial theory of consciousness (TTC) (Northoff and Huang 2017; Northoff and Lamme 2020; Northoff and Zilio 2021). Temporo-spatial nestedness thus provides the link if not a shared feature of brain and consciousness/unconsciousness.

Conclusion

Consciousness and unconscious are not homogenous entities but may instead be conceived as highly heterogeneous and multifaceted processes, with different layers of neuronal activity nesting within each other (Northoff and Huang 2017; Northoff and Lamme 2020; Northoff and Zilio 2021). The concept of layers is used throughout this chapter to indicate nestedness: in the same way different Russian dolls nest within each other, that is, the smaller one is nested or contained within the next larger one, consciousness and the brain's neural activity are supposed to be characterized by different layers that contain and nest within each other.

Nestedness in this sense applies to both phenomenal and neuronal levels, that is, consciousness/unconsciousness and brain. That carries the consequence that the nested organization of the brain's neural activity may be related to and ultimately surface in a more or less analogous nested organization of conscious and unconscious as signified by different temporal and spatial scales. Temporo-spatial nestedness may consequently provide a “common currency” of brain and consciousness, that is, neuronal and phenomenal levels (Northoff et al. 2020a, 2020b), as postulated in the temporo-spatial theory of consciousness (Northoff and Huang 2017; Northoff and Zilio 2021).

In conclusion, we suppose that the “common currency” approach provides the key to address the “hard problem”, that is, the question of why and how there is consciousness as distinct from the physical world and the brain (Chalmers 1996; Solms 2019; Northoff 2018). Because the brain exhibits a particular dynamic and topography, it predisposes and can actually manifest consciousness. It was the genius of Freud who foresaw such dynamic and topographic determination of conscious—unconscious on the level of the psychic that now can be extended to the brain, that is, its topography and dynamic. Topography and dynamic of neural activity as the brain’s inside or “deep interior” (as the philosopher Thomas Nagel says; 1998) make possible and realize the different layers of unconscious and conscious as so well described by Freud and others in psychoanalysis.

not objective visual performance. eNeuro. 4. https://doi.org/10.1523/ENEURO.0182-17.2017

Block N (2005) Two neural correlates of consciousness. Trends in Cognitive Sciences. 9:46–52. https://doi.org/10.1016/j.tics.2004.12.006

Chalmers D (1996) The conscious mind. Oxford University Press, Oxford, New York.

de Graaf TA, Hsieh PJ, Sack AT (2012) The “correlates” in neural correlates of consciousness. Neurosci Biobehav Rev. Jan;36(1):191–197. doi:10.1016/j.neubiorev.2011.05.012. Epub 2011 Jun 1.

Dijk H van, Schoffelen J-M, Oostenveld R, Jensen O (2008) Prestimulus oscillatory activity in the alpha band predicts visual discrimination ability. J. Neurosci. 28:1816–1823. https://doi.org/10.1523/JNEUROSCI.1853-07.2008

Freud S (1915) The unconscious (SE, Vol. 14, pp. 166–204). Hogarth Press, London.

Golesorkhi M, Gomez-Pilar J, Tumati S, Fraser M, Northoff G (2021a) Temporal hierarchy of intrinsic neural timescales converges with spatial core-periphery organization. Commun Biol. Mar 4;4(1):277. doi:10.1038/s42003-021-01785-z

Golesorkhi M, Gomez-Pilar J, Zilio F, Berberian N, Wolff A, Yagoub MCE, Northoff G (2021b) The brain and its time: Intrinsic neural timescales are key for input processing. Commun Biol. Aug 16;4(1):970. doi: 10.1038/s42003-021-02483-6

Hesselmann G, Kell CA, Eger E, Kleinschmidt A (2008) Spontaneous local variations in ongoing neural activity bias perceptual decisions. PNAS. 105:10984–10989. https://doi.org/10.1073/pnas.0712043105

Hua J, Zhang Y, Wolff A, Northoff G (2021) Thought dynamics is mediated by alpha and theta peak frequency. Nature Communication Biology, in press.

Huang Z, Zhang J, Longtin A, Dumont G, Duncan NW, Pokorny J, Qin P, Dai R, Ferri F, Weng X, Northoff G (2017) Is there a nonadditive interaction between spontaneous and evoked activity? Phase-dependence and its relation to the temporal structure of scale-free brain activity. Cereb Cortex. 27:1037–1059. https://doi.org/10.1093/cercor/bhv288

Hudetz AG, Liu X, Pillay S (2015) Dynamic repertoire of intrinsic brain states is reduced in propofol-induced unconsciousness. Brain Connect. 5:10–22. https://doi.org/10.1089/brain.2014.0230

Kihlstroem J (1987) The cognitive unconscious. Science. 237:1445–1452

Kihlstroem JE, Barnhardt T, Tataryn D (1992) The psychological unconscious: Found, lost and regained. American Psychologist. 47(6):788–791.

Koch C (2004) Consciousness. Oxford University Press, Oxford, New York.

Koch C, Massimini M, Boly M, Tononi G (2016) Neural correlates of consciousness: Progress and problems. Nat. Rev. Neurosci. 17:307–321. https://doi.org/10.1038/nrn.2016.22

Lamme VAF (2018) Challenges for theories of consciousness: Seeing or knowing, the missing ingredient and how to deal with panpsychism. Phil. Trans. R. Soc. B 373:20170344. https://doi.org/10.1098/rstb.2017.0344

Lau H, Rosenthal D (2011) Empirical support for higher-order theories of conscious awareness. Trends Cogn Sci. Aug;15(8):365–373. doi:10.1016/j.tics.2011.05.009. Epub 2011 Jul 6.

Mashour GA, Roelfsema P, Changeux JP, Dehaene S (2020) Conscious processing and the global neuronal workspace hypothesis. Neuron. Mar 4;105(5):776–798. doi: 10.1016/j.neuron.2020.01.026

Nagel T (1998) Conceiving the impossible and the mind-body problem. Philosophy. 73:337–352.

Northoff G (2018) The spontaneous brain: From the mind-body to the world-brain problem. MIT Press, Cambridge, MA.

Northoff G, Heiss WD (2015) Why is the distinction between neural predispositions, prerequisites, and correlates of the level of consciousness clinically relevant?: Functional brain imaging in coma and vegetative state. Stroke. Apr;46(4):1147–1151. doi: 10.1161/STROKEAHA.114.007969. Epub 2015 Feb 10.

Northoff G, Huang Z (2017) How do the brain’s time and space mediate consciousness and its different dimensions? Temporo-spatial theory of consciousness (TTC). Neurosci Biobehav Rev. 80:630–645. https://doi.org/10.1016/j.neubiorev.2017.07.013

Northoff G, Lamme V (2020) Neural signs and mechanisms of consciousness: Is there a potential convergence of theories of consciousness in sight? Neurosci Biobehav Rev. Nov;118:568–587. doi: 10.1016/j.neubiorev.2020.07.019. Epub 2020 Aug 9.

Northoff G, Wainio-Theberge S, Evers K (2020a) Is temporo-spatial dynamics the “common currency” of brain and mind? In quest of “spatiotemporal neuroscience”. Phys Life Rev. Jul;33:34–54. doi: 10.1016/j.plrev.2019.05.002. Epub 2019 May 23.

Northoff G, Wainio-Theberge S, Evers K (2020b) Spatiotemporal neuroscience: What is it and why we need it. Phys Life Rev. Jul;33:78–87. doi:10.1016/j.plrev.2020.06.005. Epub 2020 Jul 10.

Northoff G, Zilio F (2021) Temporo-spatial theory of consciousness (TTC): From neuronal to phenomenal features. Behavioral Brain Research. in press.

Panksepp J (1998) Affective neuroscience. Oxford University Press, Oxford, New York.

Panksepp J, Biven L (2012) The archaeology of mind. Norton Publisher, New York.

Podvalny E, Flounders MW, King LE, Holroyd T, He BJ (2019) A dual role of prestimulus spontaneous neural activity in visual object recognition. Nature Communications. 10:1–13. https://doi.org/10.1038/s41467-019-11877-4

Romei V, Gross J, Thut G (2010) On the role of prestimulus alpha rhythms over occipito-parietal areas in visual input regulation: Correlation or causation? J. Neurosci. 30:8692–8697. https://doi.org/10.1523/JNEUROSCI.0160-10.2010

Sadaghiani S, Hesselmann G, Friston KJ, Kleinschmidt A (2010) The relation of ongoing brain activity, evoked neural responses, and cognition. Front Syst Neurosci. 4. https://doi.org/10.3389/fnsys.2010.00020

Sadaghiani S, Poline J-B, Kleinschmidt A, D'Esposito M (2015) Ongoing dynamics in large-scale functional connectivity predict perception. PNAS. 112:8463–8468. https://doi.org/10.1073/pnas.1420687112

Schuessler G (2002) Aktuelle Konzepte des Unbewussten. Zeitschrift fuer Psychosomatische Medizin und Psychotherapy. 48:192–214.

Shevrin H, Snodgrass M, Brakel LA, Kushwaha R, Kalaida NL, Bazan A (2013) Subliminal unconscious conflict alpha power inhibits supraliminal conscious symptom experience. Front Hum Neurosci. Sep 5;7:544. doi: 10.3389/fnhum.2013.00544. eCollection 2013.

Solms M (2015) The feeling brain. Routledge, London, New York.

Solms M (2019) The hard problem of consciousness and the free energy principle. Front Psychology. Jan 30;9:2714. doi: 10.3389/fpsyg.2018.02714. eCollection 2018.

Tononi G, Boly M, Massimini M, Koch C (2016) Integrated information theory: From consciousness to its physical substrate. Nature Reviews Neuroscience. 17:450–461. https://doi.org/10.1038/nrn.2016.44

Uleman JS (2005) Introduction: Becoming aware of the new unconscious. In: The unconscious (pp. 1–12), G Hassin, JS Uleman. MIT Press, Cambridge, MA.

Vanhaudenhuyse A, Demertzi A, Schabus M, Noirhomme Q, Bredart S, Boly M, Phillips C, Soddu A, Luxen A, Moonen G, Laureys SJ (2011) Two distinct neuronal networks mediate the awareness of environment and of self. Cogn Neurosci. Mar;23(3):570–578. doi: 10.1162/jocn.2010.21488. Epub 2010 Jun 1.

Wolff A, Yao L, Gomez-Pilar J, Shoaran M, Jiang N, Northoff G (2019) Neural variability quenching during decision-making: Neural individuality and its prestimulus complexity. Neuroimage. 192:1–14. https://doi.org/10.1016/j.neuroimage.2019.02.070 Zhang J, Huang Z, Tumati S, Northoff G (2020) Rest-task modulation of fMRI-derived global signal topography is mediated by transient coactivation patterns. PLoS Biol. July 10;18(7):e3000733. doi: 10.1371/journal.pbio.3000733. eCollection 2020 July.

Zhang J, Magioncalda P, Huang Z, Tan Z, Hu X, Hu Z, Conio B, Amore M, Inglese M, Martino M, Northoff G (2019) Altered global signal topography and its different regional localization in motor cortex and hippocampus in mania and depression. Schizophr Bull. Jun 18;45(4):902–910. doi:10.1093/schbul/sby138
