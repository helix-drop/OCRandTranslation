## 1 Self and narcissism

### Part I: spatial topography – nestedness as “common currency” of brain and self

### Topography mediates the transition from brain to psyche – spatial layers and nested hierarchy

### Topography of self I – interoceptive layer and the inner bodily self

### Topography of self II – exteroceptive and mental layers

### Topography of brain and ego – spatial nestedness as their “common currency”

### Dynamic of the brain – operation across different timescales in a scale-free way

### Part II: temporal dynamic – scale-freeness as “common currency” of brain and self

### The dynamic of self – the brain’s long-range temporal correlations shape the self

### Memory and self I – temporal vs cognitive memory

### Memory and self II – scale-freeness as “common currency”

objective features of self, namely that which is shared among all subjects. Psychoanalysis, in contrast, tends to take into view more the intra-psychic, inter-subjective, and subjective features of self:

In short, they (neuroscience and psychology) concern themselves with the universal and objective. Psychoanalysis, which has historically focused on the individual (rather than the universal) and has been interested more in ontology (rather than the empirical), has as its goal the understanding of protracted intrapsychic, interpersonal, and subjective functioning of the individual. (Milrod 2002, 22–23)

The present chapter aims to connect subjective (as in psycho-analysis as the subjective core of the ego) and objective (as in neuroscience with objective neural correlates) features of self. For that, topography and dynamics are assumed to provide the bridge – spatial topography and temporal dynamics provide the shared feature or “common currency” of objective brain and subjective self. The first part will focus on the spatial topography of self as complemented by the temporal dynamics of self in the second part. The third part will focus on narcissism and its recent findings in neuroscience.

Part I: spatial topography – nestedness as “common currency” of brain and self

Topography mediates the transition from brain to psyche – spatial layers and nested hierarchy

Topography refers to a particular spatial organization or structure of brain and psyche. One key feature of their topographies are hierarchies. Hierarchies have been postulated in both neuroscience and psychoanalysis. They may thus offer insight into the intimate connection of, for instance, brain and self. The English neurologist Hughling Jackson early on proposed a three-layer hierarchy of the brain's regions with lower, middle, and higher centers that were assumed to be associated with different psychological functions (see Wiest 2012 for an overview). More recently, Panksepp (1998, 2012) conceived the brain's subcortical–cortical organization and associated its different layers with different levels of emotions (like primary, secondary, and tertiary emotions) (see also Northoff et al. 2011). Extending the limbic system to the cortical level, Northoff (Northoff et al. 2011) pursued a more radial-concentric approach with three layers of self, that is, bodily, affective, and cognitive. We will see that, together with the recent data, this supports the idea of a spatially nested hierarchy of self based on the brain's radial-concentric cortical organization.

A clearly hierarchical organization of self (the term is used here in a broader sense) that embeds and contains the concept of ego has also been proposed in psychology/psychoanalysis by Freud. For instance, Kernberg (1984) noted how Freud preserved the Ego not only as a mental structure and psychic agency but also as the subjective experiential self in all his writings. Freud suggested the Id to be the lowest level of the topography of the psyche that remains essentially unconscious but nevertheless strongly influences the upper levels of the Ego and the Super-ego.

Together, this amounts to a nested hierarchy of self where the lower layer somewhat resurfaces within the next upper layer and so forth (see also Wiest 2012). While Freud's rigid three-layer partition was criticized later by others, the multi-facedness of self with its sense of subjectivity permeating across its bodily, affective, and cognitive layers remains a key feature in both neuroscience and psychoanalysis. We will demonstrate that the model of a nested hierarchy of self is strongly supported by recent neuroscience in both its spatial and temporal aspects – therefore, we characterize the neural and psychological hierarchy of self by spatial and temporal nestedness.

Topography of self I – interoceptive layer and the inner bodily self

A recent large-scale meta-analysis in healthy subjects by Qin et al. (2020) investigated and analyzed different imaging studies that focused on different aspects of self, inner body (interoceptive), outer body (extero-proprioceptive), and own cognitive or mental states. They observed different regions to be associated with each of the three layers; at the same time, there was regional overlap, as the regions of the lower layer were included within the next upper layer.

(see subsequently for details). Together, this amounts to a spatial multi-layered nested hierarchical model of self (Qin et al. 2020), including (i) interoceptive self, (ii) extero-proprioceptive self, and (iii) mental self. This shall be detailed in the following.

The interoceptive self refers to how the brain process the body's inner organs and their inputs, resulting in our perception of our own inner body. This can be investigated through fMRI task studies that measure interoceptive awareness of one's own body, including cardio-respiratory awareness and urogenital and gastro-intestinal awareness. That was complemented by extero-proprioceptive self fMRI studies focusing on external bodily inputs like facial or proprioceptive inputs connected to the self. Finally, fMRI studies also included the "typical" more cognitive mental self fMRI studies employing trait adjectives or other stimuli where subjects have to become aware of their own self (like their own name or picture) as distinct from others.

Based on the interoceptive studies, there is a most basic or lower layer of self, an interoceptive self that is related to regions that mostly process interoceptive stimuli from the own body, that is, bilateral insula, dorsal anterior cingulate cortex, thalamus, and parahippocampus, thus including mainly regions of the salience network (Menon 2011; Qin et al. 2020). The fact that these regions were shared among the different kinds of interoceptive awareness, that is, cardiorespiratory, urogenital, and gastrointestinal, suggests that these regions are key in integrating different interoceptive inputs of the various organs of the inner body (Craig 2003, 2010). One can thus speak of an “interoceptive or vegetative self” (Babo-Rebelo et al. 2016, 2019; Tsakiris 2017), “bodily self” (Damasio 2010), or “proto-self” (Panksepp 1998) as the most basic and fundamental layer of self.

Topography of self II – exteroceptive and mental layers

The next or middle layer of self includes what Qin et al. (2020) describe as proprioceptive or exteroceptive self; the fMRI studies focusing on external bodily related inputs like facial or proprioceptive inputs yielded regions like interior frontal gyrus, premotor cortex, temporo-parietal junction (TPJ), and medial prefrontal cortex (MPFC), as well as the regions of the interoceptive layer, that is, insula, thalamus, and anterior cingulate. As these regions process inputs from different sensory modalities, they may be key in not only integrating extero- and proprioceptive modalities but also different exteroceptive sensory modalities, that is, cross-modal integration. Despite their differences, these regions share the processing of proprioceptive inputs related to the own body – one can thus speak of a “proprio- or exteroceptive self, or embodied self” (Tsakiris 2017; Gallagher 2005; Panksepp 1998; Damasio 2010).

Finally, the most upper layer of self (Qin et al. 2020) is based on fMRI studies that yielded typical DMN midline regions like medial prefrontal cortex and posterior cingulate cortex as well as the regions included in the second level, most notably bilateral TPJ, and first level, bilateral insula and thalamus. These regions seem to be recruited when one needs to represent one's own self in mental states – one can therefore also speak of a "mental or cognitive self" (Qin et al. 2020) or "extended self" (Damasio 2010).

Together, these findings suggest what Qin et al. (2020) describe as “nested hierarchy of self”: regions of the lower level were included in the next higher level where they were complemented by additional regions and so forth. For instance, bilateral insula was present on the most basic level, that is, the interoceptive self, and resurfaced (in completely independent imaging studies) again in both the second, that is, proprioceptive self, and third, that is, mental self, levels. The same holds true for the bilateral TPJ, which first showed in the intermediate layer of the proprioceptive self and re-resurfaced again in the third level of the mental self. Accordingly, each of the hierarchical levels of self recruits both overlapping and separate regions compared to the other levels, amounting to a spatially nested hierarchy of self.

Topography of brain and ego – spatial nestedness as their “common currency”

Freud and psychoanalysis target a deeper layer of the mind. Rather than focusing on the conscious at the surface, they venture into the unconscious depth of our psyche. This led him and others to assume that our mind constitutes a certain hierarchy or structure of the ego. We can now see that the ego’s subjective core, that is, its self, exhibits a certain structure, which may be based on the brain's structure, that is, its topography with the distinct layers of self. This converges with the unconscious nature of the deeper subjective layers of the ego and the mind in general that Freud and psychoanalysis describe so well.

Similar to the unconscious mind, we have no access to the deeper layers of our brain itself; that is, we remain unable to become conscious of our brain's topography as such. Its topographical organization remains unconscious if not non-conscious for us. All we can become conscious of is the self in its distinct manifestations, interoceptive, exteroceptive, and cognitive-mental, while its underlying organization, its topography, is precluded from our consciousness, thus remaining unconscious if not non-conscious.

One may now want to raise the question of whether the two topographies of Freud, his first about the ego and his second about the conscious, converge with the topography of the brain and its self sketched here. Obviously, it is tempting to associate the three layers of ego, Id, Ego, and Super-ego, with the three layers of the brain's topography, interoceptive, exteroceptive, and cognitive-mental, respectively.

However, that is complicated by the fact that the tripartite structure of the ego is far from well established even within psychoanalysis itself. Moreover, on the neuroscience side, future studies may want to refine the brain-based three-layered nested organization of the self by including sub-layers and a more sophisticated differentiation of the distinct layers of self. In particular, the notion of nestedness needs to be refined in both conceptual and empirical terms.

Though preliminarily at this point, we can nevertheless say that there are converging developments in psychoanalysis and neuroscience. Both approach the ego (or self) in terms of structure and organization and thus more generally signify them by topography. The brain-based topography of self in neuroscience holds the promise to converge with the topography of the ego in psychoanalysis. If future studies can reveal similar or analogous topography of both psychodynamic models of ego and neuroscientific models of self, the respective topographical organization may be shared by both brain and psyche as their “common currency” (Northoff et al. 2020a, 2020b). Albeit tentatively, awaiting further specification, we here assume that spatial nestedness, the resurfacing of lower layers within the upper layers, may be conceived of as a strong candidate to serve as the “common currency” of the topographies of brain and ego.

Part II: temporal dynamic – scale-freeness as “common currency” of brain and self

Dynamic of the brain – operation across different timescales in a scale-free way

We have seen the spatial organization of the brain and how that relates to its self. In addition to the spatial side, there is also the temporal dimension, the dynamic of self, that is, how it changes inherently over time. We will see that, analogously to the spatial side, there is also a particular temporal structure or organization in the dynamic of the brain. That temporal structure, in turn, is closely related to the self.

The brain’s spontaneous neural activity can be characterized by different fluctuations or waves, with frequencies ranging from infraslow (0.01–0.1 Hz), over slow (0.1–1 Hz), fast (1–40 Hz), and ultra-fast (40–180 Hz; Buzsaki 2006). Power is strongest in the infraslow range and decreases across the slow, fast, and ultrafast ranges following a power law distribution (He 2014; He et al. 2010; Huang et al. 2016). Together, the different frequencies and their distinct degrees of power constitute a complex temporal structure in the brain’s spontaneous activity, which, in large parts, can feature the balance between infraslow, slow, and faster frequencies.

The relationship between these frequencies is maintained across different temporal scales and can therefore be characterized by what is described as “scale-free dynamics” (He et al. 2010; He 2014; Linkenkaer-Hansen et al. 2001). Roughly, scale-free activity describes the fractal (i.e., self-similar) organization and thus temporal nestedness in the relationship between power and the different frequency ranges: the longer and more powerful slower frequencies nest and contain the shorter and less powerful faster frequencies – this amounts to long-range temporal correlation (LRTC), which operates across different time scales or frequencies (Northoff and Huang 2017; Linkenkaer-Hansen et al. 2001; He 2014; He et al. 2010).

LRTC makes it possible to assess the degree to which past neuronal patterns exert their influence on future dynamics, thus accounting for LRTC (Linkenkaer-Hansen et al. 2001; Northoff and Huang 2017). That amounts to a form of memory that is not defined by specific contents that are encoded, stored, and recalled or retrieved. Instead, memory refers here to the structure, the temporal structure, of the neural activity across distinct time points. Being temporal and dynamic, LRTC and its scale-free activity provide not only temporal stability through their correlation of different timescales, that is, temporal continuity, but also temporal memory, that is, temporal stability, through connecting past, future, and present timepoints. One could thus speak of temporal or dynamic memory that, as process-and structure-based memory, must be distinguished from the more content-based cognitive memory in the traditional sense (Northoff 2017; Hasson et al. 2015).

The dynamic of self – the brain’s long-range temporal correlations shape the self

Is the self related to the LRTC of the brain’s neural activity? Recent studies have shown that the brain’s scale-free activity, as measured with the power law exponent (PLE), is related to mental features such as the self (Huang et al. 2016; Scalabrini et al. 2017, 2019; Wolff et al. 2019). Together, these studies show that the degree of resting state PLE directly predicts: (i) the degree of self-consciousness (Huang et al. 2016; Wolff et al. 2019), (ii) task-related activity during self-specific stimuli (Scalabrini et al. 2019), and (iii) the degree of temporal integration on a psychological level of self-specificity (Kolvoort et al. 2020).

Let us describe the findings in more detail. Huang et al. (2016) and Wolff et al. (2018) recorded resting-state activity in fMRI and EEG of the brain, that is, a task-free condition without any external demands. They calculated the degree of the brain's PLE in both fMRI and EEG. The same subjects also underwent psychological investigation of their self with the self-consciousness scale. Both studies found the same relationship of brain PLE and self-consciousness:

the higher the PLE, that is, the more the slow-fast power balance is shifted towards the slower pole, the higher the degree of the subject's private self-consciousness. Importantly, these findings hold only for the PLE as index of slow-fast balance but not for the power of either the slow or fast frequencies alone. Hence it is really the temporal structure and thus the hierarchy of slow-fast power that is related to the self (rather than the single frequencies: power itself).

Finally, it shall be mentioned that this concerns a wide range of frequencies, from very slow (0.01 to 0.1 Hz), as covered by fMRI (Huang et al. 2016), to faster ones as measured in EEG (1–80 Hz) (Wolff et al. 2018). This means that the degree of slow-fast integration, that is, their degree of scale-freeness, is related to the sense of self. The self is thus intrinsically scale free, as it connects and links different timescales, short/fast and long/slow. Such cross-scale self exhibits both temporal continuity and discontinuity by nesting different timescales within each other in a scale-free way: temporal continuity, as mediated by the more powerful slower frequencies, nests and contains temporal discontinuity, as related to the less powerful faster frequencies.

Is such self-specificity of the brain’s internal resting state activity also carried over to external task demands during self-specific tasks? This was studied in fMRI by Scalabrini et al. (2017, 2019). They measured both rest as well as task during the active touch towards animate (another person) and non-animate (mannequin hand) targets. They observed that the degree of PLE in the resting state predicted the degree to which subjects could differentiate in their task-related activity between animate and non-animate targets.

Memory and self I – temporal vs cognitive memory

Given that rest and task states occur and are measured at distinct points in time, this strongly suggests a memory effect: the temporal or dynamic memory of the resting state is carried over to the task state, as otherwise the latter could not be modulated by the former. Note that memory is more meant in a temporal way; that is, the temporal continuity (as encoded in the resting state's LRTC) is carried over to the task state and thus to the latter's actual novel external input: the novel input (as during the task state) becomes integrated and entangled within the memory of the ongoing activity (as during the resting state) and its LRTC, that is, its temporal memory.

Psychologically, this means that the novel external stimuli, which remains unrelated to the self, is now integrated with the temporal memory of the latter's LRTC, including its temporal continuity. The degree to which the external input is integrated within the self-based LRTC will determine the degree to which the external input or stimulus, that is, the respective external event, will become self-specific and thus be perceived as being closely related to the self.

Note that the term memory is not understood in a cognitive sense here, that is, in terms of a particular mental content like a particular event (such as a tree falling). Instead, it is understood in a temporal way, the degree to which the resting state with its self-based LRTC is connected with and integrates the external event: this will decide the degree to which we, based on our self, can remember that event, including how much it is connected to our self and affects us. One can thus speak of “process memory” (Hasson et al. 2015) or “temporal memory” (Northoff 2017) which, as reflecting temporal structure, is more structure based than the traditional cognitive view of memory as content based.

Is there more direct empirical support for the resting state's temporal memory of our self and how it shapes external contents? This was addressed by Kolvoort et al. (2020) in an EEG study on self. They measured resting state in EEG and conducted a psychological self-task where subjects were required to associate self- and non-self-specific stimuli across different time delays (from 200 to 1400 ms). They demonstrated that the self-specific effects in terms of accuracy were preserved across all temporal delays with inter-subject variation. That, in turn, was related to the resting state PLE: the higher the resting state PLE, that is, the stronger the slower frequencies relative to the faster ones, the more strongly the self-specific effect was preserved across the different time delays on the psychological level. Together, these findings strongly suggest that the resting state's temporal memory (its LRTC) shapes the temporal integration (and ultimately cognition) of external inputs and events.

Memory and self II – scale-freeness as “common currency”

These findings suggest that temporal integration of different timescales as indexed by temporal memory may be key in mediating the co-occurrence of temporal stability and flexibility that features our self. The self can thus be characterized by temporal memory that, operating on a deeper layer beneath the traditional content-based cognitive memory, strongly structures and organizes the latter. Albeit tentatively, we assume that such a deeper layer of a structure-based temporal and pre-cognitive form of memory converges well with the more dynamic view of the psyche espoused in psychoanalysis.

While the concept of memory in psychoanalysis is often understood in cognitive terms featuring specific contents, that is, unconscious and conscious contents, I would like to propose a more dynamic and truly temporal concept of memory: memory is here determined by its temporal structure, its LRTC, that provides temporal continuity across different timescales, including short and long. Such temporal memory remains by itself largely unconscious, as we never experience such temporal continuity by itself, that is, independent of any contents in our cognition or mind. The LRTC thus operates at a deeper layer of the brain, just as psychoanalysis assumed that certain events remain unconscious or non-conscious in the depth of our mind.

However, the degree to which that temporal structure, the LRTC of self, is developed strongly shapes the kinds of contents we can recall and remember in our consciousness. For instance, stronger power in slower frequencies (with high LRTC) biases us towards sad contents in our memory, as it is typical of depression, while stronger power in the faster frequencies favors happy and joyful contents, resulting in mania in the most extreme cases. Hence, the deep layer of temporal memory shapes the contents of our cognitive memory.

In sum, we tentatively propose to complement the psychodynamic concept of memory, which strongly relies on the different forms of content-based memory of cognitive neuroscience, by a deeper layer of temporal that, through the brain's LRTC, is structure rather than content based. Such a temporal redefinition of memory is key in providing direct link of the neuronal findings to the psychodynamic observations. Specifically, we tentatively assume that the brain’s LRTC on the neuronal level is shared as “common currency” with a more or less corresponding temporal structure of scale-freeness on the cognitive and thus psychological level.

### From self to self-objects – narcissism

### Part III: the self and its narcissism

### Topography of narcissism I – empirical findings in insula and other regions

### Topography of narcissism II – imbalance of the brain-based spatial nestedness of self

### Dynamic of narcissism – imbalance of slow and fast frequencies

Part III: the self and its narcissism

From self to self-objects – narcissism

One key feature of the self is narcissism. While Freud conceived narcissism in a pathological way as remaining stuck in an earlier sexual and libido-driven developmental stage, Kohut (1977, 1984) considered it an intrinsic feature of our self in general. For that he introduced the notion of self-objects. Kohut points out that self-objects are those objects that are central for constituting and maintaining the self, “a self can never exist outside a matrix of self-objects” (1984, 61). Self-objects provide the self with attachment to and emotion of others: “The self-object concept illuminates a central dimension of human experience: the basic needs for emotional sustenance from others as they emerge and develop through the life cycle” (Gehrie 2009, 48).

Following the previously described brain-based nested hierarchy of self, we may want to consider a nested hierarchy of self-objects. There are the interoceptive self-objects of the own inner body; they are complemented by the proprio-exteroceptive self-objects of the outer body; finally, these two layers are complemented by more abstract cognitive self-objects that are purely mental. The nested hierarchy of self is thus well compatible with the notion of self-objects suggested by Kohut.

The self-objects constitute the matrix for the self and thereby its emotional stability. Hence, if the self-objects themselves become unstable, the self itself becomes unstable, as manifested in emotional instability. How does the self compensate such instability in its own self-objects? One way is to take the self itself as self-object — this results in narcissism. On the neuronal side, such an instability of self-objects may be related to an instability in the nested hierarchy of self with imbalances among the interoceptive, exteroceptive, and cognitive/mental layers of self. This can indeed be supported by recent brain imaging findings.

Topography of narcissism I – empirical findings in insula and other regions

How is the narcissism of self related to the brain’s spatial topography and temporal dynamics? Two recent fMRI studies shed some light on this. Fan et al. (2010) combined psychological and neuronal fMRI investigation of a group of healthy subjects with respect to their empathy. They investigated all subjects with a narcissism scale according to which they divided high vs low narcissism subjects. High-narcissism subjects showed higher alexithymia scores, a measure of emotional awareness, and higher general psychiatric symptoms (as on the symptom checklist). This was expected, as it is well known clinically.

The interesting findings were observed in fMRI. Neuronally, the high narcissistic subjects yielded significantly lower degrees of activity changes during the empathy task (compared to non-empathy), especially in the right anterior insula when compared to low narcissism subjects. This is of interest, as the right anterior insula is the region that nests and connects the three distinct layers of self (as described previously). Hence, decreased activity in the right anterior insula may index decreased degrees of connection and nestedness among the three layers of self in highly narcissistic subjects.

Reduced activity change and responsiveness of the right anterior insula as a key region in narcissism could also be observed in another study on healthy subjects and their degree of narcissism (Scalabrini et al. 2017). Here the subjects underwent rest and task fMRIs with the task concerning hand touch of an animate (person) and inanimate (robot) target hand. During the anticipation period of the hand touch, the right anterior insula was activated, which was related to the degree of narcissism: the higher the subjects' degree of narcissism, the lower the degree to which activity in the insula differentiated between the two conditions, that is, animate vs inanimate hand.

Moreover, Scalabrini et al. (2017) showed that the task-related activity in the right insula correlated with the degree of the PLE in the resting: the higher the PLE in rest, that is, the stronger the power in the slower frequencies, the less task-related activity in the insula, with their rest-task relation being mediated by the degree of narcissism (as obtained in the narcissism scale). Together, these findings strongly support the relationship of especially the right anterior insula's temporal dynamics to narcissism, with this region showing less task-related differentiation in its activity during tasks that are relevant to the self-like empathy and touching a real or non-real person's hand. Importantly, this seems to be related to the altered temporal dynamic of the right insula, which may thus be a key component contributing to narcissism.

In addition to the insula, other closely related regions like the ventral and dorsal anterior cingulate cortex and the amygdala have been found to be abnormally activated in subjects with high degrees of narcissism (Feng et al. 2018; Jauk et al. 2017; Lou et al. 2021; Chester and DeWall 2016; Nenadic et al. 2015; Mao et al. 2016). These regions are all strongly connected to the insula and implicated in emotion processing, self-referential processing, and also social relation/exclusion, reflecting exactly those dimensions that are typically altered in narcissism.

Topography of narcissism II – imbalance of the brain-based spatial nestedness of self

The findings show that the insula and related emotion regions like the amygdala are abnormally altered in narcissism. We recall that the insula is a key region in the first layer of the self, the interoceptive self, and that it resurfaces in the subsequent layers of self, the exteroceptive and mental self. In other words, the insula provides the “glue” between the different layers of the nested hierarchy of self. Lower task-related differentiation of the insula means that self and environmental contexts can no longer be properly distinguished anymore in one’s experience and perception: the environmental context as the non-self is processed and perceived in terms of the self, resulting in narcissism.

Moreover, the hierarchy of self, with its interoceptive, exteroceptive and mental layers, will become fragile and unstable. This is so because of the nestedness; the interoceptive deficit of the insula will resonate or reverberate throughout the whole nested hierarchy of self to extero-proprioceptive and mental layers of the self. That, in turn, may result in a fragile nested hierarchy of self whose different layers are no longer properly integrated, that is, nested, anymore. The self may thus become unstable, to which it may react with either grandiose self-fantasies with respect to the external world, that is, the thick-skinned type of narcissism, or, alternatively, in a more silent withdrawn and internal way, that is, the more thin-skinned narcissism.

In sum, the spatial nestedness of self may be abnormally shifted in narcissism: the different self-objects can no longer be connected and integrated with each other, which, in turn, threatens the coherent sense of self. Instead of a coherent sense of self with its different layers of self-objects being nested within each other, the different self-objects may no longer properly connect with each other, operating more in parallel rather than in an integrated and nested way. That, in turn, may induce anxiety, as mediated by the close connection of the insula to emotion-mediating regions like amygdala. Moreover, it may abnormally activate especially the mental- or cognitive-layer self (as relayed by the default-mode network with is cortical midline structures) that may then yield the typical narcissistic grandiose fantasies.

Dynamic of narcissism – imbalance of slow and fast frequencies

How about the temporal dynamic in narcissism? There are predominantly fMRI studies on the topography in narcissism but not many studies on its temporal dynamic. One exception is Scalabrini et al. (2017). Investigating healthy subjects, he shows that the insula's resting state's PLE and its modulation of task-related activity are mediated by the degree of narcissism: the stronger the power in the slow frequencies with higher PLE in the resting state of the insula, the less the task-related activity in the insula differs from the ongoing resting state activity.

What does this mean psychologically? Additionally, Scalabrini et al. (2017) observed a correlation of both resting state PLE and task-related activity with the degree of narcissism. The higher the narcissism, the higher the PLE and the lower the task-related activity. Hence, there seems to be clear relationship of rest PLE and task activity with the degree of narcissism. The task consisted in the anticipation of a target, another person's hand. Lower rest-task differentiation with lower task-related activity thus means that the more narcissistic subjects were not able to properly anticipate the next stimulus. Instead, they remained in their own resting state, that is, their own self, remaining unable to reach out to the other.

Importantly, the inability to anticipate reaching out to the other is mediated by the resting state's slow frequencies. The stronger the resting state's slow frequencies in the insula, that is, higher PLE, the less subjects could reach out to the other person. Hence, their intrinsic temporal dynamic is too slow to connect their own self to the other, which requires a faster dynamic. Hence, figuratively speaking, the narcissistic person is too slow to connect their own self with the faster environment, including other selves.

Together, albeit tentatively, the findings suggest altered dynamic in the brain related to the self in narcissism. The dynamic exhibits insufficient fast frequencies in the insula, yielding a rather limited scale-freeness. Changes in scale-freeness constrain the integration of self, including across both its multiple nested layers of self-objects and the scale-free slow-fast dynamics. Together with the spatial findings, this amounts ultimately to decreases in both spatial continuity (across its distinct layers of self-objects) and temporal continuity (across different timescales) of the self in narcissism. We therefore propose a primarily spatiotemporal (rather than cognitive or affective) view of narcissism that determines it by the degree of spatial and temporal nestedness on both neural and psychological levels.

Conclusion

The ego is characterized in psychoanalysis by a particular organization, its three-layered topography. Recent findings in neuroscience show that neuronally, the self, as subjective core of the ego, may also be mediated by a three-layered neural hierarchy of interoceptive, exteroceptive, and mental layers of self. Importantly, these different layers are nested within each other, that is, spatial nestedness. Analogously on the temporal side, one can observe temporal nestedness among slow and fast frequencies whose relationship index the degree of self-consciousness. The balances of both the three spatial layers and the slow–fast dynamic are shifted in their nestedness in subjects with high narcissism, resulting in decreased spatial and temporal continuity. Together, this supports a spatio-temporal view of both self and narcissism where topography and dynamic are shared as “common currency” by neuronal and psychological levels.

Feng C, Yuan J, Geng H, Gu R, Zhou H, Wu X, Luo Y (2018) Individualized prediction of trait narcissism from whole-brain resting-state functional connectivity. Hum Brain Mapp. Sep;39(9):3701–3712. doi: 10.1002/hbm.24205. Epub 2018 May 10.

Frewen P, Schroeter ML, Riva G, Cipresso P, Fairfield B, Padulo C, Kemp AH, Palaniyappan L, Owolabi M, Kusi-Mensah K, Polyakova M, Fehertoi N, D'Andrea W, Lowe L, Northoff G (2020) Neuroimaging the consciousness of self: Review, and conceptual-methodological framework. Neurosci Biobehav Rev. May;112:164–212. doi: 10.1016/j.neubiorev.2020.01.023. Epub 2020 Jan 26. PMID: 31996300 Free article. Review.

Gallagher S (2005) Dynamic models of body schematic processes. Adv. Consc. Res. 62:233–250. doi: 10.1075/aicr.62.15gal

Gehrie MJ (2009) The evolution of the psychology of the self: Towards a mature narcissism. Annals New York Academy of Sciences. 1159:31–50.

Hasson U, Chen J, Honey CJ (2015) Hierarchical process memory: Memory as an integral component of information processing. Trends Cogn. Sci. 19(6):304–313. doi: 10.1016/j.tics.2015.04.006

He BJ (2014) Scale-free brain activity: Past, present, and future. Trends Cogn. Sci. 18:480–487. doi: 10.1016/j.tics.2014.04.003

He BJ, Zempel JM, Snyder AZ, Raichle ME (2010) The temporal structures and functional significance of scale-free brain activity. Neuron. 66:353–369. doi: 10.1016/j.neuron.2010.04.020

Huang Z, Obara N, Davis HH 4th, Pokorny J, Northoff G (2016) The temporal structure of resting-state brain activity in the medial prefrontal cortex predicts self-consciousness. Neuropsychologia. 82:161–170. doi:10.1016/j.neuropsychologia.2016.01.025

Jauk E, Benedek M, Koschutnig K, Kedia G, Neubauer AC (2017) Self-viewing is associated with negative affect rather than reward in highly narcissistic men: An fMRI study. Sci Rep. Jul 19;7(1):5804. doi: 10.1038/s41598-017-03935-y

Kernberg OF (1984) Severe personality disorders: Psychotherapeutic strategies. Yale University Press, New Haven.

Kohut H (1977) The restoration of the self. Int Universities Press, New York.

Kohut H (1984) How does analysis cure? Chicago University Press, Chicago.

Kolvoort IR, Wainio-Theberge S, Wolff A, Northoff G (2020) Temporal integration as “common currency” of brain and self-scale-free activity in resting-state EEG correlates with temporal delay effects on self-relatedness. Hum. Brain Mapp. 41:4355–4374. doi: 10.1002/hbm.25129 Linkenkaer-Hansen K, Nikouline VV, Palva JM, Ilmoniemi RJ (2001) Long-range temporal correlations and scaling behavior in human brain oscillations. J. Neurosci. 21:1370–1377. doi: 10.1523/JNEUROSCI.21-04-01370.2001 Northoff G, Wainio-Theberge S, Evers K (2020b). Spatiotemporal neuroscience – What is it and why we need it. Phys Life Rev. 33:78–87. doi:10.1016/j.plrev.2020.06.005

Lou J, Sun Y, Cui Z, Gong L (2021) Structural brain alterations in young adult males with narcissistic personality disorder: A diffusion tensor imaging study. Int J Neurosci. Mar 8:1–8. doi: 10.1080/00207454.2021.1896504. Online ahead of print.

Mao Y, Sang N, Wang Y, Hou X, Huang H, Wei D, Zhang J, Qiu J (2016) Reduced frontal cortex thickness and cortical volume associated with pathological narcissism. Neuroscience. Jul 22;328:50–57. doi: 10.1016/j.neuroscience.2016.04.025. Epub 2016 Apr 27. PMID: 27129440.

Menon V (2011) Large-scale brain networks and psychopathology: A unifying triple network model. Trends Cogn. Sci. 15:483–506. doi: 10.1016/j.tics.2011.08.003

Milrod D (2002) The concept of self and the self representation. Neuropsychoanalysis. 4(1):7–23.

Nenadic I, Güllmar D, Dietzek M, Langbein K, Steinke J, Gaser C. (2015) Brain structure in narcissistic personality disorder: A VBM and DTI pilot study. Psychiatry Res. Feb 28;231(2):184–186. doi: 10.1016/j.pscychresns.2014.11.001. Epub 2014 Nov 8.

Northoff G (2016) Is the self a higher-order or fundamental function of the brain? The “basis model of self-specificity” and its encoding by the brain’s spontaneous activity. Cogn. Neurosci. 7(1–4):203–222. doi:10.1080/17588928.2015.1111868

Northoff G (2017) Personal identity and cortical midline structure (CMS): Do temporal features of CMS neural activity transform into “self-continuity”?. Psychol. Inq. 28(2–3):122–131. doi:10.1080/1047840X.2017.1337396

Northoff G, Huang Z (2017) How do the brain’s time and space mediate consciousness and its different dimensions? Temporo-spatial theory of consciousness (TTC). Neurosci. Biobehav. Rev. 80:630–645. doi:10.1016/j.neubiorev.2017.07.013

Northoff G, Qin P, Feinberg TE (2011) Brain imaging of the self: Conceptual, anatomical and methodological issues. Conscious Cogn. Mar;20(1):52–63. doi: 10.1016/j.concog.2010.09.011. Epub 2010 Oct 6.

Northoff G, Wainio-Theberge S, Evers K (2020a) Is temporo-spatial dynamics the “common currency” of brain and mind? In quest of “spatiotemporal neuroscience”. Phys Life Rev. 33:34–54. doi: 10.1016/j.plrev.2019.05.002 Northoff G, Wainio-Theberge S, Evers K (2020b). Spatiotemporal neuroscience – What is it and why we need it. Phys Life Rev. 33:78–87. doi:10.1016/j.plrev.2020.06.005

Northoff G, Wiebking C, Feinberg T, Panksepp J (2011) The “resting-state hypothesis” of major depressive disorder—a translational subcortical-cortical framework for a system disorder. Neurosci Biobehav Rev. Oct;35(9):1929–1945. doi: 10.1016/j.neubiorev.2010.12.007. Epub 2010 Dec 28.

Panksepp J (1998) The periconscious substrates of consciousness: Affective states and the evolutionary origins of the self. J. Conscious. Stud. 5:566–582.

Panksepp J (2012) What is an emotional feeling? Lessons about affective origins from cross-species neuroscience. Motiv. Emot. 36:4–15. doi:10.1007/s11031-011-9232-y

Qin P, Wang M, Northoff G (2020) Linking bodily, environmental and mental states in the self—A three-level model based on a meta-analysis. Neurosci Biobehav Rev. 115:77–95. doi: 10.1016/j.neubiorev.2020.05.004

Scalabrini A, Ebisch SJH, Huang Z, Di Plinio S, Perrucci MG, Romani GL, et al (2019) Spontaneous brain activity predicts task-evoked activity during animate versus inanimate touch. Cereb Cortex 29:4628–4645. doi:10.1093/cercor/bhy340

Scalabrini A, Huang Z, Mucci C, Perrucci MG, Ferretti A, Fossati A, Romani GL, Northoff G, Ebisch SJH (2017) How spontaneous brain activity and narcissistic features shape social interaction. Sci Rep. Aug 30;7(1):9986. doi: 10.1038/s41598-017-10389-9

Sui J, Humphreys GW (2015) The integrative self: How self-reference integrates perception and memory. Trends Cogn Sci. Dec;19(12):719–728. doi: 10.1016/j.tics.2015.08.015. Epub 2015 Oct 4.

Tsakiris M (2017) The multisensory basis of the self: From body to identity to others. Q. J. Exp. Psychol. (Hove). 70:597–609. doi:10.1080/17470218.2016.1181768

Wiest G (2012) Neural and mental hierarchies. Front Psychol. Nov 26;3:516. doi: 10.3389/fpsyg.2012.00516. eCollection 2012.

Wolff A, Di Giovanni DA, Gómez-Pilar J, Nakao T, Huang Z, Longtin A, Northoff G (2019) The temporal signature of self: Temporal measures of resting-state EEG predict self-consciousness. Hum Brain Mapp. Feb 15;40(3):789–803. doi: 10.1002/hbm.24412. Epub 2018 Oct 4.
