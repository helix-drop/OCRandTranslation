## Introduction

### Self and narcissism

Introduction

One of the key discoveries of Freud and subsequent psychoanalysis is that the ego is not a homogenous entity. Instead, the ego refers to a particular structure or organization, the famous three-fold structure or topography of Id, Ego, and Super-ego. There has been much discussion about this and further developments in subsequent psychoanalysis up to the present day. Instead of recounting these developments in psychoanalysis, we rather focus on whether there are corresponding developments in neuroscience that may be to integrate both psychological and neural observations.

The core of the ego is the self, which is considered intrinsically subjective. The self has been extensively investigated for its neural correlates in neuroscience in recent years. This includes different concepts of self like mental self, bodily self, objective vs subjective self, integrative self, emotional self, and so on (Northoff 2016; Frewen et al. 2020; Qin et al. 2020; Sui and Humphreys 2015 for overviews). The different concepts of self are often associated with distinct regions or networks in the brain. Core regions include especially the regions in the middle of the brain, the cortical (and also subcortical) midline structures (CMS), which are the center of the default-mode network (DMN).

How are psychodynamic and neuroscientific concepts of self-related to each other? David Milrod points out an essential difference between neuroscientific and psychoanalytic concepts of self. Neuroscience and psychology focus more on the universal and
