## 4 Cathexis and free energy

### Introduction

### Cathexis – subcortical vs cortical sources

### Part I: cathexis and global brain dynamic

### From global to local brain activity – global signal and its topography

### Global dynamic – key role of slow activity with infraslow frequencies

### Psychic energy I – global brain activity mediates the level of arousal

### Psychic energy II – global brain activity is diminished in disorders of consciousness

### Global signal topography – from neuronal to psychical topography

### Cathaxis and objects – investment of energy into internal and external objects

### Part II: cathexis and free energy

Cathexis and free energy

Introduction

What is cathexis? The concept of cathexis has a difficult history. Originally it was to designate what Freud described as Besetzung in German, which translates into “occupation” in English. However, the meaning of cathexis extends far beyond that: occupation or besetzung is only the result or outcome of an underlying complex process that consists and is maintained by recruiting and investing energy. Cathexis has therefore been reserved for describing the “investment of energy” (Hoffer 2005).

Note that energy and investment are here understood in a purely psychological or psychological way. The psyche is characterized by energy, that is, mental or psychic energy, which can be understood in either mechanical or dynamic terms. If understood in purely mechanical terms, cathexis invokes the image of a machine-like function entailing clear-cut separation between cause and effect as well as discontinuity with discrete points in time and space. This is probably what Freud had in mind when, in his 1895 writing “Project for a Scientific Psychology”, he associated cathexis with the discharge of electrochemical energy in the brain as hydraulic machine. That entails a mechanistic understanding of cathexis in terms of cause-effect and temporal discontinuity.

However, in parallel, he also implies a more dynamic understanding of cathexis on the psychological level when he associates it with drives, libido, and motivation. These psychological or behavioral concepts no longer allow clear-cut separation between cause and effect. Moreover, they presuppose some kind of temporal and spatial continuity beyond the discontinuity of discrete points in time and space: libido, drive, and motivation extend and connect different points in time and space. Together, this amounts to a more dynamic meaning of cathexis beyond both cause–effect distinction and temporo-spatial discontinuity.

Such a dynamic understanding of cathexis on the psychological level is well reflected in the following quote:

I will add the further comment that the psychological topography that I have developed here has nothing to do with the anatomy of the brain, and actually only touches it at one point. What is unsatisfactory in this picture – and I am aware of it as clearly as anyone – is due to our complete ignorance of the dynamic nature of the mental processes. We tell ourselves that what distinguishes a conscious idea from a preconscious one, and the latter from an unconscious one, can only be a modification, or perhaps a different distribution, of psychological energy. We talk of cathexes and hypercathexes, but beyond this we are without any knowledge on the subject or even any starting-point for a serviceable working hypothesis. Of the phenomenon of consciousness we can at least say that it was originally attached to perception. All sensations which originate from the perception of painful, tactile, auditory or visual stimuli are what are most readily conscious. Thought-processes, and whatever may be analogous to them in the id, are in themselves unconscious and obtain access to consciousness by becoming linked to the mnemic residues of visual and auditory perceptions along the path of the function of speech. (Freud 1939, 96; italics added)

Rather than adhering to a more or less mechanical view of cathexis as it resurfaces in current neuroscientific views (see Solms 2015; Northoff 2011; Carthart-Harris and Friston 2010; Panksepp and Biven 2012), I here follow a radical dynamic view of cathexis. Specifically, I propose that the brain exhibits exactly the kind of global dynamic that constitutes its energy, that is, cathexis, which, even more importantly, the brain invests into its relationship with the environment as a basis for what psychoanalysis describes as object relation. This will be shown by the brain's global brain dynamic and topography (first part) as well as by demonstrating the temporal-dynamic underpinnings of Karl Friston's concept of "free energy" (second part). I conclude that cathexis is related to the brain's energy, namely its global dynamic and topography: these are invested into the brain's relation to its environment, thereby constituting the physiological basis for object relation on the psychological level.

Part I: cathexis and global brain dynamic

Cathexis – subcortical vs cortical sources

Drives, motivation, and libido as the psychological manifestations of cathexis have been associated mainly with subcortical regions in recent neuropsychoanalysis (Solms 2015, 2020, 2021; Panksepp and Biven 2012). This has been strongly reinforced by the close link of cathexis with primary emotions that are also "located" mainly in subcortical regions (Panksepp and Biven 2012). Does this mean that the brain's energy, that is, its cathexis, is located in mainly subcortical regions, as these observations seem to suggest? Such a view presupposes a somewhat localizationist view of the brain where different functions like energy or cathexis and others like libido, motivation, and drives are associated with a particular set of regions, areas, or networks in the brain.

However, we will see now that the brain also exhibits a global activity that spans more or less all regions and networks, including subcortical and cortical. Importantly, that very same global activity seems to be key in assigning activity to local regions and networks; that is, the global activity is represented locally in distinct degrees in different regions – this amounts to a particular topography of global brain activity. Finally, we will see that the level of such global activity is related to the degree of arousal. Together, this suggests a more global subcortical–cortical view of the brain's cathexis that carries major implications for its manifestation on the psychological level.

From global to local brain activity – global signal and its topography

The relationship between global and local activity changes is a common phenomenon in the natural world, which, among other examples of complex systems, can be observed in climate change and economy. Global warming of the earth atmosphere affects the climate in different countries and continents in different ways depending on their respective local-regional features (like ice melting in colder regions and creation of deserts in warmer regions) (Bindoff et al. 2013; Oppenheimer et al. 2015). Similarly, the global economy strongly affects economies in different countries, albeit in different ways, depending, among other factors, on the level of their development (Goldberg and Pavcnik 2007; Rodrik 2008). What holds for climate and economy may also apply to the brain as another complex system in a more or less analogous way.

Recent evidence suggests that the brain too displays “global” activity (see subsequently for defining the term “global”) that modulates and is represented in different ways in its various local regions and networks. That may, in part, be related to subcortical–cortical modulation: subcortical nuclei like the serotoninergic raphe nucleus, acetylcholineergic nucleus basalis of Meynert, and dopaminergic substantia nigra modulate cortical activity in a multi-regional “global” way, including the balances between different networks (Conio et al. 2020; Grandjean et al. 2019; Zerbi et al. 2019). Additionally, recent studies in animals show that multiple regions are implicated in inducing and mediating one specific behavior (Stringer et al. 2019) – this supports the potential role of the brain’s more global activity in behavior.

Recent studies combining ECoG/electrophysiology and fMRI demonstrate a direct relationship of fMRI-based global brain activity as measured by the global signal (GS) with electrophysiological measures; these findings suggest that GS is not merely non-neuronal noise but also an important source of neuronal activity itself (Scholvinck et al. 2010; Wen and Liu 2016) (see subsequently for details). Furthermore, various studies show that GS is represented in different degrees in different regions: it displays a dynamic topography, that is, GS topography (Liu et al. 2018a; Liu et al. 2018b; Zhang et al. 2020).

Global dynamic – key role of slow activity with infraslow frequencies

Reviewing several studies combining GS in fMRI with electrophysiological measurements in mainly monkeys (Chang et al. 2016; Leopold et al. 2003; Liu et al. 2018a; Scholvinck et al. 2010; Scholvinck et al. 2015; Turchi et al. 2018; Wen and Liu 2016) and humans (Wen and Liu 2016), one key electrophysiological feature is that GS is related to the band limited power of different frequency ranges in different ways. For instance, infraslow frequency ranges (<0.1 Hz) show a much higher relationship, that is, correlation, with GS than faster frequencies than those in the slower (0.1–1 Hz), and faster ranges (1–100 Hz) (Leopold et al. 2003; Scholvinck et al. 2010; Scholvinck et al. 2015). These results suggest that GS is strongly driven by the long cycle durations of the very slow, that is, infraslow frequencies (<0.1 Hz) and less so by the faster frequencies.

However, there is no uniform association of GS with infraslow frequencies, as faster frequencies may contribute, too, albeit in distinct ways. In addition to the frequency range, the degree of spatial extension or distance may be an important factor. Several studies show that slower delta/theta (1–8 Hz) and faster gamma (40–80 Hz) contribute strongly to the spatial extension of neural activity beyond single regions on the cortical level and subsequently to GS (Liu et al. 2018a; Scholvinck et al. 2015; Wen and Liu 2016). In contrast, the alpha/beta range (10–30 Hz) is not related to such global extension but remains rather local as restricted to specific regions like the visual/posterior cortex and thalamus, which decreases its contributions to GS (Chang et al. 2016; Liu et al. 2018a; Scholvinck et al. 2010; Wen and Liu 2016).

Together, these data suggest that GS displays a distinct electrophysiological basis, with different frequencies making different contributions. To put it in a nutshell: the slower the frequency range, the more and stronger its contributions to the global extension of neural activity across longer cortical distances as measured by GS (Chang et al. 2016; Liu et al. 2018a; Scholvinck et al. 2010; Wen and Liu 2016). Hence, dynamic drives topography, as the degree of spatial extension of the brain’s global activity is dependent upon its slow–fast relationship.

This also makes it clear that the concept of “global” in GS is to be understood in a relative rather than absolute way: unlike in earlier theories of holism that supposed involvement of the whole brain with all regions (Lashley 1950), the term “global” designates the extension of cortical activity beyond its localization in single cortical regions, with the degree of spatial extension and the number of implicated regions being somewhat flexible. This relative meaning of the term global is further supported by the transition from global to local activity as manifest in the topography of GS, as we will see further down.

Psychic energy I – global brain activity mediates the level of arousal

There are various lines of evidence linking GS fluctuation to the level of arousal. Chang et al. (2016) take monkeys' changes from eyes closed to eyes open across time as an index of behavioral arousal. They also investigate the same monkeys in fMRI, where they observe a widespread negative correlation with behavioral arousal. The fMRI arousal index is generated by correlating the widespread arousal pattern with instantaneous single volume. Both arousal indices, fMRI and behavioral, are then correlated with each other. This yields a highly significant correlation of behavioral and fMRI arousal indices: fluctuations in the behavioral arousal index are related to corresponding fluctuations in the fMRI arousal index, whose spatial pattern is further confirmed by its similarity to an instantaneous co-activation pattern that is phase-locked to the peak of GS (Liu et al. 2018a).

In order to provide an electrophysiological basis of the fMRI index of arousal, they also obtained simultaneous ECoG measuring the beta- and theta-range power index. The fMRI index of arousal correlates significantly with the beta- and theta-range power index (15–25 and 3–7 Hz, respectively), suggesting that the widespread co-activation pattern has a distinct basis in the power spectrum (Liu et al. 2018a).

What is the neuronal origin of arousal-related GS fluctuations? The empirical findings suggest that subcortical regions related to arousal may be suitable candidates for the origin of arousal-related GS fluctuations (Liu et al. 2018a; Turchi et al. 2018). Liu et al. (2018a) demonstrate that subcortical activity exhibits correlation with the cortical GS peak, albeit in a negative way, opposite to cortical regions: the troughs of subcortical activity fluctuations correlate with cortical GS peaks, which also correlate in a positive way with activity peaks in specific cortical regions. These data suggest GS modulates neuronal activity on both the cortical and subcortical levels.

The subcortical regions correlating negatively with the cortical GS peak include the thalamus (dorsomedial), basal forebrain, and midbrain (above pons, may be substantia nigra), which all show decreased signals during cortical GS peaks (Liu et al. 2018a). The strongest subcortical decrease is observed in the basal forebrain that corresponds to the nucleus basalis of Meynert (NBM), which contains acetylcholine, which is known to modulate the arousal level.

Taken together, these findings strongly support a role of GS in mediating the level of arousal as driven by subcortical regions and their apparent anti-correlation with cortical GS. That puts into doubt recent approaches in neuropsychoanalysis that solely focus on subcortical regions like the affective approach (Solms 2015; Panksepp and Biden 2012) in a larger and more comprehensive context. Rather than single subcortical brain regions, the brain's global subcortical–cortical activity is key in mediating the brain's global energy, that is, cathexis. Moreover, we can see how the brain's global energy is key in transforming neural activity into the psychological level when mediating arousal.

Psychic energy II – global brain activity is diminished in disorders of consciousness

Various studies during anesthesia in both humans (Huang et al. 2018; Huang et al. 2016; Monti et al. 2013; Schroter et al. 2012; Tanabe et al. 2020) and animals (Hamilton et al. 2017; Liang et al. 2012; Tanabe et al. 2020), as well as unresponsive wakefulness syndrome (UWS) in humans (Huang et al. 2016), suggest that the brain's GS is strongly reduced if not absent in these states. These findings further support the assumption that the level of GS is central for maintaining the level of arousal as the most basic dimension.

of consciousness (see Northoff and Lamme (2020) for a review of the different theories of consciousness).

This assumption is tested in a recent study by Tanabe et al. (2020). Tanabe et al. (2020) conducted fMRI in a variety of different groups, including both animal (rat) and human anesthesia with different propofol dosages (high, medium, low) in rats and different levels (wakefulness, sedation, and anesthesia) in humans. In addition, they included human subjects suffering from minimally conscious state (MCS) and UWS as well as subjects in different sleep stages (N1–3).

They measured the amplitude of GS, as well as the functional connectivity of the GS to all single voxel/regions in the brain. Both the amplitude and functional connectivity of GS exhibit major reductions in complete anesthesia in both rats and humans as well as in N3 sleep and UWS, while the intermediate stages like sedation, medium propofol dosage, N1/N2, and MCS show intermediate levels of amplitude and functional connectivity of GS, as they are higher than during the complete of unconsciousness and lower than in the fully awake state. This further suggests that the level of GS may correspond to the level of arousal as the most basic dimension of consciousness rather than to the presumably different neuronal origins or causes of the different conditions.

In sum, GS displays a distinct electrophysiological basis and mediates the fluctuations in the level of arousal by its own fluctuations on subcortical and cortical levels. Initial evidence in humans suggests that GS is key for maintaining arousal as manifest in the state or level of consciousness. Together, this suggests that GS operates in the background of the brain-behavior relationship by providing a neural predisposition (Northoff 2013; Northoff and Heiss 2015; Northoff and Lamme 2020) for the level of arousal, that is, the level or state of consciousness, as a basis for our most basic behavioral navigation within the environment.

Global signal topography – from neuronal to psychical topography

We already pointed out that the term “global” must be understood in a relative sense, on a continuum of 100% global to 100% local. This means that, in addition to its global brain activity, GS also exhibits a certain cortical distribution, that is, topography which by itself is subject change, that is, dynamic. Depending on the ongoing global fluctuations (with troughs and peaks), different networks are transiently coupled together in what is described as a co-activation pattern (CAP) (Gutierrez-Barragan et al. 2019; Zhang et al. 2020) – this amounts to GS topography (Zhang et al. 2020; Zhang and Northoff 2022). Accordingly, one can distinguish the more global background activity from its more topographic surface, as has been proposed recently in the dual layer model (DLM) of global brain activity (Zhang and Northoff 2022).

While the previously mentioned disorders of consciousness all showed decreased global brain activity, that is, GS, they were distinguished in its exact cortical distribution, that is, GS topography. For instance, the different sleep stages like N1–3 and dreams exhibit different GS topography from each other, which also distinguishes them from anesthesia. Interestingly, the dream state includes strong concentration of the global brain activity along the cortical midline axis of the default-mode network and visual network regions (Tanabe et al. 2020). Different psychiatric disorders like schizophrenia (Yang et al. 2017), major depressive disorder (Scalabrini et al. 2020), and bipolar disorder (Zhang et al. 2019) exhibit different patterns of GS topography; these are closely related to the abnormal balances of cognitive, motor, sensory, and affective functions (Zhang and Northoff 2022).

Together, there is a continuum of global and local brain activity in that the global activity (GS) is “represented” in different degrees in different regions/networks, that is, GS topography. Hence, global brain activity may be one key component that may shape the brain’s topography. The brain’s topography, in turn, is key in structuring and organizing mental features like consciousness (Tanabe et al. 2020) and self (Chapter 1) – neuronal topography thus translates into mental topography.

This is akin to what Freud described as “psychical topography” on the psychological level. What determines the single content’s meaning is not the local content itself but its relationship to other contents and ultimately the overall global context of contents. The brain’s global topography may correspond on the neuronal level of the brain to what Freud referred to as “psychical topography” on the psychological level: the brain’s topography is manifest in a somewhat analogous topographical organization of mental contents on the psychical level – topography provides the “common currency” of brain and psyche.

Part II: cathexis and free energy

Cathaxis and objects – investment of energy into internal and external objects

We are now ready to come back to cathexis as discussed in the psychodynamic context. As described in the introduction, cathexis refers to the investment of energy into objects. This raises two questions. How can we determine the notion of objects in the context of energy/cathexis? Can we associate the investment of psychic energy with the energy of the brain like its global dynamic and topography? Let us start with the first question.

Energy is invested into objects; however, the meaning of objects is highly ambiguous by itself. The notion of object is here understood in a rather broad meaning of the term. Objects can be associated with external inputs and contents stemming from the environment – these are “external objects”, as I say. At the same time, objects can also be associated with the own self, as in Kohut, who speaks of “self-objects” (1985). Since the self is internal rather than external, self-objects must be designated as internal objects as distinguished from the external objects originating in the environment.

The concept of internal objects means that they originate internally within the person itself. Internal objects can refer to the self of the person. But they can also refer to the thoughts of that person, their internally oriented thoughts as distinguished from externally oriented thoughts (Vanhaudenhuyse et al. 2011; Hua et al. 2021). Moreover, internal objects can refer to mental time travel into past and future, something that is described as episodic simulation in psychology (Schacter et al. 2012; Northoff 2017). This makes it clear that, if understood in a broader sense beyond the own self, internal objects refer to various forms of internally oriented cognition like self, mind-wandering, and mental time travel.

What distinguishes internal objects from external objects? Rather than originating internally within the person itself, external objects have their source or origin in the external environment outside and beyond the person itself. Hence, internal and external objects differ in their source or origin relative to the person, that is, inside or outside the person. That difference in origin or source may overshadow their similarities, though: both refer to events or objects and may therefore share the investment of energy that applies to all objects regardless of their source or origin. For instance, we see in extreme states like depression that there is abnormally strong investment of energy into internal objects, that is, own self and its self-objects, at the expense of investing energy into the external objects (see Chapter 7). Hence, cathexis drives the investment of energy into objects in general regardless of their source or origin, that is, internal or external.

### Cathexis and free energy – cognition and mental features

### “Deep temporal models” – conjoining free energy and temporo-spatial dynamic

### Deep temporal and spatial models – investment of energy into internal and external objects

Finally, the investment of energy in both internal and external objects means that cathexis is not purely intra-psychic but also inter-personal crossing the boundary of inner/internal and outer/external. This is well expressed by McIntosh:

That the character of cathexis always infuses the character of its object, especially on the unconscious level, means that it is impossible to draw any firm line between the intrapsychic and the interpersonal. The two form a single nexus. In sum, Freud's notion of cathexis as "entering into" its objects, which finds support in recent work in cognitive psychology, has the effect of undermining the centrality of the traditional Cartesian division between the "inner" and the "outer" realms of experience. (1993, 10)

Cathexis and free energy – cognition and mental features

Recently, Mark Solms (2020, 2021) suggests replacing the notion of cathexis by the one of free energy as understood by Friston (Solms and Friston 2018; Solms 2020, 2021). He proposes to apply the various formalism and algorithms of the free energy principle (FEP) to the psyche and its modes of operation like primary motivation, drives, libido, and so on. Psychologically, he associates that closely with affect/emotion as understood by Panksepp (Panksepp and Biven 2012). This establishes cathexis as bridge between brain and psyche, neuroscience and psychoanalysis, for which reason Solms considers the FEP a key component of a “New Scientific Psychology” (Solms 2020, 2021) (see also conclusion in this chapter).

Why does he contribute such key role of the FEP for the psyche? The free energy principle is used as a powerful formalism for modeling and understanding diverse forms of internally and externally oriented cognition, including consciousness and self. Prominent in these studies is the application of free energy to the self, as well as to different facets of self like the dynamic self, the bodily self, and the subjective self ("I" vs "me"). Together, these studies point out the key relevance of free energy and the FEP for mental features and thus for the psyche in general.

Where and how is the free energy coming from? The current neuropsychoanalytic view associates FEP with the brain itself, its inside. If, as in current neuropsychoanalysis, one equates cathexis with FEP, one would conceive cathexis as intra-psychic (and intra-neuronal). However, that will raise the question of how cathexis can be linked to object relation, which requires an inter-rather than intra-psychic relationship. This leads us back to the FEP and what exactly it signifies and aims to describe. The FEP implies that the brain is standing in continuous contact and exchange with its environmental context. That contact features their minimization of free energy within the brain's relationship to its continuously changing environmental context, which, in turn, allows the brain to reduce its own inner entropy (as too high levels of the latter would destabilize the brain). Accordingly, the FEP itself cannot be conceived as intra-neuronal nor intra-psychic but presupposes by itself the relationship of brain and environment.

“Deep temporal models” – conjoining free energy and temporo-spatial dynamic

In an attempt to constitute mental features and functions, free energy enables the brain to align to and model its ecological niche; that is, the respective environmental context. The very nature of free energy minimization – such as tuning a generative model to a hierarchical world with separation of temporal scales – necessarily means that hierarchical temporo-spatial dynamics must be recapitulated in any such aligning or adapting agent. In the language of self-organization, this is what has been described as “good regulator theorem”

that describes the intimate model-like relationship between the regulator of a system and the regulated system: “every good regulator of a system must be a model of that system” (Seth 2015).

The environmental hierarchies of different events may be recapitulated and thus modelled by the brain itself within its own intrinsic hierarchical organization, that is, its temporo-spatial hierarchy. The brain's intrinsic temporo-spatial hierarchy may thus, in part, reflect a smaller scale-free version of the temporo-spatial hierarchies featuring the environment. There is no need for the living to represent a model of the environment in their head: "an agent does not have a model of its world – it is a model. In other words, the form, structure, and states of our embodied brains do not contain a model of the sensorium – they are that model" (Friston 2013). Hence, given such self-similarity between brain and environment, we may better focus on "what our head's inside of" rather than searching for "what is inside our heads" (Bruineberg and Rietveld 2014; Bruineberg et al. 2018).

How must the relationship of environment and brain be structured in order to allow such exchange and ultimately minimization of free energy? This is the moment where temporal dynamic comes in. The environmental contingencies are continuously changing, thereby reflecting the environment's "deep temporal dynamic". In order for the brain to minimize its own free energy, it must model the environment's deep temporal dynamic – this, per Friston, results in "deep temporal models" (Friston et al. 2017; Kiebel et al. 2008, 2009), entailing temporal thickness or depth (Seth 2015). These "deep temporal models" are thus crucial for the human to adjust and align their own inner temporal dynamic to the ongoing temporal dynamic of their environment. This results in a deeply temporal environment-brain/agent nexus that naturally conjoins free energy and temporo-spatial dynamics (Northoff 2019; Golesorkhi et al. 2021a, 2021b).

Deep temporal and spatial models – investment of energy into internal and external objects

Where and how can we find such deep temporal models in the brain? This leads us back to the global brain activity and specifically its dynamic and topography. We saw that the global brain dynamic is marked by very slow frequency fluctuations extending more or less throughout the whole subcortical–cortical brain (in a relative sense). This is measured by the global signal. Albeit tentatively, we assume that these very slow frequency fluctuations, through their extremely high power spectral density (which is much higher than the one of faster frequencies), provide the dynamic and thus the energy that drives the brain's neural activity to align and relate itself (in terms of free energy) with its environmental context. The brain's global dynamic may thus be key in providing energy to the brain's neural activity at its interface with the environment.

The energy provided by the very slow frequency fluctuations of the global dynamic reflects only one half of cathexis, though. While cathexis refers to energy, it refers specifically to the investment of that energy into objects. We consequently need to link the brain's global dynamic to the processing of internal and external objects. This, as we tentatively assume, may be related to the brain's global topography. We saw in the first part that the global subcortical–cortical dynamic is manifest (and “represented”) in different degrees in different regions/networks – this amounts to global topography. Importantly, each of these regions or networks is implicated in the processing of particular inputs of both internal and external sources, that is, internal and external objects.

We are now ready to formulate a specific hypothesis about global brain dynamic and cathexis. We assume that the degree to which the brain's subcortical–cortical global dynamic is manifest in specific cortical regions/networks is related to the degree to which the former's energy is invested in specific objects within the environment (as processed in particular regions/networks). The more the global dynamic is present in, for instance, the default-mode network, the more energy will be investigated into its respective inputs and its associated internal objects related to internally oriented cognition (like self-reference and mental time travel). That is, for instance, the case in depression, where we can observe increases in both global DMN activity and self-referentiality (i.e., rumination), reflecting an abnormal increase in internal objects (Scalabrini et al. 2020, Chapter 7), while in mania, increased global dynamic can be observed in the motor cortex which, behaviorally, is manifest in psychomotor agitation, which psychodynamically may be associated with an increase in external objects (Zhang et al. 2019).

Together, we assume that what the concept of free energy refers to as “deep temporal models” is related to the brain’s global dynamic. The brain’s subcortical–cortical global dynamic provides the energy that, being manifest in different cortical regions/networks in different degrees, that is, global topography, is invested into both internal and external objects. This specifies the notion of “deep temporal models” by the global brain dynamic and, at the same time, extends it to the spatial domain, that is, “deep spatial model” referring to the brain’s global topography. We assume that the brain’s global dynamic and topography, through its deep spatial and temporal models provides the brain’s interface with the environment, including free energy minimization. This makes it possible to invest the brain’s energy into its relationship with the environment as physiological basis of what is described as cathexis on the psychological level, that is, the investment of energy into objects.

Conclusion

Cathexis is a key concept in psychoanalysis that describes the psyche's investment of energy into objects. Where and how is such energy coming from? This leads us to the brain's global dynamic and its extremely powerful very slow frequency fluctuations that extend across the whole subcortical-cortical brain. Such a global brain dynamic is manifest in different degrees in different cortical regions/networks, amounting to global topography. Since the regions/networks process specific inputs and their respectively associated objects, we assume that the degree to which the global dynamic is manifest (or "represented") in specific regions/networks is directly related to cathexis as the investment of energy into objects.

This conjoins well with the assumption of “deep temporal and spatial models” of the free energy principle that highlights the brain’s minimization of free energy with the environment. We thus provide a spatiotemporal and neuro-ecological view of the FEP that is key in linking it to cathexis as the investment of energy into object relations. What Friston describes as free energy may thus be intrinsically spatial, that is, topographic and temporal, that is, dynamic, as these provide the shared features, that is, the “common currency”, of brain and environment. That “common currency”, in turn, makes first and foremost possible the exchange of energy between brain and environment, that is, free energy minimization, on the physiological level as well as the investment of energy into objects, that is, cathexis, on the psychological level. Cathexis is thus primarily characterized in spatial and temporal terms that constitute its energetic and relational nature as basis for its associated affective and cognitive features (as discussed in current neuropsychoanalysis).

Golesorkhi M, Gomez-Pilar J, Tumati S, Fraser M, Northoff G (2021a) Temporal hierarchy of intrinsic neural timescales converges with spatial core-periphery organization. Commun Biol. Mar 4;4(1):277. doi:10.1038/s42003-021-01785-z

Golesorkhi M, Gomez-Pilar J, Zilio F, Berberian N, Wolff A, Yagoub MCE, Northoff G (2021b) The brain and its time: Intrinsic neural timescales are key for input processing. Commun Biol. Aug 16;4(1):970. doi: 10.1038/s42003-021-02483-6

Grandjean J, Corcoba A, Kahn MC, Upton AL, Deneris ES, Seifritz E, Helmchen F, Mann EO, Rudin M, Saab BJ (2019) A brain-wide functional map of the serotonergic responses to acute stress and fluoxetine. Nat Commun. 10:350.

Gutierrez-Barragan D, Basson MA, Panzeri S, Gozzi A (2019) Infraslow state fluctuations govern spontaneous fMRI network dynamics. Curr Biol. 29:2295–2306, e2295.

Hamilton C, Ma Y, Zhang N (2017) Global reduction of information exchange during anesthetic-induced unconsciousness. Brain Struct Funct. 222:3205–3216.

Hoffer PT (2005) Reflections on cathexis. The Psychoanalytic Quarterly. 74:1127–1135.

Hua J, Zhang Y, Wolff A, Northoff G (2021) Thought dynamics is mediated by alpha and theta peak frequency. Nature Communication Biology, in press.

Huang Z, Liu X, Mashour GA, Hudetz AG (2018) Timescales of intrinsic BOLD signal dynamics and functional connectivity in pharmacologic and neuropathologic states of unconsciousness. J Neurosci. 38:2304–2317.

Huang Z, Zhang J, Wu J, Qin P, Wu X, Wang Z, Dai R, Li Y, Liang W, Mao Y, Yang Z, Zhang J, Wolff A, Northoff G (2016) Decoupled temporal variability and signal synchronization of spontaneous brain activity in loss of consciousness: An fMRI study in anesthesia. Neuroimage. 124:693–703.

Kiebel SJ, Daunizeau J, Friston KJ (2008) A hierarchy of time-scales and the brain. PLoS Comput Biol. Nov;4(11):e1000209. doi: 10.1371/journal.pcbi.1000209. Epub 2008 Nov 14.

Kiebel SJ, Daunizeau J, Friston KJ (2009) Perception and hierarchical dynamics. Front Neuroinform. Jul 20;3:20. doi: 10.3389/neuro.11.020.2009. eCollection 2009.

Kohut H (1985) How does analysis cure? Chicago University Press, Chicago.

Lashley KS (1950) In search of the engram. Symposia of the Society for Experimental Biology. 4:454–482.

Leopold DA, Murayama Y, Logothetis NK (2003) Very slow activity fluctuations in monkey visual cortex: Implications for functional brain imaging. Cereb Cortex. 13:422–433.

Liang Z, King J, Zhang N (2012) Intrinsic organization of the anesthetized brain. J Neurosci. 32:10183–10191.

Liu X, de Zwart JA, Scholvinck ML, Chang C, Ye FQ, Leopold DA, Duyn JH (2018a) Subcortical evidence for a contribution of arousal to fMRI studies of brain activity. Nat Commun. 9:395.

Liu X, Zhang N, Chang C, Duyn JH (2018b) Co-activation patterns in resting-state fMRI signals. Neuroimage. 180:485–494.

McIntosh D (1993) Cathexis and their objects in the thought of Sigmund Freud. J of the American Psychoanalytic Association. 41(3):679–709.

Monti MM, Lutkenhoff ES, Rubinov M, Boveroux P, Vanhaudenhuyse A, Gosseries O, Bruno MA, Noirhomme Q, Boly M, Laureys S (2013) Dynamic change of global and local information processing in propofol-induced loss and recovery of consciousness. PLoS Comput Biol. 9:e1003271.

Northoff G (2011) Neuropsychoanalysis in practice. Oxford University Press, Oxford, New York.

Northoff G (2013) What the brain’s intrinsic activity can tell us about consciousness? A tri-dimensional view. Neurosci Biobehav Rev. May;37(4):726–738. doi: 10.1016/j.neubiorev.2012.12.004. Epub 2012 Dec 17.

Northoff G (2017) Personal identity and cortical midline structures. Psychological Inquiry. 34–45.

Northoff G (2019) Lessons from astronomy and biology for the mind-Copernican revolution in Neuroscience. Front Hum Neuroscience. Sep 19;13:319. doi: 10.3389/fnhum.2019.00319. eCollection 2019.

Northoff G, Heiss W-D (2015) Why is the distinction between neural predispositions, prerequisites, and correlates of the level of consciousness clinically relevant? Functional brain imaging in coma and vegetative state. Stroke. 46:1147–1151.

Northoff G, Lamme V (2020) Neural signs and mechanisms of consciousness: Is there a potential convergence of theories of consciousness in sight? Neuroscience & Biobehavioral Reviews. In press.

Oppenheimer M, Campos M, Warren R, Birkmann J, Luber G, O'Neill B, Takahashi K, Brklacich M, Semenov S, Licker R (2015) Emergent risks and key vulnerabilities (pp. 1039–1100) (Climate Change 2014 Impacts, Adaptation and Vulnerability: Part A: Global and Sectoral Aspects). Cambridge University Press, Cambridge.

Panksepp J, Biven L (2012) The archaeology of mind. Norton Publisher, New York.

Rodrik D (2008) One economics, many recipes: Globalization, institutions, and economic growth. Princeton University Press, Princeton, NJ.

Scalabrini A, Vai B, Poletti S, Damiani S, Mucci C, Colombo C, Zanardi R, Benedetti F, Northoff G (2020) All roads lead to the default-mode network-global source of DMN abnormalities in major depressive disorder. Neuropsychopharmacology. 45:2058–2069.

Schacter DL, Addis DR, Hassabis D, Martin VC, Spreng RN, Szpunar KK (2012) The future of memory: Remembering, imagining, and the brain. Neuron. Nov 21;76(4):677–694. doi: 10.1016/j.neuron.2012.11.001

Scholvinck ML, Maier A, Ye FQ, Duyn JH, Leopold DA (2010) Neural basis of global resting-state fMRI activity. Proc Natl Acad Sci USA. 107:10238–10243.

Scholvinck ML, Saleem AB, Benucci A, Harris KD, Carandini M (2015) Cortical state determines global variability and correlations in visual cortex. J Neurosci. 35:170–178.

Schroter MS, Spoormaker VI, Schorer A, Wohlschlager A, Czisch M, Kochs EF, Zimmer C, Hemmer B, Schneider G, Jordan D, Ilg R (2012) Spatiotemporal reconfiguration of large-scale brain functional networks during propofol-induced loss of consciousness. J Neurosci. 32:12832–12840.

Seth AK (2015) Presence, objecthood, and the phenomenology of predictive perception. Cogn Neurosci. 6(2–3):111–117. doi:10.1080/17588928.2015.1026888. Epub 2015 Apr 7.

Solms M (2015) The feeling brain. Routledge, London, New York.

Solms M (2020) Project for a (new) psychology. Neuropsychoanalysis. 23–45.

Solms M (2021) The hidden spring: A journey to the source of consciousness. Norton Publisher, New York.

Solms M, Friston K (2018) Why and how consciousness arises? Some considerations from physics and biology. Journal of Consciousness Studies. 25(5–6).

Stringer C, Pachitariu M, Steinmetz N, Reddy CB, Carandini M, Harris KD (2019) Spontaneous behaviors drive multidimensional, brainwide activity. Science. 364:255.

Tanabe S, Huang Z, Zhang J, Chen Y, Fogel S, Doyon J, Wu J, Xu J, Zhang J, Qin P, Wu X, Mao Y, Mashour GA, Hudetz AG, Northoff G (2020) Altered global brain signal during physiologic, pharmacologic, and pathologic states of unconsciousness in humans and rats. Anesthesiology. 132:1392–1406.

Turchi J, Chang C, Ye FQ, Russ BE, Yu DK, Cortes CR, Monosov IE, Duyn JH, Leopold DA (2018) The basal forebrain regulates global resting-state fMRI fluctuations. Neuron. 97:940–952 e944.

Vanhaudenhuyse A, Demertzi A, Schabus M, Noirhomme Q, Bredart S, Boly M, Phillips C, Soddu A, Luxen A, Moonen G, Laureys SJ (2011) Two distinct neuronal networks mediate the awareness of environment and of self. Cogn Neurosci. Mar;23(3):570–8. doi: 10.1162/jocn.2010.21488. Epub 2010 Jun 1.

Wen H, Liu Z (2016) Broadband electrophysiological dynamics contribute to global resting-state fMRI signal. J Neurosci. 36:6030–6040.

Yang GJ, Murray JD, Glasser M, Pearlson GD, Krystal JH, Schleifer C, Repovs G, Anticevic A (2017) Altered global signal topography in schizophrenia. Cereb Cortex. 27:5156–5169.

Zerbi V, Floriou-Servou A, Markicevic M, Vermeiren Y, Sturman O, Privitera M, von Ziegler L, Ferrari KD, Weber B, De Deyn PP, Wenderoth N, Bohacek J (2019) Rapid reconfiguration of the functional connectome after chemogenetic locus coeruleus activation. Neuron. 103:702–718 e705.

Zhang J, Huang Z, Tumati S, Northoff G (2020) Rest-task modulation of fMRI-derived global signal topography is mediated by transient coactivation patterns. PLoS Biol. 18:e3000733.

Zhang J, Magioncalda P, Huang Z, Tan Z, Hu X, Hu Z, Conio B, Amore M, Inglese M, Martino M, Northoff G (2019) Altered global signal topography and its different regional localization in motor cortex and hippocampus in mania and depression. Schizophr Bull. 45:902–910.

Zhang J, Northoff G (2022) Beyond noise to function: reframing the global signal and its topography in fMRI. Nature Communications Biology. In press.
