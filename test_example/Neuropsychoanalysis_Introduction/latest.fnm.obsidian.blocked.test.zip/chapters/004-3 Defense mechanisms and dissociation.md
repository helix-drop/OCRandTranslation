## 3 Defense mechanisms and dissociation

### Defense mechanisms I – topographic and dynamic reorganization of the self

### Introduction

### Defense mechanisms II – “primacy of defense over function” vs “primacy of function over defense”

### Part I: defense mechanisms

### “Primacy of self over defense” vs “primacy of defense over self”

### “Primacy of self over defense” – basis model of self-specificity

### Defense mechanisms – balance of internal self and external objects/environment

### Internalization vs externalization

### “Primacy of defense over function” vs “primacy of function over defense”

### Brain and defense mechanisms – topography and dynamic

Defense mechanisms and dissociation

Introduction

Defense mechanisms I – topographic and dynamic reorganization of the self

Trauma can be detrimental to the self, as it disrupts the nested neural and psychological hierarchies of self, as we have seen in the last chapter. The self can defend itself against such trauma, though. This leads us to what has been described psychodynamically as defense mechanisms. The body has its own physiological defense mechanisms, namely the immune system that allows the body to defend itself against foreign intruders like viruses by producing its own antibodies. Defense mechanisms of the psyche are here understood in a more or less analogous and thus biological way; the main difference is that defense mechanisms do not concern the body but the self that is defended against foreign intrusions and threats.

What are defense mechanisms, and what is their purpose? Roughly, defense mechanisms are a set of diverse psychic or mental mechanisms that the self can recruit in response to conflict resulting from either external traumatic events or internal contradictory thoughts, memories, and/or emotions. The purpose of defense mechanisms is to keep the self and, more generally, the psyche stable and continuous in order to protect them from the instabilities and discontinuities of both the internal and external environment. Psychologically, instabilities and discontinuities lead to anxiety and insecurity against which the self has to defend itself through recruiting its defense mechanisms. How can the self do that? Based on the previous chapter, I will demonstrate that topographic and dynamic reorganization of the neural and psychological hierarchy of self plays a key role in constituting defense mechanisms.

Defense mechanisms II – “primacy of defense over function” vs “primacy of function over defense”

Freud himself focused especially on repression to keep painful thoughts and affects out of consciousness (see Freud 1915, as well as Bazan and Snodgras 2012; Shevrin et al. 2017; Bazan 2013; see Chapter 5 for discussion of repression in relation to consciousness). Since the early days of Freud, various other defense mechanisms, including immature and mature, have been described (see subsequently for details) (Vaillant 1992; Freud 1946; Northoff et al. 2007; Boeker et al. 2019). These include introjection and projection as well as splitting, reaction formation, identification, incorporation (and various others).

The multitude of different defense mechanisms speaks for a highly dynamic and context-dependent structure and organization, with different layers nesting within each other. This is indeed implicitly assumed when considering that later more mature defense mechanisms like reaction formation build on and are nested within the earlier rather immature defense mechanisms of splitting, projective identification, and so on. The different defense mechanisms are related to different functions. For instance, affective functions like primary and secondary emotions as well as cognitive functions like attention, memory, inhibition, and so on have been associated with different defense mechanisms in current neuropsychoanalysis (Panksepp and Biven 2012; Bazan 2013; Bazan et al. 2019; Shevrin et al. 2013; Solms 2015). The background assumption here is that the brain's functions constitute the defense mechanisms – this amounts to what I describe as "primacy of function over defense".

However, functions are determined by particular contents; the different affects are associated with different contents, and the same holds analogously for the different cognitive functions. The content-based nature of functions stands in contrast to defense mechanisms, though. Unlike functions, defense mechanisms are not determined by particular content but rather by their structure in the response to conflict. The same defense mechanisms, like splitting (or others), can be associated with different contents as well as with different affects and cognitive functions. Rather than by content, defense mechanisms must thus be defined by their structure – they reflect the structural organization of the psyche, that is, its topography and dynamic. That very same structural organization driving the defense mechanisms, in turn, strongly shapes the functions, including their content. This amounts to what I refer to as “primacy of defense over function”.

The reversal in the relationship of defense and function carries major implications for how to link defense mechanisms to the brain. If defense mechanisms are based on structure rather than content and function, we need to take into view the brain's spatial topography and temporal dynamics rather than its various functions. Neuronally, defense mechanisms may then be closely related to the hierarchical balance of the three layers of self as well as to its scale-free integration of slow and fast dynamics within the power spectrum. Taken in this sense, defense mechanisms can be viewed as preservation and/or reorganization of the brain-based topography and dynamic of self. We will describe defense mechanisms in such a topographic and dynamic sense in the first part, which is complemented by dissociation as a paradigmatic example in the second part.

Part I: defense mechanisms

“Primacy of self over defense” vs “primacy of defense over self”

Defense mechanisms are closely related to the self. They are mechanisms of the self to maintain its own stability and protect itself against conflict resulting from non-self-specific events within the internal and/or external environment. Put simply, defense mechanism are the tools of the self that it uses to defend and preserve its own intrinsic structure and organization, that is, its topography and dynamic.

In that sense, defense mechanisms can be compared to the body’s immune defense. The immune system recruits and constitutes antibodies to protect and defend the internal body against external invaders like antigens such as viruses and bacteria. Analogously, defense mechanisms can be conceived as the “psychological immune system” of the self on a psychological level: here traumatic events and conflicts take on the role of the antigens like viruses or bacteria in the case of the physiological immune system. Following the analogy of the immune system, we here conceive defense mechanisms in a primarily biological way: they serve to defend the self.

Different relationships of self and defense mechanisms can be conceived. One way is to conceive the self as secondary to result from the more primary defense mechanisms, or, alternatively, the defense mechanisms may be secondary to the primary self. Let us start with the first option. In current neuroscience and psychology, the self is often determined by particular bodily and/or cognitive contents resulting from the integration of the various sensory, affective, and cognitive functions (Northoff 2016b).

Since it is defined by contents based on the integration of diverse functions, the self is here conceived as a higher-order function itself – this amounts to a higher-order model of self. Applying such a higher-order model of self, one would conceive the self to be constituted by the defense mechanisms: putting and integrating all defense mechanisms together yields a self. This amounts to “primacy of defense over self”.

However, the assumption of the “primacy of defense over self” conflicts with the psychodynamic role of defense mechanisms, that is, defending and protecting the self. Only if there is a self, in whatever gestalt, is there something to defend. One would then assume that the self is more basic and fundamental, which, in a second step, invokes defense mechanisms to protect itself against external events. Now the self or ego is supposed to provide the basis or fundamental, which, in turn, gives rise to the defense mechanisms. This entails “primacy of self over defense”.

“Primacy of self over defense” – basis model of self-specificity

Presupposing primacy of self over defense entails that the self is primary, while defense mechanisms are secondary: only if there is some kind of self can it be defended. If, in contrast, there is no self, there is nothing to defend, rendering defense mechanisms superflu- distinction of antibody and antigen in the physiological immune system. Analogously, there may not be clear-cut distinction of self and defense mechanisms either. Especially the early and immature defense mechanisms of internalization and externalization (see subsequently for details) like incorporation and excorporation, introjection and projection, and identification and self-objectification not only defend a pre-existing self but, at the same time, also constitute the self. This pertains to a double role of the defense mechanisms for the self including not only (i) protection and defense of the self but also (ii) constitution or construction of the topography and dynamic of the self.

(BMSS) (Northoff 2016b; Scalabrini et al. 2020, 2022).

In a nutshell, the BMSS supposes that the self is a basic and fundamental feature that provides the basis for subsequent affective, cognitive, sensory, motor, and social function. What exactly is meant by “basis” here? Rather than providing contents specifically related to the self like self-referential contents such as one’s own name or face, “basis” refers here to structure and organization, namely topography and dynamics. By constituting a particular dynamic and topography, the self structures and organizes the various contents of affective, cognitive, sensory, motor, and social functions. Constituting such a temporo-spatial basis, the self operates on a deeper and more fundamental level than the various functions while at the same time organizing and structuring them in a self-specific way, hence the name “basis model of self-specificity”.

How can we support the BMSS with its assumption of such a deeper level of self on neuronal grounds? One line of support consists in the distinction of resting state and task-related activity. The self as higher-order function is typically associated with specific forms of task-related activity during self-referential stimuli (own face or name) as distinguished from non-self-referential inputs (like another person's name or face). This is the different in the case of the self as basis. In that case, the self is related to the brain's spontaneous activity, remaining independent of particular tasks or stimuli, that is, task-related activity.

Various studies of the brain’s spontaneous activity suggest that its dynamic, like its power law exponent (as measured during the resting state), is directly related to the degree of self-consciousness (Chapter 1). This suggests that the self is encoded by the spontaneous activity in primarily spatiotemporal (rather than cognitive and thereby content-based) terms. Together, these studies, as described in detail in Chapter 1, support the view of the self as basis and fundamental features as explicated in the BMSS as distinguished from the traditional higher-order model of self.

We need to be careful with the seemingly clear-cut distinction of self and defense mechanisms, though. There is, for instance, no clear distinction of antibody and antigen in the physiological immune system. Analogously, there may not be clear-cut distinction of self and defense mechanisms either. Especially the early and immature defense mechanisms of internalization and externalization (see subsequently for details) like incorporation and excorporation, introjection and projection, and identification and self-objectification not only defend a pre-existing self but, at the same time, also constitute the self. This pertains to a double role of the defense mechanisms for the self including not only (i) protection and defense of the self but also (ii) constitution or construction of the topography and dynamic of the self.

Defense mechanisms – balance of internal self and external objects/environment

Defending and protecting the internal self against conflicts most often resulting from external events pits the defense mechanisms right “in-between” internal self and external objects, namely self and environment. They are neither purely internal, for example, related to the self, nor completely external, such as originating in the environment. Instead, defense mechanisms provide the connection of internal self and external environment, that is, the “self-environment connection”, as I say, which, psychodynamically put, could be rephrased as “self-object relation or connection” (Spagnoli and Northoff 2021). Due to their “location” at the interface of self and environment, defense mechanisms are both intra-psychic and inter-personal at the same time – Mentzos (1992) therefore speaks of “psycho-social arrangements”.

Put in a metaphorical way, defense mechanisms establish the highways between self/ego and environment/object. Due to the fact that they constitute the internal–external highways, defense mechanisms are manifest in behavior, reflecting how the self navigates within its respective environmental context. Different defense mechanisms thus go along with different forms or patterns of behavior. For instance, more mature defense mechanisms like reaction formation only induce neurotic behavior, while otherwise behavior remains relatively “normal”. In contrast, the predominance of early, more immature defense mechanisms like projection and introjection induces severe changes in behavior, like psychotic or depressed behavior.

Together, defense mechanisms are neither purely internal, that is, self, nor entirely external, that is, environment. Instead, they constitute different balances of internal self and external environment, that is, self–environment connection. This can already be seen in the case of internalization and externalization that refer to different directions within the relationship of self and environment, namely from object/environment to self and from self to object/environment. Such internal–external balance is well reflected in the following quote by Melanie Klein, who speaks of “giving in” (as corresponding to internalization) and “taking out” (as corresponding to externalization):

the ego can then also feel that it is able to reintroject the love it has given out, as well as take in goodness from other sources, and thus be enriched by the whole process. In other words, in those cases there is a balance between giving out and taking in between introjection and projection. (1955, 312–313; see also Kernberg 1966, 364–365)

Internalization vs externalization

The most basic and therefore early and immature defense mechanisms are those related to internalization and externalization. Roughly, internalization means that something from the outside environment, that is, objects, are related to the inside of the self, while externalization describes the reverse direction, that is, from the inside of the self to the outside of the environment. This means that both establish “highways” between self and environment, albeit in different directions: internalization constitutes the “highway” from the environment/object to the self, while externalization describes the “highway” on the other side leading in the opposite direction.

Both internalization and externalization can be conceived of as umbrella terms for various defense mechanisms. Establishing the direction from object to self, internalization can play out in distinct ways like in incorporation, where an external object is integrated within and becomes part of the self with no boundaries at all anymore, as when a baby includes the mother as part of her/his own self. There is also introjection, where an external object is not integrated but closely attached and related to the self with somewhat blurry boundaries. Finally, one may also include identification, where the self transiently identifies itself with an external object while both remaining clearly separate, like a soccer fan identifying her/himself with the soccer match, but only for the latter's duration.

This is analogously so in the case of externalization, which describes the reverse direction from self to object. This includes ex-corporation, where the self is located outside the internal space of body and mind in the external environment, like when attributing ownership of one's thoughts to another person. Moreover, there is projection, where some parts of the inside of the self are located outside in the environment, like in hallucination or delusion. Finally, self-objectification is prevalent when the own self is considered and referred to only from the third-person perspective but no longer in first-person perspective.

Together, defense mechanisms refer to the internal–external relationship of self and environment. Moreover, as in the topography of self, there seem to be different layers of defense mechanisms like different layers of highways superseding each other when connecting self and environment. How these different layers of defense mechanisms are related to the self with its three-layer topography and temporal slow–fast hierarchy remains open at this point.

“Primacy of defense over function” vs “primacy of function over defense”

Defense mechanisms are manifest and expressed primarily in affect and emotion (rather than in cognition). Let us portray the example of introjection that refers to the degree to which an object of the external environment is internalized by the own self. We can see that introjection is closely related to different psychological functions. For instance, Otto Kernberg describes the affective coloring of introjection:

The affective coloring of introjection is an essential part of it and represents the active valence of introjection, which determines the fusion and organization of introjections of similar valences. Thus, introjection taking place under the positive valence of libidinal instinctual gratification, as in loving mother–child contact, tend to fuse and become organized in what has been called somewhat loosely, but pregnantly, the “good internal object”. Introjections taking place under the negative valence of aggressive drive derivates tend to fuse with similar negative valence introjections and become organized in the “bad internal objects”. (1966, 360–361)

Yet another example of the strong affective coloring is depression or major depressive disorder (MDD), where introjection is most prominent. Excessive degrees of introjection are here manifest in an extremely strong focus on the self, that is, increased self-focus (Northoff et al. 2011; Northoff 2016a; Scalabrini et al. 2020), which, in turn, induces strong negative emotions like sadness and guilt. That further supports the major importance of affect and emotion in expressing defense mechanisms (see also Panksepp and Biven 2012). However, the close coupling of defense mechanisms and affect/emotion should not deceive one to postulate that the latter constitute the former: this would be to confuse the expression/manifestation of defense mechanisms in terms of affect/emotion with their constitution at the more basic interface of self and environment when encountering conflict.

More generally, we need to avoid slipping back into the what I described as the “primacy of function over defense”. Such a view still seems to predominate in psychoanalysis, as expressed by Kernberg:

I will consider introjections as independent psychic structures, mainly growing out of primary autonomous functions (perception and memory) as they are linked with early object relationships, and although introjections will be seen as strongly influenced by oral conflicts, they will not be seen as growing out of them. (1966, 358–359)

Current neuropsychoanalysis seems to pursue an analogous strategy, as defense mechanisms are often associated with particular affective or cognitive functions (Panksepp and Biven 2012; Solms

2015; Bazan 2013; Shevrin et al. 2013; Bazan et al. 2019). This still presupposes the “primacy of function over defense”. Instead, we here suggest to consider the reverse direction, where defense mechanisms shape and are manifest in affective and cognitive function, that is, the “primacy of defense over function”. How can we describe defense mechanisms, though, if not in cognitive and affective terms? This leads us to the deeper layer of the mind, namely its spatiotemporal constitution in terms of topography and dynamic. Defense mechanisms are then conceived as particular spatiotemporal constellations featuring a specific topography and dynamic – this will be illustrated by the example of dissociation in the second part of this chapter.

Brain and defense mechanisms – topography and dynamic

How can we describe defense mechanisms if not by specific sensory, affective, and/or cognitive function? For that we need to take into view the deeper level of the psyche, its topography and dynamic and how that is mediated by a more or less analogous topography and dynamic of the brain. Let us make some tentative suggestions.

The hierarchy of defense mechanisms is well established, following most often the distinction of immature and mature. Is that hierarchy related to the hierarchy of self, with its three-layer topography? Given the intimate relationship of self and defense mechanisms with the primacy of the former over the latter (see previously), one would indeed assume so. Disruptions in one layer of self may then disrupt its balance with the respective other layers of self, leading to an overall topographic reorganization – this was indicated in the case of trauma in the previous chapter.

Given the close relationship of self and defense mechanisms, we assume that the latter induce changes in the three-layer topography of the former. Moreover, the layer of self that is predominantly involved in the defense may determine the degree of maturity or immaturity of the defense mechanisms. If, for instance, the lower layer of self, the interoceptive self, is disrupted and reorganized, it may reverberate throughout both exteroceptive and mental/cognitive self – this may resemble the more immature defense mechanisms.

### From past to present – dissociation as “out of consciousness” (Pierre Janet)

### Part II: dissociation

### Dissociation as disrupted integration – “cracks in consciousness and brain”

### Dissociation and integration II – disrupted integration as “common currency” of brain and psyche

If, in contrast, the mental/cognitive layer of self reorganizes itself, it may be more restricted to the mental layer while leaving intero- and exteroceptive layers more or less untouched and intact – this may resemble the more mature defense mechanisms.

The same may be said about the temporal dynamic. If the slower frequencies change in their power, they may reverberate throughout the whole structure of the power spectrum, as the faster frequencies are nested within the slower ones. The whole systems' scale-freeness and long-range temporal correlations (LRTC) will change and thereby lead to reorganization of the dynamic structure of self with more immature defense mechanisms. If, in contrast, only the faster frequencies change while leaving the slower ones more or less intact, the scale-freeness and its LRTC will be essentially preserved – this may be manifest in more mature defense mechanisms.

Finally, the most fundamental change may occur when the brain's neuro-ecological, scale-free, and nested relationship with the world is disrupted. This is the case in the various layers of trauma we discussed in the second chapter. These cases share the potential mismatch between the brain's scale-freeness and the world's scale-freeness. That, in turn, disrupts the brain's neuro-ecological embedding within its respective environmental context, including its LRTC with the latter. This may, for instance, be the case in the more immature forms of internalization and externalization like projection and introjection, which are fundamentally changed in psychiatric disorders like schizophrenia and depression (Chapter 7).

Part II: dissociation

From past to present – dissociation as “out of consciousness” (Pierre Janet)

How can we illustrate such topographic and dynamic view of defense mechanisms in more detail? One key defense mechanism is dissociation that is closely linked to trauma. We have seen that trauma concerns specific event life events and contents that are threatening to the very existence of the self (Chapter 2). One way to react is to simply push those events outside consciousness – this has been described as dissociation by Pierre Janet in his original work at the end of the 19th century (see Scalabrini et al. 2020). He highlighted the abnormalities in the subjects' coordination and integration of their different psychological functions whose contents are operated in a more compartmentalized, disrupted, or dissociated way, for example, “out of consciousness”:

Unable to integrate the traumatic memories, they seem to have lost their capacity to assimilate new experiences as well. It is . . . as if their personality which definitively stopped at a certain point cannot enlarge any more by the addition of new elements. (Pierre Janet 1907, 532)

The central role of disrupted coordination and integration of psychological functions and their contents also resurfaces in more recent characterizations of dissociative disorders (Lanius et al. 2005; Liotti 2004). Dissociation is nowadays considered a disruption of ordinarily integrated functions in processing of mental contents as in consciousness and perception (DSM-5; American Psychiatric Association 2013) (see Scalabrini et al. 2020).

Dissociative manifestations consist in positive and negative symptomatology: (1) positive symptoms that are experienced as unbidden intrusions into awareness and behavior, with accompanying losses of continuity in subjective experience (i.e., fragmentation of identity, depersonalization, and derealization), and/or (ii) negative symptoms that are made up of the inability to access information or to control mental functions that normally are readily amenable to access or control (i.e., such as amnesia). Both positive and negative dissociative symptoms are manifested in several stress-related psychiatric dysfunctions such as post-traumatic stress disorders, dissociative disorders, and borderline personality disorders (Scalabrini et al. 2017, 2018; Lanius et al. 2012). However, the nature and mechanism of dissociation remains unclear.

Early and more recent investigators suggest additional symptoms that concern the whole personality. Specifically, Janet spoke of abnormal mental integration of the different contents, resulting in a lack of integration among two or more “systems of ideas and functions that constitute personality” (Janet 1907, 1973/1889, 1920). This is well in accordance with more recent studies that also point out abnormal integration as a structural pathology of personality (theory of structural dissociation of the personality – TSDP). One can thus speak of structural symptoms in dissociation that complement its positive and negative symptoms.

Dissociation as disrupted integration – “cracks in consciousness and brain”

Pierre Janet’s characterization of dissociation as a disorder of integration strongly surfaces in our current view of dissociation. Like Janet, present descriptions clearly point out that dissociation concerns isolated contents, such as information, that are not connected, linked, or integrated with other contents. Dissociation may thus be characterized by an abnormal high degree of non-integrated information that does not become conscious. Even worse, the integration of these contents into the ongoing consciousness seems to be blocked in dissociation, with such a blockade apparently being related to the severity of the traumatic experience as marked by non-integrated contents. The parts or elements themselves are still present but remain non-integrated. Accordingly, on a psychological level, dissociation can be characterized as a disorder of integrated information, while, at the same time, non-integrated information still remains present.

Disruption in integration interferes with a coherent encoding of salient events (Scalabrini et al. 2017). That, in turn, leads to an unintegrated perception where different aspects of the event (such as sensory, affective, and cognitive) are encoded separately rather than being connected and integrated. The lack of connection and integration of sensory, affective, and cognitive aspects of events can distort one's perception including its various aspects, such as time (e.g., acting or feeling as if a traumatic event experienced in the past is still present), body (e.g., depersonalization and out of body experiences), thought (e.g., voice hearing in second-person perspective), and emotional numbing (Frewen and Lanius 2014). Positive symptoms like intrusions can then feature the perception of isolated un-integrated sensory stimuli as if the respective event is still present in time (Van der Kolk 2015; Van der Kolk et al. 1996).

In the case of negative symptoms, one may assume that the traumatic events and their contents simply “fall through the cracks of "consciousness" in a rather literal way: they are no longer integrated with others, that is, non-traumatic ones, for which reason they cannot be perceived anymore, that is, they are no longer associated with consciousness at all. This is paradigmatically reflected in the loss of awareness with a continuum of different forms of des- or un-integrated contents starting from absorptions and mild gaps in awareness to more pathological manifestations such as depersonalization, derealization, and amnesia (Putnam 1995). This, as we will postulate later, may be related to "cracks in the temporo-spatial structure of the brain's spontaneous activity".

Dissociation and integration I – disrupted integration on intra-regional, inter-regional, and global levels of the brain’s neural activity

In order to understand how we can link disrupted integration on the psychological level to the brain with abnormal integration on the neuronal level, we first have to briefly determine the concept of integration in a most basic and general sense (e.g., independent of either psychological or neuronal levels). Integration can be defined as the combination of different features, parts, or objects into one unified whole or unity. The different features or parts that are integrated can concern psychological functions, such as affective, sensory, cognitive, and so on, including their respective contents, while on the neuronal level, the different elements refer to the different regions' and networks' neuronal activities and how they are connected and integrated with each other.

The relationships between different brain regions are constituted by so-called “functional connectivity” (FC), which measures the degree of neuronal synchronization between different regions, shaping various neural networks in the brain’s resting state (Menon 2011, for a review). Such neuronal synchronization allows integration of neuronal activity from different brain regions (and their respective psychological functions and contents) over longer stretches of time and distant regions/networks. Together, this constitutes a complex elaborated temporo-spatial structure and dynamics in the brain’s spontaneous activity (Northoff 2014a and b; Northoff et al. 2020).

To better elucidate the connection between neuronal synchronization and the concept of integration, we might consider the example of the visual binding problem, that is, how different properties of an "object" might result in a unified global representation. One of the proposed solutions is based on the idea that visual objects are coded by a firing synchronization of cell assemblies. Following that hypothesis, this refers to (i) "local" integration of neuronal properties, that is, synchronization with neighboring cortical regions (deputed to the same function). This is different from (ii) "long distance" integration, that is, synchronization with distant cortical regions (deputed to different functions). Finally, there is (iii) "global" integration, that is, synchronization at the global level of the brain activity, which is necessary for the vision of the object within a more complex context of a global conscious experience. Departing from this example, one may want to distinguish between different neuronal levels of synchronization in fMRI, as on the (i) local or intra-regional level, (ii) network or inter-regional level, and (iii) global level of the whole brain. These different levels of integration will serve as a roadmap for our investigation of altered integration in dissociation.

Dissociation and integration II – disrupted integration as “common currency” of brain and psyche

How is integration on intraregional, inter-regional, and global brain levels related to integration on the psychological level? Neuronal synchronization and integration are central in constituting the spontaneous activity's temporo-spatial structure (see Scalabrini et al. 2020 for details). Even more important, based on recent data, we propose that neuronal synchronization and integration are linked on the regional, network, and global levels of the brain's neural activity; disruption of this link leads to disintegration on the psychological level, resulting in positive, negative, and structural symptoms of dissociation.

Accordingly, integration or, better, disruption of integration provides a link or bridge and thus a “common currency” (see Northoff et al. 2020) of neuronal and psychological levels in dissociation. Conceived from a historical perspective, this integration providing a “common currency” extends Janet’s proposal from the psychological to the neuronal level. Integration is disrupted on both psychological and neuronal levels, for which reason neuronal changes can transform into psychological changes. What is “taken out” of the brain’s neural integration and remains isolated surfaces in a more or less analogous way on the psychological level: here the respective content remains “out of consciousness” as well as unconnected and deeply isolated from other contents in the unconscious.

In sum, following and extending the original description by Pierre Janet, we here propose that dissociation is a disorder of integration on both psychological and neuronal levels. Several lines of evidence, including our own data, lend support to the assumption that integration, in dynamic and temporo-spatial terms, is disrupted on all three levels of the brain's neuronal activity, that is, regional, network, and global, in dissociative states. We assume different temporo-spatial mechanisms to be altered in dissociation. Specifically, based on the neuronal data, we assume that temporo-spatial binding of different stimuli/contents on the regional level, temporo-spatial synchronization of different functions on the network level, and temporo-spatial globalization of linking contents to level/state of consciousness on the global level are disrupted in dissociation.

Importantly, temporo-spatial integration on the three levels of the brain, that is, intra-regional, inter-regional, and global, can be linked to the different symptoms, that is, positive, negative, and structural, in dissociation. Hence, we conceive disruption in temporo-spatial integration as a “common currency” (Northoff et al. 2020) of the neuronal and psychological levels in dissociation. We therefore conclude that we can extend Pierre Janet's original concept of dissociation as disorder of integration to the brain in terms of temporo-spatial disintegration at distinct levels (intra-regional, inter-regional, global) as manifest in distinct symptoms (positive, negative, personality/global).

Conclusion

Defense mechanisms date back to the beginning of psychoanalysis and have been considerably developed since. Despite all the differences, defense mechanisms are regarded as psychological strategies to maintain and protect the self from conflicts, including both painful external events and internal memories. Current neuropsychoanalysis conceives of defense mechanisms mainly in terms of affective and cognitive functions – we therefore speak of “primacy of function over defense”.

That neglects the deeper layers of our defense strategies, which are more basic and fundamental than the various functions. This deeper layer refers to the topography and dynamic of defense mechanisms, which we here explicate on both neuronal and psychological grounds. We thus characterize defense mechanisms in terms of their topography and dynamic; this allows them to connect internal self and external environment on a most basic level, prior to specific functions.

Klein M (1955) On identification. Basic Books, New York.

Lanius RA, Brand B, Vermetten E, Frewen PA, Spiegel D (2012) The dissociative subtype of posttraumatic stress disorder: Rationale, clinical and neurobiological evidence, and implications. Depression and Anxiety. 29(8):701–708.

Lanius RA, Williamson PC, Bluhm RL, Densmore M, Boksman K, Neufeld RW, ... Menon RS (2005) Functional connectivity of dissociative responses in posttraumatic stress disorder: A functional magnetic resonance imaging investigation. Biol Psychiatry. 57(8):873–884.

Liotti G (2004) Trauma, dissociation, and disorganized attachment: Three strands of a single braid. Psychotherapy: Theory, Research, Practice, Training. 41(4):472.

Menon V (2011) Large-scale brain networks and psychopathology: A unifying triple network model. Trends Cogn Sci. Oct;15(10):483–506. doi:10.1016/j.tics.2011.08.003. Epub 2011 Sep 9.

Mentzos S (1992) Psychose und Konflikt. Vandenhoeck und Rupprecht, Goettingen.

Northoff G (2014a and b) Unlocking the brain. Vol. I Coding; Vol II Consciousness. Oxford University Press, Oxford, New York.

Northoff G (2016a) Spatiotemporal psychopathology I: No rest for the brain’s resting state activity in depression? Spatiotemporal psychopathology of depressive symptoms. J Affect Disord. Jan 15;190:854–866. doi: 10.1016/j.jad.2015.05.007. Epub 2015 May 14. PMID: 26048657 Review.

Northoff G (2016b) Is the self a higher-order or fundamental function of the brain? The “basis model of self-specificity” and its encoding by the brain’s spontaneous activity. Cogn Neurosci. Jan–Oct;7(1–4):203–222. doi:10.1080/17588928.2015.1111868. Epub 2016 Feb 1. PMID: 26505808.

Northoff G, Bermpohl F, Schoeneich F, Boeker H (2007) How does our brain constitute defense mechanisms? First-person neuroscience and psychoanalysis. Psychother Psychosom. 76(3):141–153. doi:10.1159/000099841

Northoff G, Wainio-Theberge S, Evers K (2020) Is temporo-spatial dynamics the “common currency” of brain and mind? In quest of “spatiotemporal neuroscience”. Phys Life Rev. Jul;33:34–54. doi: 10.1016/j.plrev.2019.05.002. Epub 2019 May 23.

Northoff G, Wiebking C, Feinberg T, Panksepp J (2011) The “resting-state hypothesis” of major depressive disorder—a translational subcortical-cortical framework for a system disorder. Neurosci Biobehav Rev. Oct;35(9):1929–1945. doi: 10.1016/j.neubiorev.2010.12.007. Epub 2010 Dec 28. PMID: 21192971 Review.

Panksepp J, Biven L (2012) The archaeology of mind. Norton Publisher, New York.

Putnam FW (1995) Traumatic stress and pathological dissociation. Annals of the New York Academy of Sciences. 771(1):708–715.

Scalabrini A, Cavicchioli M, Fossati A, Maffei C (2017) The extent of dissociation in borderline personality disorder: A meta-analytic review. J Trauma Dis-sociation. Jul–Sep;18(4):522–543. doi: 10.1080/15299732.2016.1240738. Epub 2016 Sep 28.

Scalabrini A, Mucci C, Esposito R, Damiani S, Northoff G (2020) Dissociation as a disorder of integration: On the footsteps of Pierre Janet. Prog Neuropsychopharmacol Biol Psychiatry. Jul 13;101:109928. doi:10.1016/j.pnppb.2020.109928. Epub 2020 Mar 16.

Scalabrini A, Mucci C, Northoff G (2018) Is our self related to personality? A neuropsychodynamic model. Front Hum Neurosci. Oct 4;12:346. doi:10.3389/fnhum.2018.00346. eCollection 2018.

Scalabrini A, Schimmenti A, De Amicis M, Porcelli P, Benedetti F, Mucci C, Northoff G (2022) The self and its internal thought: In search for a psychological baseline. Conscious Cogn. Jan;97:103244. doi: 10.1016/j.concog.2021.103244. Epub 2021 Nov 27.

Scalabrini A, Vai B, Poletti S, Damiani S, Mucci C, Colombo C, Zanardi R, Benedetti F, Northoff G (2020) All roads lead to the default-mode network-global source of DMN abnormalities in major depressive disorder. Neuropsychopharmacology. Nov;45(12):2058–2069. doi: 10.1038/s41386-020-0785-x. Epub 2020 Aug 2.

Shevrin H, Snodgrass M, Brakel LA, Kushwaha R, Kalaida NL, Bazan A (2013) Subliminal unconscious conflict alpha power inhibits supraliminal conscious symptom experience. Front Hum Neurosci. Sep 5;7:544. doi: 10.3389/fnhum.2013.00544. eCollection 2013.

Solms M (2015) The feeling brain. Routledge, London, New York.

Spagnoli R, Northoff G (2021) The dynamic self. Routledge Publisher, London, New York.

Steinig J, Bazan A, Happe S, Antonetti S, Shevrin H (2017) Processing of a subliminal rebus during sleep: Idiosyncratic primary versus secondary process associations upon awakening from REM- versus non-REM-sleep. Front Psychology. Nov 20;8:1955. doi: 10.3389/fpsyg.2017.01955. eCollection 2017.

Vaillant G (1992) Ego mechanisms of defense. American Psychiatric Association Press, Washington, DC.

Van der Kolk BA, Pelcovitz D, Roth S, Mandel FS (1996) Dissociation, somatization, and affect dysregulation. The American Journal of Psychiatry. 153(7):83.
