## 6 Dreams

### Introduction

### Dream contents I – semantic association vs semantic similarity/identity of external contents

### Part I: topography and dynamic of the psyche in dreams

### Dream contents II – manipulation of internal contents like body, emotion, memories, and self

### The psyche and its dreams – topography and dynamic

### Part II: topography and dynamic of the brain in dreams

### Topography of the cortex in dreams I – default-mode network, hippocampus, and visual cortex

### Topography of the cortex in dreams II – subcortical–cortical biochemical modulation

### Dynamic of the cortex in dreams I – shift to slower frequencies

### Dynamic of the cortex in dreams II – longer time windows

### Part III: topographic-dynamic reorganization theory of dreams

### Topographic reorganization – increase in internally oriented cognition

### Self in dreams I – relative increase of the mental self

Dreams

Introduction

Dreams take on a key role in psychoanalysis. They provide access to the unconscious, that is, the “via regia to the unconscious”. At the same time, dreams are considered therapeutic, as they offer insight into early traumatic memories that then can be used for conflict resolution in psychotherapy. Finally, there has been much neuroscientific research on dreams in recent years so that they provide a paradigmatic example of inner mental life.

Going back to Freud, dreams are psychoanalytically often conceived as wish fulfillment reflecting endogenous drives and primary processes that are disinhibited and uncontrolled. They are conceived as the hallucinatory realization of those impulses that are strongly driven by energy, that is, cathexis, and unconscious affective demands. More recently, dreams have been related to specific affect/emotions like the SEEKING system that drives emotion and behavior (Panksepp and Biven 2012; Solms 2020), while cognitively, dreams are associated with unconscious memories: the memories often can be traced back to early childhood where they have been “stored” in terms of body signatures in the unconscious without yet leaving any cognitive traces in the conscious. Consequently, the concept of “embodied memories” has been invoked to describe those memories that are recruited and reactivated during dreams (Leuzinger-Bohleber et al. 2019).

The study of dreams has gone far beyond psychoanalysis to psychology and neuroscience in recent years, though. Hence, some of the original psychodynamic features of dreams like unconscious memories are now taken up in psychology and neuroscience. I suppose that the topography and dynamic of the psyche (first part) during dreams is manifest in a more or less corresponding topography and dynamic of the brain (second part). That leads me to develop what I describe as the “topographic-dynamic re-organization theory of dreams” (TRoD) (third part).

Part I: topography and dynamic of the psyche in dreams

Dream contents I – semantic association vs semantic similarity/identity of external contents

Psychologically, dreams can first and foremost be characterized by rather bizarre emotions and cognitions in the hallucinatory episodes. Contents that are usually not connected or integrated are now linked and combined or put together in a semantically novel way. One can still somewhat identify certain familiar external environmental contents like other humans, buildings, and so on, but they are put together in a semantically bizarre and strange way. Hence, there is some semantic connection between the conscious contents in the awake state and those occurring during dreams.

However, that connection does not imply semantic identity or sameness of the external contents in awake and dream states. Fogel et al. (2018) developed a particular method to investigate the degree of semantic association during dreams. They let subjects, during the awake state, mentally imagine tennis playing (after seeing real tennis players in visual display) (and spatially navigate) in the awake state. After that, they asked the subjects to take short naps from which they were woken up asked to report their dreams. The investigators recorded all the words and sentences uttered by the subjects in their dream reports; their dream reports were then entered into a machine learning algorithm for detecting semantic relations to tennis playing (and spatial navigation). This allowed researchers to detect and quantify the degree to which semantic contents associated with tennis were incorporated into the contents experienced during dreams.

The results show that there is a semantic relationship of the dream contents with tennis playing. For instance, the subjects dreamt about playing ball on the green lane in a park but did not experience tennis playing itself. This suggests semantic association but not semantic similarity: the contents during the awake state (tennis) were incorporated into the dream contents (soccer playing in a park) but were not replayed in an identical or similar way. Hence, there is semantic association but not semantic similarity or identity.

This is well in accordance with, for instance, the paintings by Salvador Dali. He reconstructed his often bizarre dream contents in his paintings: they are bizarre because they reflect distortions and thus semantic associations of the real contents occurring in the awake state. Dreams are thus not simply a replay of semantically similar contents. Instead, they feature active manipulation of our awake contents during the dream state.

Dream contents II – manipulation of internal contents like body, emotion, memories, and self

We have so far focused only on externally oriented mental contents like the tennis playing in dreams. The active manipulation of dreams extends even further, as it also includes mental contents of internally oriented cognition and emotion. The best example of that is the experience of the own body and its self in dreams. As in the case of our tennis example, the relationship of body and self in dreams is somewhat loosened but not disrupted during dreams. For instance, the own body may no longer be experienced as such – rather, as in extreme cases, one may experience oneself to be out of one's own body, something that is described as "full body illusion" (FBI) (Windt 2021).

Despite being possibly detached from its own body, the own self is still experienced as such at the same time. It is after all my own self in first-person perspective that experiences the contents in the dream hallucination – this experience of the own self has been described as “felt presence” (FP) (Windt 2021). Hence, even if “body-less”, dreams are not “self-less”. The presence of self is even more supported by the fact that dream contents are highly autobiographical.

As pointed out in psychodynamics, dream contents tell us about the own self and its hidden and/or earlier experiences that remain unconscious in the awake state. Dreams may thus be seen as an entrance gate to the dynamic unconscious and possibly also, in part, of the deep unconscious of the self: this may be manifest in the self's previous relations to the environment which, usually remaining unconscious in the awake state, resurface in dreams.

The experience of an altered sense of self and its otherwise unconscious life events is accompanied by strong affects and emotions in dreams. They mostly reflect what Panksepp describes as primary emotions, seeking, lust, care, and so on, which psychodynamically can be described as primary processes (Panksepp and Biven 2012; Solms 2015, 2020, 2021). Especially the SEEKING system, which drives emotion and behavior, has been assumed to take on a key role in dreams (Panksepp and Biven 2012; Solms 2020).

Importantly, the affects and emotions in dreams are often described as unbound, free-floating, and unconstrained, remaining devoid of any form of rationality. The same may apply to certain cognitive contents like the events one experiences in dreams that may also be more or less free-floating proceeding in a completely spontaneous way without any deliberative control (Christoff et al. 2016; Windt 2021; Fox et al. 2016). One can thus characterize affect not only by its often bizarre nature in dreams but also by its extreme degree of spontaneity, lacking any containment by deliberative and rational control. This suggests that the dynamic of dreams is also changing compared to the awake state.

Besides their strong affects/emotions, dreams also involve unconscious memories: the memories often can be traced back to early childhood where they have been “stored” in terms of body signatures in the unconscious without yet leaving any cognitive traces in the conscious. Consecutively, the concept of “embodied memories” has been invoked to describe memories recruited and reactivated during dreams (Leuzinger-Bohleber et al. 2019).

The psyche and its dreams – topography and dynamic

Together, these phenomenological observations clearly point out an active dream-related manipulation of the contents of both externally and internally oriented contents. Both the external environment

(external events in awake state) and the internal self with its body and emotions are experienced in a distorted way. However, they can still be recognized as such but are different – there is semantic association rather than semantic similarity/identity.

Put in more psychodynamic terms, dreams are paradigmatic examples of an altered topography of the psyche. We need to distinguish between content and topography, with the latter describing the context in which the former are processed during both awake and dream states. We postulate that the context; that is, the topography changes during dreams. Now the same content, that is, that of the awake state, is replayed during dreams in a different topographic context – this, as we suppose, changes the content. Rather than simulating, e.g., replaying the awake contents in an identical way, the awake contents are now embedded in an altered overall mental topography: the contents from the awake state are manipulated by their changed topographical context, for which reason they remain only semantically related but not identical to the original awake contents.

Where and how are such changes in the topography of the psyche during dreams coming from? This leads us to the topography and dynamic of the brain and specifically how they change during dreams compared to awake states. Following the assumption of “common currency” with shared features of mental and neural states (Northoff et al. 2020a, 2020b), we suppose that the altered topography and dynamic of the psyche during dreams is related to more or less analogous changes in the topography and dynamic of the brain.

Part II: topography and dynamic of the brain in dreams

Topography of the cortex in dreams I – default-mode network, hippocampus, and visual cortex

One cannot conceive the brain’s topographic changes in REM sleep, which is associated with strong dreams independent of the other sleep stages. The NREM 1 sleep stage is characterized by mostly activation in visual cortex and its various widespread regions. At the same time, it seems that the lateral prefrontal cortex and the central executive network (CEN) tend to reduce their activity level at this stage (Tanabe et al. 2020). NREM 2 shows more diffuse changes, which are not yet clearly identified, as the results are rather confusing, if not contradictory (Fox et al. 2016; Tanabe et al. 2020).

Finally, the slow-wave sleep stages, NREM 3 and 4, show generally reduced activity levels in widespread regions of the brain with lower degrees of functional connectivity between all regions (Tanabe et al. 2020). We need to be careful, though, as these results are based on a limited number of studies due to the difficulties of conducting fMRI in different sleep stages.

More studies are available for REM sleep. Here the patterns show increased activation and connectivity of medial temporal regions like the hippocampus. Given that the hippocampus is key in encoding and retrieving memory, this fits well with the observation that memories are increasingly recruited or retrieved during dreams as well as, at the same time, enhanced after a dream-rich sleep. Additionally, there is increased activity and connectivity within the cortical midline regions of the DMN in especially the medial prefrontal cortex, while, at the same time, activity in lateral prefrontal cortex and CEN is reduced. Hence, the reciprocal modulation of medial vs lateral prefrontal and, more generally, between DMN and CEN, is shifted towards the DMN in dreams.

Finally, there is also increased activity in widespread regions of the visual cortex during dreams, that is, REM, compared to NREM sleep stages (Fox et al. 2013; Domhoff and Fox 2015; Fox et al. 2013, 2016). This is even more remarkable given that the eyes are closed during sleep so that the subjects do not receive direct visual input from the external environment. The observed activity increase in the visual cortex may consequently be related to internal (rather than external) input from the visual cortex's own spontaneous activity. Together, the visual cortex's resting state activity is elevated in dreams.

In contrast, task-evoked activity in the visual cortex, as usually associated with external visual inputs, remains absent due to the lack of visual processing of external environmental inputs (eyes are closed). The increase in visual cortex resting state activity during dreams may reach the level that the visual cortex usually displays in the awake state when processing external visual inputs. During dreams subjects may thus take their elevated spontaneous visual cortex activity to be indicative of events occurring in the external environment (see Northoff and Qin 2011 for an analogous case in auditory cortex during auditory hallucination in schizophrenia). This is well in accordance with dream experience where subjects often report external environmental scenes and events, albeit in a distorted way.

Together, these findings suggest that REM sleep is characterized by a distinct cortical topography compared to both the awake state and NREM sleep (see also Qin et al. 2021). The reciprocal DMN-CEN balance is shifted towards the DMN, with a reduced activity level in CEN. Moreover, medial temporal regions, including the hippocampus, seem to show elevated activity. Finally, the visual cortex, despite the closed eyes with a lack of external visual input, is elevated in its spontaneous activity. Accordingly, putting it all together, the spatial topography of the dreaming (REM) brain is distinct from those during both awake and other sleep (NREM) states.

Topography of the cortex in dreams II – subcortical–cortical biochemical modulation

Why and how is there such a change in the brain’s topography during dreams? One possibility is that the topography of the cortex is modulated in a different way by the subcortical nuclei of different biochemical systems.

Biochemically, subcortically originating cortical neuromodulatory transmitter systems like acetylcholine (forebrain – nucleus basalis of Meynert), dopamine (ventral tegmental area and substantia nigra), serotonin (raphe nucleus), and adrenalin/noradrenalin (locus coerulus) have been associated with changes in sleep (compared to awake). Moreover, they show differential changes in NREM and REM sleep, making it likely that dreams are mediated by a particular subcortical biochemical signature with respect to acetylcholine, dopamine, serotonin, and adrenaline/noradrenaline (Fox et al. 2013). The concentrations of these transmitters are in somewhat of an intermediate level in REM sleep between higher concentrations in the awake state and lower ones in NREM.

However, it shall be noticed that it is not one particular transmitter system and one subcortical region but rather their balance that seems to be specifically altered in dreams. There seems to be a relative increase in acetylcholine and dopamine (relative to serotonin and adrenaline/noradrenaline) in REM that may be key for dreams. This is supported by the known impact of acetylcholine and its nucleus basalis of Meynert on the level of arousal/consciousness (Fox et al. 2013; Zhang et al. 2020; Zhang and Northoff 2021; Tanabe et al. 2020).

Most interestingly, these subcortical nuclei and their respective transmitters modulate cortical patterns in a global way (Zhang et al. 2020; Conio et al. 2020). For instance, they modulate the balance between DMN and sensorimotor networks as well as between DMN and salience network (that includes the insula) (Conio et al. 2020). Changes on the cortical level and its topography may thus, in part, be related to the shifts in their subcortical–cortical biochemical modulation.

Together, dreams are characterized by changes in subcortical–cortical biochemical modulation with shifts between different biochemicals. Can such a change in subcortical–cortical modulation account for the shift towards subcortically driven primary emotions like SEEKING, drives, and predominant primary processes in dreams? At the same time, can it also explain the loss of the more cortically mediated rational and intentional control, including their secondary processes? To address these questions, we shift our focus to the dynamics of the brain in dreams.

Dynamic of the cortex in dreams I – shift to slower frequencies

Dynamic can be measured using EEG for the temporal dynamics of the power spectrum and various electrophysiological changes. NREM 1 sleep is typically characterized by a decrease of alpha (8–13 Hz) combined with the strengthening of power and occurrence of ripple waves in theta (5–8 Hz). NREM 2 features high frequency spindles (12–30 Hz) and large-amplitude K-complexes. Finally, NREM 3 and 4 show highly synchronized slow waves (0.5 to 4 Hz).

REM sleep shows highly desynchronized low amplitude activity in EEG in mainly theta (5–8 Hz) and beta (13–30 Hz), which resemble the awake state; the difference is that REM sleep lacks the alpha power that characterizes the awake state. The alpha power is typically decreased, while theta power is relatively increased during dreams (see also Berberian et al. 2022). That is also reflected in the power law exponent that, measuring the balance of slow and fast frequency power, is lower in dreams compared to NREM 2 and 3 but still higher than in the awake state. The dream state is thus characterized by more power in the slow frequencies relative to faster ones when compared to the awake state, while it is still faster than deep sleep (N3) (Zilio et al. 2021).

Dynamic of the cortex in dreams II – longer time windows

The intermediate position of REM sleep between awake and deep sleep (N3) is also reflected in its intrinsic neural timescales (INT). REM sleep shows shorter intrinsic neural timescales than NREM as measured by the autocorrelation window (ACW): the ACW in dreams is shorter than in N2 and N3 but still longer than in the awake state (Zilio et al. 2021). The ACW and, more generally, the INT are important in processing input, as they parse the input streams into different chunks through temporal integration and segregation (Golesorkhi et al. 2021a, 2021b). Longer temporal windows (longer ACWs) favor the temporal integration of different inputs both internally and externally while, at the same time, diminishing their temporal segregation (Wolff et al. 2022).

This leads us to the following tentative hypothesis. The longer temporal windows, together with the shift towards slower frequencies, may explain why different “normal” contents are put together in an abnormal way: temporally distinct contents may be summed or lumped together in dreams, that is, high temporal integration, which otherwise, as in the awake state, may be separated, that is, higher temporal segregation, given its shorter time windows and faster frequencies. The typically bizarre dream contents may thus, in part, be related to the shift towards temporal integration of inputs at the expense of temporal segregation which, neuronally, may be related to the shift towards longer time windows and slower frequencies. One would consequently hypothesize that the degree of semantic association as distinguished from semantic identity/similarity should be related to the degree to which temporal integration becomes stronger over temporal segregation in dreams compared to awake. That, in turn, should be related to the degree of prolongation of the brain’s INT, that is, its ACW.

Part III: topographic-dynamic reorganization theory of dreams

Given the findings of an altered topography and dynamic of the brain, we now aim to link the brain's neuronal level to the psychological dreams of dreams. Specifically, we suggest that the altered topography and dynamic of the brain are manifest in more analogous topography and dynamic of the psyche. This amounts to what I here, for the first time, introduce as the topographic-dynamic reorganization theory of dreams. The background assumption of TRoD is that topographic and dynamic changes are shared in a more or less corresponding way by both brain and psyche as their "common currency" (Northoff et al. 2020a, 2020b).

Topographic reorganization – increase in internally oriented cognition

Dreams are characterized by topographic reorganization of the cortex. One key feature is that the balance of DMN-CEN shifts towards the DMN. The CEN and especially the lateral prefrontal cortex are related to cognitive control and goal orientation. These are strongly diminished in dreams, where rational and voluntary control are lost, while spontaneity and automatic involuntary dynamic of affect/emotion and cognition/thought are strongly increased. One would thus hypothesize that the loss of rational voluntary control and goal orientation with respect to emotions and cognition are related to the relative decrease of CEN activity in dreams. This remains to be tested in the future.

How about the DMN? The data show that DMN activity is relatively increased in dreams. The DMN is well known to mediate internally oriented cognition like mental time travel, autobiographical memory, and mind-wandering (Christoff et al. 2016; Fox et al. 2016). All three are increased in dreams: there is indeed mental time travel, with abnormal shifts towards either the past or future accompanied by detachment from the present, that is, the actual point in time. Autobiographical memories are increasingly retrieved during dreams – this may be especially related to increased hippocampal activity. Finally, there is increased mind-wandering with freely floating unconstrained thoughts in dreams.

Albeit tentatively, one may hypothesize that the changes in these three forms of internally oriented cognition may, in part, be related to the abnormal increase in DMN activity, including the hippocampus. Moreover, the increases in both DMN and its internally oriented cognition during dreams may provide an access to the dynamic unconscious (Chapter 5). For that reason, dreams are often conceived as taking on a key role in psychodynamic psychotherapy (Leuzinger-Bohleber et al. 2019).

The topographic shift towards DMN goes along with a dynamic shift towards slower frequencies and longer time windows in the brain's neural activity during dreams. Are topographic and dynamic changes related to each other? We currently do not know. We know, though, that, in the awake state, the DMN exhibits slower frequencies and longer time windows than CEN and especially unimodal sensory regions (Golesorkhi et al. 2021a, 2021b). Inferring from these findings in the awake state, one may assume that the topographic shift towards DMN during dreams goes along with a dynamic shift towards slower frequencies and longer time windows. These dynamic changes, in turn, may favor internally oriented cognition, as that is known to be related to slow dynamic and long timescales (Vanhaudenhuyse et al. 2011; Hua et al. 2021).

Self in dreams I – relative increase of the mental self

The awake state is characterized by a topography of self marked by its nestedness of three layers of self (Chapter 1 and Qin et al. 2020). Roughly, interoceptive self, featuring the own inner body, is the lowest layer, being related to the insula and subcortical regions. That is followed by the proprioceptive self that extends to the outer body as mediated by additional regions like temporo-parietal junction. Finally, the third most upper layer consists in the mental self that is mediated by the DMN and especially its midline structure (see Chapter 1 for details as well as Qin et al. 2020).

### Self in dreams II – relative decrease of the proprioceptive self

### The topographic shifts in subcortical and cortical regions during

### Self in dreams III – relative increase of the interoceptive self

### Spatiotemporal reference frame I – immersive spatiotemporal hallucination

### Spatiotemporal reference frame II – semantic association rather than semantic similarity

### Conclusion – from dreams and TRoD to psychotherapy

How is this three-layer nestedness of the self affected in dreams? The topographic shifts in subcortical and cortical regions during dreams strongly suggest that the three-layer nested hierarchy of self is also shifted and rebalanced. The increase in DMN suggests an increase in the mental self while, due to the lacking extero- and pro-prioceptive input, the middle layer of the proprioceptive self may be relatively diminished during dreams. Psychologically, the increase of mental self may be related to what is described as the “felt presence” of self: this describes an increased presence of the own self in one’s mental states, that is, mental self, during dreams (Windt 2021).

The increased presence of the mental self in dreams is further supported by the dynamic changes. In the awake state, more powerful slow frequencies and longer time windows in DMN activity are known to mediate higher degrees of self-consciousness (Huang et al. 2016; Wolff et al. 2019; Kolvoort et al. 2020). The shift towards slower frequencies and longer timescales during dreams may thus translate into an increased mental self: the increased power of the slower frequencies may be manifest psychologically in the experience of a more powerful self that is increasingly present in one's experience and mental states.

Self in dreams II – relative decrease of the proprioceptive self

The self is not limited to the mental self, though. The increase in mental self may go along with a relative decrease of the proprioceptive self as mediated by the TPJ. In the awake state, the TPJ is well known to mediate out-of-body experiences even in healthy subjects (Blanke et al. 2015). Inferring again from the awake state, one would thus assume that the typical occurrence of partial- or full-body illusions with, in the most extreme instances, out-of-body experiences during dreams (Windt 2021) may be related to the (relative) activity decrease of the TPJ and other regions constituting the middle layer of the proprioceptive self. Hence, while the DMN and its mental self are increasingly present in dreams, the proprioceptive self and its neural correlates may be diminished (in at least a relative way).

Neuronally, one would expect decoupling of insula and subcortical regions (interoceptive self) and TPJ (exteroceptive self)

from the DMN (mental self) – their degree of connectivity and ultimately their degree of nestedness may decrease in dreams, resulting in the experience of a mental self detached from its own body's intero- and proprio-exteroceptive input. The upper layer of the mental self and its DMN may consequently be less nested and contained within the lower layers of the intero- and exteroceptive self as related to subcortical and cortical regions like the thalamus, insula, and TPJ.

Self in dreams III – relative increase of the interoceptive self

Finally, these topographical changes on the cortical level may, in part, be driven by subcortical sources and their various transmitter systems. Subcortically located transmitter systems like serotonin, noradrenaline, acetylcholine, dopamine, and others (Fox et al. 2013) are changing during sleep in general and also in dreams, where they seem to show peculiar shifts in their balances. Since subcortical regions in pons, brainstem, and forebrain like the raphe nucleus (serotonin) and the nucleus basalis of Meynert (acetylcholine) mediate cortical balance of DMN, CEN, and other non-DMN networks (Conio et al. 2020; Martino et al. 2020), changes in the cortical topography in both its spatial and temporal aspects may be related, in part, to these subcortical shifts in the balances of different transmitter systems.

Do these subcortical changes translate into a relative increase in the interoceptive self and thus the bodily based self during dreams? The bodily or interoceptive self may be decoupled from and less nested within the mental self. This may be manifest in the decrease of voluntary control of the interoceptive self by the mental self: this may be related to the increased spontaneity and involuntary automaticity with the increased occurrence of drives, primary processes and primary affects/emotions like SEEKING, as is typical for dreams (Panksepp and Biven 2012). Together, one would assume that the subcortical–cortical changes during dreams may be related to a relative increase of the interoceptive self, while, at the same time, the interoceptive self is increasingly detached from and less nested within the more upper layers of the proprioceptive and especially mental self.

Spatiotemporal reference frame I – immersive spatiotemporal hallucination

Why are the experiences in dreams so bizarre and, at the same time, somewhat familiar, though? We still have the experience to navigate in some kind of environment during dreams, albeit in a distorted way. Jennifer Windt (Windt 2010, 2021; Windt and Noreika 2011) proposes that there is still a spatiotemporal reference framework in place during dreams for the presence of self, full-body illusions, and environmental experiences. She therefore proposes to describe dreams as “immersive spatiotemporal hallucination” (ISTH). ISTH are described as amodal manifestations of hallucinations concerning both internally and externally oriented cognition, which, during dreams, operate within an abnormal spatiotemporal reference framework.

We hallucinate in dreams about the external environment, including our own self as part of it, even though we are more or less detached and decoupled from the external environmental input. The lack of external environmental input seems to be compensated for by the relative increase of internal inputs from within both body and brain themselves during dreams. In addition to the more interoceptive sources from the body, this internal input may come from within the brain itself most notably the DMN and visual cortex (VC), which are strongly activated during dreams (see previously).

Together, this links the DMN-based internal inputs that are internally oriented in their contents with the VC-based internal inputs that are usually externally oriented in their contents (as it comes from visual cortex usually mediating external environmental contents). That, as I propose, constitutes a spatiotemporal reference framework, probably in a three-dimensional (or multi-dimensional) way, within which the various types of contents are perceived and experienced in an abnormal way, that is, semantically associated but not semantically similar.

Spatiotemporal reference frame II – semantic association rather than semantic similarity

One may be confused by the distinction of internal vs external inputs relative to internally vs externally oriented contents. The brain and especially the visual cortex are isolated from direct external input in dreams: the eyes are closed, which blocks external visual input from the environment. However, the visual cortex still exhibits neural activity, that is, spontaneous activity during dreams independent of any direct external input. This spontaneous activity thus provides an internal input to the visual cortex.

However, since the visual cortex is usually associated with external input and its externally oriented cognition contents, the internal input is now processed as if it were an external input: it is consequently associated with externally oriented cognition contents (see also Vanhaudenhuyse et al. 2011): “the brain isolated from the outside world, treats its endogenous stimulation as if it were exogenous” (Hobson 2009, 809). This, according to Hobson (2009, 808), leads the dreamer to make or “built-in predictions about external time and space”. Due to the peculiar combination of internal input and externally oriented cognition contents, I characterized dreams by “as if external perception” and “as if objects” in my earlier book (Northoff 2011, 196ff).

Moreover, the VC-based constitution and prediction of external time and space allows linking it to the internal space and time predictions as related to the DMN and the self (Northoff et al. 2018 for the distinction of inner/internal and outer/external time and space). Together, the connection of DMN and VC mediating internal and external time-space allows to constitute a virtual spatiotemporal reference frame during dreams just as in the awake state. The difference is only that the spatiotemporal reference frames in dreams and awake exhibit distinct coordinates, that is, a different spatiotemporal organization or topography. I therefore speak of topographical reorganization of the spatiotemporal reference frame in dreams.

This is supported by a recent paper by Berberian et al. (2022). They demonstrate that the shift towards slower frequencies like theta peak frequency is directly related to the degree of semantic association: the stronger the theta peak frequency, the higher the degree to which the awake scenario, that is, spatial navigation, is incorporated into the semantic meaning of dreams during naps. Hence, the same content, that is, spatial navigation, is now processed in a different dynamic context, that is, slower as related to theta rather than alpha peak frequency (Berberian et al. 2022). The changes in the brain's dynamic or temporal reference framework during dreams thus shifts the semantic meaning of the same contents.

Such a reorganized spatiotemporal reference frame harbors and embeds the various contents in dreams in a way different from their embedding in the awake state: the “normal” contents themselves become embedded and integrated with an abnormal and “distorted” spatiotemporal reference frame. For instance, one and the same input like an interoceptive input from the body or a neuronal input from visual cortex is now processed in the context of a topography shifted towards DMN and a dynamic characterized by slow frequencies and longer time windows. That, in turn, “distorts” the meaning of the content – the contents in dreams are still the same, but their meaning or semantics shifts and therefore remains no longer exactly the same. This may account for what we described previously as semantic association as distinguished from both semantic non-association/difference and semantic similarity/identity. That is well compatible with the depiction of the often bizarre backgrounds in Salvador Dali’s paintings that “distort” the contents in the foreground.

Conclusion – from dreams and TRoD to psychotherapy

Dreams provide the via regia to the unconscious. That is literally true, as they operate on a deeper layer of the psyche than the awake state. Since they operate on this deeper layer, their effects can reverberate to the upper layers and reorganize them – this allows for what psychotherapists describe as “structural change”. Taken within the context of the TRoD, such “structural change” is topographic (and dynamic) change that can be traced to the reorganization of the brain’s topography and its dynamic. The TRoD claims that such topographic and dynamic changes in the brain are manifest in analogous ways on the mental level accounting for semantic association, hallucination, and changes in body and self during dreams.

I now extend the TRoD to the realm of psychotherapy, which can be viewed as therapy of the topographical and dynamic organization of both brain and psyche. One key focus of psychotherapy are traumatic events for whose resolution dreams are used as therapeutic tools. Due to the topographic reorganization, the problematic or traumatic event or content, as originally situated in the dynamic unconscious, may now gain access to a wider spatiotemporal repertoire.

during dreams: this concerns the different topography with more subcortical–cortical bottom-up modulation and less DMN-top-down modulation as well as changed dynamic with slower frequencies.

This topographic and dynamic reorganization may make possible to more easily access the traumatic events of the dynamic unconscious as well as to integrate them with other non-traumatic events as “the more ‘healthy’ parts of the unconscious and conscious”. Traumatic events are thus linked to and integrated within non-traumatic events (of the “healthy” parts of the self) through spatiotemporal integration, that is, topographic and dynamic integration, into a novel and possibly wider spatiotemporal context. That, in turn, mitigates the effects of the traumatic event that now can find its passage from the dynamic unconscious over the preconscious to the conscious.

Neuronally, I hypothesize that this wider opening of the unconscious–conscious passage may be related neuronally to especially the changes in the degree of temporo-spatial nestedness among the three layers of self during dreams: the mental self exerts less top-down control, which releases the interoceptive self, allowing it increased spontaneity which, as we assume, facilitates and releases the dynamic unconscious, including its more embodied memories of the traumatic events.

What does this imply for psychotherapy? The therapist may want to analyze dreams primarily in spatiotemporal terms rather than exclusively focusing on the contents themselves: the relation between the different contents, their spatial configuration, and temporal changes over time should be the main focus. Dreams are consequently no longer analyzed primarily in a content-based way, including both affective and cognitive contents. Instead, the integration of the affective and cognitive contents into a spatiotemporal framework as subjectively perceived and experienced by the subjects may be key in psychotherapy.

There are limits to what the subjects can report of their dreams, though. Besides verbal report, one can include non-verbal report like painting or drawing (just like Salvador Dali did): the spatiotemporal coordinates of the drawings may then provide some insight into the spatiotemporal reference frame of the dream itself, which, in turn, may mirror the spatiotemporal dynamic repertoire of the brain itself (see Lin et al. 2020 for a first investigation).

The psychotherapist may then work spatiotemporally with the client in order to reset her/his spatiotemporal reference frame. That could, for instance, be done by modulating the frequency and speed of the own language, the spatial interaction with the client, and various other ways. Ideally, that is accompanied by continuous monitoring of the client's brain states using brain-computer interface which will show on-line how the therapeutic or better spatiotemporal intervention by the therapist modulates the client's spatiotemporal dynamic repertoire. Dynamic psychotherapy of dreams may thus transform into what can be described as "spatiotemporal psychotherapy" (see Spagnioli and Northoff 2021; Northoff and Scalabrini 2021).

Fox KC, Nijeboer S, Solomonova E, Domhoff GW, Christoff K (2013) Dreaming as mind wandering: Evidence from functional neuroimaging and first-person content reports. Front Hum Neuroscience. Jul 30;7:412. doi: 10.3389/fnhum.2013.00412. eCollection 2013.

Golesorkhi M, Gomez-Pilar J, Tumati S, Fraser M, Northoff G (2021a) Temporal hierarchy of intrinsic neural timescales converges with spatial core-periphery organization. Commun Biol. Mar 4;4(1):277. doi:10.1038/s42003-021-01785-z

Golesorkhi M, Gomez-Pilar J, Zilio F, Berberian N, Wolff A, Yagoub MCE, Northoff G (2021b) The brain and its time: Intrinsic neural timescales are key for input processing. Commun Biol. Aug 16;4(1):970. doi: 10.1038/s42003-021-02483-6

Hobson JA (2009) REM sleep and dreaming: Towards a theory of proto-consciousness. Nat Rev Neurosci. Nov;10(11):803–813. doi: 10.1038/nrn2716. Epub 2009 Oct 1. PMID: 19794431 Review.

Hua J, Zhang Y, Wolff A, Northoff G (2021) Thought dynamics is mediated by alpha and theta peak frequency. Nature Communication Biology. in press.

Huang Z, Obara N, Davis HH 4th, Pokorny J, Northoff G (2016) The temporal structure of resting-state brain activity in the medial prefrontal cortex predicts self-consciousness. Neuropsychologia. Feb;82:161–170. doi: 10.1016/j.neuropsychologia.2016.01.025. Epub 2016 Jan 21.

Kolvoort IR, Wainio-Theberge S, Wolff A, Northoff G (2020) Temporal integration as “common currency” of brain and self-scale-free activity in resting-state EEG correlates with temporal delay effects on self-relatedness. Hum Brain Mapp. Oct 15;41(15):4355–4374. doi: 10.1002/hbm.25129. Epub 2020 Jul 22.

Leuzinger-Bohleber M, et al (2019) Dreams. In: Neuropsychodynamic psychiatry, ed. H Boeker, P Hartwich, G Northoff. Springer, New York, Heidelberg.

Lin YS, Hartwich P, Wolff A, Golesorkhi M, Northoff G (2020) The self in art therapy: Brain-based assessment of the drawing process. Med Hypotheses. May;138:109596. doi: 10.1016/j.mehy.2020.109596. Epub 2020 Jan 23.

Martino M, Magioncalda P, Conio B, Capobianco L, Russo D, Adavastro G, Tumati S, Tan Z, Lee HC, Lane TJ, Amore M, Inglese M, Northoff G (2020) Abnormal functional relationship of sensorimotor network with neurotransmitter-related nuclei via subcortical-cortical loops in manic and depressive phases of bipolar disorder. Schizophr Bull. Jan 4;46(1):163–174. doi: 10.1093/schbul/sbz035

Northoff G (2011) Neuropsychoanalysis in practice. Oxford University Press, Oxford, New York.

Northoff G, Magioncalda P, Martino M, Lee HC, Tseng YC, Lane T (2018) Too fast or too slow? Time and neuronal variability in bipolar disorder—A combined theoretical and empirical investigation. Schizophr Bull. Jan 13;44(1):54–64. doi: 10.1093/schbul/sbx050

Northoff G, Qin P (2011) How can the brain’s resting state activity generate hallucinations? A ‘resting state hypothesis’ of auditory verbal hallucinations. Schizophr Res. Apr;127(1–3):202–214. doi: 10.1016/j.schres.2010.11.009. Epub 2010 Dec 13.

Northoff G, Scalabrini A (2021) "Project for a spatiotemporal neuroscience": Brain and psyche share their topography and dynamic. Front Psychol. Oct 14;12:717402. doi: 10.3389/fpsyg.2021.717402. eCollection 2021.

Northoff G, Wainio-Theberge S, Evers K (2020a) Is temporo-spatial dynamics the “common currency” of brain and mind? In quest of “spatiotemporal neuroscience”. Phys Life Rev. Jul;33:34–54. doi: 10.1016/j.plrev.2019.05.002. Epub 2019 May 23.

Northoff G, Wainio-Theberge S, Evers K (2020b) Spatiotemporal neuroscience: What is it and why we need it. Phys Life Rev. Jul;33:78–87. doi:10.1016/j.plrev.2020.06.005. Epub 2020 Jul 10.

Panksepp J, Biven L (2012) The archaeology of mind. Norton Publisher, New York.

Qin P, Wang M, Northoff G (2020) Linking bodily, environmental and mental states in the self-A three-level model based on a meta-analysis. Neurosci Biobehav Rev. Aug;115:77–95. doi: 10.1016/j.neubiorrev.2020.05.004. Epub 2020 May 31.

Qin P, Wu X, Wu C, Wu H, Zhang J, Huang Z, Weng X, Zang D, Qi Z, Tang W, Hiromi T, Tan J, Tanabe S, Fogel S, Hudetz AG, Yang Y, Stamatakis EA, Mao Y, Northoff G (2021) Higher-order sensorimotor circuit of the brain's global network supports human consciousness. Neuroimage. May 1;231:117850. doi: 10.1016/j.neuroimage.2021.117850. Epub 2021 Feb 12.

Solms M (2015) The feeling brain. Routledge, London, New York.

Solms M (2020) Project for a (new) psychology. Neuropsychoanalysis. 23–45.

Solms M (2021) The hidden spring: A journey to the source of consciousness. Norton Publisher, New York.

Spagnoli R, Northoff G (2021) The dynamic self. Routledge Publisher, London, New York.

Tanabe S, Huang Z, Zhang J, Chen Y, Fogel S, Doyon J, Wu J, Xu J, Zhang J, Qin P, Wu X, Mao Y, Mashour GA, Hudetz AG, Northoff G (2020) Altered global brain signal during physiologic, pharmacologic, and pathologic states of unconsciousness in humans and rats. Anesthesiology. Jun;132(6):1392–1406. doi: 10.1097/ALN.0000000000003197 Vanhaudenhuyse A, Demertzi A, Schabus M, Noirhomme Q, Bredart S, Boly M, Phillips C, Soddu A, Luxen A, Moonen G, Laureys SJ (2011) Two distinct neuronal networks mediate the awareness of environment and of self. Cogn Neurosci. Mar;23(3):570–578. doi: 10.1162/jocn.2010.21488. Epub 2010 Jun 1.

Windt JM (2010) The immersive spatiotemporal hallucination model of dreaming. Phenomenol Cogn Sci. 9(2):295–316.

Windt JM (2021) How deep is the rift between conscious states in sleep and wakefulness? Spontaneous experience over the sleep-wake cycle. Philos Trans R Soc Lond B Biol Sci. Feb;376(1817):20190696. doi: 10.1098/rstb.2019.0696. Epub 2020 Dec 14.

Windt JM, Noreika V (2011) How to integrate dreaming into a general theory of consciousness—A critical review of existing positions and suggestions for future research. Conscious Cogn. Dec;20(4):1091–1107. doi: 10.1016/j.concog.2010.09.010. Epub 2010 Oct 8. PMID: 20933438 Review.

Wolff A, Di Giovanni DA, Gómez-Pilar J, Nakao T, Huang Z, Longtin A, Northoff G (2019) The temporal signature of self: Temporal measures of resting-state EEG predict self-consciousness. Hum Brain Mapp. Feb 15;40(3):789–803. doi: 10.1002/hbm.24412. Epub 2018 Oct 4.

Zhang J, Huang Z, Tumati S, Northoff G (2020) Rest-task modulation of fMRI-derived global signal topography is mediated by transient coactivation patterns. PLoS Biol. Jul 10;18(7):e3000733. doi: 10.1371/journal.pbio.3000733. eCollection 2020 Jul.

Zhang J, Northoff G (2021) Function of the global signal: Dual layer model. Neuroimage, in press.

Zilio F, Gomez-Pilar J, Cao S, Zhang J, Zang D, Qi Z, Tan J, Hiromi T, Wu X, Fogel S, Huang Z, Hohmann MR, Fomina T, Synofzik M, Grosse-Wentrup M, Owen AM, Northoff G (2021) Are intrinsic neural timescales related to sensory processing? Evidence from abnormal behavioral states. Neuroimage. Feb 1;226:117579. doi: 10.1016/j.neuroimage.2020.117579. Epub 2020 Nov 20.
