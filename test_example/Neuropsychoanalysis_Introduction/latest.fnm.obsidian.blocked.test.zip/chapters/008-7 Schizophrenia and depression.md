## 7 Schizophrenia and depression

### Introduction

### Part I: schizophrenia and projection

### Topography of schizophrenia I – reverse representation of global brain activity

### Topography of schizophrenia II – reduced rest/prestimulus – task modulation

### Psychodynamic of schizophrenia I – confusion of internally and externally oriented cognition

### Dynamic of schizophrenia I – reduced alignment and entrainment

### Psychodynamic of schizophrenia II – reduced differentiation of self/self-objects and objects

### Dynamic of schizophrenia II – deficit in the timing with temporal discoordination

### Dynamic of schizophrenia III – reduced temporal integration of inputs

### Psychodynamic of schizophrenia III – loss of object relation and projection

### Part II: depression and introjection

### Topography of depression I – disbalance between medial and lateral prefrontal cortex

Schizophrenia and depression

Introduction

We already showed that the self operates on a continuum between healthy and pathological states, as in narcissism, trauma, and dissociation. This leaves open the very extreme pathological end of that continuum where psychiatric disorders like schizophrenia and major depressive disorders (in the following simply termed depression) are “located”. We show how the spatiotemporal approach can yield novel insight into the neuronal mechanisms of the typical psychodynamic features like introjection in depression and projection in schizophrenia.

We will discuss topographic and dynamic changes in the brain's neural activity in schizophrenia and depression. That, in turn, serves as stepping stone for understanding the psychodynamic changes in these disorders. Given the constraints of this book, I cannot focus on all the psychodynamic or neuronal details in depression and schizophrenia. For that, I refer to specific papers and books (Boeker et al. 2019). I therefore focus on some psychodynamic core features. Introjection is a typical characteristic of depression, while increased projection is a psychodynamic hallmark feature of schizophrenia. This lets me focus on object relations as well as how objects are related to the self in these disorders.

Part I: schizophrenia and projection

Topography of schizophrenia I – reverse representation of global brain activity

We already encountered the brain’s global activity and how it is locally represented in specific regions (see Chapter 4). Roughly, the brain exhibits global activity that can be measured by the global signal in fMRI. Additionally, the GS is represented in the activity levels of different regions in distinct degrees, thus showing a certain spatial topography. For instance, GS in healthy subjects is more strongly represented in the lower-order sensory and motor regions, that is, input and output regions, than in higher-order more cognitive association regions like the prefrontal cortex and the DMN (Wang et al. 2019; Yang et al. 2017; Zhang et al. 2020).

This is no longer the case in schizophrenia. Here the spatial topography of GS is different, if not reversed. The brain’s global activity is no longer represented most strongly within the lower-order sensory input and motor output regions like the sensory and motor cortices. Instead, it is now more strongly represented within the higher-order association cortices like the prefrontal and parietal cortex and DMN (Yang et al. 2017; Wang et al. 2019). The local–regional re-redistribution of GS is especially related to positive symptoms like delusion and hallucination: the more strongly the global brain activity is re-distributed from lower-order sensori-motor to higher-order association cortices, the more severe the symptoms, like hallucinations and delusions.

Together, these findings show that lower-order sensori-motor systems that process external inputs (and outputs) stand in an abnormal if not reverse relationship to those higher-order associative regions that process internally oriented contents, that is, higher-order neural systems. The boundaries between internally and externally oriented cognition are consequently blurred, leading to what psychodynamically is described as the “blurring of the inner ego boundaries” (Federn 1952): the boundaries of the internal self (including its self-objects, as pointed out by Kohut) can no longer be properly distinguished from the objects of the external environment.

Topography of schizophrenia II – reduced rest/prestimulus – task modulation

Given the reverse topography of lower- and higher-order regions in schizophrenia, one would suspect that internally oriented cognition including the self interacts in an abnormal if not reduced way with external objects or events. For that, we need to take into view the interaction of resting state/prestimulus and task-related activity. How can we characterize such rest/prestimulus-task interaction? Internally oriented cognition already takes place during the spontaneous activity as measured in resting state and prestimulus activity, while external objects or events induce what is described as task-related activity. Since task-related activity is preceded by prestimulus activity, which mirrors the brain's spontaneous activity, we need to consider how the latter interacts with and modulates the former.

The blurring of internally and externally oriented cognition in schizophrenia should be related to lower differentiation of resting state/prestimulus and task-related activity. This was investigated in a recent study by Northoff and Gomez-Pillar (2021). They first conducted a meta-analysis of all EEG and fMRI studies in schizophrenia, including both resting state/prestimulus activity and task-related activity. They observe that, relative to prestimulus or resting state activity, task-related activity in different tasks was significantly reduced in schizophrenia: they were no longer able to properly differentiate their task-related activity from the ongoing prestimulus or resting state activity.

This, in a second step, was complemented by our own EEG studies showing that the altered (enhanced or reduced depending on the measure) prestimulus connectivity between regions made it impossible for the external stimulus (an auditory tone) to increase activity level. Task-related activity could thus no longer be properly differentiated from the prestimulus activity: this entails that the external contents, that is, the auditory tone, could no longer be properly distinguished from the ongoing internally oriented cognition including the self.

Psychodynamic of schizophrenia I – confusion of internally and externally oriented cognition

What are the mechanisms through which resting state changes and/or reduced rest/prestimulus-task modulation impact cognition and especially its differentiation of internally and externally oriented cognition? Predictive coding could be one such mechanism, since it modulates the contents of both internally and externally oriented cognition. Roughly, predictive coding assumes that the predicted input or empirical prior, which is based on the prestimulus or resting state dynamic, strongly shapes subsequent task-related activity, with the latter being the manifestation of the prediction error, that is, the comparison of predicted and actual input. Given their altered input processing, schizophrenia subjects may suffer from a high prediction error – they are often wrong in their predictions about the external environment (and ultimately also being wrong about their own internal self).

It is well known that especially the generation of the predicted input is abnormal in schizophrenia; this is distributed and reverberates across the whole brain and its cortical hierarchy, affecting basically all cognitive and psychological domains. These abnormalities in the predicted input or empirical prior during rest or prestimulus period impact the internal contents of internally oriented cognition, including self-referential processing, mind wandering, and mental time travel, with changes in these being well recorded in schizophrenia.

At the same time, the abnormal prestimulus dynamics may, through its extreme degrees, lose the ability or capacity to change during the external stimuli, that is, the subsequent task states of the brain that are elicited by the external contents of externally oriented cognition. The resulting prediction error may consequently be abnormally high, as it is more strongly determined by the predicted input, that is, the internal content of the own self, than the external content of the environment – internal contents (i.e., self and self-objects in psychodynamic terms) dominate even during externally oriented perception and cognition (i.e., objects in psychodynamic terms).

Psychodynamic of schizophrenia II – reduced differentiation of self/self-objects and objects

Given the topographic changes and reduced rest/prestimulus-task modulation, the transient external stimuli or tasks are perceived and cognized in abnormal proximity to the internal contents of the own self (and its self-objects). Ultimately, this leads to the confusion of internally and externally oriented cognition contents: the different origins or sources of the different cognition contents, that is, internal self and external environment, can no longer be distinguished and monitored by the subjects, that is, source monitoring deficits (Nelson et al. 2020; Sass et al. 2018).

Psychodynamically, the confusion of self and object as well as of self-objects and objects has been highlighted in schizophrenia (Northoff 2011; Boeker et al. 2019). Self and its self-objects are distinguished by contents that are generated internally by an internal source, that is, the own self, as manifested in internally oriented cognition, while what psychodynamically is described as object refers to the contents that have their ultimate source in the external world and are manifested in externally oriented cognition.

What neuronally is described in terms of rest/prestimulus-task interaction corresponds more or less to what psychologically is framed as interaction of internally and externally oriented cognition contents; the latter, in turn, may find its analogue in the psychodynamic distinction of self/self-object and object. Decreased self/self-object-object differentiation in schizophrenia may thus be traced to reduced separation of internally and externally oriented cognition, which, neuronally, may be based on reduced differentiation of task-related activity from the ongoing resting state/prestimulus activity. We can thus yield a neuropsychodynamic hypothesis where increased projection of the own internal self onto external objects in schizophrenia is related to decreased rest/prestimulus-task interaction.

Dynamic of schizophrenia I – reduced alignment and entrainment

Why and how are schizophrenia subjects so disconnected from their respective environmental context? In a seminal study, Lakatos (Lakatos et al. 2013) conducted an EEG study in schizophrenic patients to whom they presented a stream of auditory stimuli (i.e., tones) with regular, that is, rhythmic interstimulus intervals (1500 ms). They presented the stream of auditory stimuli with some deviant stimuli (20%) that were distinguished in their frequency. Subjects had to either passively listen (passive task), detect the easily detectable deviant stimuli (easy task), or detect the more difficult (variation by frequency) detectable stimuli (difficult task).

The authors measured what is called phase coherence (i.e., inter-trial coherence; ITC) that refers to the synchronization of the brain's phase fluctuations with the timing of the external stimuli. As expected, increased task difficulty lead to higher ITC (in 1–4 Hz/delta) in healthy subjects. In contrast, such a task-related increase in delta ITC was not observed in schizophrenic patients. These patients were thus not able to properly align, or shift, their auditory cortical phase onsets in the delta range (that corresponded to the stimulation frequency of the presented tones) to the onset of the external tones – they could not adapt their internal neural activity to the external task. This suggests decreased phase alignment or entrainment to external auditory stimuli.

Finally, reduced delta ITC correlated with both the behavioral measure, such as the detection rate of the deviant tones, and the electrophysiological index, the P300 (in response to deviant tones), in schizophrenic subjects. Importantly, reduced delta ITC also predicted the severity of psychopathological symptoms (as measured with the Brief Psychiatric Rating Scale/BPRS) and especially the positive symptoms (that include hallucinations, delusions, and excitement) (Lakatos et al. 2013).

Abnormal, that is, reduced, entrainment of phase onsets to external stimuli has also been observed in other studies in schizophrenia, such as in response to 40-hz auditory stimuli (Hamm et al. 2015; Hamm et al. 2011). Other studies also observed major abnormalities in phase resetting in delta (1–4 Hz) and theta (5–8 Hz) ranges in schizophrenia (Doege et al. 2010a; Doege et al. 2010b) during an auditory oddball task, which, even more interestingly, predicted the degree of positive symptoms in schizophrenia, such as disorganization (see also Hamm et al. 2011).

Taken together, these findings suggest that schizophreniaic patients remain unable to properly link their internal auditory cortical neural activity, as indexed by phase onsets in delta, to a stream of external auditory stimuli. Lakatos et al. (2013) speak of deficits in active predictive sensing by phase resetting that does not allow schizophrenic patients to increase their cortical excitability at stimulus onset for the subsequent processing of external stimuli. Hence, the deficit in input synchronization, as one may say, impacts the subject's capacity to predict subsequent stimuli, including their timing and content.

Dynamic of schizophrenia II – deficit in the timing with temporal discoordination

Where and how is such a deficit in phase synchronization with external stimuli coming from? Wolff et al. (2022) investigated schizophrenia in an auditory task (oddball). She again, like Lakatos and others, observed deficits in the ITC, as schizophrenia participants could not synchronize their brain's phase onset to the onsets of the external stimuli. In a second step, Wolff et al. (2022) investigated temporal coordination of ITC. Given that all subjects were exposed to the same stimuli at the same time, she correlated the subjects' neural activity among or between the subjects. As expected, this yielded high inter-subjective ITC correlation among the healthy subjects.

In contrast, there was no such inter-subjective ITC correlation among the schizophrenia subjects, nor of the schizophrenia subjects with the healthy subjects. Providing further simulation and modeling, Wolff et al. (2022) conclude that neural activity in schizophrenia may exhibit abnormal temporal discoordination, which, in turn, deteriorates their ability to phase synchronize with external stimuli. This, as Wolff et al. (2022) also showed, renders the schizophrenia brain too noisy, with decreased signal-to-noise ratio (SNR) during the processing of external inputs.

Taken together, these results strongly suggest that schizophrenia subjects are no longer able to temporally synchronize their internal neural activity with the external activity in the environment. This means that their brain can no longer process the external inputs from the world properly – which speaks to a basic temporal deficit in input processing in schizophrenia. Schizophrenia subjects and their brains are thus neuronally decoupled from the environment – such “decoupling from the environment” has been described phenomenologically as “loss of vital contact with reality” (Minkowski 1927), or “crisis of common sense” (Stanghellini 2000).

Dynamic of schizophrenia III – reduced temporal integration of inputs

Complementing EEG, input processing has also been probed in a recent fMRI study by Wengler et al. (2020). Inputs are mediated through sensory systems like the visual, auditory, and somatosensory systems. Wengler et al. (2020) traced the different regions from bottommost to topmost in these three input stream systems by measuring their intrinsic neural timescales, that is, their autocorrelation window. They observed that healthy subjects exhibited a continuous increase, that is, longer duration in ACW from bottom to top, within each of the three input processing streams.

Longer duration in ACW means that from bottom to top, more and more external stimuli occurring at distinct time points can be integrated with each other – this yields complex perceptual and cognitive contents (Himberger et al. 2018). Schizophrenia participants, in contrast, no longer showed such a hierarchy of ACW with bottom-to-top progression within each of the three input processing streams. This means that they, unlike healthy subjects, can no longer properly integrate different external inputs and thus cannot constitute complex perceptual and cognitive contents; instead, perceptual and cognitive contents are fragmented due to lack of temporal integration which dominate their time experience (Fuchs and Van Duppen 2017; Arantes-Gonçalves et al. 2021).

The schizophrenic subjects can consequently no longer perceive any difference between different events in the external environment nor a difference of the latter to their own ongoing internal mental or cognitive events, that is, their self. They subsequently confuse their internal self with the external environment (and vice versa), as is typical in symptoms like auditory hallucination, delusions, thought disorder, and ego and passivity disturbances.

Psychodynamic of schizophrenia III – loss of object relation and projection

Together, the neuroscientific findings show decreases in different temporal features of external input processing, including input entrainment and input differentiation. Importantly, these findings point to a temporal deficit in the neural activity during external input processing: neural activity is no longer temporally organized in a coherent and coordinated way, which makes it impossible to phase synchronize to and temporally integrate external inputs (Wolff et al. 2021). As a consequence, neural activity related to external (and ultimately also internal) inputs is temporally fragmented – this is manifest psychologically in the experience of temporal fragmentation (Stanghellini et al. 2016; Fuchs 2019).

The loss of input processing is related to what psychodynamically is described as the “loss of object relation” as based on decreased investment of energy (cathexis), that is, “decathexis of objects” (Boeker et al. 2019; Northoff 2011). This has already been pointed out by Freud himself in his famous case of Schreber: “The patient has withdrawn from the people in his environment and form the external world generally the libidinal cathexis which he has hitherto directed onto them. Thus everything has become indifferent and irrelevant to him” (Freud 1911, 74) (see also Hartwich and Northoff in Boeker et al. 2019, 184ff, for different notions of cathexis in schizophrenia).

The loss of object relation carries major psychopathological implications. If one can no longer perceive externally oriented contents in a synchronized and integrated way, one's perception turns inwards to internally oriented contents like delusions and hallucinations: these are the internal substitutes of the missing external perceptual contents the schizophrenic patients assume to be out there in the external world – they are internal "paraconstructions" of a lost external world (Hartwich and Northoff in Boeker et al. 2019, 184ff). "Para-constructions" can be viewed as redirection of the cathexis from the external to the internal objects – this is manifest in increased projection of one's own internal self/self-objects to the external environment as in hallucination and delusion.

Part II: depression and introjection

Topography of depression I – disbalance between medial and lateral prefrontal cortex

Major depressive disorder, abbreviated as depression in the following, shows major topographic changes in the brain. In a meta-analysis combining human and animal data, Alcaro (Alcaro et al. 2010)

looked at the brain’s resting state activity, that is, the neural activity that can be observed in different regions and networks during the absence of specific stimuli or tasks. This yielded hyperactive regions in the medial prefrontal cortex like the perigenual anterior cingulate cortex (PACC) and ventromedial prefrontal cortex (VMPFC) (as well as subcortical midline regions such as thalamic regions like the dorsomedial thalamus and the pulvinar and pallidum/putamen and midbrain regions like the ventral tegmental area [VTA], substantia nigra [SN], tectum, and periaqueductal gray [PAG]).

In contrast, resting-state activity was hypoactive in the lateral prefrontal cortex regions, being reduced in the dorsolateral prefrontal cortex (DLPFC) (and other regions like the posterior cingulate cortex [PCC] and adjacent precuneus/cuneus; Alcaro et al. 2010) (see also Kaiser et al. 2015 for similar results). Especially the medial prefrontal resting state hyperactivity changes in PACC and VMPFC seem to be somehow specific for depression, as they are not observed in other psychiatric disorders (see Kaiser et al. 2015).

The medial prefrontal regions like the PACC and VMPFC are core regions of the default-mode network, while lateral prefrontal regions like the DLPFC a part of the central executive network. A meta-analysis of resting state functional connectivity observed the following abnormal changes in these networks that seem to be (more or less) specific to MDD as distinguished from other psychiatric disorders (Kaiser et al. 2015). The DMN shows functional hyperconnectivity among its regions, especially between the anterior and posterior midline regions. In contrast to the regions within the DMN, regions within the CEN show functional hypoconnectivity and are also less connected to parietal regions implicated in attention towards the external environment.

This suggests spatial disbalance between the two networks, with an abnormal spatial shift towards the DMN and away from the CEN, with the former also enslaving the latter (as suggested by abnormally negative functional hyperconnectivity between DMN and CEN; Kaiser et al. 2015). These findings are specific to MDD, as in bipolar disorder (BD), such a pattern cannot be observed (Martino et al. 2016) while in schizophrenia, functional connectivity between the DMN and CEN is positive (rather than abnormally negative, as in MDD) (Carthart-Harris et al. 2013).

### Topography of depression II – increased self-focus and decreased environment-focus

### Psychodynamic of depression I – increased introduction

### Topography of depression III – DMN “enslaves and magnetizes” the rest of the brain

### Dynamic of depression – input processing is too slow and reduced

### Psychodynamic of depression II – reduced actual objects and identification with the lost object

Topography of depression II – increased self-focus and decreased environment-focus

The data provide evidence for abnormal resting state hyperactivity in medial prefrontal regions as part of the DMN in MDD, while there is resting state hypoactivity in lateral prefrontal regions as part of the CEN. This suggests the opposite, that is, reciprocal modulation between the medial and lateral prefrontal cortex, with resting state activity being abnormally increased in the former and decreased in the latter.

Abnormal opposite or reciprocal modulation between medial and lateral prefrontal cortical resting state activity in MDD is further supported by analogous functional connectivity: increased functional connectivity in PACC-VMPFC and thus within DMN is accompanied by decreased functional connectivity in the lateral prefrontal cortex and the CEN (Hasler and Northoff 2011; Northoff 2014a; Northoff and Synille 2014). One can thus speak of abnormal reciprocal modulation between the medial/DMN and lateral/CEN prefrontal cortex, with their spatial balance tilting abnormally towards the former at the expense of the latter.

How now is the abnormal spatial balance between the medial and lateral prefrontal cortex related to the psychopathological symptoms in MDD? This spatial imbalance on the level of the brain’s spontaneous activity is well reflected on the phenomenal level: MDD patients’ experiences are characterized by an increased focus on their own internal contents as consisting in either thoughts, as in ruminations with “increased self-focus”, and/or the body, leading to various unspecific somatic symptoms, such as “increased body-focus” (Northoff 2016a, 2016b).

In contrast, these patients’ experience is no longer focused on the external environment at all, for example, “decreased environment-focus”, which psychopathologically is manifest in social withdrawal and lack of motivation. One can consequently say that the abnormal spatial structure in the brain’s spontaneous activity translates and surfaces in the spatial structure of experience, that is, the spatial organization of contents with regard to body, self, and environment, which in turn leads to the various kinds of psychopathological symptoms.

Topography of depression III – DMN “enslaves and magnetizes” the rest of the brain

Why and how is there such abnormal neuronal disbalance? For that, Andrea Scalabrini, a very gifted Italian neuroscientist and psycho-analyst, investigated fMRI-based global brain activity and its local-regional representation in major depressive disorder (Scalabrini et al. 2020). Global brain activity can be measured by the functional connectivity between all regions of the brain – the average of all their connections is the global signal. One then correlates GS with the time series of each region, that is, global signal correlation (GSCORR), which gives us the degree to which the former is represented in the different regions of the brain, that is, GS topography.

What did Andrea Scalabrini find? He observed that the brain’s global activity is much more strongly represented in the regions of the default-mode network in depression compared to healthy subjects. In short, the DMN concentrates the brain’s global activity on itself.

How about the connections of the DMN to the rest of the brain, the non-DMN like the various lower-order sensory regions like visual and auditory networks? For that, he investigated the functional connectivity of the DMN to all non-DMN regions. Most interestingly, he observed that all non-DMN networks were too strongly connected with the DMN in depression: the DMN “enslaves” and “magnetizes” the non-DMN, that is, the rest of the brain, hence the title of Scalabrini's paper, “All Roads Lead to the DMN” (Scalabrini et al. 2020). Finally, the researchers could also show that, using machine learning, the degree to which global brain activity focused on the DMN and enslaved its connection to the non-DMN highly predicted whether the subjects were healthy or depressed (more than 90% accuracy of prediction). This suggests that the global DMN–non-DMN topography may represent a basic disturbance that underlies and drives depression.

Psychodynamic of depression I – increased introduction

Together, MDD can be characterized by a too-strong DMN relative to the rest of the brain, that is, non-DMN. This means that the DMN “enslaves” the rest of the brain; it, according to Andrea Scalabrini, operates as a “too strong magnet” for the non-DMN. This means that the signals and stimuli processed in the non-DMN are abnormally strongly impacted by the DMN. On the psychological level, this means that everything is perceived in terms of the DMN and its self – the brain’s global focus is on the DMN, which psychologically is mirrored in an analogous global psychological focus on the self, the “increased self-focus” (Northoff 2016a, 2016b). This happens mainly on the mental or cognitive layer of the self, as that is based on the DMN (see Chapter 1). However, that may also affect the lower layers of the self, like its extero-proprioceptive and interoceptive layers, as manifest in the often rather strong somatic bodily symptoms of depression.

In contrast, the environmental inputs as mainly processed in the lower-order non-DMN regions are not as functionally highlighted by the brain's global brain topography — the brain's global focus on the processing of external inputs from the environment is reduced, resulting psychologically in “decreased environment-focus”. We can thus see that the brain's neuronal topography of increased DMN vs decreased non-DMN is well mirrored by an almost analogous mental or psychic topography of increased self-focus vs decreased environment-focus. Hence, neuronal topography transforms into psychic topography. The topographical spatial disbalance thus provides the shared feature, that is, “common currency”, of brain and psyche in depression.

Psychodynamically, the DMN-based increased self-focus corresponds well to what is described as introjection. Depressed subjects introject external content by abnormally strongly relating them to their own self: this may be traced to the function of the DMN and its self operating as an abnormally strong magnet that attracts, enslaves, and magnetizes all non-self-specific contents, as Andrea Scalabrini says. Increased introjection thus goes along with loss of actual object relations and, even more importantly, abnormally strong reactualization of the lost object (self-object, if one follows Kohut).

Dynamic of depression – input processing is too slow and reduced

Objects are typically about external events in the environment. To better understand changes in object relation in depression, we must investigate how the brain’s input processing is affected in depression. To investigate input processing in depression, we focus on the visual or occipital cortex (OC) as a paradigmatic example. OC processes visual input, and it is well known that depressed subjects perceive their environment in mainly gray, static, and coarse-grained ways (Song et al. 2021; Fitzgerald 2013). Additionally, depressed subjects perceive their own inner time speed as too slow (Fuchs 2019; Northoff et al. 2018). Together, these psychological observations raise the question of whether neural activity in OC is too slow. This was investigated in two recent papers of ours by Song et al. (2021, 2022).

We first observed that OC neural activity is indeed not fast enough; that is, it is too slow. In fMRI we could observe decreased representation of global brain activity in specifically the faster frequencies (slow 3: 0.073 to 0.198 Hz) of the signal (Song et al. 2022). Analogous findings were obtained in the faster frequency range (1–50 Hz) of EEG. Here again, OC activity was too slow as measured by median frequency (MF) and autocorrelation window. Moreover, the abnormally slow activity in the OC resting state impacted its responsiveness to external inputs during task-related activity: the latter was simply too slow in depression to process especially fast inputs.

Most interestingly, the too-slow OC activity was abnormally strongly connected with the cortical midline regions of the DMN. This, again, was observed in both fMRI and EEG. Accordingly, the enslavement of OC by DMN, that is, their increased functional connectivity, is related to decreased speed in the temporal dynamics of OC itself, that is, too-slow neural activity.

Finally, Song et al. (2021, 2022) tested whether abnormally slow OC activity affects visual perception in an analogous way with the perception being too slow. They indeed could show that depressed subjects showed deficits in visual perception, that is, motion surround suppression, during specifically faster visual stimuli, whereas no such deficit was observed during slower stimuli. That suggests that the abnormal slowness is manifested on both neuronal and psychological-perceptual levels – it provides the “common currency” of brain and psyche.

Psychodynamic of depression II – reduced actual objects and identification with the lost object

What do these findings tell us for the psychodynamic of depression? If the input processing is too slow, some of the respectively associated contents may get lost – the brain is simply too slow or sluggish to process all of the usually fast incoming inputs as related to the actual objects of the external environment. The person can no longer associate and relate the external objects to its own self – this results in what psychodynamically is described as “loss of actual object relation” (Northoff 2011; Boeker et al. 2019).

If there are no actual external objects processed anymore related to the own self, the balance of actual-external vs past-internal objects shifts towards the latter. Typically, depressed subjects refer to past objects of their internal memories (like self-objects, to use Kohutian terms) that are lost, like the lost mother or father. All energy, that is, their cathexis, is invested in those lost objects – the latter are thereby reactivated and identified with the own self in the mental life of the depressed subjects.

Freud describes this very vividly in terms of the libido:

But the libido was not displaced onto another object, it was withdrawn into the ego. There, however, it was not employed in an unspecific way, but served to establish an identification of the ego with abandoned object. Thus the shadow of the object fell upon the ego, and the latter could henceforth be judged by a special agency, as though it were an object, the forsaken object. In this way, an object-loss was transformed into an ego-loss and the conflict between the ego and the loved person into a cleavage between the critical activity of the ego and the ego as altered by identification.

The abnormal focus on the ego or self may neuronally be based upon the abnormally strong representation of the DMN in the brain's global activity – the DMN and its internal self magnetize and slow down the input processing of the actual external objects, for instance, in the OC. The actual objects are then replaced by increased focus on the past and its lost objects: if no actual external objects are processed, one needs to revert to the more internal objects of the past, including the lost ones, to stabilize the self (through internal rather than external self-objects). This, in turn, initiates the abnormal identification of the ego or self with the lost object Freud describes so well. Accordingly, the combination of increased global DMN representation and abnormally slow non-DMN or sensory like OC input processing may lead to the strange combination of decreased actual external object relation and increased reactivation of past and lost internal objects.

Conclusion

Can neuropsychoanalysis contribute to a better understanding of the most extreme changes of our psyche in psychiatric disorders like schizophrenia and depression? Though not the main focus of psychoanalysis, I consider the explanation of these psychiatric disorders a “litmus test” for neuropsychoanalysis. Only if neuropsychoanalysis can properly account for these psychiatric disorders, namely their self-disturbances, symptoms, and psychodynamic mechanisms, may it provide a proper model of brain and psyche.

Recent neuroscientific findings about the brain’s abnormal spatial topography and its temporal dynamics can provide novel insights into the abnormal psychodynamic mechanisms like object relation, ego/self, introjection and projection, paraconstruction, and self-self-object/object relation in schizophrenia and depression. The explanatory power of neuropsychoanalysis for these psychiatric disorders strongly supports the view that spatial topography and temporal dynamic do indeed serve as “common currency” of brain and psyche (Northoff et al. 2020a, 2020b; Northoff and Scalabrini 2021). Even more importantly, such a spatiotemporal topographic-dynamic view may prove fruitful clinically for developing a novel psychopathology, “spatiotemporal psychopathology” (Northoff 2016a, 2016b), as proper ground for more efficient and objective diagnosis and therapy of these psychiatric disorders.

References

Alcaro A, Panksepp J, Witczak J, Hayes DJ, Northoff G (2010) Is subcortical-cortical midline activity in depression mediated by glutamate and GABA? A cross-species translational approach. Neurosci Biobehav Reviews. Mar;34(4):592–605. doi: 10.1016/j.neubiorev.2009.11.023. Epub 2009 Dec 1. PMID: 19958790 Review.

Arantes-Gonçalves F, Wolman A, Bastos-Leite AJ, Northoff G (2021) Scale for space and time experience in psychosis: Converging phenomenological and psychopathological perspectives. Psychopathology. Dec 6:1–11. doi:10.1159/000519500. Online ahead of print.

Boeker H, Hartwich P, Northoff G (Eds) (2019) Neuropsychodynamic psychiatry. Springer, Heidelberg, New York.

Carhart-Harris RL, Leech R, Erritzoe D, Williams TM, Stone JM, Evans J, Sharp DJ, Feilding A, Wise RG, Nutt DJ (2013) Functional connectivity measures after psilocybin inform a novel hypothesis of early psychosis. Schizophr Bull. Nov;39(6):1343–1351. doi: 10.1093/schbul/sbs117. Epub 2012 Oct 8.

Doege K, Jansen M, Mallikarjun P, Liddle EB, Liddle PF (2010a) How much does phase resetting contribute to event-related EEG abnormalities in schizophrenia? Neurosci Lett. Aug 30;481(1):1–5. doi: 10.1016/j.neulet.2010.06.008. Epub 2010 Jun 16.

Doege K, Kumar M, Bates AT, Das D, Boks MP, Liddle PF (2010b) Time and frequency domain event-related electrical activity associated with response control in schizophrenia. Clin Neurophysiol. Oct;121(10):1760–1771. doi: 10.1016/j.clinph.2010.03.049. Epub 2010 Apr 18.

Federn P (1952) Ego psychology and the psychoses. Basic Books, New York.

Fitzgerald PJ (2013) Gray colored glasses: Is major depression partially a sensory perceptual disorder? J Affect Disorders. Nov;151(2):418–422. doi: 10.1016/j.jad.2013.06.045. Epub 2013 Jul 29.

Freud S (1911) Psychoanalytic notes on an autobiographical account of a case of paranoia (Dementia Paranoides). Translated by Alix and James Strachey. Republished: 1979. Penguin Freud Library, London, New York.

Freud S (1917) Trauer und Melancholie (Mourning and melancholia). Internationale Zeitschrift für Ärztliche Psychoanalyse [International Journal for Medical Psychoanalysis]. 4(6):288–301.

Fuchs T, Stanghellini G (ed.) (2019) The experience of time and its disorders. In: The oxford handbook of phenomenological psychopathology (pp. 431–441). Oxford University Press, Oxford, New York.

Fuchs T, Van Duppen Z (2017) Time and events: On the phenomenology of temporal experience in schizophrenia (Ancillary article to EAWE domain 2). Psychopathology. 50(1):68–74. doi: 10.1159/000452768. Epub 2017 Jan 7.

Hamm JP, Bobilev AM, Hayrynen LK, Hudgens-Haney ME, Oliver WT, Parker DA, McDowell JE, Buckley PA, Clementz BA (2015) Stimulus train duration but not attention moderates gamma-band entrainment abnormalities in schizophrenia. Schizophr Res. Jun;165(1):97–102. doi:10.1016/j.schres.2015.02.016. Epub 2015 Apr 11.

Hamm JP, Gilmore CS, Picchetti NA, Sponheim SR, Clementz BA (2011) Abnormalities of neuronal oscillations and temporal integration to low- and high-frequency auditory stimulation in schizophrenia. Biol Psychiatry. May 15;69(10):989–996. doi: 10.1016/j.biopsych.2010.11.021. Epub 2011 Jan 8.

Hasler G, Northoff G (2011) Discovering imaging endophenotypes for major depression. Mol Psychiatry. Jun;16(6):604–619. doi: 10.1038/mp.2011.23

Himberger KD, Chien HY, Honey CJ (2018) Principles of temporal processing across the cortical Hierarchy. Neuroscience. Oct 1;389:161–174. doi: 10.1016/j.neuroscience.2018.04.030. Epub 2018 May 2.

Kaiser RH, Andrews-Hanna JR, Wager TD, Pizzagalli DA (2015) Large-scale network dysfunction in major depressive disorder: A meta-analysis of resting-state functional connectivity. JAMA Psychiatry. Jun;72(6):603–611. doi: 10.1001/jamapsychiatry.2015.0071

Lakatos P, Schroeder CE, Leitman DI, Javitt DC (2013) Predictive suppression of cortical excitability and its deficit in schizophrenia. J Neurosci. Jul 10;33(28):11692–1702. doi: 10.1523/JNEUROSCI.0010-13.2013

Martino M, Magioncalda P, Huang Z, Conio B, Piaggio N, Duncan NW, Rocchi G, Escelsior A, Marozzi V, Wolff A, Inglese M, Amore M, Northoff G (2016) Contrasting variability patterns in the default mode and sensorimotor networks balance in bipolar depression and mania. Proc Natl Acad Sci U S A. Apr 26;113(17):4824–4829. doi: 10.1073/pnas.1517558113. Epub 2016 Apr 11.

Minkoswki E (1927) Lived time. Northwestern Press, Chicago.

Nelson B, Lavoie S, Gawęda Ł, Li E, Sass LA, Koren D, McGorry PD, Jack BN, Parnas J, Polari A, Allott K, Hartmann JA, Whitford TJ (2020) The neurophenomenology of early psychosis: An integrative empirical study. Conscious Cogn. Jan;77:102845. doi: 10.1016/j.concog.2019.102845. Epub 2019 Nov 1.

Northoff G (2011) Neuropsychoanalysis in practice. Oxford University Press, Oxford, New York.

Northoff G (2014a and b) Unlocking the brain, Vol I coding; Vol II consciousness. Oxford University Press, Oxford, New York.

Northoff G (2016a) Spatiotemporal psychopathology I: No rest for the brain’s resting state activity in depression? Spatiotemporal psychopathology of depressive symptoms. J Affect Disord. Jan 15;190:854–866. doi:10.1016/j.jad.2015.05.007. Epub 2015 May 14.

Northoff G (2016b) Spatiotemporal psychopathology II: How does a psychopathology of the brain's resting state look like? Spatiotemporal approach and the history of psychopathology. J Affect Disord. Jan 15;190:867–879. doi: 10.1016/j.jad.2015.05.008. Epub 2015 May 19.

Northoff G, Gomez-Pilar J (2021) Overcoming rest-task divide-abnormal temporospatial dynamics and its cognition in schizophrenia. Schizophr Bull. Apr 29;47(3):751–765. doi: 10.1093/schbul/sba178 Northoff G, Magioncalda P, Martino M, Lee HC, Tseng YC, Lane T (2018) Too fast or too slow? Time and neuronal variability in bipolar disorder—A combined theoretical and empirical investigation. Schizophr Bull. Jan 13;44(1):54–64. doi: 10.1093/schbul/sbx050 Wang X, Liao W, Han S, Li J, Zhang Y, Zhao J, Chen H (2019) Altered dynamic global signal topography in antipsychotic-naive adolescents with early-onset schizophrenia. Schizophr Res. 208:308–316.

Northoff G, Scalabrini A (2021) “Project for a spatiotemporal neuroscience”: Brain and psyche share their topography and dynamic. Front Psychol. Oct 14;12:717402. doi: 10.3389/fpsyg.2021.717402. eCollection 2021.

Northoff G, Sibille E (2014) Why are cortical GABA neurons relevant to internal focus in depression? A cross-level model linking cellular, biochemical and neural network findings. Mol Psychiatry. Sep;19(9):966–977. doi: 10.1038/mp.2014.68. Epub 2014 Jul 22.

Northoff G, Wainio-Theberge S, Evers K (2020a) Is temporo-spatial dynamics the “common currency” of brain and mind? In quest of “spatiotemporal neuroscience”. Phys Life Rev. Jul;33:34–54. doi: 10.1016/j.plrev.2019.05.002. Epub 2019 May 23.

Northoff G, Wainio-Theberge S, Evers K (2020b) Spatiotemporal neuroscience: What is it and why we need it. Phys Life Rev. Jul;33:78–87. doi:10.1016/j.plrev.2020.06.005. Epub 2020 Jul 10.

Sass L, Borda JP, Madeira L, Pienkos E, Nelson B (2018) Varieties of self disorder: A bio-pheno-social model of Schizophrenia. Schizophr Bull. Jun 6:44(4):720–727. doi: 10.1093/schbul/shv001

Scalabrini A, Vai B, Poletti S, Damiani S, Mucci C, Colombo C, Zanardi R, Benedetti F, Northoff G (2020) All roads lead to the default-mode network-global source of DMN abnormalities in major depressive disorder. Neuropsychopharmacology. Nov;45(12):2058–2069. doi: 10.1038/s41386-020-0785-x. Epub 2020.

Song XM, Hu XW, Li Z, Gao Y, Ju X, Liu DY, Wang QN, Xue C, Cai YC, Bai R, Tan ZL, Northoff G (2021) Reduction of higher-order occipital GABA and impaired visual perception in acute major depressive disorder. Mol Psychiatry. Apr 16. doi: 10.1038/s41380-021-01090-5. Online ahead of print.

Song XM, Hu XW, Li Z, Gao Y, Ju X, Liu DY, Wang QN, Xue C, Cai YC, Bai R, Tan ZL, Northoff G (2022) From neuronal to perceived speed in visual area MT. Submitted.

Stanghellini G (2000) Vulnerability to schizophrenia and lack of common sense. Schizophr Bull. 26(4):775–787. doi: 10.1093/oxfordjournals.schbul.a033493

Stanghellini G, Ballerini M, Presenza S, Mancini M, Raballo A, Blasi S, Cutting J (2016) Psychopathology of lived time: Abnormal time experience in persons with schizophrenia. Schizophr Bull. Jan;42(1):45–55. doi: 10.1093/schbul/sbv052. Epub 2015 May 4.

Wang X, Liao W, Han S, Li J, Zhang Y, Zhao J, Chen H (2019) Altered dynamic global signal topography in antipsychotic-naive adolescents with early-onset schizophrenia. Schizophr Res. 208:308–316.

Wengler K, Goldberg AT, Chahine G, Horga G (2020) Distinct hierarchical alterations of intrinsic neural timescales account for different manifestations of psychosis. Elife. Oct 27;9:e56151. doi: 10.7554/eLife.56151

Wolff A, Gomez-Pilar J, Zhang J, Choueiry J, de la Salle S, Knott V, Northoff G (2021) It's in the timing: Reduced temporal precision in neural activity of schizophrenia. Cereb Cortex. Dec 7:bhab425. doi: 10.1093/cercor/bhab425. Online ahead of print.

Yang GJ, Murray JD, Glasser M, Pearlson GD, Krystal JH, Schleifer C, Repovs G, Anticevic A (2017) Altered global signal topography in schizophrenia. Cereb Cortex. 27:5156–5169.

Zhang JF, Huang ZR, Tumati S, Northoff G (2020) Rest-task modulation of fMRI-derived global signal topography is mediated by transient coactivation patterns. PLoS Biology. 18:e3000733.
