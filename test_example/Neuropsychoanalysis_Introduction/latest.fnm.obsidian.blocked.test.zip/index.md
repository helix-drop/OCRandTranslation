# 目录

- [Introduction](chapters/001-Introduction.md)
- [1 Self and narcissism](chapters/002-1 Self and narcissism.md)
- [2 Attachment and trauma](chapters/003-2 Attachment and trauma.md)
- [3 Defense mechanisms and dissociation](chapters/004-3 Defense mechanisms and dissociation.md)
- [4 Cathexis and free energy](chapters/005-4 Cathexis and free energy.md)
- [5 Unconscious and conscious](chapters/006-5 Unconscious and conscious.md)
- [6 Dreams](chapters/007-6 Dreams.md)
- [7 Schizophrenia and depression](chapters/008-7 Schizophrenia and depression.md)
- [Conclusion](chapters/009-Conclusion.md)
