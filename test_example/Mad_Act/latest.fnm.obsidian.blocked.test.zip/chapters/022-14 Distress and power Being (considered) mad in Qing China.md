## 14. Distress and power Being (considered) mad in Qing China

###    "

### Distress and power

### 14

### Distress and power Being (considered) mad in Qing China

I emulate Guandi, behaving loyally and uprightly; therefore I style myself the Great King of Shanxi. 我學關帝做人忠直 所以自稱山西大王的

Lin Zhigong 林志功 (1762)

Because it imagines power, madness is both impotence and omnipotence.

Roy Porter (1987b: 39)

Meaning is inescapable: that is to say, illness always has meaning.

Arthur Kleinman (1988: 144)

In Chapter 13 I explored the ways in which ordinary people treated their insane relatives, described and explained their madness, and coped with their disorder. Here I try to view the situation from the point of view of the men (I have no data on women) who were considered mad. Again, my main source of information is legal documents, “palace memorials” that reported on crimes that the authorities considered serious. Since these crimes were committed through speech, writing, and fantasy, officials tended to record more details about the words and fancies of the “criminals” involved than in homicide cases.

The plight of the eighteenth-century people I study in this chapter was not purely private anguish, the inner torments of the self, madness as “the most solitary of afflictions.”[^1] Much of their vexation arose from being taken as mad, an inflexible diagnosis they fervently disputed. The little that has survived of their voices was recorded during trials and in a few texts they had written that were seized during criminal investigations. It may be impossible to understand their outlook on life, but these texts still give us the best glimpse we will ever get on the world of people that their contemporaries considered mad.


Unlike the “madmen” that official homicide reports described, those I discuss here and in Chapter 15 were quite “aware of human affairs.” “Unaware of human affairs” (不醒人事) was the state of mind in which a “killer” had to be for Qing law to classify his homicidal act as “killing because of madness.” Lucid most of the time, the people I discuss here could interact with people and express complex opinions about their world. The writings and confessions that I use to reconstruct these views also give us a more concrete understanding of what was taken as “mad language” in eighteenth-century China.

This chapter does not explain the functioning of madness in any particular field (though the Qing judicial system is constantly in the background), but focuses instead of various aspects of what it meant to be considered “mad” in eighteenth-century China. I first analyze the main grievances that people who were treated as mad expressed and what these tell us about the way they were treated. The second section shows examples of how they constructed personas that others interpreted as crazy. My last section is devoted to the case of Lin Zhigong 林志功, a peculiar man who wrote several texts in which he spoke of key events in his life in a way that sounded both poignant and utterly crazy. As Roy Porter said, I do not study these people’s unconscious, but what they said (or wrote) about themselves and others, about the way they were treated, and about the symbols that struck them. This chapter should be read along with the next one, which presents more of “mad” people’s voices but focuses on the way officials interpreted their words and writings. Both chapters are about self-aggrandizement, writing, and power.

### ghf gg b dck f

### 14.1 Grievances and reproaches

As we have seen, some individuals in Chinese villages were identified as madmen (瘋子) or fools (痴子). More than a simple act of naming, this identification was a diagnosis sustained by the community—close relatives, neighbors, classmates, etc., who probably thought they were simply stating the obvious. "The local community called [Yang Huaizhen] a madman and stopped interacting with him" (鄉黨呼為瘋子 不與往來).[^1]

Too much is missing from these people's local worlds to understand the difficulties they faced, the way people related to them daily, and the way their treatment differed from the way other poor people were treated. But some themes recur. The commonest grievance I found in mad people's statements was a disagreement with this informal but persistent identification as mad or idiotic. Some people emphasized that this diagnosis came from others. Deng Tingmei 鄧廷梅 (1736): "My son had poxes and died. At once I became so angry that my mind became confused. My ears also became deaf. They said I had gone mad."[^2] (出痘死了 一時把心氣成昏迷 耳朵也氣韜了 他們說我瘋了) Ding Wenbin 丁文彬 (1753), whose trial I discuss in 15.4, claimed to have been designated the Son of Heaven by the descendant of Confucius on orders of Shangdi the Lord on High, a title Ding's relatives did not recognize: "[My older brother] is an unreasonable person; he often calls me a fool" (他是不明道理的人 常罵我癡子). [^4] And elsewhere: "I am not a fool, damn it! At home everybody says I'm a fool." (並不是癡子 可恨 家裏人人說我是癡子) "Fools" (癡子) were not necessarily persons of low intelligence. Those called "fools"

were often people who harbored fantasies that their abilities or positions would never allow them to fulfill (as in the expression "the fool who speaks his dream" 痴人說夢).[^3] This was the case of "Great King of Shanxi" Lin Zhigong 林志功 (1762): "everybody says I am a fool and nobody believes me" (人人說我是痴子都不信我).[^2]



The fact that protests did not change their neighbors' and relatives' opinions probably vindicated or intensified some people's sense of injustice. [^7] Lin Shiyuan's 林時元 statement was vehement: "In the third month of last year [1762], I suffered from some dizziness. They all said I was crazy and they invited a Daoist master to treat me. I am really not crazy at all!" [^8] (我舊年三月有些頭暈的病 祇他們都說我瘋癲 叫道士替我醫治 我實在並不瘋) These men were caught in a language game they resented but could not escape, because the words they uttered to dispute their diagnosis only worked to confirm it.

People whom others considered mad often objected to the way their relatives beat them, ignored them, wronged them, locked them up, and (maybe above all else) called them what they insisted they were not: mad. Any rough treatment received under the pretext that they were insane probably intensified their feelings of injustice. Lin Zhigong wrote in a poem that "turning human relations upside-down, the younger brother beats his elder" (顛倒人倫弟打兄). He Cheng'ao's 何成敖 words (1817), recorded after his arrest, denoted distress and a confused sense of grievance: "From childhood I haven't been able to untie this knot and it has wronged me and entangled me (?) It is I who killed uncle He Dongrun. Actually this is an injustice. Right now, I am also being wronged." (我叫何成敖 我自幼解结不清把我冤枉缠住了 叔子何東潤是我打死的 實是冤枉 我今也是冤枉)

### 14.2 Recuperating symbols: virtue, emperorship, and cosmic destinies

None, as far as I know, protested against medicine. The difference in the treatment received in Western asylums and that received from Chinese physicians can probably explain this lack of protest: whereas internment in an English asylum often meant a prolonged regimen of vomits and purges (even for completely lucid “mad people,” who, when they protested, were confirmed in their condition), treatment by Chinese physicians was not institutional and was most of the time quite short: one or a few doses of an emetic or a purgative often sufficed to conclude to failure or success. Until the very late nineteenth century, no one in Qing China was interned in public asylums where they might be mistreated by strangers or administered medicine against their will. The life of mad people was neither significantly medicalized nor institutionalized. This does not mean they lived an easy and happy life. Mistreatments were simply of a different sort.[^4]

Both madness and literature can be understood, historically, as ways of producing the world.... Madness is a pathology that derives, in part from the capacity for literature.


Alan Thither (1999: 322)

“When madness starts to manifest itself.... one considers oneself to be elevated or of superior virtue, to be shrewd and wise, or to be of high rank; one acts in a conceited manner.” 狂之始發···自高賢也自辨智也自貴倨也 The Canon of Problems ( $ 1^{st} $ century CE), problem 59 Many people who were identified as mad constructed a superlative persona that made them glorious and excellent. Either before they were socially diagnosed as crazy or as a reaction to this label, they spoke of their dreams and visions and often sought official or imperial recognition for their mission or their virtue. Here I use a few cases to illustrate what a “crazy” persona could be like.

Yao Zeng 姚增 came to Beijing from Zhejiang in search of the emperor. He “claimed that he could know the heavenly periods and the earthly principles; his words were empty and boastful” (自稱能知天時地理 言語虛誇).[^5] In remembrance of his father, Liu Yuhou 劉裕後 wrote a book he called Dajiang pangshu 大江滂書 [Book of the torrential great river?], in which he compared his father to the sages, to immortals, and to Buddhas. [11] Lin Shiyuan called himself “the prime-teacher worthy” (第一師賢). [12]

Bai Shengqi 白升奇 was born in Xianning 咸寧 (modern Xi'an, Shaanxi) in 1724 and had acquired some literacy when he was young, but soon "abandoned books for commerce" (棄書貿易), said the official report. [13] Since his case is better documented, let me recount at some length what happened to him and what compelled him to seek the help of Qing officials to justify himself. On his way south to Sichuan to sell pottery (販賣瓷器) in 1751, his boat had capsized and he had been greatly frightened. While traveling back home on the Han river, he had lost his belongings and his luggage (將衣物行李遺失). This loss was either the first sign of his madness or the event that triggered it. When Bai returned, his father confined him at home because he thought his son was mad.


Bai remained confined for years, but when his father died of illness in 1760, his mother "slightly slackened his confinement" (關鎖稍懈). In the late summer of 1761, he asked his ten-sui daughter—was she born after he had "become mad"?—to give him a bamboo rake and a bamboo pole (竹爬一柄、竹竿一根) and later a knife. The child gave him a sickle (!), with which he cut the bamboo into strips (劈碎削成竹簽). Responding to more of her father's requests, she also gave him a brush, an ink stone, and some slips of scrap paper (殘帖廢紙). On the strips and slips, Bai wrote the names of people he knew and the names of official posts (官職), sometimes next to the names of his acquaintances. On the two pieces of paper with which he wrapped 211 bamboo strips and 25 slips of paper, he wrote, "to be delivered to the Shaanxi provincial treasurer." Having managed to escape undetected, Bai went to find his old acquaintance, shopkeeper Yang Xuan 楊選. Since Yang was gone, Bai, claiming to be surnamed Li 立, left the two packages to a man who was responsible for "making fire at Yang Xuan's store" (於楊選舖內燒火) and instructed the man to deliver these urgent documents to the treasurer's office.

When Yang Xuan's employee did what Bai had told him to do, he was immediately arrested. Seeing names of official posts next to the names of unknown people, the provincial treasurer probably worried that the slips hid a rebellious plot or the seed of events for which he would be blamed if he did not handle this matter swiftly. Even more ominous was the phrase "fifth year of Liqi" (立契五年), which sounded like the name of an imperial reign period. Since the taking of a reign title was often the decisive step organized groups took when they decided to move into open rebellion, this case demanded a serious and thorough investigation, the first step of which was to identify the author of the mysterious slips.

The officials in charge first found Yang Xuan, the person to whom the slips were originally destined, but Yang did not know anyone called Li Ⅶ. He only knew two people called Bai:[14] the head of a “community compact” (郷約) and “Bai the madman” (Bai fēngzi 白瘋子), who Yang claimed knew how to write. Governor Zhong Yin 鍾音 sent deputies to arrest Bai and search his house, where they found eleven bamboo strips and five slips of paper with the same handwriting as on the slips that had been delivered to the treasurer’s office. Bai Shengqi was then taken to the Governor’s complex, where, as was customary in cases of possible sedition, he was interrogated by the three highest officials in the province—the governor, the provincial judge, and the provincial treasurer.[15]

It turned out that Bai's motives for presenting the slips were far from those of a rebel. Asked what his intentions were (究屬何心), he answered as follows:

I lost my clothes and things in the Han River and no one pursued [this matter]. I have also been locked up for many years, which has been ghastly and difficult to bear. I wrote the names of people I know on bamboo strips and paper slips, and filled out the official posts, hoping to make them look for the lost objects for me. Because I do not see many people from year to year, I had [the slips] sent to the provincial treasurer's yamen, so that he could help me search the things and return them to me.

因在漢中遺失衣物 無人追究 兼被鎖禁多年 苦楚難堪 每將認識之人並寫竹簽紙條填以官職 欲令代找失物 又因每年不見眾人 交送布政司衙門即可為我查傳 教給返獲東西

The three provincial officials asked more specifically why he had written such things as “the fifth year of Liqi” and “Liqi prefectures and counties” (立契府縣).

I used to write contracts for people. On them I would write the two characters "Liqi" ("Establishing the agreement"). Formerly, I used to be called Bai Shengqi, but because everybody calls me Bai the madman, I changed my name to Bai Liqi. It is because they have been confining me for five or six years that I wrote "fifth year of Liqi" on the paper strips. As for "prefectures and counties".... this is something I just wrote offhandedly.

我曾替人寫過文約 上面俱寫「立契」二字 我從前原叫白升奇 因人都叫我白瘋子 我就改名立契 又被他們鎖禁有五六年 因此紙條上寫「立契五年」 那府縣名 □是我隨手潛寫的

To make sure Bai Shengqi was not lying or hiding other relevant details, the officials interrogated him under torture, but as they reported, all he said was that "all the strips and slips in the packages were the injustices [he had undergone and] that he wanted to submit and protest about. Otherwise his recorded statement is confused and upside-down, without any coherence." (包內簽條俱係伊的冤枉 急要伸訴 此外供詞 率多糊涂顛倒 毫無倫次) Bai Shengqi was eventually bastinadoed to death in the marketplace.

“Bai the madman” had made sense of his predicament with meaningful terms and semantically rich symbols. His words were not inane prattle, but their meaning was quite different for Bai than for the officials who condemned him. Bai could not have been unaware that “the fifth year of Liqi” sounded like a reign title. This title—and the phrase “prefectures and counties,” which he “wrote offhandedly”—make it appear as though he was not only extending his grievances (lost objects, years of home confinement), but was trying to compensate for them by draping himself in the trappings of imperial authority. We know too little about Bai to tell how much he “believed” in his (admittedly indirect) claims to emperorship or if the self-aggrandizing “fifth year of Liqi” only sounded comforting in distressing times.[^6]

Zhang Tingyong 張廷用 also managed to sound politically subversive even as he constructed his "delirium" from daily objects and local names of people and organizations. [17] Of course his words were also designed to sound politically meaningful. As a youth, "Zhang Tingyong had participated in a [semi-annual local] examination to become a licentiate but had not been admitted. [18] This turned into madness/idiocy: he would constantly chant the Buddha's name; [the illness was] intermittent" (張廷用曾考試式童未能進取 染成瘋癡隨口念佛 時發時止). In 1748, having shaved his hair and queue (自剃髮辦), he went to Wutai Mountain to become a monk, but the bonzes in charge (當處僧人) made him return home. In 1756, when Zhang's illness became more serious, his family declared him to the county office through the head of the local community compact (經鄉約報官). The county issued chains and locks and delivered Zhang to his relatives, who were instructed to lock him up and keep watch over him (發給鎖封 交伊親屬鎖錮看守). [19] In 1760, he twisted his locks open and managed to flee to the city (扭鎖脫身 奔入城市), where he was captured by the magistrate's men. He was sent back home with new locks (仍發鎖封看守). The county government had files on both events (各有案).


In 1767, while everybody was working in the fields, Zhang broke his chains again and fled from Shanxi to Huaian 懷安 county in Zhili (near the Great Wall), carrying 10 manuscript notes that he may have written over the years or along the road (the report did not tell). He was caught again. As the magistrate in charge of his case reported:

The text is mediocre and pedestrian, preposterous and confused, constantly redundant and not forming full sentences. But among the words we find "White-rain dragon-king association," "Society of the Ten Buddhas," and the names of people in those associations, such as "Liu Guangrong," "Association Leader Cao," and "Association Leader Wang." I am very afraid that [these names] hide something else, such as [sutra?] reading associations. 閱其鄙俚誕妄迷係重複雷同 不成語句 惟字內載有白雨龍王會、十佛會及會中人劉光榮 曹會長 王會長名 甚恐有念□會別情

Symbolically loaded language made officials apprehensive. Zhang Tingyong's slips seemed to mention the kind of religious association that was often banned under the label of “devious cult” (邪教). Such religious groups were common in Qing China, but the state feared they might develop into large-scale organizations that could rival the state in their sway over “people’s hearts.” [20]

The officials who interrogated the local leaders and the people Zhang Tingyong named in his notes soon found that there was no rebellion in the making. The “Society of the Ten Buddhas” was the name of a long-banned association that was named after ten days representing the birthdays of ten gods and Buddhas (神佛誕日 十項相傳). The report specified that “this association no longer exists” (現無此會). Liu Guangrong was the name of a “hearth-dwelling Taoist priest” (火居道士) who pleaded to gods in the name of those who sought his services and chose auspicious days for marriages and funerals (代人酹神祈禱 并選擇婚葬日期), but practiced no occult arts.

The lofty-sounding “dragon-king association” turned out to be an agricultural cult and “white rain” the name local peasants gave to hailstones (冰雹). From the fourth to the eighth lunar month, the villagers went to the neighboring temple of the dragon spirit.... to burn incense and paper to [?] and pray (村農至附近龍神廟內□帶香褚靼流祈禱) that the hail would not harm the crops: “there are in fact no such things as gatherings of crowds to read sutras or the establishment of devious cults” (實無聚眾念經、創立邪教情事). The practice of presenting incense at the local dragon-god temple was in fact consistent with what the Code called “charitable societies that conduct prayers in the spring and fall” (在本村神龍廟靼月進香 與律載春秋義社以行祈报者相同 似無庸置議). [21]

The Governor of Shanxi clarified small details: under interrogation in Zhili soon after he was caught, Zhang Tingyong had mentioned the existence of “one effortless knife kept by xianzi [i.e., a sage]” (顺刀一把是賢子收著). The “knife kept by the sage” was not the fantastic weapon or religious object that officials feared it might be. The Shanxi Governor, who had a copy of Zhang’s statement, discovered that Zhang’s house was near a mountain and that the family owned an old knife for protection against wild animals, which was kept in the house of “this criminal’s younger brother Zhang Qixian” (原有防獸舊刀一把 在該犯之弟張企賢家內收存). The last character in the name of Zhang Tingyong’s brother was xian (“sage”). Xianzi (“a sage”) came from the common Chinese practice of addressing one’s siblings by adding zi 子 to the last character of their personal name.

### ghf gg b dck f

### 14.3 “Idle steed” Lin Zhigong and his writings

Because Zhang had not impinged on the sanctity of imperial symbols, he was not physically punished. As the 1767 report concluded, “it has been established that this criminal Zhang Tingyong is indeed mad; according to the [1762] sub-statute [on those who have committed a killing because of madness], the Yingzhou magistrate shall be ordered to confine him and take the proper precautions, so that [Zhang] will not be allowed to break out and stir up trouble again” (该犯张廷用實屬瘋癲 應飭令應州知州照例嚴加鎖禁防範 毋使再以出境滋事). We know of Bai Shengqi and Zhang Tingyong through third-person reports on their words and acts. We now turn to someone who left his own writings, and whose view on life we therefore know much more about than Bai’s and Zhang’s.

Lin Zhigong's 林志功 case is one of the most interesting to have survived in the records. [22] Lin was born in 1708 in Changshan 常山 county in Quzhou 衢州, the westernmost prefecture of Zhejiang, near the border of Jiangxi province. He became mad with grief after his wife and one of his two sons died of disease early in 1735. His relatives tried to have him exorcized, but without success. A new marriage was nonetheless arranged between Lin and a young bride from Yushan 玉山, a county west of Changshan in Jiangxi.

At an unspecified time, Lin's relatives declared him to the county government and confined him at home, but eventually released him. In 1755, magistrate Qin Tingji 秦廷基 somehow found out that Lin's condition had worsened; he ordered Lin's relatives to "keep watch" (收管) over him. $ ^{23} $ Lin was probably not seriously restrained, because in 1756 he managed to go to the residence of former prefect Lin Minglun 林明倫 to "acknowledge" him as part of the same patrilineal clan (前守林明倫署妄認同宗). $ ^{24} $ The retired official promptly had Lin sent home for preventive guard. Angry that Zhigong had stirred up trouble, his uncle (叔) Lin Fengrui locked him up in an empty room (鎖錮空房), but Zhigong was eventually liberated because his mother pitied and missed him (後因伊母憐念仍行鬆放). Zhigong dreamed of becoming a virtuous official. A plan to build a small dam near his home prompted him to submit a petition to the county office, but instead of being allowed to help, he was (again) captured by county magistrate Zhang Youtai 張又泰, who turned him over to his relatives and the local baojia head for proper supervision.

Lin Zhigong's final escape took place in April or May 1762 (the fourth month of Qianlong 27) when his relatives let him go to Yushan county to visit his wife's father. But once in Yushan, Lin did something he had not announced: he went to place a note in county magistrate Rao Jinjun's 饒晉均 sedan chair. The note read: Of all-under-heaven I am the idle steed, 我是天下無事馬

Arriving in Hangzhou [25] the emperor to greet. [26] 特到浙杭迎帝駕

The Han teacher a thousand years ago had so predicted, 漢師千年前定數 The prophecy is now unraveled, and it is attested. 今解數語寔不假 interpret, perhaps because Lin Zhigong's texts were eminently authored. I have no way to understand the significance of particular words or images to their author, and although I may have retained passages in which Lin "sounded mad," seemingly innocuous details—a date, the name of a person, the sound of a string of words, etc.—may have been even more important to Lin himself.

Even if he was nowhere near Hangzhou, Lin Zhigong was immediately arrested because his cryptic title and his claim that he came because of a prophecy (and the charismatic power it could potentially carry) sounded inherently suspicious. Officials seized one sheet of paper that Lin was carrying and examined it for traces of subversive formulas or insinuations. They also sent runners to search Lin's home, where they found eight manuscripts "hidden"— possibly just inserted—in Lin's old copy of the Four Books, the only book he owned.

Officials tried to determine whether Lin had “borrowed the guise of madness to dissimulate” (借瘋掩飾) rebellion or other illicit activities. Lin was sent to Hangzhou (the capital of Zhejiang) for trial. Lin was eventually sentenced to military deportation to the empire’s northern borders for “writing apocryphal auguries and books about sorcery in order to circulate them and confuse people, [cases in which the materials] did not reach the multitudes” (造纖緯妖書傳用惑人 不及衆者).[27] But let me concentrate on Lin’s writings and what they reveal about his outlook on the world.

The eight texts that officials seized in Lin Zhigong’s house form a fantastic array. [28] They show us how Lin created a relationship with his world, and they give as good an insight as we will ever get into an eighteenth-century man’s experience of what others called “madness.” Written in clear and simple language, they are nonetheless extremely difficult to interpret, perhaps because Lin Zhigong's texts were eminently authored. I have no way to understand the significance of particular words or images to their author, and although I may have retained passages in which Lin "sounded mad," seemingly innocuous details—a date, the name of a person, the sound of a string of words, etc.—may have been even more important to Lin himself.

At some unknown time, Lin started claiming that he had received a revelation. Many of his texts purported to be copies of a thousand-year-old stele inscription that had supposedly come to light in 1735 when a section of the city wall of Ji'an 吉安 (Jiangxi) had collapsed. 1735 happened to be the year when Lin's wife and son had died of illness, the shock that had driven Lin mad. Lin claimed that the text of the stele had been written by "Zhuge the teacher of Han" (诸葛漢師)—Zhuge Liang, the brilliant strategist who had helped Liu Bei during the Three-Kingdoms period and was one of the heroes of the immensely popular Romance of the Three Kingdoms and of many plays based thereon. [29] Zhuge was also a popular god who had the reputed ability to possess people and speak through them. [30] After an investigation showed that the city wall of Ji'an had not collapsed and that no stele had been discovered there, officials asked Lin who had composed the text of the "inscription." Lin told them it had been dictated to him by "the three Mao lords" (三茅君), three deified brothers after whom Mount Mao (Maoshan 茅山) was named. [31]

Lin claimed that he had not understood the text at first, but that he was eventually able to explain it and even annotate it line by line (從前總解釋不通後來才能解釋就

逐句註解出來), as one would a canonical book or a sacred text. Lin worked on the text of this revelation on many occasions, rewriting and re-annotating it at least three times.[^7] Here is a translation of the main text, which was written in rhymed seven-character stanzas, with explanations of how Lin thought the prophecy was about himself: Dense drizzle, the fields cannot be seen [33] 細雨霏霏不見田 My heart is connected, at Nine-rings [34] 自心相接凡九連


Three lights, fear that a heart will die of itself [35] 三光恐有心自死

Five horses coming from the east, five going south [36] 五馬東來六馬南

A sword and a halberd buried facing ten-mouth mountain [37] 十口山前埋劍戟 A pitiable scholar on a bright-and-dark islet [38] 光陰洲上茂士怜

In Shanxi there is again a guest from the West mountain [39] 山西又有西山客 Endured for many years and endured censure [40] 边受几年边受弹

The year of five-nine, there was much [on?] five-nine [41] 五九之年五九多

To the swallowed (?) across-the-sea to receive a pineapple [42] (?) 到吞横海受波羅 The three-seven kid-child; three-seven died [43] 三七孩兒三七死 Two-eight beauty, two-eight wonder $ ^{44} $ 二八嬌娥二八奇 If a licentiate can decipher it 秀才若能說得開 experience with the Daoist priest did not include Guandi. There is now way to determine whether the encounter took place the way Lin said it did.

Only after the steed fell did we know it appeared at Nine-rivers [46] 落馬方知出九河 For Lin, this poem was charged with personal meaning. It asserted his virtue, compared him to Guandi, and gave him a title (the “idle steed” 無事馬) that likened him to a gentleman.

Like most texts written in a prophetic style, Lin's "stele inscription" could sustain multiple interpretations, but only Lin himself could decipher it properly, as he did in his annotations. Lin also claimed that his interpretive aptitude endeared him to the ultimate authority figure: the emperor. As he wrote at the end of a non-annotated copy of the revelation: This stele poem was made by Zhuge Liang 造此碑詩諸葛亮

A halberd buried facing the mountain: Guan's clouds are long 山前埋戟関雲長

Although there is an optimus at every session [47] 狀元雖然科 " 有 Not one can expound this poem 見着此詩無能講 Though the poem's meaning has been divulged 詩中意義雖然洩 Writing on it is difficult to conceive 能做文章難忖想 If you want someone who can explain this poem 若要得此解詩人 He comes from Chang[shan] in Quzhou in Zhejiang 出在浙江衢州常 If a registered student can explain this poem 童生解得此詩來 Grant him a real licentiate title [48] 赐他一名真秀才 If a licentiate can decipher it 秀才若能說得開 experience with the Daoist priest did not include Guandi. There is now way to determine whether the encounter took place the way Lin said it did.

Lin’s privileged access to meaning in this case contrasted with his daily situation, where neighbors and relatives refused to believe him and simply called him mad. His texts expressed his grievances in terms that mixed powerlessness with omnipotence, distress with self-aggrandizement. Once again the emperor was a key focus of Lin’s calls for recognition. People must know of this idle gentleman 無事君子人要知

If so they should report and notify the emperor in detail 知得詳奏皇上知

Filial, brotherly, loyal, trustworthy, humane, righteous, and frugal 孝弟忠信仁义廉 Public-minded, selfless, and not suspicious 公直無私無可疑

Some of Lin's texts were written in response to the way others treated him. Lin's uncle, for instance, had once sought the help of a Daoist priest to treat his madness. The priest had invoked the powers of Guandi, the popular deification of Guan Yu 關羽 (1622–220), a hero and general who, like Zhuge Liang, had lived in the Three-Kingdoms period that followed the fall of the Eastern Han dynasty. [50] In his commentary to the revealed poem, however, Lin Zhigong recounted a therapeutic encounter with Guandi (through a child medium) and a separate meeting later with a Daoist priest. Lin's agonizing account of his experience with the Daoist priest did not include Guandi. There is now way to determine whether the encounter took place the way Lin said it did.

I swallowed cold water to protect my heart and liver ☐吃凉水保肝心

Burned like that for two nights, the pain was unbearable 連燒兩夜痛難當

I called to my father, but the heart was masterless [52] 口叫我父心無主 Those who attended trembled in fear 来看之人心戰競 I called to my mother, but she did not answer 又叫我母母不應

The Daoist priest asked me what ghost was following me 道士問我何鬼跟

“Speak the truth so you shall be spared the burning” 好“講夾免燒身 I said I'd not seen any ghost. 我說不曾見何鬼

The flames and oil fire kept coming at me[^8] 炎 " 油火不離身 I said there was indeed some ghost following me 我說是有某鬼跟 Obviously false words to trick the Daoist 明"假言騙道人 Had I been truly mad or stupid 若还我是真颠呆

The oil fire and the flames would have been difficult to escape 油火炎" 難脫身

Lin recalled his encounter with Guandi more positively in his long commentary to the line "Burying a sword and halberd in front of ten-mouth mountain" (十口山前埋劍戟)

in the “stele inscription”:


If you don't believe, look at the poem [54] 不信但看後詩言 Guandi buried a halberd as proof to see [55] 関帝埋戟作証見

In the first month of yimao my relatives believed words[^9] 乙卯正月親信言 They believed hearsay and suspected I was mad 听信傍言疑我颠

Younger brother went to the temple at the Guan-village bridge [57] 弟到関広橋頭廟 And asked Guandi to treat my madness 接請關帝治我顛 I did not act rudely, neither did I scold 我無撒野無罵人


Guandi spoke to me face-to-face through a child [medium] [58] 關帝托童親面言 The child conveyed Guan's sagely words 童子竟傳關聖語 He said this person is not mad 說道此人不是顛 Guandi transformed me a living body and bones (?) 関帝換我陽身骨 And buried my cap and garments in front of my room 把我冠衿埋屋前 A "ten" [十] inside a "mouth" [口] is a "field" [田] 口内加十是一田

There are a field and a mountain in front of my room 有田有山我屋前

The halberd was buried in the mountain in the first month 埋戟案山是正月

The stele arrived in Caoping in the fourth month [59] 碑到草萍四月間

The halberd is the cap and garments; cap is hat, garments are clothes 戟是冠衿冠是帽衿是衣裳

Lin's commentary to the next line of the prophecy contained more on this encounter with the powerful deity.

In the first month of yimao [1735], through a child-medium 乙卯正月托童子 The child-medium taught me to be Guan [Yu] 童子教我做関身 The second younger brother did the child medium 第二胞弟做童子 Exorcism has a higher symbolic content than drug intake, and symbols offer more to relate to than purgatives. Lin was clearly transformed by his ritual encounter and he integrated the symbols of his therapy into his delirium. Although his friends and relatives made little of his claim that Guandi was efficacious, Lin's texts were permeated with the images he had encountered in his (fictional?) session with a child medium.

He fought with me in front of my house south of the mountain 同我屋前山南攒 His hand weaving a wooden stick he met me 手舞木棍與我覿 The child-medium possessed me 童子把我身上拖 And asked me to wave my hands for him 教我手舞舆他看 At the time I thought I had nothing else to do 彼时我忖無他事 The child played Zhou Cang, I played Guan [60] 童為周倉吾為關 I took the stick and danced 我拿木棍舞一場 The child smiled and felt happy 童子口笑心喜歡 The stick, my clothes and hat together were buried 木棍衣帽一同埋 To make me be a great-peace [?] Guan 是叫我做太平関

Before he died the teacher of Han [Zhuge Liang] wrote this poem 漢師未死造此詩 Yet people now say I am mad or crazy 今人反毁我颠乱

After his encounter, Lin felt much better and told his friends how efficacious Guandi was, but the more he said so the more they thought he was crazy.

Despite having felt transformed, Lin was not healed. Healing in this case would have had to be in the eye of Lin’s relatives, those who had made the diagnostic in the first place. But Lin’s texts expressed resentment that these people kept calling him mad. The fact that he was sent home many times with orders to take precautions shows that local officials agreed with this diagnostic. Depositions made during Lin’s trial concurred that he was crazy, and the officials in charge even worried that he “used madness” to dissimulate other plans. [61] In all these documents, the only voices saying that Lin was not crazy were Guandi’s and Lin’s own.

Exorcism has a higher symbolic content than drug intake, and symbols offer more to relate to than purgatives. Lin was clearly transformed by his ritual encounter and he integrated the symbols of his therapy into his delirium. Although his friends and relatives made little of his claim that Guandi was efficacious, Lin's texts were permeated with the images he had encountered in his (fictional?) session with a child medium.

Popular gods also gave Lin Zhigong an idiom by which to express his hopes and grievances. As he told the magistrate who arrested him:

I emulate Guandi, behaving loyally and uprightly, therefore I style myself the Great King of Shanxi. [62] Because everybody says I am an idiot and nobody believes me, I wrote one page and crossed the mountains from Zhejiang to come to your hall. I put [the note] into your empty sedan chair so that you would see it and recommend me to become an official. [63]

我學關帝 做人忠直 所以自稱山西大王的 因人人說我是痴子都不信我故此寫了一張 從浙江走過山 來到你堂 上撩在你空轎子裏 要你看見好保舉我做官的意思

Lin Zhigong was attracted to the prestige and claims of superior virtue that went with service in the bureaucracy. During trial, his relatives and neighbors testified that he would “often brag and speak crazy words in front of people, saying how loyal and filial he was and how much good he did, but that there was still no one who recommended him to be an official” (時向人前大言狂語 謂其如此忠孝行善 竟無人保薦做官). [64]

Lin expressed his privileged contacts with the gods and his desire for recognition in an account of his encounter with magistrate Zhang Youtai concerning the building of a dam, in which Lin wanted to help. If Lin Zhigong managed to talk to the magistrate in person, it was probably because he did not appear obviously mad at first sight. The fascinating text takes the form of an order by “the teacher of Han” (Zhuge Liang) to “Emperor-King Lin” (帝王林) to “investigate the matter of the befuddled, unfilial, unbrotherly, and unbenevolent minister” (為查朦朧、不孝、不弟、不仁宰賭事): $ ^{65} $

Master Zhang of Changshan is truly confused, [66] wildly taking loyalty and filiality for madness. On the 26 $ ^{th} $ day of the 10 $ ^{th} $ month of yimao year [1735], [67] my presenting a petition in his official hall was for the public good, [68] I had one petition to present at the same time. The master looked at the report and laughed, asking me who had written it: I said it was of my own brush. Yang Gao did not know what matter the petition reported, [69] in a muted voice he told the master I was crazy. I had a report to present so I ignored him; hearing him speak I feigned deafness. When Master Zhang finished asking, he told me to leave. I returned home that very day. Unexpectedly on the 27 $ ^{th} $ came a vermilion rescript, [70] ordering the bao and the family head to restrain me as mad, with no permission to let me out to cause more trouble.

常山張主真朦朧 亂指忠孝為癲瘋 十月廿六已卯年 當堂遞呈是為公 有一首呈共時遞 主看稟呈口嗜笑 問我此呈何人做 我說是我自筆踪 楊高不知稟何事 輕聲主前說我瘋 我有稟呈不理他 我聽他說假耳聾 張主問

### ghf gg b dck f

### 14.4 Conclusion

了叫下去 當日即回到家中 不料廿七出硃卑 著保家長管束瘋 不許縱放出生事

Even if his writings were calls for recognition, in a way, Lin dismissed society's judgment in the name of its highest values. His pure advocacy of virtue and filiality and the fact that people rejected him or beat him up instead of praising him only confirmed his belief in his oppressors' confusedness or lack of virtue.

Lin’s fantasies organized his experience by imposing the terms by which he wished reality would unfold. Lin shaped this symbolic material as much as he was shaped by it. Since details of his fate had been engraved on a stele more than a millennium ago, Lin’s life had cosmic meaning. Yet his implementation of the greatest virtues (loyalty in public service, filial piety) were dismissed—“slandered”毁, as he said—as madness. One of Lin’s texts started: “My relatives say I am muddled in my heart; clearly they mistake my words; Zhuge knows I am true, loyal, and filial [or truly loyal and filial]; [because] my ancestors accumulated merit, [Zhuge] composed a stele inscription” (家人說我心中潛明”枉我之言論 諸葛知我真忠孝 祖父積德造碑文). [71] When Lin’s relatives called him “mad” and dismissed him as an idiot, he countered with contentions of pure virtue. Both parties remained inflexible. The esoteric yet redoubtable coherence of Lin’s text confirmed him as a virtuous person, but condemned him to remaining misunderstood.

Modern psychiatry tends to give little role to the content of pathological language.

The view that disorderly speech says little about etiology and is of little help to therapy corresponds with the common psychiatric attribution of mental illnesses to neurochemical imbalances. This problematization (or deproblematization) of speech can easily turn the coherent words of mad people into “an irredeemable babble.” $ ^{72} $ Even psychoanalysis, which is bent on working with and through language, does not take psychotic delirium at face value. This chapter has shown that speech that some Qing people labeled as “mad” was not always unintelligible, $ ^{73} $ and that some officials often took it quite literally.

The ways in which the eighteenth-century men I discussed in this chapter expressed their grievances and constructed powerful symbolic selves shows that “even the mad are men of their times” (Porter 1987b: 5). People like Bai Shengqi expressed themselves in intelligible idiom with symbols they borrowed from their readings, from the little formal education they had received, from the plays they had seen and the stories they had heard, and no doubt from the multiplicity of unrecorded little events and encounters that marked their lives.

Lin Zhigong's case has shown that the words of a "madman" (i.e., a man whom others treated as "mad") could sound crazy, yet be both meaningful and interactive. Daniel Moerman (2002) has attributed the well-known "placebo effect" (by which the health of patients improves even if the remedies they take are pharmacologically inactive) to what he has called "meaning response." In Lin Zhigong's case, "meaning response" clearly took place, but it failed to modify the diagnostic of "madness" (顛; 瘋) or "foolishness" (痴) that others had imposed upon him. Instead of the therapeutic "effectiveness of symbols" (Lévi-Strauss 1966 [1958]), we could thus speak of the transformative power of symbols and broaden Moerman's notion of "meaning response" to include all transformations (not only beneficial ones) that result from "meaning-full" responses.

Interestingly, those who suffered mental collapse and displayed symptoms of madness used the same symbols in their fantasies as literati and successful examination candidates did in their own stories or dreams. [74] Benjamin Elman (2000: 368) has argued that “the cultural boundaries of mental health were drawn differently in late imperial China than in early modern Europe.” Fighting against reductionist accounts of Hong Xiuquan 洪秀全 (1813-1864)—the leader of the Taiping rebellion—as “mentally ill” (see Yap 1954), Elman explained that

Hong's visions are less evidence of an individual Han Chinese man's paranoia than they are comprehensible narratives drawing on the rich symbolic traditions of Chinese religious and cultural life, which well-adjusted Ming zhuangyuan and Qing literati equally engaged in and which were deemed socially acceptable among upper elites until the late seventeenth century.

Lin Zhigong's (14.3) and Ding Wenbin's (15.4) visions also borrowed from "the rich symbolic traditions of Chinese religious and cultural life." Like Hong Xiuquan, Lin and Ding claimed to have received revelations from gods and they draped themselves in imperial regalia. Yet, their relatives still dismissed them as either crazy or "foolish."

One crucial difference between Hong Xiuquan and the men I discuss in this chapter and the next was in the support society gave them. Hindsight probably made a significant difference. As Elman himself remarked (2000: 368-69), only after Hong became the leader of a large-scale rebellion were his dreams reinterpreted as “a sign of his special future and confirmed his fate as the anointed leader of the Taiping.” Before that, Hong’s relatives had made the same decision as Lin Zhigong’s: they had sought a Daoist priest to treat him. We lack details on Hong Xiuquan's early life, but we must assume that his relatives had also interpreted Hong's words as the result of some sickness, perhaps possession.

Because some labels carry social or institutional consequences, there can be large stakes to the way people are labeled. And because labels are contextual, forms of behavior that could be called mad were not always called mad. Labeling decisions were made in practice. Hong Xiuquan was not considered mad because he found a social role in which he could integrate his visions. It is indeed important not to label Hong as “mentally ill” too hastily, but we also need to realize that in some Qing contexts Hong could have been (and even was, by his family) taken as a madman.

The same themes (revelations, access to the divine, etc.) expressed by a rebel leader were interpreted differently when they came from the mouth of a destitute man rejected by his family, even if both drew from common symbols and deployed these symbols through conventional genres. My point is that the boundaries of “mad speech” (and “mental health”) were perhaps more social than cultural. More accurately, no words or acts are inherently either mad or not mad on a purely cultural level. As in the case of Hong Xiuquan, it was social interactions that led other people either to accept these acts or to dismiss them as insane. The next chapter extends this point by showing how words that villagers considered as signs of madness could acquire a subversive force in politicized contexts.

### NOTES

[^1]: 1. A@ B 34and0wasused0as0the0title0of Xcull0 A@?6
[^2]: 2. indeed0went0into0open rebellion0in0the0late0eighteenth0century60Xusan0Saquin0has0recounted0the0socialrootsand0unfolding0of0smaller5 scale0uprisings0in0two0books 2 A?>a0and0 A@ 36 Yo0some0extent40the0government~s0fears0were0self5fulfilling6 Iavid0Twnby 2 AA>3 has arguedthat0some0rebellions0started0only0after0the0statehad bann ed organizationsIRU IHDU0W H\0ZRX G0UHEH 6 or0explanations0of0why0the0Ving0state0saw0it0as0its0duty0to Prectify0people~s0heartsQ in ordinary0times0and Pawe0people~s0heartsQ in0cases0of0sedition40see0 =6>6
[^3]: 3. 6 A3by Fcting0Xhandong0 overnor Gai0^hongshanƾʋÜ and Xhandong0Jducation0commissioner \ie0WongshengɑƎƯ 2V[I B0?> 36 S ^ªb¬ S XzTq[ memo¡ial da£ed `a p¤g] `fbe WQ{`]f]eX] rom0Iing~s0confession02V[IB 36
[^4]: 4. See for instance the case of Ms. Zhang in 9.2.
[^5]: 5. Palace memorial dated 7 Jan. 1778 (QL42.12.9); LFZZ, mf 098.0267-9.
[^6]: 6. 0and0Fppendix0@0under0 ?>>36
[^7]: f] halberd buried facing the mountain uan~s clouds are longÜd Ęʒʟʎ name Qin claimed should be read as P[est riverQ ȶŽ am not certain why P[est WiverQ referred to Qin~s place of origin which Qin~s texts also designated as [est Rountain see note above lthough there is anRSW P XV at every session
[^8]: 8. claimsthatby @ 0they0had0become PubiquitousQ even in0\injiang cities0on0the0northwestern0reaches0of0the0Ving0empire6 Fround0 ? =40the0Ving0government0also0started0to0integrate0 uandi0into0the0official0state0cult02see0Iuara0 A@@36 =@ F WRQJ] Ǧò was0the0young0servant0of0a0deity0who0could0channel0this0deity~s0words6 or0more0on0their0roles in0local0religion40with0a0focus0on0exorcistic0ceremonies0in0the0Xong0dynasty4 see0Iavis0 B0@?5 ? 6 =A Haoping0was0a0mountain0village0west0of0Hhangshan on0the0border0of0^hejiang0and0 iangxi6
[^9]: 9. > 0suggested0in 6 thatcommon0people~s depositions0aboutthe0words0or0acts0ofmad0people0must0be understood0in0the0context0of0the0case0under0investigation60Yhe0fact0that0Qin~s0case partly0concerned0his fantasies about officialdomprodded investigatorsto record0pastbehavior0that0appeared0to0adumbrate the0case0at0hand6
