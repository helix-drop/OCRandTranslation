## Appendices

APPENDICES

### NOTES

[^1]: 1. 01: “Blithely circulating devious words, writing placards, and rousing and confusing people’s hearts” 妄布邪言書寫張貼煽惑人心 [DLCY 25: 567]. This penal denomination was based on an imperial edict proclaimed in 1636; this edict was imperially approved during the Kangxi reign (1662-1722), when it was made into a li 例. Applied only to the imperial capital originally, but was broadened to the entire empire in 1740. Was merged with another text of law in 1801 (see next entry) to form sub-statute 256.01.
[^2]: 2. 01: “Injuring someone with a weapon or gathering in crowds to injure someone with a weapon and incite trouble” 執持凶器傷人及聚眾執持凶器傷人滋事
[^3]: 3. 02: “A concubine kills the principal wife accidentally” 妾過失殺正妻 [DLCY 36:929]
[^4]: 4. 02: “Injuring senior relatives of the third to fifth degrees in an assault, when they die within and without the number of days [within which their death counts as a homicide]” 颱傷功緦尊長尊屬餘限內外身死 [DLCY 36: 932] Art. 318: “Assaults on superior or elder relatives of the second degree of mourning” 駁期親尊長 [DLCY 37: 943; Jones 1994: 303-4]
[^5]: 5. 02: “The amount of silver [needed] for redeeming a sentence of strangulation for accidental killing” 過失殺人絞罪收贖銀數
[^6]: 6. 02: “When an adoptive son transgresses against adoptive parents and the parents or paternal grand-parents of the adoptive parents, as well as the second-degree senior relatives and maternal grand-parents of the adoptive parents” 義子於義父母及義父之祖父母父母義父之期尊及外祖父母等相犯 [DLCY 37: 950-51]
[^7]: 7. 03: “When a superior or senior relative from the same paternal clan or with affinal ties kills three persons who have not been sentenced to death (including master, servants and hired laborers) from the family of an inferior or younger relative within the mourning relations” 本宗及外姻尊長殺有服卑幼一家主僕顧工非死罪三人 [DLCY 33: 816] Art. 290: Killing in an affray or in an assault, and intentional killing 鬪毆及故殺人 [DLCY 33: 829-30; Jones 1994: 276] Art. 292: Killing or injuring in play, by mistake, or accidentally 戲殺誤殺過失殺傷人 [DLCY 34: 849; Jones 1994: 278-79]
[^8]: 8. 03: “When illicit sex leads to the suicide of one’s husband or parents” 因姦致夫或父母羞忍自盡
[^9]: 9. 05: “When a junior relative mistakenly injures a senior relative, leading to their death, and when the sentence is immediate decapitation, but the investigation [finds] that the crime was not committed out of cruelty”卑幼誤傷尊長至死 罪干斬決 審非逞兇干犯 [DLCY 36: 945] Art. 319: Assaults on one's parents or paternal grand-parents 颛祖父母父母 [DLCY 37: 949-50; Jones 1994: 304-5]
[^10]: 10. Art. 317: Assaults on senior relatives of the third degree of mourning and lower 駁大功以下尊長 [DLCY 36: 930-31; Jones 1994: 301-2]
